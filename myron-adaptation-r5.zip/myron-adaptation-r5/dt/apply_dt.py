#!/usr/bin/env python3
"""Apply the reviewed Myron DT changes after the r1 prepare step."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def apply(workspace):
    manifest = json.loads((HERE / "dt-manifest.json").read_text())
    dt = workspace / "vendor/qcom/sm8850-devicetrees"
    head = subprocess.check_output(["git", "-C", str(dt), "rev-parse", "HEAD"], text=True).strip()
    if head != manifest["revision"]:
        raise ValueError("DT revision does not match the r5 source lock")
    provider = manifest["provider_source"]
    if digest(dt / provider["path"]) != provider["sha256"]:
        raise ValueError("Upstream audio provider source differs from the reviewed source")
    pending, records = [], []
    for item in manifest["files"]:
        target, payload = dt / item["path"], HERE / item["payload"]
        if digest(payload) != item["after_sha256"]:
            raise ValueError("DT payload checksum mismatch: " + item["payload"])
        current = digest(target) if target.is_file() else None
        if current not in (item["before_sha256"], item["after_sha256"]):
            raise ValueError("Unexpected DT contents: " + item["path"])
        pending.append((target, payload.read_bytes()))
        records.append({"path": item["path"], "before_sha256": current,
                        "after_sha256": item["after_sha256"]})
    # Check every preimage before writing any file.
    for target, data in pending:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    subprocess.run(["git", "-C", str(dt), "diff", "--check"], check=True)
    reports = workspace / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    result = {"schema": 1, "revision": head, "files": records, "flashable": False,
              "note": "DT dependency and audio-provider repair; no partition packaging or hardware validation."}
    (reports / "myron-dt-r5-apply.json").write_text(json.dumps(result, indent=2) + "\n")
    print("Myron r5 DT repair applied; compiled merge validation is still required.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args()
    apply(args.workspace.resolve())
