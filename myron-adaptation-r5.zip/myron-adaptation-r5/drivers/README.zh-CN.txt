Myron r5: hwid 机型识别适配与 miev 构建基线

范围
延续第 9 轮已成功生成的 hwid.ko / miev.ko；本轮修正 hwid 的机型识别和依赖。
这不是已验证的原厂模块替代包，不能据此替换手机分区或混用旧 KMI 5 模块。

来源
unmoved21/android_kernel_xiaomi_onyx
commit: 8276ba954d8076303a5ae0f7b15d4092d66bdff6
完整原文件放在 upstream/；source-lock.json 同时固定 Git blob SHA1、SHA256、字节数。
其中 hwid 保留 Xiaomi/LineageOS GPL-2.0 声明；miev 保留 GPL 模块许可证与原作者声明。
代码不是 return 0 的占位实现：hwid 读模块参数并解析位域，miev 实现事件链表、格式化、字符设备和 FIFO。

接入
1. 对固定 SoC 提交执行原 r1 prepare_workspace.py。
2. python3 myron-adaptation-r5/drivers/apply_drivers.py --workspace "$WORKSPACE_DIR"
3. 使用原同一构建目标、配置完成 soc 或 full 构建。
4. python3 myron-adaptation-r5/drivers/validate_drivers.py --workspace "$WORKSPACE_DIR" --stage full

安装器验证所有源与 r1 后置文件后才改写；同一 r5 内容允许重复，未知内容拒绝。
只给 canoe_perf 增加 CONFIG_MI_HARDWARE_ID=m、CONFIG_MIEV=m；新模块注册在 r1 的 Myron modules.bzl。
MIEV 头文件作为 DDK srcs 显式声明并通过已有 include/**/*.h 导出；后续使用这些函数的驱动仍需声明模块依赖。
hwid.h 仅安装在本模块目录，未作为通用 Myron 项目编号头文件导出。

相对来源的 miev 修正
- 去掉跨事件共享的 JSON 长度状态，保留原始公开结构体布局与五个导出函数签名。
- 格式串限制在 4096 字节并正确预留结尾 NUL；转义引号、反斜线和控制字符。
- 空输入、分配失败、过长事件和传输失败返回错误，不越界写入。
- 初始化 FIFO、锁、等待队列和暂存内存后才注册字符设备。
- 验证 FIFO 长度前缀；短读取缓冲区返回 -EMSGSIZE 并保留记录，复制失败不消费记录。
- 去掉重复手工模块引用和锁外共享缓冲区调试输出。
原版文件仍保留在 upstream/，便于审核差异。以上行为变化需要真实内核与 MiSight 用户态验证。

hwid 本轮变化与依据
来自同一公开 Onyx 基础的数值 getter 保持不变，保留原始文件于 upstream/。
删除原厂没有的 project_name 参数；保留 project/hwid_value/build_adc/project_adc 四个 uint/0444 参数。
product_name_get() 调用真实 socinfo_get_id()，仅在 SoC ID 660 时按已验证表返回：
1 popsicle、2 pudding、3 pandora、4 myron、5 nezha、6 pecan、7 pixiu。
其它 SoC、未知项目、缺失参数均返回 unknown，不猜测当前设备，也不硬编码某台手机的 ADC。
上述表来自已采集原厂 hwid.ko 的分支、重定位及字符串表交叉检查。
已有 live FDT 的 bootargs 包含四个参数而不含 project_name；SoC 运行值尚未实测。
私有于本模块的头文件移除 O 系列常量，使用明确标有 660 的语义名；不伪造 P 系列编号。
DDK 显式声明 socinfo.h 输入和 socinfo 依赖，Kconfig 依赖 QCOM_SOCINFO。

sysfs 边界
本轮不增加持久 /sys/hwid 节点。原厂 ELF 及公开 MiCode 旧实现均在 sysfs group
创建成功后落入 kobject_del；当前没有真机路径采样，不能把持久节点当成已验证原厂契约。
四项属性的名称/模式/格式和生命周期证据记录于 evidence/stock-hwid-contract.json。
其它 SoC 的产品表也不属于此 Myron 候选实现的支持范围。

源码与证据
Onyx 原始来源继续由 source-lock.json 锁定；payload 中修改保留 GPL-2.0 声明。
evidence/public-reference-provenance.json 固定 MiCode Vili 与 LineageOS SM8550 的公开参考提交。
未拿到完整的官方 SM8850/Myron hwid 源；此处是基于已有 GPL 实现和原厂可观察接口的适配。
原厂 ELF 本体不打包、不用于链接，仅保留契约和 SHA256。

门禁
validate_drivers.py 从本轮 artifact-manifest.json 定位并校验产物哈希：
- 两个模块各唯一、ELF 为 AArch64、名称正确且具有 MODVERSIONS；
- 导出符号集精确为 hwid 的 9 项、miev 的 5 项；
- 所有强导入均有 CRC，逐项等于本轮同源 Module.symvers 中唯一的 CRC；
- 两个新模块 vermagic 一致；hwid 必须真实导入 socinfo_get_id、依赖 socinfo，且恰好四个 uint 参数。
DT 构建目标的重复 Module.symvers 不参与驱动 CRC 门禁。
结果写 integration-reports/<stage>-r5-driver-contracts.json，始终 flashable=false。

验证边界
本地对实际 mievent.c 用 host shim 运行 ASan/UBSan，覆盖空事件、交错事件、
LONG_MIN、引号/控制字符转义、过长事件、分配失败、写失败保留事件和释放计数。
本环境 LeakSanitizer 无法访问 /proc task，运行时禁用 LSan；shim 独立检查分配/释放总数为 0。
这不是内核编译或实机测试；最终 DDK 编译和新增模块 CRC 验证由本轮 CI 执行。

第 8 轮构建后的 Kconfig 修复
-------------------------
修正 hwid/miev 两个 source 引用，加入 $(KCONFIG_EXT_PREFIX)。
高通 flattener 从工作区根目录运行，原先的裸 drivers/misc 路径解析错误。
增加编译前实际配置展开检查，确认两个 config 各出现一次，再启动 Bazel。
该检查复用固定源码脚本，不改变内核配置选项或模块实现。

hwid 主机验证
编译前运行 tests/hwid/run_hwid.sh，直接编译 payload C 并用 UBSan 检查机型映射、
未知/零/最大值、原厂采样 getter 和位域边界。源码适配准备时已用 ASan/UBSan 验证。
这是纯逻辑检查，不能代替内核模块加载、socinfo ready 时序或完整手机行为验证。
