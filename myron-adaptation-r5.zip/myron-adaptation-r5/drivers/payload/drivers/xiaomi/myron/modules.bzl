# SPDX-License-Identifier: GPL-2.0-only
# Myron experimental source modules. Loaded in the SoC root Bazel package.
def register_modules(registry):
    registry.register(
        name = "drivers/input/fingerprint/mi_fp",
        out = "mi_fp.ko",
        config = "CONFIG_FINGERPRINT_MI_FP",
        srcs = [
            "drivers/input/fingerprint/mi_fp/fp_driver.c",
            "drivers/input/fingerprint/mi_fp/fp_platform.c",
            "drivers/input/fingerprint/mi_fp/fp_netlink.c",
            "drivers/input/fingerprint/mi_fp/fp_input.c",
            "drivers/input/fingerprint/mi_fp/fp_driver.h",
            "drivers/input/fingerprint/mi_fp/fp_ultra.h",
        ],
        deps = ["drivers/soc/qcom/panel_event_notifier"],
    )
    registry.register(
        name = "drivers/xiaomi/mi_stack",
        out = "mi_stack.ko",
        config = "CONFIG_MI_STACK",
        srcs = ["drivers/xiaomi/mi_stack/mi_stack.c"],
    )
    registry.register(
        name = "drivers/xiaomi/mi_ubt",
        out = "mi_ubt.ko",
        config = "CONFIG_MI_UBT",
        srcs = ["drivers/xiaomi/mi_ubt/mi_ubt.c"],
    )
    registry.register(
        name = "drivers/xiaomi/printk_enhance",
        out = "printk_enhance.ko",
        config = "CONFIG_PRINTK_ENHANCE",
        srcs = ["drivers/xiaomi/printk_enhance/printk_enhance.c"],
    )
    registry.register(
        name = "drivers/misc/hwid/hwid",
        out = "hwid.ko",
        config = "CONFIG_MI_HARDWARE_ID",
        srcs = [
            "drivers/misc/hwid/hwid.c",
            "drivers/misc/hwid/hwid.h",
            "include/soc/qcom/socinfo.h",
        ],
        includes = ["include"],
        deps = ["drivers/soc/qcom/socinfo"],
    )
    registry.register(
        name = "drivers/misc/miev/miev",
        out = "miev.ko",
        config = "CONFIG_MIEV",
        srcs = [
            "drivers/misc/miev/midevice.c",
            "drivers/misc/miev/midevice.h",
            "drivers/misc/miev/mievent.c",
            "include/miev/mievent.h",
        ],
        includes = ["include"],
    )
