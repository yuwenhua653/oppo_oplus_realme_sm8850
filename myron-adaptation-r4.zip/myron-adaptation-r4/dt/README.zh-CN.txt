Myron DT r4：补齐设备树组合与实际合并检查

适用版本
DT 固定为 lolipuru/android_kernel_xiaomi_sm8850-devicetrees
8b86fedda64183338411f9751f5e62ce25997620。
必须在 r1 prepare_workspace.py 和现有 DT collection fix2 完成后应用。
qcom/platform_map.bzl 的应用前 SHA256 为
33a50ccf84bfeb9bb5387322be4c866dda238a9bb58cf4efefdd9e0f088dd357。

本轮修改
1. 让 Kleaf 收集 canoe-audio.dtbo、canoe-camera-v2.dtbo、canoe-sde.dtbo。
   采用唯一文件名，沿用现有工作流的递归查找约定。
2. 给 Myron 现有的两个 WSA pinctrl 节点补 wsa_spkr_en02/13 标签别名。
   将不存在的 wsa_spkr_en1/2_active/sleep 改为已有的
   spkr_02/13_sd_n_active/sleep；两个节点继续保持 disabled。
3. 仅从同一固定提交的 lpass-cdc-gpio.dtsi 引入五个所缺 provider：
   wcd939x_rst_gpio、cdc_dmic01/23/45/67_gpios。
   使用已核对的 Myron 状态：codec reset、DMIC67 为 disabled；其他为 ok。
   不引入整个通用 MTP 音频配置，也不添加其 WSA 硬件启用策略。

检查接口
python3 apply_dt.py --workspace WORKSPACE
随后再次运行现有 check-myron-dt-wiring.py，检查 GNU make 输出与 Kleaf 唯一查找。
编译和产物收集完成后：
python3 validate_dt.py --workspace WORKSPACE --stage full
dtbs 阶段同样会执行真实合并，analyze/soc 阶段记录不适用。

合并顺序
canoe-v2.dtb
canoe-audio.dtbo
canoe-camera-v2.dtbo
canoe-sde.dtbo
myron-sm8850-overlay.dtbo
myron-audio-mtp.dtbo
myron-sm8850-camera-sensor.dtbo
myron-sde-display-mtp-overlay.dtbo

门禁从已收集的 artifact-manifest.json 选择唯一输入并核验 SHA256，
从工作区固定且未修改的 external/dtc 源码构建 fdtoverlay/fdtget。
逐个应用上述七个 overlay；任何 libfdt 错误都会使任务失败。
最终检查七个 provider 的状态、compatible 与十四组 pinctrl 实际引用。
报告位于 integration-reports/{stage}-r4-dt-merge.json。
中间合并 DTB 仅保存在诊断报告目录。

本地证据
local-validation.json 记录真实负对照和修复后的成功合并。
本地工具为 Android DTC 1.4.2 与上游 libfdt 1.7.2，并非 CI 的精确工具版本；
CI 会针对本轮实际编译产物重跑门禁。源码、工具版本和 SHA256 均列入证据。
本地固定的两个通用 IRQ 头来自 Linux v6.12；SoC、音频、相机头来自锁定源码。

范围限制
合并成功只证明这个开发组合可以解析、重定位并应用，以及所列音频引用成立。
它不证明全部硬件参数与原厂一致，也没有定义 OEM dtbo.img 表、vendor_boot
布局或启动器实际合并过程。显示指令、MCA 充电配置、WLAN 内存保留区、模块
覆盖和实机运行仍须继续适配。所有报告保留 flashable=false；本轮不生成刷机包。
