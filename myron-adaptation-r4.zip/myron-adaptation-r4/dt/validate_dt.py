#!/usr/bin/env python3
"""Require a real libfdt merge of the compiled Myron development DT inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

DT_REVISION = "8b86fedda64183338411f9751f5e62ce25997620"
DTC_REVISION = "edd020ac81db8c68a7dfd38d5993001aeadedd5e"
INPUTS = [
    "canoe-v2.dtb", "canoe-audio.dtbo", "canoe-camera-v2.dtbo", "canoe-sde.dtbo",
    "myron-sm8850-overlay.dtbo", "myron-audio-mtp.dtbo",
    "myron-sm8850-camera-sensor.dtbo", "myron-sde-display-mtp-overlay.dtbo",
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_tools(workspace, cache):
    src = workspace / "external/dtc"
    head = subprocess.check_output(["git", "-C", str(src), "rev-parse", "HEAD"], text=True).strip()
    if head != DTC_REVISION:
        raise ValueError("Unexpected libfdt source revision")
    dirty = subprocess.check_output(["git", "-C", str(src), "status", "--porcelain", "--untracked-files=no"], text=True)
    if dirty.strip():
        raise ValueError("Tracked external/dtc source has local changes")
    cache.mkdir(parents=True, exist_ok=True)
    (cache / "version_gen.h").write_text('#define DTC_VERSION "DTC external/dtc ' + head + '"\n')
    lib_sources = sorted((src / "libfdt").glob("*.c"))
    if not (src / "libfdt/fdt_overlay.c").is_file():
        raise ValueError("Pinned libfdt overlay implementation is absent")
    sources = lib_sources + [src / "util.c", src / "fdtoverlay.c", src / "fdtget.c"]
    for name in ("fdtoverlay", "fdtget"):
        command = ["gcc", "-O2", "-I", str(cache), "-I", str(src), "-I", str(src / "libfdt"),
                   str(src / (name + ".c")), str(src / "util.c"), *map(str, lib_sources),
                   "-o", str(cache / name)]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (cache / (name + "-build.log")).write_text(result.stdout)
        if result.returncode:
            raise RuntimeError("Cannot build " + name + "; see " + str(cache / (name + "-build.log")))
    return {"revision": head,
            "sources": {str(p.relative_to(src)): sha(p) for p in sources},
            "binaries": {name: sha(cache / name) for name in ("fdtoverlay", "fdtget")}}


def select_inputs(stage_dir):
    manifest = json.loads((stage_dir / "artifact-manifest.json").read_text())
    if manifest.get("flashable") is not False:
        raise ValueError("Input artifact manifest must remain explicitly non-flashable")
    selected = []
    for name in INPUTS:
        items = [item for item in manifest["files"] if Path(item["file"]).name == name]
        if len(items) != 1:
            raise ValueError("Expected one collected DT input: " + name)
        item = items[0]
        rel = Path(item["file"])
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unsafe artifact path")
        path = (stage_dir / rel).resolve()
        if not path.is_relative_to(stage_dir.resolve()) or not path.is_file():
            raise ValueError("DT artifact escapes its stage or is absent: " + name)
        if sha(path) != item["sha256"]:
            raise ValueError("DT artifact checksum differs from manifest: " + name)
        selected.append(path)
    return selected


def get(tool, blob, path, prop, kind="s"):
    return subprocess.check_output([str(tool), "-t", kind, str(blob), path, prop], text=True).strip().split()


def assert_audio_contract(tool, blob):
    expected = {"wsa_spkr_en02": "disabled", "wsa_spkr_en13": "disabled",
                "wcd939x_rst_gpio": "disabled", "cdc_dmic01_gpios": "ok",
                "cdc_dmic23_gpios": "ok", "cdc_dmic45_gpios": "ok", "cdc_dmic67_gpios": "disabled"}
    nodes = {}
    for label, status in expected.items():
        paths = get(tool, blob, "/__symbols__", label)
        if len(paths) != 1:
            raise ValueError("Invalid provider symbol: " + label)
        path = paths[0]
        if get(tool, blob, path, "status") != [status]:
            raise ValueError("Unexpected audio provider status: " + label)
        if get(tool, blob, path, "compatible") != ["qcom,msm-cdc-pinctrl"]:
            raise ValueError("Unexpected audio provider compatible: " + label)
        nodes[label] = {"path": path, "status": status}
    pins = {"wsa_spkr_en02": ["spkr_02_sd_n"], "wsa_spkr_en13": ["spkr_13_sd_n"],
            "wcd939x_rst_gpio": ["wcd939x_reset"],
            "cdc_dmic01_gpios": ["lpi_dmic0_clk", "lpi_dmic0_data"],
            "cdc_dmic23_gpios": ["lpi_dmic1_clk", "lpi_dmic1_data"],
            "cdc_dmic45_gpios": ["lpi_dmic2_clk", "lpi_dmic2_data"],
            "cdc_dmic67_gpios": ["lpi_dmic3_clk", "lpi_dmic3_data"]}
    for label, pin_labels in pins.items():
        for index, state in ((0, "active"), (1, "sleep")):
            targets = [get(tool, blob, "/__symbols__", pin + "_" + state)[0] for pin in pin_labels]
            phandles = [get(tool, blob, target, "phandle", "x")[0] for target in targets]
            if get(tool, blob, nodes[label]["path"], "pinctrl-" + str(index), "x") != phandles:
                raise ValueError("Audio provider pinctrl does not refer to the reviewed pins: " + label)
            nodes[label]["pinctrl-" + str(index)] = targets
    return nodes


def merge_and_check(inputs, tool_dir, output_dir, report):
    output_dir.mkdir(parents=True, exist_ok=True)
    current = inputs[0]
    report["inputs"] = [{"name": p.name, "sha256": sha(p), "bytes": p.stat().st_size} for p in inputs]
    report["steps"] = []
    for index, overlay in enumerate(inputs[1:], 1):
        target = output_dir / (f"{index:02d}-" + overlay.stem + ".dtb")
        command = [str(tool_dir / "fdtoverlay"), "-i", str(current), "-o", str(target), str(overlay)]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        record = {"overlay": overlay.name, "returncode": result.returncode, "log": result.stdout}
        report["steps"].append(record)
        if result.returncode:
            raise RuntimeError("libfdt failed on " + overlay.name + ": " + result.stdout.strip())
        record["result_sha256"] = sha(target)
        current = target
    report["audio_providers"] = assert_audio_contract(tool_dir / "fdtget", current)
    report["merged_sha256"] = sha(current)
    report["merged_file"] = str(current)
    report["merge_passed"] = True


def validate(workspace, stage):
    reports = workspace / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    report = {"schema": 1, "stage": stage, "success": False, "merge_passed": False,
              "flashable": False, "hardware_tested": False,
              "scope": "Source diagnostic composition: Canoe v2 + 3 SoC overlays + 4 Myron overlays",
              "limits": ["Does not reproduce OEM DTBO table or vendor_boot layout",
                         "Display command tables, charging, WLAN reservations and driver coverage remain unverified"]}
    try:
        if stage not in ("full", "dtbs"):
            report.update(success=True, skipped=True, reason="This stage does not compile DT outputs")
            return
        dt = workspace / "vendor/qcom/sm8850-devicetrees"
        head = subprocess.check_output(["git", "-C", str(dt), "rev-parse", "HEAD"], text=True).strip()
        if head != DT_REVISION:
            raise ValueError("Unexpected DT revision during merge validation")
        tool_dir = workspace / "integration-cache/myron-r4-dt-tools"
        report["tool_provenance"] = build_tools(workspace, tool_dir)
        inputs = select_inputs(workspace / "integration-artifacts" / stage)
        merge_and_check(inputs, tool_dir, reports / ("myron-r4-dt-merge-" + stage), report)
        report["success"] = True
        print("Myron r4 actual libfdt merge and audio-provider contract: PASS (not flashable).")
    except Exception as error:
        report["error"] = str(error)
        raise
    finally:
        (reports / (stage + "-r4-dt-merge.json")).write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--stage", choices=("analyze", "soc", "dtbs", "full"), required=True)
    args = parser.parse_args()
    validate(args.workspace.resolve(), args.stage)
