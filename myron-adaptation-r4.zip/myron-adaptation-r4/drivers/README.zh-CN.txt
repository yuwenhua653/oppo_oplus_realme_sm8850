Myron r4: hwid + miev 源码编译候选

范围
接入源码支持的基础模块，使下一轮 QCOM/ACK 同源构建产出 hwid.ko 和 miev.ko。
这不是已验证的原厂模块替代包，不能据此替换手机分区或混用旧 KMI 5 模块。

来源
unmoved21/android_kernel_xiaomi_onyx
commit: 8276ba954d8076303a5ae0f7b15d4092d66bdff6
完整原文件放在 upstream/；source-lock.json 同时固定 Git blob SHA1、SHA256、字节数。
其中 hwid 保留 Xiaomi/LineageOS GPL-2.0 声明；miev 保留 GPL 模块许可证与原作者声明。
代码不是 return 0 的占位实现：hwid 读模块参数并解析位域，miev 实现事件链表、格式化、字符设备和 FIFO。

接入
1. 对固定 SoC 提交执行原 r1 prepare_workspace.py。
2. python3 myron-adaptation-r4/drivers/apply_drivers.py --workspace "$WORKSPACE_DIR"
3. 使用原同一构建目标、配置完成 soc 或 full 构建。
4. python3 myron-adaptation-r4/drivers/validate_drivers.py --workspace "$WORKSPACE_DIR" --stage full

安装器验证所有源与 r1 后置文件后才改写；同一 r4 内容允许重复，未知内容拒绝。
只给 canoe_perf 增加 CONFIG_MI_HARDWARE_ID=m、CONFIG_MIEV=m；新模块注册在 r1 的 Myron modules.bzl。
MIEV 头文件作为 DDK srcs 显式声明并通过已有 include/**/*.h 导出；后续使用这些函数的驱动仍需声明模块依赖。
hwid.h 仅安装在本模块目录，未作为通用 Myron 项目编号头文件导出。

相对来源的 miev 修正
- 去掉跨事件共享的 JSON 长度状态，保留原始公开结构体布局与五个导出函数签名。
- 格式串限制在 4096 字节并正确预留结尾 NUL；转义引号、反斜线和控制字符。
- 空输入、分配失败、过长事件和传输失败返回错误，不越界写入。
- 初始化 FIFO、锁、等待队列和暂存内存后才注册字符设备。
- 验证 FIFO 长度前缀；短读取缓冲区返回 -EMSGSIZE 并保留记录，复制失败不消费记录。
- 去掉重复手工模块引用和锁外共享缓冲区调试输出。
原版文件仍保留在 upstream/，便于审核差异。以上行为变化需要真实内核与 MiSight 用户态验证。

已知 hwid 差异（后续适配项）
本机原模块依赖 socinfo_get_id，并含 hwid 的 sysfs 属性；Onyx 代码没有这些路径。
候选 product_name_get() 直接返回 project_name 模块参数，默认是空字符串；不能假定手机自动传入该参数。
原始头文件中的 O 系列项目常量也不是 Myron P 系列项目定义。
因此“9 个导出函数存在”仅表示接口名称覆盖，不能证明硬件识别行为、参数来源或 ABI 与原厂相同。
下一阶段需从公开 Xiaomi 代码补齐 Myron 项目映射与属性契约，并核对实际启动参数。

门禁
validate_drivers.py 从本轮 artifact-manifest.json 定位并校验产物哈希：
- 两个模块各唯一、ELF 为 AArch64、名称正确且具有 MODVERSIONS；
- 导出符号集精确为 hwid 的 9 项、miev 的 5 项；
- 所有强导入均有 CRC，逐项等于本轮同源 Module.symvers 中唯一的 CRC；
- 两个新模块 vermagic 一致。
DT 构建目标的重复 Module.symvers 不参与驱动 CRC 门禁。
结果写 integration-reports/<stage>-r4-driver-contracts.json，始终 flashable=false。

验证边界
本地对实际 mievent.c 用 host shim 运行 ASan/UBSan，覆盖空事件、交错事件、
LONG_MIN、引号/控制字符转义、过长事件、分配失败、写失败保留事件和释放计数。
本环境 LeakSanitizer 无法访问 /proc task，运行时禁用 LSan；shim 独立检查分配/释放总数为 0。
这不是内核编译或实机测试；最终 DDK 编译和新增模块 CRC 验证由本轮 CI 执行。

第 8 轮构建后的 Kconfig 修复
-------------------------
修正 hwid/miev 两个 source 引用，加入 $(KCONFIG_EXT_PREFIX)。
高通 flattener 从工作区根目录运行，原先的裸 drivers/misc 路径解析错误。
增加编译前实际配置展开检查，确认两个 config 各出现一次，再启动 Bazel。
该检查复用固定源码脚本，不改变内核配置选项或模块实现。
