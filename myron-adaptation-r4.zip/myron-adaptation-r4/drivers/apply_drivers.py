#!/usr/bin/env python3
"""Install pinned foundation driver candidates AFTER the r1 source integration."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe(root, rel):
    parts = PurePosixPath(rel)
    if parts.is_absolute() or any(x in ("", ".", "..") for x in parts.parts):
        raise ValueError("unsafe path: " + rel)
    result = (root / rel).resolve()
    if not result.is_relative_to(root.resolve()):
        raise ValueError("path escapes root: " + rel)
    return result


def validate_inputs(soc, lock):
    head = subprocess.check_output(["git", "-C", str(soc), "rev-parse", "HEAD"], text=True).strip()
    if head != lock["soc_commit"]:
        raise ValueError("wrong SoC HEAD: " + head)
    for item in lock["sources"]:
        raw = safe(HERE, item["payload"]).read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if len(raw) != item["bytes"] or sha(raw) != item["sha256"] or blob != item["git_blob_sha1"]:
            raise ValueError("upstream source verification failed: " + item["source_path"])
    planned = []
    seen = set()
    for item in lock["writes"]:
        rel = item["path"]
        if rel in seen:
            raise ValueError("duplicate destination: " + rel)
        seen.add(rel)
        data = safe(HERE, item["payload"]).read_bytes()
        if sha(data) != item["sha256"]:
            raise ValueError("integration payload verification failed: " + rel)
        target = safe(soc, rel)
        current = sha(target.read_bytes()) if target.exists() else None
        if current not in {item["before_sha256"], item["sha256"]}:
            raise ValueError("expected r1 postimage or exact r4 repeat: " + rel)
        planned.append((target, data, {"path": rel, "before_sha256": current,
                        "after_sha256": item["sha256"], "changed": current != item["sha256"]}))
    return head, planned


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    root = args.workspace.resolve()
    soc = root / "vendor/qcom/sm8850"
    lock = json.loads((HERE / "source-lock.json").read_text())
    head, planned = validate_inputs(soc, lock)
    if not args.check:
        for target, data, audit in planned:
            if audit["changed"]:
                target.parent.mkdir(parents=True, exist_ok=True)
                temp = target.with_name(target.name + ".myron-r4-tmp")
                with temp.open("xb") as stream:
                    stream.write(data)
                temp.replace(target)
    result = {"schema": 1, "success": True, "mode": "check" if args.check else "applied", "soc_commit": head,
              "source_repository": lock["repository"], "source_commit": lock["commit"],
              "outputs": ["hwid.ko", "miev.ko"], "files": [x[2] for x in planned],
              "flashable": False, "runtime_equivalent_to_stock": False,
              "limitations": ["hwid candidate has module parameters and nine exports, but lacks stock socinfo-derived product-name mapping and hwid sysfs attributes",
                              "Onyx project constants are not Myron project definitions",
                              "miev bounded formatting and FIFO fixes require kernel/userspace runtime validation",
                              "all consumers must be source-rebuilt against the same new kernel; old modules are not ABI-compatible"]}
    report = root / "integration-reports/myron-r4-driver-integration.json"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"mode": result["mode"], "files": len(planned), "outputs": result["outputs"], "report": str(report)}))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        sys.exit(1)
