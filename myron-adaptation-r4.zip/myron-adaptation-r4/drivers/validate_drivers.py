#!/usr/bin/env python3
"""Gate the two new source candidates on same-build exports, imports and CRCs."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import struct
import sys

HERE = Path(__file__).resolve().parent


def elf(data):
    if data[:6] != b'\x7fELF\x02\x01' or struct.unpack_from('<H', data, 18)[0] != 183:
        raise ValueError('expected little-endian AArch64 ELF64 module')
    shoff = struct.unpack_from('<Q', data, 40)[0]
    entsize, count, stridx = struct.unpack_from('<HHH', data, 58)
    if entsize != 64 or not count or stridx >= count or shoff + count * entsize > len(data):
        raise ValueError('invalid ELF section table')
    headers = [struct.unpack_from('<IIQQQQIIQQ', data, shoff + i * entsize) for i in range(count)]
    def section(header):
        offset, size = header[4:6]
        if offset + size > len(data):
            raise ValueError('ELF section outside file')
        return data[offset:offset + size]
    def string(blob, off):
        if off >= len(blob):
            raise ValueError('ELF string outside table')
        return blob[off:blob.index(b'\0', off)].decode()
    names = section(headers[stridx])
    by_name = {string(names, h[0]): h for h in headers}
    def get(name):
        return section(by_name[name]) if name in by_name else b''
    info = {}
    for raw in get('.modinfo').split(b'\0'):
        if b'=' in raw:
            key, val = raw.decode().split('=', 1)
            info.setdefault(key, []).append(val)
    versions = {}
    raw = get('__versions')
    if len(raw) % 64:
        raise ValueError('invalid __versions length')
    for offset in range(0, len(raw), 64):
        versions[raw[offset+8:offset+64].split(b'\0')[0].decode()] = struct.unpack_from('<Q', raw, offset)[0]
    raw_names, raw_crcs = get('__version_ext_names'), get('__version_ext_crcs')
    if raw_names or raw_crcs:
        ext_names = raw_names.rstrip(b'\0').split(b'\0')
        if len(raw_crcs) != 4 * len(ext_names):
            raise ValueError('invalid extended modversion lengths')
        for i, name in enumerate(ext_names):
            versions[name.decode()] = struct.unpack_from('<I', raw_crcs, i * 4)[0]
    exports, imports = set(), set()
    for h in headers:
        if h[1] != 2:  # SHT_SYMTAB
            continue
        if h[6] >= len(headers) or h[9] != 24:
            raise ValueError('invalid symbol table')
        strings = section(headers[h[6]])
        table = section(h)
        if len(table) % 24:
            raise ValueError('invalid symbol table length')
        for offset in range(0, len(table), 24):
            name, binding, _, index, _, _ = struct.unpack_from('<IBBHQQ', table, offset)
            text = string(strings, name)
            if index and text.startswith('__ksymtab_'):
                exports.add(text.removeprefix('__ksymtab_'))
            elif not index and binding >> 4 == 1 and text:
                imports.add(text)
    return {'info': info, 'exports': exports, 'imports': imports, 'versions': versions}


def run(workspace, stage):
    dest = workspace / 'integration-artifacts' / stage
    manifest = json.loads((dest / 'artifact-manifest.json').read_text())
    lock = json.loads((HERE / 'source-lock.json').read_text())
    if manifest.get('stage') != stage or manifest.get('flashable') is not False:
        raise ValueError('unexpected diagnostic artifact manifest')
    modules = collections.defaultdict(list)
    symvers = []
    for item in manifest['files']:
        rel = Path(item['file'])
        path = (dest / rel).resolve()
        if rel.is_absolute() or '..' in rel.parts or not path.is_relative_to(dest.resolve()):
            raise ValueError('unsafe artifact manifest path')
        if path.suffix == '.ko':
            modules[path.stem].append((path, item))
        if path.suffix == '.symvers' and '/canoe_perf_dtb_build/' not in path.as_posix():
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != item['sha256']:
                raise ValueError('symvers hash mismatch: ' + str(path))
            symvers.append(data)
    if not symvers:
        raise ValueError('no same-build Module.symvers inputs')
    providers = collections.defaultdict(set)
    for data in symvers:
        for line in data.decode().splitlines():
            fields = line.split()
            if len(fields) >= 3:
                providers[fields[1]].add(int(fields[0], 16))
    reports, vermagics = [], set()
    for name, expected in lock['exports'].items():
        if len(modules[name]) != 1:
            raise ValueError('expected exactly one new module: ' + name)
        path, item = modules[name][0]
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('module hash mismatch: ' + name)
        parsed = elf(data)
        if parsed['info'].get('name') != [name] or len(parsed['info'].get('vermagic', [])) != 1:
            raise ValueError('unexpected module name or vermagic: ' + name)
        vermagic = parsed['info']['vermagic'][0]
        if 'modversions' not in vermagic or 'module_layout' not in parsed['versions']:
            raise ValueError('MODVERSIONS metadata missing: ' + name)
        vermagics.add(vermagic)
        if parsed['exports'] != set(expected):
            raise ValueError('export set mismatch: ' + name + ': ' + str(sorted(parsed['exports'])))
        missing_versions = parsed['imports'] - parsed['versions'].keys()
        if missing_versions:
            raise ValueError('imports without CRC: ' + name + ': ' + ','.join(sorted(missing_versions)))
        bad = []
        for symbol, crc in parsed['versions'].items():
            if providers.get(symbol) != {crc}:
                bad.append({'symbol': symbol, 'import_crc': hex(crc), 'provider_crcs': sorted(map(hex, providers.get(symbol, set())))})
        if bad:
            raise ValueError('same-build import CRC mismatch: ' + name + ': ' + json.dumps(bad))
        reports.append({'name': name, 'file': item['file'], 'sha256': item['sha256'],
                        'vermagic': vermagic, 'exports': sorted(parsed['exports']),
                        'checked_import_crcs': len(parsed['versions']),
                        'depends': parsed['info'].get('depends', []), 'license': parsed['info'].get('license', [])})
    if len(vermagics) != 1:
        raise ValueError('new modules have different vermagic')
    return {'schema': 1, 'passed': True, 'success': True, 'stage': stage, 'same_build_symvers_files': len(symvers),
            'modules': reports, 'flashable': False, 'hardware_tested': False,
            'runtime_equivalent_to_stock': False,
            'scope': 'New hwid/miev source outputs and their import/export contracts. No stock-module CRC rewriting; stock functional equivalence and full device integration remain unproven.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--stage', choices=('soc', 'full'), required=True)
    args = parser.parse_args()
    root = args.workspace.resolve()
    report = root / 'integration-reports' / (args.stage + '-r4-driver-contracts.json')
    report.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = run(root, args.stage)
    except (OSError, ValueError, KeyError, struct.error) as exc:
        report.write_text(json.dumps({'schema': 1, 'passed': False, 'success': False, 'flashable': False, 'error': str(exc)}, indent=2) + '\n')
        raise
    report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'passed': True, 'modules': [x['name'] for x in result['modules']], 'report': str(report)}))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, struct.error) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        sys.exit(1)
