#!/usr/bin/env python3
"""Apply source-only adaptation, or validate outputs from this build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def check_kconfig(root, reports):
    """Run QCOM's actual config flattener with the genrule's cwd/prefix."""
    soc = root / "vendor/qcom/sm8850"
    script = soc / "flatten_kconfig.sh"
    script_bytes = script.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(script_bytes)).encode() + b"\0" + script_bytes).hexdigest()
    if blob != "1be80d05e67db781abb805cb0fe0dd6911969816":
        raise ValueError("Unexpected QCOM Kconfig flattener")
    output = reports / "r4-Kconfig.ext"
    log = reports / "r4-kconfig-preflight.log"
    report = reports / "r4-kconfig-preflight.json"
    prefix = "vendor/qcom/sm8850/"
    state = {"success": False, "source_prefix": prefix, "flattener_git_blob": blob,
             "scope": "QCOM Kconfig expansion before Bazel; not a sandbox or kernel compilation test"}
    try:
        with output.open("wb") as out, log.open("wb") as err:
            result = subprocess.run(["bash", str(script), prefix + "Kconfig.msm"], cwd=root,
                                    env={**os.environ, "KCONFIG_EXT_PREFIX": prefix},
                                    stdout=out, stderr=err, check=False)
        state["returncode"] = result.returncode
        if result.returncode:
            raise RuntimeError("QCOM Kconfig expansion failed; see " + str(log))
        data = output.read_bytes()
        lines = data.decode().splitlines()
        counts = {name: sum(line.strip() == "config " + name for line in lines)
                  for name in ("MI_HARDWARE_ID", "MIEV")}
        state["driver_config_counts"] = counts
        if any(count != 1 for count in counts.values()):
            raise ValueError("Expected each foundation Kconfig exactly once: " + repr(counts))
        state.update(success=True, output_sha256=hashlib.sha256(data).hexdigest())
        print("QCOM Kconfig expansion and hwid/miev declarations: PASS")
    except Exception as error:
        state["error"] = str(error)
        raise
    finally:
        report.write_text(json.dumps(state, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("apply", "validate"))
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--stage", required=True, choices=("analyze", "soc", "dtbs", "full"))
    args = parser.parse_args()
    root = args.workspace.resolve()
    reports = root / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    status_file = reports / (args.stage + "-r4-status.json")
    state = {"adaptation": "myron-r4", "stage": args.stage, "action": args.action,
             "success": False, "flashable": False, "hardware_tested": False}
    try:
        if args.action == "apply":
            scripts = ["dt/apply_dt.py", "drivers/apply_drivers.py"]
        else:
            scripts = []
            if args.stage in ("full", "dtbs"):
                scripts.append("dt/validate_dt.py")
            if args.stage in ("full", "soc"):
                scripts.append("drivers/validate_drivers.py")
        failures = []
        for script in scripts:
            command = [sys.executable, str(HERE / script), "--workspace", str(root)]
            if args.action == "validate":
                command += ["--stage", args.stage]
            result = subprocess.run(command, cwd=root, check=False)
            if result.returncode:
                failures.append({"script": script, "returncode": result.returncode})
                if args.action == "apply":
                    break
        if failures:
            state["failures"] = failures
            raise RuntimeError("Source adaptation or output checks failed: " + ", ".join(x["script"] for x in failures))
        state["success"] = True
        state["validated_scripts"] = scripts if args.action == "validate" else []
        if args.action == "apply":
            check_kconfig(root, reports)
            # Recheck the whole Kbuild/Kleaf output map after adding the three
            # SoC overlays; the earlier r1 preflight saw only the old map.
            subprocess.run([
                sys.executable,
                str(HERE.parent / "myron-qcom-platform-r1/devicetrees/check-myron-dt-wiring.py"),
                str(root / "vendor/qcom/sm8850-devicetrees"),
                "--report", str(reports / "r4-dt-wiring.json"),
            ], check=True)
            # The earlier r1 report is deliberately retained. Capture the final
            # complete tracked diff after both additive source changes too.
            for name, path in (("soc", "vendor/qcom/sm8850"), ("devicetrees", "vendor/qcom/sm8850-devicetrees")):
                subprocess.run(["git", "-C", str(root / path), "diff", "--check"], check=True)
                with (reports / ("r4-" + name + "-integration.diff")).open("wb") as output:
                    subprocess.run(["git", "-C", str(root / path), "diff", "--binary"], stdout=output, check=True)
    except Exception as error:
        state["success"] = False
        state["error"] = str(error)
        print("r4 failed: " + str(error), file=sys.stderr)
    finally:
        status_file.write_text(json.dumps(state, indent=2) + "\n")
        destination = root / "integration-artifacts" / args.stage
        if args.action == "validate" and destination.is_dir():
            for path in reports.glob(args.stage + "-r4-*.json"):
                shutil.copy2(path, destination / path.name)
    return 0 if state["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
