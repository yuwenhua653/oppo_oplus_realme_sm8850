#!/usr/bin/env python3
"""Apply source-only adaptation, or validate outputs from this build."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("apply", "validate"))
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--stage", required=True, choices=("analyze", "soc", "dtbs", "full"))
    args = parser.parse_args()
    root = args.workspace.resolve()
    reports = root / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    status_file = reports / (args.stage + "-r4-status.json")
    state = {"adaptation": "myron-r4", "stage": args.stage, "action": args.action,
             "success": False, "flashable": False, "hardware_tested": False}
    try:
        if args.action == "apply":
            scripts = ["dt/apply_dt.py", "drivers/apply_drivers.py"]
        else:
            scripts = []
            if args.stage in ("full", "dtbs"):
                scripts.append("dt/validate_dt.py")
            if args.stage in ("full", "soc"):
                scripts.append("drivers/validate_drivers.py")
        failures = []
        for script in scripts:
            command = [sys.executable, str(HERE / script), "--workspace", str(root)]
            if args.action == "validate":
                command += ["--stage", args.stage]
            result = subprocess.run(command, cwd=root, check=False)
            if result.returncode:
                failures.append({"script": script, "returncode": result.returncode})
                if args.action == "apply":
                    break
        if failures:
            state["failures"] = failures
            raise RuntimeError("Source adaptation or output checks failed: " + ", ".join(x["script"] for x in failures))
        state["success"] = True
        state["validated_scripts"] = scripts if args.action == "validate" else []
        if args.action == "apply":
            # Recheck the whole Kbuild/Kleaf output map after adding the three
            # SoC overlays; the earlier r1 preflight saw only the old map.
            subprocess.run([
                sys.executable,
                str(HERE.parent / "myron-qcom-platform-r1/devicetrees/check-myron-dt-wiring.py"),
                str(root / "vendor/qcom/sm8850-devicetrees"),
                "--report", str(reports / "r4-dt-wiring.json"),
            ], check=True)
            # The earlier r1 report is deliberately retained. Capture the final
            # complete tracked diff after both additive source changes too.
            for name, path in (("soc", "vendor/qcom/sm8850"), ("devicetrees", "vendor/qcom/sm8850-devicetrees")):
                subprocess.run(["git", "-C", str(root / path), "diff", "--check"], check=True)
                with (reports / ("r4-" + name + "-integration.diff")).open("wb") as output:
                    subprocess.run(["git", "-C", str(root / path), "diff", "--binary"], stdout=output, check=True)
    except Exception as error:
        state["success"] = False
        state["error"] = str(error)
        print("r4 failed: " + str(error), file=sys.stderr)
    finally:
        status_file.write_text(json.dumps(state, indent=2) + "\n")
        destination = root / "integration-artifacts" / args.stage
        if args.action == "validate" and destination.is_dir():
            for path in reports.glob(args.stage + "-r4-*.json"):
                shutil.copy2(path, destination / path.name)
    return 0 if state["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
