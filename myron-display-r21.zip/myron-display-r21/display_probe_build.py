#!/usr/bin/env python3
"""Build and audit one R21 display probe candidate, never a partition image.

The unchanged R18 source bundle supplies preparation, configuration and the
ELF reader. A cold build still compiles the kernel and declared prerequisites.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
DISPLAY = '//vendor/qcom/sm8850-modules/qcom/opensource/display-drivers:canoe_perf_msm_drm'
TARGETS = [DISPLAY, '//common:kernel_aarch64', '//myron_artifact_metadata:kernel_release']
CORE = 'bazel-out/aarch64-fastbuild/bin/common/kernel_aarch64/'
MODULE = ('bazel-out/aarch64-fastbuild/bin/vendor/qcom/sm8850-modules/'
          'qcom/opensource/display-drivers/canoe_perf_msm_drm/msm_drm.ko')
MODULE_SYMVERS = MODULE.rsplit('/', 1)[0] + '/canoe_perf_msm_drm_Module.symvers'
R18_ZIP_SHA = 'a3c7e97e4a28f6574a619bcc10dab8962911ed5fcef8617aeb7fc835bdbe7d13'
EXPECTED = {
    'config_sha256': '1694fba9900e978fb9494250fb5be8515d022b8b52062721b1a2d267f92490c0',
    'core_symvers_sha256': '9d69a48179b0288dbd452dffc061f7754fba09d507fba3086161dfb019c496e3',
    'kernel_release': '6.12.81-android16-6-maybe-dirty-4k',
    'full_vermagic': '6.12.81-android16-6-maybe-dirty-4k SMP preempt mod_unload modversions aarch64',
}
CORE_REQUIRED = {'Image', 'vmlinux.symvers', 'kernel_aarch64_Module.symvers',
                 'kernel_aarch64_dot_config', 'include/config/kernel.release',
                 'modules.builtin', 'modules.builtin.modinfo'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def safe_path(value):
    p = PurePosixPath(value)
    require(value and not p.is_absolute() and '..' not in p.parts
            and '\\' not in value and '\x00' not in value
            and str(p) == value and not any(ord(c) < 32 for c in value),
            'Unsafe declared path: ' + repr(value))
    return p


def verify_bundle():
    lock = json.loads((HERE / 'bundle-lock.json').read_text())
    seen = set()
    for item in lock['files']:
        relative = safe_path(item['path'])
        require(str(relative) not in seen, 'Duplicate bundle entry')
        seen.add(str(relative))
        path = HERE / relative
        require(path.is_file() and path.resolve().is_relative_to(HERE), 'Missing/escaping bundle file')
        data = path.read_bytes()
        require(sha(data) == item['sha256'], 'Bundle hash mismatch: ' + str(relative))
        if 'bytes' in item:
            require(len(data) == item['bytes'], 'Bundle size mismatch')
    require({'display_probe_build.py', 'probe-patch/apply_probe.py',
             'probe-patch/manifest.json', 'baseline/myron-boot-r18.zip'} <= seen,
            'Incomplete R21 bundle lock')
    require(sha((HERE / 'baseline/myron-boot-r18.zip').read_bytes()) == R18_ZIP_SHA,
            'R18 baseline archive changed')
    return sha((HERE / 'bundle-lock.json').read_bytes())


def commands(bazel, options):
    """Exactly the same build configuration must select cquery providers."""
    query = 'deps(set(' + ' '.join(TARGETS) + '))'
    return (list(bazel) + ['build'] + list(options) + TARGETS,
            list(bazel) + ['cquery'] + list(options) + ['--output=files', query])


def parse_symvers(data, source):
    rows = []
    for line in data.decode('utf-8').splitlines():
        if not line.strip():
            continue
        fields = line.split('\t')
        require(len(fields) in (4, 5) and re.fullmatch(r'0x[0-9a-fA-F]{8}', fields[0])
                and fields[1] and fields[2] and fields[3].startswith('EXPORT_'),
                'Malformed Symvers row: ' + source)
        rows.append({'symbol': fields[1], 'crc': int(fields[0], 16),
                     'provider': fields[2], 'export': fields[3],
                     'namespace': fields[4] if len(fields) == 5 else '', 'source': source})
    return rows


def symbol_table(symvers):
    table = {}
    for source, data in symvers.items():
        for row in parse_symvers(data, source):
            old = table.get(row['symbol'])
            if old:
                require(all(old[k] == row[k] for k in ('crc', 'provider', 'export', 'namespace')),
                        'Conflicting/duplicate symbol provider: ' + row['symbol'])
                old['sources'].append(source)
            else:
                row['sources'] = [row.pop('source')]
                table[row['symbol']] = row
    return table


def check_module(elf, table, all_modules):
    imports = []
    imported_ns = set(elf['info'].get('import_ns', []))
    for symbol, crc in sorted(elf['versions'].items()):
        require(symbol in table, 'Missing import provider: ' + symbol)
        row = table[symbol]
        require(row['crc'] == crc, 'Import CRC mismatch: ' + symbol)
        require(not row['namespace'] or row['namespace'] in imported_ns,
                'Missing import namespace: ' + symbol)
        imports.append(dict(row))
    for symbol, crc in elf['export_crcs'].items():
        require(symbol in table and table[symbol]['crc'] == crc
                and PurePosixPath(table[symbol]['provider']).name.replace('-', '_') == 'msm_drm',
                'Target export differs from Symvers: ' + symbol)
    require(set(elf['depends']) <= set(all_modules), 'Declared module dependency not built/recorded')
    return imports


def collect(root, paths, destination, parse_elf, patch_manifest):
    """Only cquery-declared files; keep one KO plus kernel/dependency evidence."""
    require(not destination.exists(), 'Refusing stale output directory')
    destination.mkdir(parents=True)
    manifest = {'schema': 1, 'stage': 'display-probe', 'target': DISPLAY,
                'files': [], 'dependency_modules': [], 'kernel_build_inputs': [], 'missing_required_outputs': [],
                'flashable': False, 'hardware_tested': False,
                'runtime_compatibility_review_required': True,
                'scope': 'Only msm_drm.ko is a candidate; no boot images or autoload changes.'}
    audit = {'success': False, 'r18_core_contract_passed': False,
             'same_build_crc_verified': False, 'hardware_tested': False,
             'expected_r18': EXPECTED, 'limitations':
             'New KO still requires comparison against the actual R18 kernel and 16 RAM providers.'}
    modules, symvers, present, module_data = {}, {}, set(), []
    try:
        declared = list(dict.fromkeys(paths))
        for name in declared:
            rel = safe_path(name)
            # deps() also lists source/header inputs: record their names in the
            # cquery report, but never copy unbounded repository source trees.
            if not name.startswith('bazel-out/'):
                continue
            is_module, is_symvers = name.endswith('.ko'), name.endswith('.symvers')
            is_core = name.startswith(CORE) and name[len(CORE):] in CORE_REQUIRED | {'System.map'}
            if not (is_module or is_symvers or is_core):
                continue
            source = root / rel
            require(source.is_file(), 'Declared build output missing: ' + name)
            data = source.read_bytes()
            entry = {'source': name, 'bytes': len(data), 'sha256': sha(data)}
            if is_module:
                module_data.append((name, data, entry))
                if name != MODULE:
                    manifest['dependency_modules'].append(entry)
                    continue
            if is_symvers:
                symvers[name] = data
            if name == CORE + 'Image':
                # Identify this build's core, but do not ship a new kernel.
                manifest['kernel_build_inputs'].append(entry)
                present.add(name)
                continue
            target = destination / 'objects' / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            entry['file'] = 'objects/' + name
            manifest['files'].append(entry)
            present.add(name)
        # Save available evidence before parsing/rejecting an ELF. An ABI or
        # malformed-module failure must not discard the newly built candidate.
        for name, data, entry in module_data:
            elf = parse_elf(data)
            module = elf['name']
            require(module not in modules, 'Duplicate module provider: ' + module)
            modules[module] = elf
            entry.update(name=module, full_vermagic=elf['info']['vermagic'][0],
                         depends=elf['depends'], softdeps=elf['softdeps'])
            require((module == 'msm_drm') == (name == MODULE), 'Unexpected msm_drm provider path')
        required = {CORE + n for n in CORE_REQUIRED} | {MODULE, MODULE_SYMVERS}
        manifest['missing_required_outputs'] = sorted(required - present)
        require(not manifest['missing_required_outputs'],
                'Missing required outputs: ' + ', '.join(manifest['missing_required_outputs']))
        raw = lambda n: ((root if n == 'Image' else destination / 'objects') / (CORE + n)).read_bytes()
        release = raw('include/config/kernel.release').decode().strip()
        audit['actual'] = {'config_sha256': sha(raw('kernel_aarch64_dot_config')),
                           'core_symvers_sha256': sha(raw('vmlinux.symvers')),
                           'kernel_release': release,
                           'full_vermagic': modules['msm_drm']['info']['vermagic'][0],
                           'kernel_image_sha256': sha(raw('Image'))}
        audit['core_checks'] = {k: audit['actual'][k] == v for k, v in EXPECTED.items()}
        audit['r18_core_contract_passed'] = all(audit['core_checks'].values())
        require((b'Linux version ' + release.encode() + b' ') in raw('Image'), 'Image/release mismatch')
        require(all(m['info']['vermagic'] == [EXPECTED['full_vermagic']] for m in modules.values()),
                'A dependency module has a different full vermagic')
        markers = patch_manifest['expected_markers']
        require(markers and len(markers) == len(set(markers)) and
                all(isinstance(x, str) and x.startswith('MYRON_R21') for x in markers),
                'Missing or ambiguous expected probe markers')
        candidate = (destination / 'objects' / MODULE).read_bytes()
        audit['markers'] = {s: s.encode() in candidate for s in markers}
        require(all(audit['markers'].values()), 'Probe marker absent from new msm_drm.ko')
        table = symbol_table(symvers)
        audit['imports'] = check_module(modules['msm_drm'], table, modules)
        audit['target_module'] = {'name': 'msm_drm', 'sha256': sha(candidate),
                                 'bytes': len(candidate), 'depends': modules['msm_drm']['depends'],
                                 'softdeps': modules['msm_drm']['softdeps'],
                                 'info': modules['msm_drm']['info']}
        audit['same_build_crc_verified'] = True
        require(audit['r18_core_contract_passed'], 'R18 config/core CRC/release/vermagic contract changed')
        audit['success'] = True
    except Exception as error:
        audit['error'] = str(error)
        raise
    finally:
        write_json(destination / 'artifact-manifest.json', manifest)
        write_json(destination / 'display-audit.json', audit)
        write_json(destination / 'artifact-lock.json', {'schema': 1, 'metadata': {
            n: sha((destination / n).read_bytes()) for n in ('artifact-manifest.json', 'display-audit.json')}})
        (destination / 'NOT-A-FLASH-PACKAGE.txt').write_text(
            'R21 source probe build only. Do not flash or replace the running R18 kernel.\n'
            'msm_drm.ko requires an independent R18 + existing-provider ABI review before RAM testing.\n')
    return audit


def run(args):
    root, package, baseline = args.workspace.resolve(), args.package.resolve(), args.baseline.resolve()
    r18 = args.r18_bundle.resolve()
    reports = root / 'integration-reports'
    output = root / 'integration-artifacts/display-probe'
    status_path = reports / 'r21-display-status.json'
    status = dict(schema=1, success=False, compiled=False, hardware_tested=False,
                  flashable=False, phase='verify', targets=TARGETS,
                  runtime_compatibility_review_required=True)
    reports.mkdir(parents=True, exist_ok=True)
    # A failed/retried invocation cannot upload the previous invocation's KO.
    if not args.dry_run:
        if output.exists():
            shutil.rmtree(output)
        for path in reports.glob('r21-*'):
            if path.is_file():
                path.unlink()
    write_json(status_path, status)
    try:
        require(args.jobs in (2, 4) and args.ram_mb >= 2048, 'Invalid build resources')
        status['bundle_lock_sha256'] = verify_bundle()
        old = load('r21_r18_builder', r18 / 'boot_build.py')
        status['r18_bundle_lock_sha256'] = old.verify_bundle()
        helper = load('r21_r13_driver_check', baseline / 'drivers/driver_check.py')
        runner_data, metadata = helper.verify_bundle(baseline, package / 'build_platform.py')
        status['baseline_runner'] = metadata
        bazel, options = helper.runner_build_configuration(runner_data, root, args.jobs, args.ram_mb)
        build_cmd, cquery_cmd = commands(bazel, options)
        write_json(reports / 'r21-command-plan.json', {'build': build_cmd, 'cquery': cquery_cmd,
                   'cold_build_note': 'Kernel and all declared prerequisites are built as necessary.'})
        if args.dry_run:
            status.update(phase='dry_run_only', dry_run=True)
            print(json.dumps({'build': build_cmd, 'cquery': cquery_cmd}, indent=2))
            return 0
        runner = load('r21_r13_runner', package / 'build_platform.py')
        status['phase'] = 'prepare_unchanged_r18_sources'
        runner.logged([sys.executable, str(package / 'prepare_workspace.py'), '--workspace', str(root)],
                      root, reports / 'r21-prepare.log')
        runner.logged([sys.executable, str(baseline / 'run_r12.py'), 'apply', '--workspace', str(root), '--stage', 'soc'],
                      root, reports / 'r21-r13-apply.log')
        helper.verify_applied_writes(baseline, root)
        runner.logged([sys.executable, str(r18 / 'source-fix/apply_soccp.py'),
                       '--soc', str(root / 'vendor/qcom/sm8850')], root, reports / 'r21-soccp-apply.log')
        status['phase'] = 'apply_probe_only'
        patch = HERE / 'probe-patch'
        runner.logged([sys.executable, str(patch / 'apply_probe.py'), '--modules-root',
                       str(root / 'vendor/qcom/sm8850-modules'), '--report', str(reports / 'r21-probe-apply.json')],
                      root, reports / 'r21-probe-apply.log')
        patch_manifest = json.loads((patch / 'manifest.json').read_text())
        status['patch_manifest_sha256'] = sha((patch / 'manifest.json').read_bytes())
        # This helper creates the kernel.release output-group wrapper only;
        # its broad returned list of targets is intentionally never used.
        runner.build_targets(root, 'soc')
        status['phase'] = 'compile_target'
        write_json(status_path, status)
        runner.logged(build_cmd, root, reports / 'r21-display-build.log')
        status['compiled'] = True
        result = subprocess.run(cquery_cmd, cwd=root, capture_output=True, text=True)
        (reports / 'r21-cquery.log').write_text(result.stderr)
        (reports / 'r21-cquery-outputs.txt').write_text(result.stdout)
        require(result.returncode == 0, 'cquery failed; see r21-cquery.log')
        status['phase'] = 'verify_binary'
        elf_reader = load('r21_elf_contract', r18 / 'stage-builder/elf_contract.py')
        audit = collect(root, result.stdout.splitlines(), output, elf_reader.parse_elf, patch_manifest)
        status.update(success=True, phase='source_probe_candidate_verified',
                      r18_core_contract_passed=audit['r18_core_contract_passed'],
                      same_build_crc_verified=audit['same_build_crc_verified'])
    except Exception as error:
        status['error'] = str(error)
        print('R21 STOP:', error, file=sys.stderr)
    finally:
        status['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        write_json(status_path, status)
        if output.is_dir() and not args.dry_run:
            if (HERE / 'probe-patch/manifest.json').is_file():
                shutil.copy2(HERE / 'probe-patch/manifest.json', output / 'probe-patch-manifest.json')
            for path in reports.glob('r21-*'):
                if path.is_file() and path.suffix in ('.json', '.log', '.txt'):
                    shutil.copy2(path, output / path.name)
    return 0 if status['success'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path)
    parser.add_argument('--package', type=Path)
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--r18-bundle', type=Path)
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--ram-mb', type=int, default=10000)
    parser.add_argument('--dry-run', action='store_true', help='Verify prepared bundles and print commands; do not build')
    parser.add_argument('--print-plan', action='store_true', help='Print static scope without a prepared workspace')
    args = parser.parse_args()
    if args.print_plan:
        print(json.dumps({'targets': TARGETS, 'candidate': MODULE, 'expected_r18': EXPECTED,
                          'device_operations': False, 'partition_images': False,
                          'cold_build_includes_kernel_and_prerequisites': True}, indent=2))
        return 0
    if not all((args.workspace, args.package, args.baseline, args.r18_bundle)):
        parser.error('--workspace --package --baseline --r18-bundle are required unless --print-plan')
    return run(args)


if __name__ == '__main__':
    sys.exit(main())
