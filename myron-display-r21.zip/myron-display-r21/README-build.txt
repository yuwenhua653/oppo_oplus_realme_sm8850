R21 targeted display probe build — implementation notes

This is an offline source-build workflow. It never opens ADB/fastboot, writes a
device, creates boot/vendor_boot/recovery images, or changes modules.load.
The runtime kernel and the 142-module boot stage remain the already-tested R18.

Exact new build target:
  //vendor/qcom/sm8850-modules/qcom/opensource/display-drivers:canoe_perf_msm_drm
Additional explicit metadata targets:
  //common:kernel_aarch64
  //myron_artifact_metadata:kernel_release

The pinned display DDK rule points to the Canoe/perf base-kernel alias. Its
declared dependencies are built by Bazel as necessary. A cold CI job therefore
still builds the common kernel and prerequisite modules; this is not a promise
of single-KO compile time. It does not request the full 605-module target or the
142 boot-module inventory as a top-level build target.

Assembly interface (the coordinator creates the archive and hashes):
  myron-display-r21/
    display_probe_build.py
    bundle-lock.json
    baseline/myron-boot-r18.zip    byte-identical original R18 archive
    probe-patch/apply_probe.py
    probe-patch/manifest.json
    probe-patch/...               every file required by the patch owner
    tests/test_display_probe_build.py

bundle-lock.json uses {"files":[{"path":"relative/path","sha256":"hex",
"bytes":123}]} and locks every shipped file except itself. The bytes field is
optional to the reader; SHA256 is mandatory. The workflow template uses
__R21_BUNDLE_SHA256__ for the paired inner archive; replace it only after the
archive is final. Do not change the embedded R18 archive or its fixed checksum.

The complete previous R18 workflow preparation from “Extract uploaded
integration ZIP” through “Install Myron r13 source adaptation and validation
gates” is preserved byte for byte. The new runner verifies the R18 bundle and
the prepared, locked R13 runner. It extracts the identical Bazel configuration
from that runner, applies the same R13 adaptation and R18 SOCCP fix, and then
applies the strictly pinned three-source-file R21 probe patch.

Build and cquery use identical configuration flags. cquery is deps(set(...)):
querying only the three top-level rules would miss dependency Module.symvers.
Only declared bazel-out outputs are considered. There is no filesystem glob
that could select an old msm_drm. A new output directory is used; a failed or
retried invocation cannot upload the preceding invocation's successful KO.

Collected output: integration-artifacts/display-probe/
  - exactly one candidate msm_drm.ko at its fixed provider path
  - core config/release/builtins and core + dependency Symvers
  - hash, size, vermagic and dependency metadata for prerequisite KOs
  - actual Image hash/release evidence, without copying a new Image
  - marker/namespace/import CRC audit, source patch manifest, build/cquery logs
  - artifact manifest, lock and status, including failure details

All config, vmlinux.symvers, release and full vermagic checks must match the
known R18 contract. The candidate must contain the pinned probe markers and
its imported CRCs/namespaces must match this build's exact providers. Missing
outputs, duplicate providers, missing markers or incompatible core values fail
the job while preserving available diagnostic artifacts. Passing this check
does not authorize a RAM test: compare the actual candidate's imports against
the existing R18 kernel plus the 16 already-used RAM providers first.

Offline checks:
  python3 -m unittest discover -s tests -v
  python3 display_probe_build.py --print-plan

After the normal workflow has prepared its local source workspace, --dry-run
with the same required workspace/package/baseline/r18-bundle arguments verifies
bundle and runner locks and prints build/cquery commands, without preparing,
patching or building sources. It records dry_run_only, compiled=false and
success=false, avoiding a fake build-success record.

No remote CI, source sync, kernel compilation, device test or Windows execution
was performed for the offline validation. The test fixture mocks ELF extraction
only for small synthetic collector cases; production uses the unchanged R18
ELF parser. workflow-validation.json additionally records actual R18 core
Symvers parsing and unchanged preparation / embedded-script syntax checks.
