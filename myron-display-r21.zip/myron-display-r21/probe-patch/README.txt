R21 source-only display initialization trace

Pinned input
  Repository: LineageOS/android_kernel_qcom_sm8850-modules
  Commit: f2ecb6a09ea56bd8ec9a0bfd2e97f45e200ab322
  Exact target paths and SHA256 before/after: manifest.json.
  Only sde_rm.c, sde_hw_dspp.c and sde_kms.c change.

Apply to an already prepared modules checkout
  mkdir -p /path/to/reports
  python3 apply_probe.py --modules-root /path/to/vendor/qcom/sm8850-modules \
    --report /path/to/reports/r21-probe-apply.json

The report directory must already exist and be outside both modules-root and this
patch bundle. The applicator first verifies the pinned manifest, all before/after
payloads, the patch and all three existing source files. Only exact before or
reviewed after hashes are accepted. Unknown input means no source write. Existing
after bytes are not rewritten. Known mixed before/after inputs are completed after
all three pass. File permissions are preserved. Each replacement is atomic; this
is not a three-file filesystem transaction. I/O failure after one replacement is
reported as partial_failure and is never reported as success. Symlink/reparse
components are rejected. No checkout command, build, image or device operation is
performed by this bundle.

Scope and semantics
There are 61 source marker occurrences and 59 unique format strings. Each uses
pr_info with MYRON_R21, stage, phase, type, id and rc. RM construction logs bracket
the existing selected hardware initializer and record registration completion.
DSPP setup and existing debug-range registrations have paired boundaries. Existing
hardware-fence and continuous-splash callbacks are evaluated once, as before.
KMS brackets RM, interrupt initialization, splash discovery, VBIF, UIDLE, SID,
performance, software fuse and DRM objects; the caller brackets all returns from
_sde_kms_hw_init_blocks, including its HFI early-return path. Top-level KMS return
and existing error cleanup are marked. This patch does not add broad hot-path,
module-init, panel-command or PHY logging.

Three temporary-result rewrites retain exactly one existing call and its original
nonzero/boolean branch: sde_hw_fence_init, _init_hw_fences, read_active_status.
Other changes are logs and necessary braces. Pointer-return logs use PTR_ERR only
when IS_ERR, otherwise rc=0 with null separately. A NULL result is not success.
Existing error paths, including any original rc==0 oddities, are not repaired.
The rm_init cleanup exit is phase=failure even if original rc is zero. Optional
UIDLE/sw-fuse/hardware-fence failures retain their original nonfatal handling.
Numeric type=-1/id=-1 denotes a stage without an RM hardware-block identity.

No DT, SSIP bit interpretation, catalog feature, power vote, MMIO read/write,
sleep, timeout, return value or hardware-call count is intentionally changed.
Printk adds execution time and bounded per-probe output; it is not timing-neutral.
An unmatched enter log narrows an observed interval but does not prove the exact
fault instruction, since transport loss can hide later emitted messages.

Verification and collector contract
  python3 verify_structure.py --report /path/to/reports/r21-structure.json
  python3 -m unittest discover -s tests -v

structure-validation.json records an exact inverse of all edits back to original
hashes, unchanged nonlogging function-invocation counts, return expressions, goto
sequence and preprocessor directives. All markers are outside #if conditions.
A real host C compilation of the literal table verifies C escape decoding and
ELF string matching only; it is not a Qualcomm driver compilation or ABI test.

manifest.expected_markers contains 19 core initialization format strings without
a newline suffix or C backslash escapes. The compiled msm_drm.ko collector must
find every one. manifest.all_source_markers contains all 59 source formats for
auditing; optional/error branches are deliberately not mandatory ELF literals.
The actual targeted CI must compile the source, verify required marker bytes and
validate module compatibility before a device test can be considered ready.

Current validation: structural checks pass; six focused applicator test methods
cover pristine apply, idempotence/permissions, unknown-third-file zero writes,
corrupted inputs, manifest pin, symlinks and path/report escape cases. Independent
review is coordinated separately. No kernel/module compile or device test has
been performed by this patch task.
