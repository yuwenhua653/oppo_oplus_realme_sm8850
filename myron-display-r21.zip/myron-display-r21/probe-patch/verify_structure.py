#!/usr/bin/env python3
"""Structural evidence, not a substitute for compiling or device observation."""
import argparse, ast, collections, difflib, hashlib, json, re, subprocess, tempfile
from pathlib import Path

D=Path(__file__).resolve().parent
SHA=lambda b:hashlib.sha256(b).hexdigest()
MARKER=re.compile(r'^[ \t]*pr_info\(("MYRON_R21 (?:[^"\\]|\\.)*").*\);\n',re.M)

def nonstrings(text):
    return re.sub(r'/\*.*?\*/|//[^\n]*|"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'', ' ', text, flags=re.S)

def functions(text):
    return collections.Counter(re.findall(r'\b([A-Za-z_]\w*)\s*\(',nonstrings(text)))

def returns(text):
    return re.findall(r'\breturn\s+([^;]+);',nonstrings(text))

def normalize(text):
    return re.sub(r'\s+','',text)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--report',required=True);args=parser.parse_args()
    m=json.loads((D/'manifest.json').read_text());edits=json.loads((D/'edits.json').read_text())
    reports=[];decoded=[];patch=[];c_literals=[]
    for f in m['files']:
        old=(D/f['before_file']).read_bytes();new=(D/f['after_file']).read_bytes()
        assert SHA(old)==f['before_sha256'] and SHA(new)==f['after_sha256']
        a=old.decode();b=new.decode();inverse=b
        for e in reversed([e for e in edits if e['file']==Path(f['path']).name]):
            assert inverse.count(e['after'])==1, e
            inverse=inverse.replace(e['after'],e['before'],1)
        assert inverse==a,'Exact reverse of documented edits differs'
        stripped=MARKER.sub('',b)
        oldcalls=functions(a);newcalls=functions(stripped)
        # if branches receive harmless braces/temp-variable conditions. All function,
        # MMIO, indirect callback identifiers and their invocation counts stay fixed.
        oldcalls.pop('if',None);newcalls.pop('if',None)
        assert oldcalls==newcalls, oldcalls-newcalls or newcalls-oldcalls
        assert [normalize(x) for x in returns(a)]==[normalize(x) for x in returns(stripped)]
        assert re.findall(r'\bgoto\s+\w+;',a)==re.findall(r'\bgoto\s+\w+;',stripped)
        oldpp=[x for x in a.splitlines() if x.lstrip().startswith('#')]
        newpp=[x for x in b.splitlines() if x.lstrip().startswith('#')]
        assert oldpp==newpp
        # Decode C literals (these only use the common C/Python escape subset) before
        # checking manifest strings; literal backslash-n is not an ELF requirement.
        occurrences=[];stack=[]
        for number,line in enumerate(b.splitlines(True),1):
            if re.match(r'\s*#if',line):stack.append(line.strip())
            elif re.match(r'\s*#endif',line):stack.pop()
            hit=MARKER.match(line)
            if hit:
                value=ast.literal_eval(hit.group(1));assert value.endswith('\n')
                key=value[:-1];assert '\\' not in key and '\n' not in key
                assert not stack, ('marker under preprocessor condition',number,stack)
                decoded.append(key);c_literals.append(hit.group(1));occurrences.append(number)
        assert len(occurrences)==f['marker_occurrences']
        patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+f['path'],tofile='b/'+f['path']))
        reports.append(dict(path=f['path'],sha256_before=SHA(old),sha256_after=SHA(new),exact_inverse_edits=True,nonlogging_function_invocation_counts_identical=True,return_expressions_and_goto_sequence_identical=True,preprocessor_directives_identical=True,marker_lines=occurrences,markers_outside_preprocessor_conditions=True))
    assert sorted(set(decoded))==m['all_source_markers']
    assert set(m['expected_markers'])<=set(decoded) and len(m['expected_markers'])==m['expected_marker_count']
    assert SHA(''.join(patch).encode())==m['patch']['sha256']==SHA((D/m['patch']['path']).read_bytes())
    # Real host C compilation checks the escape-decoding/ELF-string contract only.
    # It does not compile Qualcomm driver code or establish its target ABI.
    with tempfile.TemporaryDirectory(prefix='r21-literals-') as temp:
        source=Path(temp)/'literals.c';obj=Path(temp)/'literals.o'
        source.write_text('const char *r21_markers[] = {\n'+',\n'.join(c_literals)+'\n};\n')
        result=subprocess.run(['cc','-c',str(source),'-o',str(obj)],capture_output=True,text=True)
        assert result.returncode==0,result.stderr
        raw=obj.read_bytes();assert all(x.encode() in raw for x in m['expected_markers'])
    report=dict(passed=True,manifest_sha256=SHA((D/'manifest.json').read_bytes()),files=reports,source_marker_occurrences=len(decoded),source_unique_markers=len(set(decoded)),mandatory_elf_markers=len(m['expected_markers']),host_compiled_literal_encoding_verified=True,kernel_compiled=False,device_tested=False,limitations=['Structural checks plus independent C review; no assertion that printk is timing-neutral.','Logging changes boot timing and adds bounded per-probe output; lost transport may hide emitted return markers.','Three explicit temporary-result rewrites retain one call and the same nonzero/boolean branch; C review remains required.','Pointer rc zero plus null true is a NULL result, not a successful constructor; original error handling is unchanged.'])
    out=Path(args.report);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='files'},indent=2))

if __name__=='__main__':main()
