#!/usr/bin/env python3
"""Focused offline tests. No kernel build, network or device command is run."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

SOURCE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('display_probe_build', SOURCE / 'display_probe_build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Collection(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.out = self.root / 'result'
        self.dep = m.MODULE.replace('canoe_perf_msm_drm/msm_drm.ko', 'canoe_perf_supplier/supplier.ko')
        self.dep_sym = self.dep.replace('/supplier.ko', '/supplier_Module.symvers')
        self.config = b'CONFIG_ARM64_4K_PAGES=y\n'
        self.core = b'0x00000001\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\t\n'
        self.files = {
            m.CORE + 'Image': b'Linux version fixture ' + b'not-a-boot-image',
            m.CORE + 'kernel_aarch64_dot_config': self.config,
            m.CORE + 'vmlinux.symvers': self.core,
            m.CORE + 'kernel_aarch64_Module.symvers': self.core,
            m.CORE + 'include/config/kernel.release': b'fixture\n',
            m.CORE + 'modules.builtin': b'', m.CORE + 'modules.builtin.modinfo': b'',
            m.MODULE: b'msm_drm MYRON_R21 probe=%d', self.dep: b'supplier',
            m.MODULE_SYMVERS: b'0x00000003\tdisplay_export\t../display/msm_drm\tEXPORT_SYMBOL_GPL\t\n',
            self.dep_sym: b'0x00000002\tsupply\t../supplier\tEXPORT_SYMBOL_GPL\tNS_SUPPLIER\n',
        }
        self.marker = {'expected_markers': ['MYRON_R21 probe=%d']}
        self.expected = {'config_sha256': m.sha(self.config), 'core_symvers_sha256': m.sha(self.core),
                         'kernel_release': 'fixture', 'full_vermagic': 'fixture SMP'}
        self.pin = patch.object(m, 'EXPECTED', self.expected)
        self.pin.start()
        self.addCleanup(self.pin.stop)

    def elf(self, data):
        name = 'msm_drm' if data.startswith(b'msm_drm') else 'supplier'
        return dict(name=name, info={'name': [name], 'vermagic': ['fixture SMP'], 'import_ns': ['NS_SUPPLIER']},
                    versions={'module_layout': 1, 'supply': 2}, export_crcs={'display_export': 3} if name == 'msm_drm' else {},
                    depends=['supplier'] if name == 'msm_drm' else [], softdeps=[])

    def collect(self, extra=()):
        for name, data in self.files.items():
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        return m.collect(self.root, list(self.files) + list(extra), self.out, self.elf, self.marker)

    def test_complete_only_target_ko_and_metadata_are_copied(self):
        result = self.collect(['vendor/source/header.h'])
        self.assertTrue(result['success'])
        self.assertTrue(result['same_build_crc_verified'])
        self.assertEqual([p.name for p in self.out.rglob('*.ko')], ['msm_drm.ko'])
        self.assertFalse(list(self.out.rglob('Image')))
        manifest = json.loads((self.out / 'artifact-manifest.json').read_text())
        self.assertEqual(manifest['dependency_modules'][0]['name'], 'supplier')
        self.assertEqual(manifest['kernel_build_inputs'][0]['sha256'], m.sha(self.files[m.CORE + 'Image']))
        self.assertFalse(manifest['flashable'])
        self.assertTrue(manifest['runtime_compatibility_review_required'])

    def test_missing_dependency_symvers_is_not_silently_ignored(self):
        del self.files[self.dep_sym]
        with self.assertRaisesRegex(ValueError, 'Missing import provider: supply'):
            self.collect()
        self.assertFalse(json.loads((self.out / 'display-audit.json').read_text())['success'])

    def test_crc_mismatch_fails_and_retains_candidate_and_audit(self):
        self.files[self.dep_sym] = self.files[self.dep_sym].replace(b'0x00000002', b'0x00000009')
        with self.assertRaisesRegex(ValueError, 'CRC mismatch: supply'):
            self.collect()
        self.assertTrue((self.out / 'objects' / m.MODULE).is_file())
        self.assertTrue((self.out / 'artifact-lock.json').is_file())

    def test_changed_core_contract_is_failure_with_diagnostic_output(self):
        self.files[m.CORE + 'kernel_aarch64_dot_config'] += b'CONFIG_UNEXPECTED=y\n'
        with self.assertRaisesRegex(ValueError, 'R18 config/core CRC'):
            self.collect()
        audit = json.loads((self.out / 'display-audit.json').read_text())
        self.assertFalse(audit['r18_core_contract_passed'])
        self.assertTrue(audit['same_build_crc_verified'])

    def test_reject_stale_directory(self):
        self.out.mkdir()
        (self.out / 'old.ko').write_bytes(b'old')
        with self.assertRaisesRegex(ValueError, 'stale output'):
            self.collect()
        self.assertEqual((self.out / 'old.ko').read_bytes(), b'old')

    def test_reject_path_escape(self):
        with self.assertRaisesRegex(ValueError, 'Unsafe declared path'):
            self.collect(['bazel-out/../../escape.ko'])

    def test_reject_duplicate_target_provider(self):
        self.files[m.MODULE.replace('canoe_perf_', 'canoe_consolidate_')] = self.files[m.MODULE]
        with self.assertRaisesRegex(ValueError, 'Duplicate module provider'):
            self.collect()

    def test_missing_new_marker_rejects_old_module(self):
        self.files[m.MODULE] = b'msm_drm old uninstrumented module'
        with self.assertRaisesRegex(ValueError, 'Probe marker absent'):
            self.collect()

    def test_missing_core_metadata_fails(self):
        del self.files[m.CORE + 'kernel_aarch64_Module.symvers']
        with self.assertRaisesRegex(ValueError, 'Missing required outputs'):
            self.collect()

    def test_conflicting_provider_same_crc_is_not_accepted(self):
        self.files[self.dep_sym] += b'0x00000001\tmodule_layout\tanother_provider\tEXPORT_SYMBOL\t\n'
        with self.assertRaisesRegex(ValueError, 'Conflicting/duplicate symbol provider'):
            self.collect()


class Entrypoint(unittest.TestCase):
    def test_commands_use_identical_configuration_and_transitive_query(self):
        options = ['--config=fast', '--jobs=2', '--//kernel:variant=perf']
        build, query = m.commands(['tools/bazel'], options)
        self.assertEqual(build[2:5], options)
        self.assertEqual(query[2:5], options)
        self.assertEqual(build[5:], m.TARGETS)
        self.assertTrue(query[-1].startswith('deps(set('))
        self.assertIn(m.DISPLAY, query[-1])
        self.assertNotIn('kernel_aarch64_modules', build)

    def test_static_plan_and_python_entrypoint(self):
        result = subprocess.run([sys.executable, str(SOURCE / 'display_probe_build.py'), '--print-plan'],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        plan = json.loads(result.stdout)
        self.assertFalse(plan['device_operations'])
        self.assertEqual(plan['targets'], m.TARGETS)

    def test_failed_build_removes_old_success_output(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            output = root / 'integration-artifacts/display-probe'
            output.mkdir(parents=True)
            (output / 'old.ko').write_bytes(b'old')
            args = SimpleNamespace(workspace=root, package=root / 'package', baseline=root / 'baseline',
                                   r18_bundle=root / 'r18', jobs=2, ram_mb=10000, dry_run=False)
            old = SimpleNamespace(verify_bundle=lambda: 'r18-lock')
            helper = SimpleNamespace(verify_bundle=lambda *a: (b'runner', {}),
                                     runner_build_configuration=lambda *a: (['bazel'], []),
                                     verify_applied_writes=lambda *a: None)
            runner = SimpleNamespace(logged=lambda *a: (_ for _ in ()).throw(RuntimeError('prepare failed')))
            with patch.object(m, 'verify_bundle', return_value='lock'), patch.object(m, 'load', side_effect=[old, helper, runner]):
                self.assertEqual(m.run(args), 1)
            self.assertFalse(output.exists())
            status = json.loads((root / 'integration-reports/r21-display-status.json').read_text())
            self.assertFalse(status['success'])
            self.assertFalse(status['compiled'])

    def test_verified_dry_run_has_no_prepare_or_compile(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            args = SimpleNamespace(workspace=root, package=root / 'package', baseline=root / 'baseline',
                                   r18_bundle=root / 'r18', jobs=2, ram_mb=10000, dry_run=True)
            old = SimpleNamespace(verify_bundle=lambda: 'r18-lock')
            helper = SimpleNamespace(verify_bundle=lambda *a: (b'runner', {}),
                                     runner_build_configuration=lambda *a: (['bazel'], ['--config=locked']))
            with patch.object(m, 'verify_bundle', return_value='lock'), patch.object(m, 'load', side_effect=[old, helper]), contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(m.run(args), 0)
            self.assertFalse((root / 'integration-artifacts/display-probe').exists())
            status = json.loads((root / 'integration-reports/r21-display-status.json').read_text())
            self.assertFalse(status['compiled'])
            self.assertFalse(status['success'])
            self.assertEqual(status['phase'], 'dry_run_only')


if __name__ == '__main__':
    unittest.main()
