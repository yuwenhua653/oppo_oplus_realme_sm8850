R27 DSI 日志窗口源码构建包
构建身份：R27-DSI-LOG-WINDOWS-20261012-01

本包编译新的 msm_drm.ko 诊断候选模块。保留 R25 原有探针与修复，增加默认关闭的
myron_r27_log_windows 布尔参数。后续经审计的实机加载包开启参数时，仅首次 DSI
连接器初始化的当前任务拥有日志窗口；每次安全上下文请求 msleep(50)，最多 60 次
窗口尝试（跳过也计数）。这会改变诊断时序；不是已经验证的开机修复。

沿用成功 R25 构建条件
  - baseline/myron-boot-r18.zip 原封不动，SHA-256：
    a3c7e97e4a28f6574a619bcc10dab8962911ed5fcef8617aeb7fc835bdbe7d13
  - 源码锁、工具链、R13 准备流程、R18 SOCCP 修复、内核配置保持原样。
  - 顶层目标仍只有 msm_drm、kernel_aarch64、kernel_release：
    //vendor/qcom/sm8850-modules/qcom/opensource/display-drivers:canoe_perf_msm_drm
    //common:kernel_aarch64
    //myron_artifact_metadata:kernel_release
  - 冷构建仍需编译内核和声明依赖，不等于只编译一个 KO。
    成功 R25 run 38205562491 全流程约 31 分钟，不保证本轮耗时。

保留原产物收集与 ABI 门
  build / cquery / aquery 使用相同配置；cquery 只查询三个根目标。
  aquery 选中唯一 msm_drm 的 KernelModule 或 KernelModuleProcessWrapperSandbox
  动作，按它真实使用的输入收集依赖 Symvers，不要求无关的依赖 KO 复制输出。
  缺产物、缺实际输入 Symvers、重复提供者、CRC 或 namespace 不匹配都会失败。
  R18 内核配置、核心 CRC、release、完整 vermagic 校验不变。
  新 Image 仅记录 hash/release，不作为候选交付；16 个 RAM 依赖不在这里替换。

R27 实际 KO 验证
  - manifest 的全部必需格式串均要求 marker + 换行 + NUL；固定保留原 R25 的
    59 条必需探针，再加入 R27 必需探针。近似前缀不能替代原标记。
  - 同时解析 ELF 的只读已分配段与执行段重定位，要求每条必需格式串存在实际
    代码引用；追加到文件尾或未引用的字符串不能通过此检查。
  - 解析 __param_myron_r27_log_windows 的 ARM64 kernel_param 结构：bool 类型、
    0444 权限、param_ops_bool、真实参数指针与默认 false 的单字节存储。
  - myron_r27_log_window 必须是真正的全局函数、未 EXPORT，并在五个公开 DSI
    函数中存在真实 AArch64 CALL26/JUMP26 分支重定位；支持 section+addend 形式。
  - 保留 hwfence 旧危险完整日志格式缺席、新安全完整日志格式存在的检查。
  - 这些结构检查不替代编译后逐函数指令、实际 R18 + 16 个 RAM 提供者的复核。
    尚无 R27 实际编译结果；任何运行结果未知时不得声称已成功适配或硬件通过。

产物与失败信息
  GitHub artifact：myron-r27-display-output-<run_id>
  GitHub reports：myron-r27-display-reports-<run_id>
  内部产物目录仍为 integration-artifacts/display-probe/，运行报告统一 r27-*。
  包括 msm_drm.ko、核心元数据、实际动作输入、使用的 Symvers、source manifest、
  marker/ELF/CRC 检查与构建日志。失败时可保留本次候选用于审查，但 success=false；
  每次正式运行前删除旧候选输出，不能让上轮 KO 或失败元数据冒充本轮成功。

使用
  将外层配对的 myron-display-r27.zip 放仓库根目录，
  build-myron-display-r27.yml 放 .github/workflows/，手动运行 R27 workflow。
  默认 jobs=2。编译完成后提供 output 与 reports 两个 artifact。
  这是源码构建包，不是刷机包；不调用 ADB/fastboot，不变更分区或自动加载列表。
  后续实机加载包必须显式验证新参数与模块 hash，才可开启日志窗口进行一次测试。

离线检查与局限
  python3 -m unittest discover -s tests -v
  python3 display_probe_build.py --print-plan
  collector 测试用明确标注的合成 ELF/aquery 样例，不是实际内核编译；结构检查另有
  合成 AArch64 ELF 正反例。生产路径保留 R18 原 ELF CRC 解析器，并新增 R27 结构门。
  真实 R25 参考 KO 已用于确认旧模块会被新参数门拒绝、原 59 条代码引用可识别。
  源码 patch 的精确 hash、结构、离线 dry-apply 与重复应用测试见 probe-patch/。
  离线检查不包含远程 CI、实际 R27 内核编译、设备试运行或完整开机验证。

封包
  bundle-lock.json 锁定本目录交付文件（不含自身）的路径、大小与 SHA-256。
  源码 patch 合并后重新生成 lock 和 ZIP，并以最终 ZIP SHA-256 替换 workflow 的
  __R27_BUNDLE_SHA256__。配对不符会在编译前停止。
