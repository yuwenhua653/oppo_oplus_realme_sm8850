"""Structural ELF evidence for the R27 opt-in log window candidate.

This checks a relocatable AArch64 KO, not text appended to a binary. It does not
prove runtime safety or replace source/control-flow and R18 provider reviews.
No external Python modules or host cross-disassembler are required in CI.
"""
import struct

BUILD_ID = 'R27-DSI-LOG-WINDOWS-20261012-01'
PARAM = 'myron_r27_log_windows'
HELPER = 'myron_r27_log_window'


def require(value, message):
    if not value:
        raise ValueError('R27 ELF contract: ' + message)


class Elf:
    def __init__(self, data):
        self.data = data
        require(len(data) >= 64 and data[:6] == b'\x7fELF\x02\x01', 'not ELF64 LE')
        require(struct.unpack_from('<HH', data, 16) == (1, 183), 'not AArch64 ET_REL')
        offset = struct.unpack_from('<Q', data, 40)[0]
        size, count, names = struct.unpack_from('<HHH', data, 58)
        require(size == 64 and 0 < names < count and offset + count * size <= len(data), 'bad section table')
        self.headers = [struct.unpack_from('<IIQQQQIIQQ', data, offset + i * size) for i in range(count)]
        strings = self.section(names)
        self.names = [self.string(strings, h[0]) for h in self.headers]
        require(len(set(self.names)) == count, 'duplicate section names')
        self.byname = {name: i for i, name in enumerate(self.names)}
        require('.symtab' in self.byname, 'missing .symtab')
        symindex = self.byname['.symtab']
        header = self.headers[symindex]
        require(header[1] == 2 and header[9] == 24 and header[5] % 24 == 0 and header[6] < count, 'bad symbols')
        strings = self.section(header[6])
        self.symbols = []
        for no, info, other, index, value, length in struct.iter_unpack('<IBBHQQ', self.section(symindex)):
            self.symbols.append(dict(name=self.string(strings, no), info=info, other=other,
                                     index=index, value=value, size=length))
        self.relocations = []
        for i, h in enumerate(self.headers):
            if h[1] != 4:
                continue
            require(h[6] == symindex and h[7] < count and h[9] == 24 and h[5] % 24 == 0, 'bad RELA table')
            for address, info, addend in struct.iter_unpack('<QQq', self.section(i)):
                require(info >> 32 < len(self.symbols) and address < self.headers[h[7]][5], 'bad RELA record')
                self.relocations.append(dict(index=h[7], offset=address, kind=info & 0xffffffff,
                                             symbol=self.symbols[info >> 32], addend=addend))

    @staticmethod
    def string(data, offset):
        require(0 <= offset < len(data), 'bad string offset')
        end = data.find(b'\0', offset)
        require(end >= 0, 'unterminated string')
        return data[offset:end].decode('utf-8')

    def section(self, index):
        require(0 <= index < len(self.headers), 'bad section index')
        h = self.headers[index]
        require(h[1] != 8 and h[4] + h[5] <= len(self.data), 'section outside file or NOBITS')
        return self.data[h[4]:h[4] + h[5]]

    def symbol(self, name):
        found = [s for s in self.symbols if s['name'] == name]
        require(len(found) == 1, 'missing/ambiguous symbol ' + name)
        return found[0]

    def defined(self, symbol):
        require(0 < symbol['index'] < len(self.headers), 'undefined symbol ' + symbol['name'])
        require(symbol['value'] + symbol['size'] <= self.headers[symbol['index']][5], 'symbol outside section')
        return symbol

    def target(self, relocation):
        s = self.defined(relocation['symbol'])
        return s['index'], s['value'] + relocation['addend']

    def relocation(self, index, offset):
        rows = [r for r in self.relocations if r['index'] == index and r['offset'] == offset]
        require(len(rows) == 1 and rows[0]['kind'] == 257, 'missing/ambiguous ABS64 pointer')
        return rows[0]

    def owners(self, index, offset):
        return [s['name'] for s in self.symbols if s['index'] == index and s['info'] & 15 == 2
                and s['value'] <= offset < s['value'] + s['size']]


def check(candidate, manifest):
    require(manifest.get('build_id') == BUILD_ID, 'wrong source build identity')
    elf = Elf(candidate)
    modinfo = elf.section(elf.byname.get('.modinfo', -1)).split(b'\0')
    require(modinfo.count(b'parmtype=' + PARAM.encode() + b':bool') == 1, 'missing unique bool parmtype')
    parameter = elf.defined(elf.symbol('__param_' + PARAM))
    # struct kernel_param in this pinned ARM64 kernel: name/mod/ops pointers,
    # u16 perm, s8 level, u8 flags, padding, then argument pointer; 40 bytes.
    require(elf.names[parameter['index']] == '__param' and parameter['size'] == 40, 'unexpected kernel_param layout')
    raw = elf.section(parameter['index'])[parameter['value']:parameter['value'] + 40]
    require(struct.unpack_from('<H', raw, 24)[0] == 0o444, 'parameter permissions are not 0444')
    base = parameter['value']
    nameptr = elf.relocation(parameter['index'], base)
    ni, no = elf.target(nameptr)
    require(elf.string(elf.section(ni), no) == PARAM, 'parameter name pointer differs')
    op = elf.relocation(parameter['index'], base + 16)
    require(op['symbol']['name'] == 'param_ops_bool' and op['symbol']['index'] == 0 and op['addend'] == 0,
            'parameter does not use bool operations')
    argument = elf.relocation(parameter['index'], base + 32)
    ai, ao = elf.target(argument)
    variable = elf.defined(elf.symbol(PARAM))
    require(variable['info'] & 15 == 1 and variable['size'] == 1 and (ai, ao) == (variable['index'], variable['value']),
            'parameter argument does not target one-byte bool')
    header = elf.headers[ai]
    require(header[2] & 3 == 3 and 0 <= ao < header[5], 'parameter storage is not writable allocated data')
    require(header[1] == 8 or elf.section(ai)[ao] == 0, 'parameter default is not false')
    helper = elf.defined(elf.symbol(HELPER))
    require(helper['info'] == 0x12 and helper['size'] >= 4 and elf.headers[helper['index']][2] & 4,
            'helper must be a defined global function in executable code')
    require(not any(s['name'] == '__ksymtab_' + HELPER for s in elf.symbols), 'helper unexpectedly exported')
    calls = []
    for relocation in elf.relocations:
        if relocation['kind'] not in (282, 283) or not elf.headers[relocation['index']][2] & 4:
            continue
        if not relocation['symbol']['index']:
            continue
        if elf.target(relocation) == (helper['index'], helper['value']):
            callers = elf.owners(relocation['index'], relocation['offset'])
            require(len(callers) == 1, 'helper call has no unique function owner')
            word = struct.unpack_from('<I', elf.section(relocation['index']), relocation['offset'])[0]
            require(word & 0xfc000000 == (0x94000000 if relocation['kind'] == 283 else 0x14000000),
                    'helper call relocation is not on a branch instruction')
            calls.append(dict(caller=callers[0], offset=relocation['offset'], kind=relocation['kind']))
    required_callers = {'sde_connector_init', 'dsi_connector_get_modes', 'dsi_display_get_modes',
                        'dsi_display_get_modes_helper', 'dsi_panel_get_mode'}
    require(required_callers <= {c['caller'] for c in calls}, 'helper calls absent from required DSI functions')
    marker_evidence = check_markers(elf, manifest['expected_markers'])
    return dict(success=True, parameter=dict(name=PARAM, type='bool', permission_octal='0444', default=False),
                helper=dict(name=HELPER, exported=False, bytes=helper['size'], calls=calls),
                mandatory_markers=marker_evidence,
                limitation='Structural ELF + relocation evidence; not full register-flow, ABI or runtime proof.')


def check_markers(elf, markers):
    marker_evidence = []
    for marker in markers:
        token = (marker + '\n\0').encode()
        locations = []
        references = []
        for i, h in enumerate(elf.headers):
            if h[1] == 8 or h[2] & 3 != 2:  # allocated and read-only
                continue
            section = elf.section(i)
            start = 0
            while True:
                pos = section.find(token, start)
                if pos < 0:
                    break
                # Kernel pr_info has KERN_INFO before the marker. Preserve
                # the prior source's DRM prefix while validating its suffix.
                begin = section.rfind(b'\0', 0, pos) + 1
                locations.append((i, begin, pos + len(token)))
                start = pos + 1
        require(locations, 'mandatory marker absent from allocated read-only data: ' + marker)
        for r in elf.relocations:
            if not elf.headers[r['index']][2] & 4 or r['kind'] not in (275, 277):
                continue
            if not r['symbol']['index']:
                continue
            ti, to = elf.target(r)
            if any(ti == i and begin <= to < end for i, begin, end in locations):
                owners = elf.owners(r['index'], r['offset'])
                require(len(owners) == 1, 'marker relocation has no unique code owner')
                references.append(dict(function=owners[0], offset=r['offset'], kind=r['kind']))
        require(references, 'mandatory marker lacks executable relocation: ' + marker)
        marker_evidence.append(dict(marker=marker, references=references))
    return marker_evidence
