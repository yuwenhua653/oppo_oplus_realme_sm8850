#!/usr/bin/env python3
"""Check pinned source structure and extracted helper; no target/device build."""
import argparse, ast, difflib, hashlib, json, re, subprocess, tempfile
from pathlib import Path

D = Path(__file__).resolve().parent
SHA = lambda b: hashlib.sha256(b).hexdigest()
MARKER = re.compile(r'^[ \t]*pr_info\(("MYRON_R(?:21|23|25|27) (?:[^"\\]|\\.)*").*\);\n', re.M)

def reverse(text, edits, name):
    for edit in reversed([e for e in edits if e['file'] == name]):
        assert text.count(edit['after']) == 1, (name, edit['note'])
        text = text.replace(edit['after'], edit['before'], 1)
    return text

STUB = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#define DRM_MODE_CONNECTOR_DSI 16
#define noinline __attribute__((noinline))
#define module_param_named(a,b,c,d)
#define MODULE_PARM_DESC(a,b)
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
typedef struct { int value; } atomic_t;
#define ATOMIC_INIT(x) { x }
static int atomic_read(atomic_t *a) { return a->value; }
static void atomic_set(atomic_t *a,int value) { a->value=value; }
static int atomic_cmpxchg(atomic_t *a, int old, int value) {
    int previous=a->value; if(previous==old)a->value=value; return previous;
}
struct task_struct { int pid; };
static struct task_struct task_a={1},task_b={2};
static struct task_struct *current=&task_a;
static bool atomic_flag,irq_flag,interrupt_flag;
static unsigned int sleeps,requested_ms,log_count,context_skips,budget_skips;
static int in_atomic(void) { return atomic_flag; }
static int irqs_disabled(void) { return irq_flag; }
static int in_interrupt(void) { return interrupt_flag; }
static void msleep(unsigned int ms) {
    assert(!atomic_flag&&!irq_flag&&!interrupt_flag); ++sleeps;requested_ms+=ms;
}
static void pr_info(const char *fmt,...) __attribute__((format(printf,1,2)));
static void pr_info(const char *fmt,...) {
    char text[512];va_list ap;va_start(ap,fmt);vsnprintf(text,sizeof(text),fmt,ap);va_end(ap);
    ++log_count;if(strstr(text,"reason=context"))++context_skips;
    if(strstr(text,"reason=budget"))++budget_skips;
}
'''
HARNESS = r'''
int main(void) {
    int scope_a=0,scope_b=0;
    /* Disabled and non-DSI invocations do not claim, log or sleep. */
    myron_r27_log_begin(16,&scope_a);myron_r27_log_window("disabled");
    assert(!myron_r27_claimed.value&&!log_count&&!sleeps);
    myron_r27_log_windows=true;
    myron_r27_log_begin(15,&scope_a);myron_r27_log_window("wb");
    assert(!myron_r27_claimed.value&&!log_count&&!sleeps);
    myron_r27_log_begin(16,&scope_a);
    assert(myron_r27_claimed.value==1&&myron_r27_owner==&task_a&&log_count==1);
    /* Another task cannot borrow the scope or terminate it. */
    current=&task_b;
    myron_r27_log_begin(16,&scope_b);myron_r27_log_window("other");
    myron_r27_log_end(&scope_a,"other");
    assert(myron_r27_owner==&task_a&&atomic_read(&myron_r27_windows)==0&&log_count==1);
    current=&task_a;
    /* Nested WB/DSI invocation token cannot close the original owner. */
    myron_r27_log_begin(15,&scope_b);myron_r27_log_end(&scope_b,"nested_wb");
    myron_r27_log_begin(16,&scope_b);myron_r27_log_end(&scope_b,"nested_dsi");
    assert(myron_r27_owner==&task_a&&myron_r27_scope==&scope_a&&log_count==1);
    atomic_flag=true;myron_r27_log_window("atomic");atomic_flag=false;
    irq_flag=true;myron_r27_log_window("irq");irq_flag=false;
    interrupt_flag=true;myron_r27_log_window("interrupt");interrupt_flag=false;
    assert(context_skips==3&&sleeps==0&&atomic_read(&myron_r27_windows)==3);
    for(unsigned int i=0;i<100;i++)myron_r27_log_window("safe");
    assert(atomic_read(&myron_r27_windows)==60&&sleeps==57&&requested_ms==2850&&budget_skips==1);
    myron_r27_log_end(&scope_a,"done");
    assert(!myron_r27_owner&&!myron_r27_scope);
    unsigned int final_logs=log_count;
    myron_r27_log_begin(16,&scope_b);myron_r27_log_window("after_end");
    myron_r27_log_end(&scope_b,"after_end");
    assert(log_count==final_logs&&sleeps==57&&myron_r27_claimed.value==1);
    puts("helper behavior and printf formats passed");
    return 0;
}
'''

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--report',required=True);args=parser.parse_args()
    m=json.loads((D/'manifest.json').read_text())
    edits=json.loads((D/'edits.json').read_text())
    delta=json.loads((D/'r27-edits.json').read_text())
    markers=[];literals=[];patch=[];reports=[]
    for f in m['files']:
        old=(D/f['before_file']).read_bytes();new=(D/f['after_file']).read_bytes()
        name=Path(f['path']).name;a=old.decode();b=new.decode()
        assert SHA(old)==f['before_sha256'] and SHA(new)==f['after_sha256']
        assert reverse(b,edits,name)==a
        baseline=reverse(b,delta,name)
        assert SHA(baseline.encode())==m['r25_after_sha256'][name]
        old_literals=MARKER.findall(baseline)
        found=MARKER.findall(b)
        assert [x for x in found if not x.startswith('"MYRON_R27 ')]==old_literals
        assert len(found)==f['marker_occurrences']
        decoded=[ast.literal_eval(x) for x in found]
        assert all(x.endswith('\n') and '\\' not in x for x in decoded)
        markers.extend(x[:-1] for x in decoded);literals.extend(found)
        if name in ('sde_rm.c','sde_hw_dspp.c','sde_kms.c','sde_fence.c'):
            assert SHA(new)==m['r25_after_sha256'][name]
        else:
            body=b
            if name=='sde_connector.c':
                helper_start=body.index('/* R27 opt-in diagnostics.')
                helper_end=body.index('\n#define BL_NODE_NAME_SIZE',helper_start)
                body=body[:helper_start]+body[helper_end:]
            assert re.findall(r'^[ \t]*return\s+([^;]+);',baseline,re.M)==re.findall(r'^[ \t]*return\s+([^;]+);',body,re.M)
            assert re.findall(r'\bgoto\s+\w+;',baseline)==re.findall(r'\bgoto\s+\w+;',body)
        patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+f['path'],tofile='b/'+f['path']))
        reports.append(dict(path=f['path'],exact_reverse_to_original=True,exact_reverse_to_r25=True,r25_marker_sequence_preserved=True,after_sha256=SHA(new)))
    assert sorted(set(markers))==m['all_source_markers']
    assert set(m['r25_all_source_markers'])<=set(markers)
    assert set(m['r25_expected_markers'])<=set(m['expected_markers'])
    assert len(m['expected_markers'])==65==m['expected_marker_count']
    assert len(markers)==m['marker_occurrences']
    assert SHA(''.join(patch).encode())==m['patch']['sha256']==SHA((D/m['patch']['path']).read_bytes())
    connector=(D/'after/sde_connector.c').read_text()
    start=connector.index('/* R27 opt-in diagnostics.')
    end=connector.index('\n#define BL_NODE_NAME_SIZE',start)
    helper=connector[start:end]
    assert 'module_param_named(myron_r27_log_windows, myron_r27_log_windows, bool, 0444);' in helper
    assert 'static bool myron_r27_log_windows;' in helper
    assert 'noinline void myron_r27_log_window(const char *site)' in helper
    assert 'EXPORT_SYMBOL(' not in helper and 'EXPORT_SYMBOL_GPL(' not in helper
    init_start=connector.index('struct drm_connector *sde_connector_init(')
    init=connector[init_start:connector.index('\n}\n',init_start)+3]
    returns=list(re.finditer(r'^[ \t]*return [^;]+;',init,re.M))
    assert len(returns)==6 and init.count('myron_r27_log_end(')==6
    for hit in returns:
        assert 'myron_r27_log_end(' in init[:hit.start()].splitlines()[-1]
    sites=[]
    for f in m['files']:
        text=(D/f['after_file']).read_text()
        sites.extend(re.findall(r'\bmyron_r27_log_window\("([^"]+)"\);',text))
    assert len(sites)==27 and sorted(sites)==sorted(x['site'] for x in m['r27_window_sites'])
    with tempfile.TemporaryDirectory(prefix='r27-helper-') as temp:
        temp=Path(temp);source=temp/'helper.c';binary=temp/'helper';literal=temp/'literals.c';obj=temp/'literals.o'
        source.write_text(STUB+'\n'+helper+'\n'+HARNESS)
        compile_result=subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wformat=2',str(source),'-o',str(binary)],capture_output=True,text=True)
        assert compile_result.returncode==0,compile_result.stderr
        run=subprocess.run([str(binary)],capture_output=True,text=True)
        assert run.returncode==0,run.stderr
        literal.write_text('const char *r27_markers[]={\n'+',\n'.join(literals)+'\n};\n')
        result=subprocess.run(['cc','-c',str(literal),'-o',str(obj)],capture_output=True,text=True)
        assert result.returncode==0,result.stderr
        assert all(x.encode()+b'\n\0' in obj.read_bytes() for x in m['expected_markers'])
    report=dict(passed=True,manifest_sha256=SHA((D/'manifest.json').read_bytes()),files=reports,
                source_marker_occurrences=len(markers),source_unique_markers=len(set(markers)),mandatory_elf_markers=65,
                original_four_after_byte_identical=True,r25_marker_sequence_preserved=True,scope_return_sites=6,
                static_window_sites=len(sites),helper_host_format_and_behavior_compile_passed=True,
                helper_host_behavior_checks=['disabled_no_claim_log_sleep','non_dsi_no_claim_log_sleep','first_dsi_claims','different_task_cannot_use_or_end','nested_token_cannot_end','atomic_irq_interrupt_skip','60_attempt_budget_including_skips','budget_report_once','same_owner_end','claim_never_resets'],
                literal_lf_nul_contract_verified=True,kernel_compiled=False,device_tested=False,
                limitations=['Host stubs validate actual extracted helper C, not kernel atomics, concurrency, target ABI or scheduler behavior.','No guarantee printk or USB/pstore finishes during a window.','Maximum 60 requests of 50 ms is not a wall-clock bound.','New timing can mask or expose defects; this is diagnostic source, not a boot fix.'])
    out=Path(args.report);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='files'},indent=2))

if __name__=='__main__':main()
