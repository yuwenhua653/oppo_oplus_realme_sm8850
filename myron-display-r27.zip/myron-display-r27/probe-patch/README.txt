MYRON R27 bounded DSI log-window diagnostics
Build ID: R27-DSI-LOG-WINDOWS-20261012-01

This is a source update requiring CI compilation and subsequent artifact review.
It is NOT a confirmed boot fix and is NOT a flashable package.

The source repository and eight source targets remain pinned to the R25 source
baseline. sde_rm.c, sde_hw_dspp.c, sde_kms.c and sde_fence.c retain exact R25
after bytes, including the older debug-only IOVA read removal. All R25 probe
calls and their argument expressions remain unchanged and in the same order.

Only dsi_panel.c, dsi_display.c, dsi_drm.c and sde_connector.c receive R27 changes.
The new bool parameter myron_r27_log_windows defaults false, permission 0444.
When disabled it does not claim, log or sleep. A later reviewed runtime package
must opt in explicitly; this source update does not execute device commands.

When enabled, atomic_cmpxchg claims only the first type-16 DSI connector init.
The owner is the current task plus this invocation's local token. The claim is
never reset. All six original returns close the scope, while nested WB/DSI
invocations cannot close another invocation's token. A private noinline helper
is linked within msm_drm, without EXPORT_SYMBOL or an added exported ABI.

There are 27 selected static call sites, including connector entry, properties,
panel mode entry/exit, transfer calculation, mode-loop return, display/helper boundaries, DRM
conversion/duplicate/add and helper return. Only the owner task is eligible.
Each eligible attempt atomically reserves one of 60 slots, including against
same-task IRQ reentry; unsafe atomic, IRQ-disabled or
interrupt context records a skip and does not sleep. The exhausted budget is
reported once. Each safe window requests msleep(50). These scheduling chances
do not prove log delivery or flushing. Sixty requests mean at most 3000 ms of
requested sleeps, not a wall-clock upper bound.

Under the observed three-CMD-mode configuration, with one successful DSI init,
no DFPS duplication or callback recursion, the source path is estimated at 47
attempts (third panel-mode entry at sequence 19); this is not a device result.
No mode, DSC, refresh-rate, return value, DT, hardware-register operation or
core kernel configuration is changed. Additional scheduling changes timing.

The bundle retains all 59 mandatory R25 format literals and adds six R27
formats. Compiled presence means neither runtime execution nor successful boot.
The build collector must reject an old module without the new parameter/helper.

Apply to a pristine pinned modules checkout (or exact current R27 after bytes):
python3 apply_probe.py --modules-root /absolute/modules --report /outside/apply.json
All eight targets and payload hashes are checked before the first replacement.
Unknown contents are rejected; R25's four newly instrumented files are not
silently treated as pristine inputs. Replacement is atomic per file, not a
multi-file transaction. Reapplying the exact complete R27 result is idempotent.

Local verification:
python3 verify_structure.py --report /outside/structure.json
python3 -m unittest discover -s tests -v

Host tests compile the actual extracted helper using explicit kernel stubs and
check its print formats, owner/token behavior, skips and budget. They do not
compile Qualcomm driver code or prove target ABI, kernel concurrency or sleep
behavior. Full CI compilation and subsequent reviewed device testing remain.
