#!/usr/bin/env python3
"""Apply the pinned R27 source fix and diagnostic payload; never builds or uses a device."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile


MANIFEST_SHA256 = "e7ab324df39c3de6aa58d5b2f3523f3425dd858194a09b6bf2ae2c21ea43bc4a"
BUNDLE_ROOT = Path(__file__).absolute().parent
HEX = re.compile(r"[0-9a-f]{64}")


class Refused(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise Refused(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def absolute(path):
    return Path(os.path.abspath(os.fspath(path)))


def checked(path, kind="file", missing_leaf=False):
    """Reject symlinks/junctions in every component, including the root path."""
    path = absolute(path)
    current = Path(path.anchor)
    components = [current]
    for part in path.parts[1:]:
        current = current / part
        components.append(current)
    for current in components:
        try:
            info = current.lstat()
        except FileNotFoundError:
            if missing_leaf and current == path:
                return None
            raise Refused("Path does not exist: " + str(current))
        reparse = getattr(info, "st_file_attributes", 0) & 0x400
        require(not stat.S_ISLNK(info.st_mode) and not reparse,
                "Symlink/reparse path is forbidden: " + str(current))
        if current != path or kind == "directory":
            require(stat.S_ISDIR(info.st_mode), "Expected directory: " + str(current))
        else:
            require(stat.S_ISREG(info.st_mode), "Expected regular file: " + str(current))
    return info


def relative(root, value):
    require(isinstance(value, str) and value and "\\" not in value
            and ":" not in value and "\0" not in value, "Invalid relative path")
    pure = PurePosixPath(value)
    require(not pure.is_absolute() and value == pure.as_posix()
            and all(p not in (".", "..") for p in pure.parts),
            "Relative path escapes or is noncanonical: " + value)
    return root.joinpath(*pure.parts)


def read_regular(path):
    expected = checked(path)
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, "rb") as handle:
        opened = os.fstat(handle.fileno())
        require(stat.S_ISREG(opened.st_mode) and os.path.samestat(expected, opened),
                "File changed while opening: " + str(path))
        data = handle.read()
        ended = os.fstat(handle.fileno())
    require((opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns)
            == (ended.st_size, ended.st_mtime_ns, ended.st_ctime_ns),
            "File changed while reading: " + str(path))
    return data, ended


def inside(path, root):
    return path == root or root in path.parents


def validate_report(path, modules_root, bundle_root):
    require(not inside(path, modules_root) and not inside(path, bundle_root),
            "Report must be outside both modules-root and the probe bundle")
    checked(path.parent, "directory")
    checked(path, missing_leaf=True)


def write_report(path, report):
    checked(path, missing_leaf=True)
    fd, name = tempfile.mkstemp(prefix=".r27-report-", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write((json.dumps(report, indent=2) + "\n").encode())
            handle.flush()
            os.fsync(handle.fileno())
        checked(path, missing_leaf=True)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def preflight(modules_root, bundle_root):
    checked(modules_root, "directory")
    checked(bundle_root, "directory")
    require(HEX.fullmatch(MANIFEST_SHA256) is not None,
            "Manifest pin has not been frozen; no source changes made")
    manifest_bytes, _ = read_regular(bundle_root / "manifest.json")
    require(digest(manifest_bytes) == MANIFEST_SHA256, "Manifest SHA256 mismatch")
    manifest = json.loads(manifest_bytes)
    require(manifest.get("schema") == 1, "Unsupported manifest schema")
    files = manifest.get("files")
    require(isinstance(files, list) and len(files) == 8, "Expected exactly eight target files")
    patch = manifest["patch"]
    require(HEX.fullmatch(patch["sha256"]) is not None, "Invalid patch SHA256")
    patch_path = relative(bundle_root, patch["path"])
    patch_bytes, _ = read_regular(patch_path)
    require(digest(patch_bytes) == patch["sha256"], "Patch payload SHA256 mismatch")
    if "patch_sha256" in manifest:
        require(manifest["patch_sha256"] == patch["sha256"], "Patch pins disagree")
    targets, payloads, prepared = set(), {os.path.normcase(str(patch_path))}, []
    for entry in files:
        target = relative(modules_root, entry["path"])
        key = os.path.normcase(str(target))
        require(key not in targets, "Duplicate target path")
        require(not inside(target, bundle_root), "Target overlaps the probe bundle")
        targets.add(key)
        content = {}
        for stage in ("before", "after"):
            expected = entry[stage + "_sha256"]
            require(HEX.fullmatch(expected) is not None, "Invalid payload SHA256")
            payload = relative(bundle_root, entry[stage + "_file"])
            key = os.path.normcase(str(payload))
            require(key not in payloads, "Duplicate/overlapping payload path")
            payloads.add(key)
            content[stage], _ = read_regular(payload)
            require(digest(content[stage]) == expected,
                    stage + " payload SHA256 mismatch: " + entry["path"])
        require(entry["before_sha256"] != entry["after_sha256"], "Probe has identical before/after pins")
        current, info = read_regular(target)
        current_hash = digest(current)
        require(current_hash in (entry["before_sha256"], entry["after_sha256"]),
                "Unknown source SHA256; no source writes: " + entry["path"])
        prepared.append(dict(path=target, entry=entry, current_hash=current_hash,
                             mode=stat.S_IMODE(info.st_mode), after=content["after"],
                             needs_write=current_hash == entry["before_sha256"]))
    return manifest, prepared


def apply(modules_root, report_path, bundle_root=BUNDLE_ROOT):
    """All content gates precede temporary files and the first source replacement."""
    modules_root, bundle_root, report_path = map(absolute, (modules_root, bundle_root, report_path))
    report = dict(schema=1, status="refused", compiled=False, device_operations=False,
                  manifest_sha256=MANIFEST_SHA256, modules_root=str(modules_root),
                  source_files_replaced=[], already_applied=[],
                  atomicity="Atomic replacement per file; not a multi-file transaction")
    temporary_files = []
    report_safe = False
    code = 1
    try:
        validate_report(report_path, modules_root, bundle_root)
        report_safe = True
        manifest, prepared = preflight(modules_root, bundle_root)
        report["patch_id"] = manifest.get("patch_id")
        report["preflight_all_eight_passed"] = True
        report["already_applied"] = [p["entry"]["path"] for p in prepared if not p["needs_write"]]
        for item in prepared:
            if not item["needs_write"]:
                continue
            checked(item["path"].parent, "directory")
            fd, name = tempfile.mkstemp(prefix=".r27-probe-", dir=item["path"].parent)
            temporary = Path(name)
            temporary_files.append(temporary)
            item["temporary"] = temporary
            with os.fdopen(fd, "wb") as handle:
                handle.write(item["after"])
                handle.flush()
                os.chmod(temporary, item["mode"])
                os.fsync(handle.fileno())
        # Revalidate the whole source set after staging, before any replacement.
        for item in prepared:
            data, info = read_regular(item["path"])
            require(digest(data) == item["current_hash"]
                    and stat.S_IMODE(info.st_mode) == item["mode"],
                    "Source changed after preflight: " + item["entry"]["path"])
        for item in prepared:
            if not item["needs_write"]:
                continue
            checked(item["path"])
            checked(item["temporary"])
            os.replace(item["temporary"], item["path"])
            report["source_files_replaced"].append(item["entry"]["path"])
        report["files"] = []
        for item in prepared:
            data, info = read_regular(item["path"])
            require(digest(data) == item["entry"]["after_sha256"]
                    and stat.S_IMODE(info.st_mode) == item["mode"], "Post-write validation failed")
            report["files"].append(dict(path=item["entry"]["path"], sha256=digest(data),
                                        mode=oct(item["mode"])))
        report.update(status="applied" if report["source_files_replaced"] else "already_applied",
                      message="Pinned source patch applied/verified only; not compiled or tested on device.")
        code = 0
    except (Exception, KeyboardInterrupt) as error:
        report["error"] = str(error) or type(error).__name__
        if report["source_files_replaced"]:
            report["status"] = "partial_failure"
        print("STOP: " + report["error"], file=sys.stderr)
    finally:
        for temporary in temporary_files:
            temporary.unlink(missing_ok=True)
    if report_safe:
        try:
            write_report(report_path, report)
        except Exception as error:
            print("Cannot write report: " + str(error), file=sys.stderr)
            code = 1
    if code == 0:
        print(report["message"])
    return code


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--modules-root", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path,
                        help="JSON path in an existing directory outside modules-root and the probe bundle")
    args = parser.parse_args(argv)
    return apply(args.modules_root, args.report)


if __name__ == "__main__":
    sys.exit(main())
