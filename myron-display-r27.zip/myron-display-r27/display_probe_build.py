#!/usr/bin/env python3
"""Build and audit one R27 bounded DSI log window diagnostic candidate, never a partition image.

The unchanged R18 source bundle supplies preparation, configuration and the
ELF reader. A cold build still compiles the kernel and declared prerequisites.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
BUILD_ID = 'R27-DSI-LOG-WINDOWS-20261012-01'
MARKER_PREFIXES = ('MYRON_R21 ', 'MYRON_R23 ', 'MYRON_R25 ', 'MYRON_R27 ')
UNSAFE_HWFENCE_FORMAT = 'hwfence registered ctl:%d client:%d handle:0x%pK tx_wm:0x%x wr_idx:0x%x\n'
SAFE_HWFENCE_FORMAT = 'hwfence registered ctl:%d client:%d handle:0x%pK tx_wm:0x%x\n'
DISPLAY = '//vendor/qcom/sm8850-modules/qcom/opensource/display-drivers:canoe_perf_msm_drm'
TARGETS = [DISPLAY, '//common:kernel_aarch64', '//myron_artifact_metadata:kernel_release']
CORE = 'bazel-out/aarch64-fastbuild/bin/common/kernel_aarch64/'
MODULE = ('bazel-out/aarch64-fastbuild/bin/vendor/qcom/sm8850-modules/'
          'qcom/opensource/display-drivers/canoe_perf_msm_drm/msm_drm.ko')
MODULE_SYMVERS = MODULE.rsplit('/', 1)[0] + '/canoe_perf_msm_drm_Module.symvers'
MODULE_ACTIONS = {'KernelModule', 'KernelModuleProcessWrapperSandbox'}
R18_ZIP_SHA = 'a3c7e97e4a28f6574a619bcc10dab8962911ed5fcef8617aeb7fc835bdbe7d13'
EXPECTED = {
    'config_sha256': '1694fba9900e978fb9494250fb5be8515d022b8b52062721b1a2d267f92490c0',
    'core_symvers_sha256': '9d69a48179b0288dbd452dffc061f7754fba09d507fba3086161dfb019c496e3',
    'kernel_release': '6.12.81-android16-6-maybe-dirty-4k',
    'full_vermagic': '6.12.81-android16-6-maybe-dirty-4k SMP preempt mod_unload modversions aarch64',
}
CORE_REQUIRED = {'Image', 'vmlinux.symvers', 'kernel_aarch64_Module.symvers',
                 'kernel_aarch64_dot_config', 'include/config/kernel.release',
                 'modules.builtin', 'modules.builtin.modinfo'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def safe_path(value):
    p = PurePosixPath(value)
    require(value and not p.is_absolute() and '..' not in p.parts
            and '\\' not in value and '\x00' not in value
            and str(p) == value and not any(ord(c) < 32 for c in value),
            'Unsafe declared path: ' + repr(value))
    return p


def verify_bundle():
    lock = json.loads((HERE / 'bundle-lock.json').read_text())
    seen = set()
    for item in lock['files']:
        relative = safe_path(item['path'])
        require(str(relative) not in seen, 'Duplicate bundle entry')
        seen.add(str(relative))
        path = HERE / relative
        require(path.is_file() and path.resolve().is_relative_to(HERE), 'Missing/escaping bundle file')
        data = path.read_bytes()
        require(sha(data) == item['sha256'], 'Bundle hash mismatch: ' + str(relative))
        if 'bytes' in item:
            require(len(data) == item['bytes'], 'Bundle size mismatch')
    require({'display_probe_build.py', 'probe-patch/apply_probe.py',
             'probe-patch/manifest.json', 'baseline/myron-boot-r18.zip',
             'baseline/r25-required-markers.json', 'elf_window_contract.py'} <= seen,
            'Incomplete R27 bundle lock')
    require(sha((HERE / 'baseline/myron-boot-r18.zip').read_bytes()) == R18_ZIP_SHA,
            'R18 baseline archive changed')
    return sha((HERE / 'bundle-lock.json').read_bytes())


def commands(bazel, options):
    """Exactly the same build configuration must select cquery providers."""
    query = 'set(' + ' '.join(TARGETS) + ')'
    return (list(bazel) + ['build'] + list(options) + TARGETS,
            list(bazel) + ['cquery'] + list(options) + ['--output=files', query],
            list(bazel) + ['aquery'] + list(options) +
            ['--output=jsonproto', '--include_artifacts=true',
             'mnemonic("^KernelModule(ProcessWrapperSandbox)?$", ' + DISPLAY + ')'])


def action_evidence(graph):
    """Resolve only the selected module action's inputs, not deps DefaultInfo.

    Kleaf compiles a dependency's Symvers/staging in KernelModule and copies
    its public .ko in a separate KernelModuleCpOutputs action. Merely building
    a consumer never requests that dependency's public KO copy. The selected
    consumer action's input depsets are the exact files it actually needed.
    """
    def index(name):
        result = {}
        for item in graph.get(name, []):
            key = str(item['id'])
            require(key not in result, 'Duplicate aquery ' + name + ' ID')
            result[key] = item
        return result

    fragments, artifacts = index('pathFragments'), index('artifacts')
    targets, depsets = index('targets'), index('depSetOfFiles')
    resolved = {}

    def fragment(key):
        key = str(key)
        parts, seen = [], set()
        while key not in ('0', ''):
            require(key in fragments and key not in seen, 'Missing/cyclic aquery path fragment')
            seen.add(key)
            node = fragments[key]
            require(node['label'] and '/' not in node['label'] and '\\' not in node['label'],
                    'Invalid aquery path fragment')
            parts.append(node['label'])
            key = str(node.get('parentId', 0))
        return str(safe_path('/'.join(reversed(parts))))

    def artifact(key):
        key = str(key)
        require(key in artifacts, 'Missing aquery artifact')
        if key not in resolved:
            row = artifacts[key]
            if 'execPath' in row:
                resolved[key] = str(safe_path(row['execPath']))
            else:
                resolved[key] = fragment(row['pathFragmentId'])
        return resolved[key]

    matches = []
    for action in graph.get('actions', []):
        target = targets.get(str(action.get('targetId')))
        require(target is not None, 'Missing aquery action target')
        label = target['label'].removeprefix('@@')
        if action.get('mnemonic') in MODULE_ACTIONS and label == DISPLAY:
            matches.append(action)
    require(len(matches) == 1, 'Expected exactly one configured msm_drm KernelModule action')
    selected = matches[0]
    outputs = sorted({artifact(k) for k in selected.get('outputIds', [])})
    require(MODULE_SYMVERS in outputs, 'Selected action does not produce the pinned target Symvers')
    require(selected.get('actionKey'), 'Missing action identity')

    # Iterative traversal handles large depsets without recursion limits.
    pending = list(selected.get('inputDepSetIds', []))
    seen, input_ids = set(), set()
    while pending:
        key = str(pending.pop())
        if key in seen:
            continue
        require(key in depsets, 'Missing aquery input depset')
        seen.add(key)
        node = depsets[key]
        input_ids.update(str(k) for k in node.get('directArtifactIds', []))
        pending.extend(node.get('transitiveDepSetIds', []))
    inputs = sorted({artifact(k) for k in input_ids})
    symvers = [s for s in inputs if s.endswith('.symvers')]
    require(symvers and all(s.startswith('bazel-out/') for s in symvers),
            'No valid actual dependency Symvers inputs')
    require(MODULE_SYMVERS not in symvers, 'Target Symvers cannot be its own input')
    return {'schema': 1, 'target': DISPLAY, 'mnemonic': selected['mnemonic'],
            'action_key': selected['actionKey'], 'configuration_id': selected.get('configurationId'),
            'input_count': len(inputs), 'required_symvers': symvers, 'outputs': outputs,
            'policy': 'Exact selected action inputs; dependency public KO copy outputs are not requested.'}


def parse_symvers(data, source):
    rows = []
    for line in data.decode('utf-8').splitlines():
        if not line.strip():
            continue
        fields = line.split('\t')
        require(len(fields) in (4, 5) and re.fullmatch(r'0x[0-9a-fA-F]{8}', fields[0])
                and fields[1] and fields[2] and fields[3].startswith('EXPORT_'),
                'Malformed Symvers row: ' + source)
        rows.append({'symbol': fields[1], 'crc': int(fields[0], 16),
                     'provider': fields[2], 'export': fields[3],
                     'namespace': fields[4] if len(fields) == 5 else '', 'source': source})
    return rows


def symbol_table(symvers):
    table = {}
    for source, data in symvers.items():
        for row in parse_symvers(data, source):
            old = table.get(row['symbol'])
            if old:
                require(all(old[k] == row[k] for k in ('crc', 'provider', 'export', 'namespace')),
                        'Conflicting/duplicate symbol provider: ' + row['symbol'])
                old['sources'].append(source)
            else:
                row['sources'] = [row.pop('source')]
                table[row['symbol']] = row
    return table


def check_module(elf, table):
    imports = []
    imported_ns = set(elf['info'].get('import_ns', []))
    for symbol, crc in sorted(elf['versions'].items()):
        require(symbol in table, 'Missing import provider: ' + symbol)
        row = table[symbol]
        require(row['crc'] == crc, 'Import CRC mismatch: ' + symbol)
        require(not row['namespace'] or row['namespace'] in imported_ns,
                'Missing import namespace: ' + symbol)
        imports.append(dict(row))
    for symbol, crc in elf['export_crcs'].items():
        require(symbol in table and table[symbol]['crc'] == crc
                and PurePosixPath(table[symbol]['provider']).name.replace('-', '_') == 'msm_drm',
                'Target export differs from Symvers: ' + symbol)
    providers = {PurePosixPath(r['provider']).name.replace('-', '_') for r in imports
                 if r['provider'] != 'vmlinux'}
    require(set(elf['depends']) == providers,
            'ELF depends differs from actual imported-symbol providers')
    return imports


def collect(root, paths, destination, parse_elf, patch_manifest, dependency_evidence):
    """Root cquery outputs and exact aquery inputs; never require dependency KOs."""
    require(not destination.exists(), 'Refusing stale output directory')
    destination.mkdir(parents=True)
    manifest = {'schema': 1, 'build_id': BUILD_ID, 'stage': 'display-probe', 'target': DISPLAY,
                'files': [], 'dependency_providers': [], 'kernel_build_inputs': [], 'missing_required_outputs': [],
                'dependency_ko_policy': 'Not requested: Kleaf uses Symvers as consumer inputs, not public KO copies.',
                'flashable': False, 'hardware_tested': False,
                'runtime_compatibility_review_required': True,
                'scope': 'Only msm_drm.ko is a candidate; no boot images or autoload changes.'}
    audit = {'build_id': BUILD_ID, 'success': False, 'r18_core_contract_passed': False,
             'same_build_crc_verified': False, 'hardware_tested': False,
             'expected_r18': EXPECTED, 'limitations':
             'New KO still requires comparison against the actual R18 kernel and 16 RAM providers.'}
    modules, symvers, present, module_data = {}, {}, set(), []
    try:
        # An action-query failure still preserves the already-built root KO
        # and core evidence, but can never produce a successful ABI audit.
        evidence_error = dependency_evidence.get('error')
        if not evidence_error:
            require(dependency_evidence['target'] == DISPLAY and dependency_evidence['mnemonic'] in MODULE_ACTIONS
                    and dependency_evidence['action_key'] and MODULE_SYMVERS in dependency_evidence['outputs'],
                    'Dependency evidence is not bound to the selected module action')
        provider_paths = [] if evidence_error else dependency_evidence['required_symvers']
        require(evidence_error or (provider_paths and len(provider_paths) == len(set(provider_paths))),
                'Invalid dependency input inventory')
        for name in provider_paths:
            safe_path(name)
            require(name.startswith('bazel-out/') and name.endswith('.symvers'), 'Invalid dependency Symvers input')
        declared = list(dict.fromkeys(list(paths) + provider_paths))
        for name in declared:
            rel = safe_path(name)
            require(not name.endswith('/msm_drm.ko') or name == MODULE,
                    'Unexpected msm_drm provider path')
            # deps() also lists source/header inputs: record their names in the
            # cquery report, but never copy unbounded repository source trees.
            if not name.startswith('bazel-out/'):
                continue
            is_module = name == MODULE
            is_symvers = name == MODULE_SYMVERS or name in provider_paths or name in {
                CORE + 'vmlinux.symvers', CORE + 'kernel_aarch64_Module.symvers'}
            is_core = name.startswith(CORE) and name[len(CORE):] in CORE_REQUIRED | {'System.map'}
            if not (is_module or is_symvers or is_core):
                continue
            source = root / rel
            require(source.is_file(), 'Declared build output missing: ' + name)
            data = source.read_bytes()
            entry = {'source': name, 'bytes': len(data), 'sha256': sha(data)}
            if is_module:
                module_data.append((name, data, entry))
            if is_symvers:
                symvers[name] = data
            if name == CORE + 'Image':
                # Identify this build's core, but do not ship a new kernel.
                manifest['kernel_build_inputs'].append(entry)
                present.add(name)
                continue
            target = destination / 'objects' / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            entry['file'] = 'objects/' + name
            manifest['files'].append(entry)
            present.add(name)
        # Save available evidence before parsing/rejecting an ELF. An ABI or
        # malformed-module failure must not discard the newly built candidate.
        for name, data, entry in module_data:
            elf = parse_elf(data)
            module = elf['name']
            require(module not in modules, 'Duplicate module provider: ' + module)
            modules[module] = elf
            entry.update(name=module, full_vermagic=elf['info']['vermagic'][0],
                         depends=elf['depends'], softdeps=elf['softdeps'])
            require((module == 'msm_drm') == (name == MODULE), 'Unexpected msm_drm provider path')
        required = {CORE + n for n in CORE_REQUIRED} | {MODULE, MODULE_SYMVERS} | set(provider_paths)
        manifest['missing_required_outputs'] = sorted(required - present)
        require(not manifest['missing_required_outputs'],
                'Missing required outputs: ' + ', '.join(manifest['missing_required_outputs']))
        require(not evidence_error, 'Actual action input evidence unavailable: ' + str(evidence_error))
        raw = lambda n: ((root if n == 'Image' else destination / 'objects') / (CORE + n)).read_bytes()
        release = raw('include/config/kernel.release').decode().strip()
        audit['actual'] = {'config_sha256': sha(raw('kernel_aarch64_dot_config')),
                           'core_symvers_sha256': sha(raw('vmlinux.symvers')),
                           'kernel_release': release,
                           'full_vermagic': modules['msm_drm']['info']['vermagic'][0],
                           'kernel_image_sha256': sha(raw('Image'))}
        audit['core_checks'] = {k: audit['actual'][k] == v for k, v in EXPECTED.items()}
        audit['r18_core_contract_passed'] = all(audit['core_checks'].values())
        require((b'Linux version ' + release.encode() + b' ') in raw('Image'), 'Image/release mismatch')
        require(modules['msm_drm']['info']['vermagic'] == [EXPECTED['full_vermagic']],
                'Candidate has a different full vermagic')
        markers = patch_manifest['expected_markers']
        require(markers and len(markers) == len(set(markers)) and
                all(isinstance(x, str) and x.startswith(MARKER_PREFIXES)
                    and not any(c in x for c in ('\n', '\r', '\0')) for x in markers),
                'Missing or ambiguous expected probe markers')
        candidate = (destination / 'objects' / MODULE).read_bytes()
        # Source manifests omit the line-ending. Require the complete format
        # suffix including newline + NUL, so a longer lookalike cannot pass.
        audit['marker_match_policy'] = 'Exact manifest marker plus newline and NUL'
        audit['markers'] = {s: (s.encode() + b'\n\0') in candidate for s in markers}
        require(all(audit['markers'].values()), 'Probe marker absent from new msm_drm.ko')
        audit['r27_window_contract'] = check_window_contract(candidate, patch_manifest)
        # These exact, NUL-terminated format suffixes are evidence that the
        # source fix reached this KO. This is not a generic wr_idx ban and
        # does not replace the later actual-ELF instruction review.
        audit['hwfence_debug_format'] = {
            'unsafe_format': UNSAFE_HWFENCE_FORMAT,
            'safe_format': SAFE_HWFENCE_FORMAT,
            'unsafe_format_absent': (UNSAFE_HWFENCE_FORMAT.encode() + b'\0') not in candidate,
            'safe_format_present': (SAFE_HWFENCE_FORMAT.encode() + b'\0') in candidate,
            'actual_elf_instruction_review_required': True,
        }
        require(audit['hwfence_debug_format']['unsafe_format_absent'],
                'Unsafe hwfence debug format remains in new msm_drm.ko')
        require(audit['hwfence_debug_format']['safe_format_present'],
                'Fixed hwfence debug format absent from new msm_drm.ko')
        table = symbol_table(symvers)
        audit['imports'] = check_module(modules['msm_drm'], table)
        manifest['dependency_providers'] = sorted({row['provider'] for row in audit['imports'] if row['provider'] != 'vmlinux'})
        audit['dependency_evidence'] = dependency_evidence
        audit['target_module'] = {'name': 'msm_drm', 'sha256': sha(candidate),
                                 'bytes': len(candidate), 'depends': modules['msm_drm']['depends'],
                                 'softdeps': modules['msm_drm']['softdeps'],
                                 'info': modules['msm_drm']['info']}
        audit['same_build_crc_verified'] = True
        require(audit['r18_core_contract_passed'], 'R18 config/core CRC/release/vermagic contract changed')
        audit['success'] = True
    except Exception as error:
        audit['error'] = str(error)
        raise
    finally:
        write_json(destination / 'artifact-manifest.json', manifest)
        write_json(destination / 'display-audit.json', audit)
        write_json(destination / 'selected-action-inputs.json', dependency_evidence)
        write_json(destination / 'artifact-lock.json', {'schema': 1, 'metadata': {
            n: sha((destination / n).read_bytes()) for n in ('artifact-manifest.json', 'display-audit.json', 'selected-action-inputs.json')}})
        (destination / 'NOT-A-FLASH-PACKAGE.txt').write_text(
            'R27 bounded DSI log window diagnostic build only. Do not flash or replace the running R18 kernel.\n'
            'msm_drm.ko requires an independent R18 + existing-provider ABI review before RAM testing.\n')
    return audit


def check_window_contract(candidate, manifest):
    prior = json.loads((HERE / 'baseline/r25-required-markers.json').read_text())
    require(len(prior) == len(set(prior)) == 59 and set(prior) <= set(manifest['expected_markers']),
            'R25 mandatory marker set was relaxed')
    require(any(s.startswith('MYRON_R27 ') for s in manifest['expected_markers']),
            'No mandatory R27 window markers')
    expected_contract = dict(helper='myron_r27_log_window', parameter='myron_r27_log_windows',
                             parameter_type='bool', parameter_permissions='0444',
                             parameter_default=False, exported=False, noinline=True,
                             limit=60, sleep_ms=50)
    source_contract = manifest.get('r27_window_contract', {})
    require(all(source_contract.get(k) == v for k, v in expected_contract.items()),
            'R27 source log-window contract changed')
    require(set(source_contract.get('elf_required_callers', [])) == {
        'sde_connector_init', 'dsi_connector_get_modes', 'dsi_display_get_modes',
        'dsi_display_get_modes_helper', 'dsi_panel_get_mode'},
        'R27 source/ELF required caller contract differs')
    contract = load('r27_window_contract', HERE / 'elf_window_contract.py')
    return contract.check(candidate, manifest)


def run(args):
    root, package, baseline = args.workspace.resolve(), args.package.resolve(), args.baseline.resolve()
    r18 = args.r18_bundle.resolve()
    reports = root / 'integration-reports'
    output = root / 'integration-artifacts/display-probe'
    status_path = reports / 'r27-display-status.json'
    status = dict(schema=1, build_id=BUILD_ID, success=False, compiled=False, hardware_tested=False,
                  flashable=False, phase='verify', targets=TARGETS,
                  runtime_compatibility_review_required=True)
    reports.mkdir(parents=True, exist_ok=True)
    # A failed/retried invocation cannot upload the previous invocation's KO.
    if not args.dry_run:
        if output.exists():
            shutil.rmtree(output)
        for path in reports.glob('r27-*'):
            if path.is_file():
                path.unlink()
    write_json(status_path, status)
    try:
        require(args.jobs in (2, 4) and args.ram_mb >= 2048, 'Invalid build resources')
        status['bundle_lock_sha256'] = verify_bundle()
        old = load('r27_r18_builder', r18 / 'boot_build.py')
        status['r18_bundle_lock_sha256'] = old.verify_bundle()
        helper = load('r27_r13_driver_check', baseline / 'drivers/driver_check.py')
        runner_data, metadata = helper.verify_bundle(baseline, package / 'build_platform.py')
        status['baseline_runner'] = metadata
        bazel, options = helper.runner_build_configuration(runner_data, root, args.jobs, args.ram_mb)
        build_cmd, cquery_cmd, aquery_cmd = commands(bazel, options)
        write_json(reports / 'r27-command-plan.json', {'build': build_cmd, 'cquery': cquery_cmd, 'aquery': aquery_cmd,
                   'cold_build_note': 'Kernel and all declared prerequisites are built as necessary.'})
        if args.dry_run:
            status.update(phase='dry_run_only', dry_run=True)
            print(json.dumps({'build': build_cmd, 'cquery': cquery_cmd, 'aquery': aquery_cmd}, indent=2))
            return 0
        runner = load('r27_r13_runner', package / 'build_platform.py')
        status['phase'] = 'prepare_unchanged_r18_sources'
        runner.logged([sys.executable, str(package / 'prepare_workspace.py'), '--workspace', str(root)],
                      root, reports / 'r27-prepare.log')
        runner.logged([sys.executable, str(baseline / 'run_r12.py'), 'apply', '--workspace', str(root), '--stage', 'soc'],
                      root, reports / 'r27-r13-apply.log')
        helper.verify_applied_writes(baseline, root)
        runner.logged([sys.executable, str(r18 / 'source-fix/apply_soccp.py'),
                       '--soc', str(root / 'vendor/qcom/sm8850')], root, reports / 'r27-soccp-apply.log')
        status['phase'] = 'apply_display_source_patch'
        patch = HERE / 'probe-patch'
        runner.logged([sys.executable, str(patch / 'apply_probe.py'), '--modules-root',
                       str(root / 'vendor/qcom/sm8850-modules'), '--report', str(reports / 'r27-probe-apply.json')],
                      root, reports / 'r27-probe-apply.log')
        patch_manifest = json.loads((patch / 'manifest.json').read_text())
        status['patch_manifest_sha256'] = sha((patch / 'manifest.json').read_bytes())
        # This helper creates the kernel.release output-group wrapper only;
        # its broad returned list of targets is intentionally never used.
        runner.build_targets(root, 'soc')
        status['phase'] = 'compile_target'
        write_json(status_path, status)
        runner.logged(build_cmd, root, reports / 'r27-display-build.log')
        status['compiled'] = True
        result = subprocess.run(cquery_cmd, cwd=root, capture_output=True, text=True)
        (reports / 'r27-cquery.log').write_text(result.stderr)
        (reports / 'r27-cquery-outputs.txt').write_text(result.stdout)
        require(result.returncode == 0, 'cquery failed; see r27-cquery.log')
        try:
            result_action = subprocess.run(aquery_cmd, cwd=root, capture_output=True, text=True)
            (reports / 'r27-aquery.log').write_text(result_action.stderr)
            (reports / 'r27-aquery.json').write_text(result_action.stdout)
            require(result_action.returncode == 0, 'aquery failed; see r27-aquery.log')
            evidence = action_evidence(json.loads(result_action.stdout))
        except Exception as error:
            evidence = {'error': str(error), 'success': False}
        write_json(reports / 'r27-selected-action-inputs.json', evidence)
        status['phase'] = 'verify_binary'
        elf_reader = load('r27_elf_contract', r18 / 'stage-builder/elf_contract.py')
        audit = collect(root, result.stdout.splitlines(), output, elf_reader.parse_elf, patch_manifest, evidence)
        status.update(success=True, phase='display_source_candidate_verified',
                      r18_core_contract_passed=audit['r18_core_contract_passed'],
                      same_build_crc_verified=audit['same_build_crc_verified'])
    except Exception as error:
        status['error'] = str(error)
        print('R27 STOP:', error, file=sys.stderr)
    finally:
        status['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        write_json(status_path, status)
        if output.is_dir() and not args.dry_run:
            if (HERE / 'probe-patch/manifest.json').is_file():
                shutil.copy2(HERE / 'probe-patch/manifest.json', output / 'probe-patch-manifest.json')
            for path in reports.glob('r27-*'):
                if path.is_file() and path.suffix in ('.json', '.log', '.txt'):
                    shutil.copy2(path, output / path.name)
    return 0 if status['success'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path)
    parser.add_argument('--package', type=Path)
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--r18-bundle', type=Path)
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--ram-mb', type=int, default=10000)
    parser.add_argument('--dry-run', action='store_true', help='Verify prepared bundles and print commands; do not build')
    parser.add_argument('--print-plan', action='store_true', help='Print static scope without a prepared workspace')
    args = parser.parse_args()
    if args.print_plan:
        print(json.dumps({'build_id': BUILD_ID, 'targets': TARGETS, 'candidate': MODULE, 'expected_r18': EXPECTED,
                          'device_operations': False, 'partition_images': False,
                          'cold_build_includes_kernel_and_prerequisites': True}, indent=2))
        return 0
    if not all((args.workspace, args.package, args.baseline, args.r18_bundle)):
        parser.error('--workspace --package --baseline --r18-bundle are required unless --print-plan')
    return run(args)


if __name__ == '__main__':
    sys.exit(main())
