"""Small synthetic AArch64 ET_REL fixtures for R27 structural gates.

These are deliberately not loadable kernel modules or claims of compilation.
The independent post-build review must inspect the actual compiled candidate.
"""
import importlib.util
from pathlib import Path
import struct
import unittest

spec = importlib.util.spec_from_file_location('window_elf', Path(__file__).resolve().parents[1] / 'elf_window_contract.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
MARKER = 'MYRON_R27 fixture=%d'
MANIFEST = {'build_id': m.BUILD_ID, 'expected_markers': [MARKER]}


def fixture(permission=0o444, default=0, ops='param_ops_bool', exported=False,
            helper=True, calls=True, code_marker=True, allocated_marker=True,
            parmtype=True, bad_opcode=False, nobits=False, section_call=False):
    # Build real ELF sections, symbols and relocations without cross-tools.
    sections = [dict(name='', type=0, flags=0, data=b'', link=0, info=0, entsize=0)]
    def section(name, data=b'', kind=1, flags=0, link=0, info=0, entsize=0):
        sections.append(dict(name=name, data=data, type=kind, flags=flags, link=link, info=info, entsize=entsize))
        return len(sections)-1
    text = section('.text', struct.pack('<II', 0x90000000, 0xd65f03c0) +
                   b''.join(struct.pack('<II', 0xd503201f if bad_opcode else 0x94000000, 0xd65f03c0) for _ in range(5)), flags=6)
    ro = section('.rodata', m.PARAM.encode() + b'\0\x016' + MARKER.encode() + b'\n\0', flags=2 if allocated_marker else 0)
    paramraw = bytearray(40)
    struct.pack_into('<H', paramraw, 24, permission)
    param = section('__param', bytes(paramraw), flags=2)
    var = section('.bss' if nobits else '.data', bytes([default]), kind=8 if nobits else 1, flags=3)
    section('.modinfo', b'parmtype=' + m.PARAM.encode() + (b':bool\0' if parmtype else b':int\0'), flags=2)
    symbols = [('', 0, 0, 0, 0)]
    def sym(name, info, index, value, size):
        symbols.append((name, info, index, value, size))
        return len(symbols)-1
    rosym = sym('', 3, ro, 0, 0)
    varsym = sym(m.PARAM, 1, var, 0, 1)
    sym('__param_' + m.PARAM, 1, param, 0, 40)
    opsym = sym(ops, 16, 0, 0, 0)
    hs = sym(m.HELPER, 18, text if helper else 0, 0, 8 if helper else 0)
    textsym = sym('', 3, text, 0, 0)
    if exported:
        sym('__ksymtab_' + m.HELPER, 1, ro, 0, 8)
    for i, name in enumerate(['sde_connector_init', 'dsi_connector_get_modes', 'dsi_display_get_modes', 'dsi_display_get_modes_helper', 'dsi_panel_get_mode']):
        sym(name, 18, text, 8+i*8, 8)
    strings = b'\0'
    symboldata = bytearray()
    for name, info, index, value, size in symbols:
        offset = len(strings)
        strings += name.encode()+b'\0'
        symboldata += struct.pack('<IBBHQQ', offset, info, 0, index, value, size)
    strtab = section('.strtab', strings, kind=3)
    symtab = section('.symtab', bytes(symboldata), kind=2, link=strtab, entsize=24)
    paramrels = [(0, rosym, 257, 0), (16, opsym, 257, 0), (32, varsym, 257, 0)]
    textrels = [(8+i*8, textsym if section_call else hs, 283, 0) for i in range(5)] if calls else []
    if code_marker:
        textrels.append((0, rosym, 275, len(m.PARAM)+1))
    for name, target, rows in [('.rela__param', param, paramrels), ('.rela.text', text, textrels)]:
        raw = b''.join(struct.pack('<QQq', addr, sy << 32 | kind, add) for addr, sy, kind, add in rows)
        section(name, raw, kind=4, link=symtab, info=target, entsize=24)
    shstr = section('.shstrtab', kind=3)
    shstrings = b'\0'
    for item in sections:
        item['nameoffset'] = len(shstrings)
        shstrings += item['name'].encode()+b'\0'
    sections[shstr]['data'] = shstrings
    output = bytearray(64)
    for item in sections:
        output += b'\0' * (-len(output) % 8)
        item['offset'] = len(output)
        if item['type'] != 8:
            output += item['data']
    output += b'\0' * (-len(output) % 8)
    shoff = len(output)
    for item in sections:
        output += struct.pack('<IIQQQQIIQQ', item['nameoffset'], item['type'], item['flags'], 0,
                              item['offset'], len(item['data']), item['link'], item['info'], 8, item['entsize'])
    ident = b'\x7fELF\x02\x01\x01' + b'\0'*9
    struct.pack_into('<16sHHIQQQIHHHHHH', output, 0, ident, 1, 183, 1, 0, 0, shoff, 0, 64, 0, 0, 64, len(sections), shstr)
    return bytes(output)


class WindowElf(unittest.TestCase):
    def test_positive_real_elf_structure(self):
        result = m.check(fixture(), MANIFEST)
        self.assertTrue(result['success'])
        self.assertEqual(len(result['helper']['calls']), 5)
        self.assertEqual(result['parameter']['permission_octal'], '0444')

    def test_section_symbol_calls_and_zero_bss_are_supported(self):
        self.assertTrue(m.check(fixture(section_call=True, nobits=True), MANIFEST)['success'])

    def test_readwrite_parameter_rejected(self):
        with self.assertRaisesRegex(ValueError, 'permissions'):
            m.check(fixture(permission=0o644), MANIFEST)

    def test_enabled_default_rejected(self):
        with self.assertRaisesRegex(ValueError, 'default is not false'):
            m.check(fixture(default=1), MANIFEST)

    def test_wrong_parameter_ops_rejected(self):
        with self.assertRaisesRegex(ValueError, 'bool operations'):
            m.check(fixture(ops='param_ops_int'), MANIFEST)

    def test_wrong_parmtype_rejected(self):
        with self.assertRaisesRegex(ValueError, 'bool parmtype'):
            m.check(fixture(parmtype=False), MANIFEST)

    def test_exported_helper_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unexpectedly exported'):
            m.check(fixture(exported=True), MANIFEST)

    def test_only_undefined_helper_rejected(self):
        with self.assertRaisesRegex(ValueError, 'undefined symbol'):
            m.check(fixture(helper=False), MANIFEST)

    def test_unused_helper_rejected(self):
        with self.assertRaisesRegex(ValueError, 'helper calls absent'):
            m.check(fixture(calls=False), MANIFEST)

    def test_invalid_call_opcode_rejected(self):
        with self.assertRaisesRegex(ValueError, 'not on a branch instruction'):
            m.check(fixture(bad_opcode=True), MANIFEST)

    def test_unused_marker_string_rejected(self):
        with self.assertRaisesRegex(ValueError, 'lacks executable relocation'):
            m.check(fixture(code_marker=False), MANIFEST)

    def test_appended_marker_outside_allocated_data_rejected(self):
        with self.assertRaisesRegex(ValueError, 'absent from allocated'):
            m.check(fixture(allocated_marker=False) + (MARKER+'\n\0').encode(), MANIFEST)

    def test_wrong_build_identity_rejected(self):
        with self.assertRaisesRegex(ValueError, 'wrong source build identity'):
            m.check(fixture(), dict(MANIFEST, build_id='R25'))

    def test_truncated_elf_rejected(self):
        with self.assertRaisesRegex(ValueError, 'bad section table'):
            m.check(fixture()[:-1], MANIFEST)


if __name__ == '__main__':
    unittest.main()
