#!/usr/bin/env python3
"""Focused offline tests. No kernel build, network or device command is run."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

SOURCE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('display_probe_build', SOURCE / 'display_probe_build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Collection(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.out = self.root / 'result'
        self.dep = m.MODULE.replace('canoe_perf_msm_drm/msm_drm.ko', 'canoe_perf_supplier/supplier.ko')
        self.dep_sym = self.dep.replace('/supplier.ko', '/supplier_Module.symvers')
        self.config = b'CONFIG_ARM64_4K_PAGES=y\n'
        self.core = b'0x00000001\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\t\n'
        self.files = {
            m.CORE + 'Image': b'Linux version fixture ' + b'not-a-boot-image',
            m.CORE + 'kernel_aarch64_dot_config': self.config,
            m.CORE + 'vmlinux.symvers': self.core,
            m.CORE + 'kernel_aarch64_Module.symvers': self.core,
            m.CORE + 'include/config/kernel.release': b'fixture\n',
            m.CORE + 'modules.builtin': b'', m.CORE + 'modules.builtin.modinfo': b'',
            m.MODULE: b'msm_drm MYRON_R21 probe=%d\n\0' + m.SAFE_HWFENCE_FORMAT.encode() + b'\0',
            self.dep: b'supplier',
            m.MODULE_SYMVERS: b'0x00000003\tdisplay_export\t../display/msm_drm\tEXPORT_SYMBOL_GPL\t\n',
            self.dep_sym: b'0x00000002\tsupply\t../supplier\tEXPORT_SYMBOL_GPL\tNS_SUPPLIER\n',
        }
        self.marker = {'expected_markers': ['MYRON_R21 probe=%d']}
        self.evidence = {'target': m.DISPLAY, 'mnemonic': 'KernelModule', 'action_key': 'fixture-action',
                         'outputs': [m.MODULE_SYMVERS], 'required_symvers': [self.dep_sym]}
        self.expected = {'config_sha256': m.sha(self.config), 'core_symvers_sha256': m.sha(self.core),
                         'kernel_release': 'fixture', 'full_vermagic': 'fixture SMP'}
        self.pin = patch.object(m, 'EXPECTED', self.expected)
        self.pin.start()
        self.addCleanup(self.pin.stop)
        # These collector fixtures deliberately are not real ELF. Structural
        # R27 ELF evidence has separate real-ELF positive/negative fixtures.
        self.window = patch.object(m, 'check_window_contract', return_value={'success': True, 'synthetic_fixture': True})
        self.window.start()
        self.addCleanup(self.window.stop)

    def elf(self, data):
        name = 'msm_drm' if data.startswith(b'msm_drm') else 'supplier'
        return dict(name=name, info={'name': [name], 'vermagic': ['fixture SMP'], 'import_ns': ['NS_SUPPLIER']},
                    versions={'module_layout': 1, 'supply': 2}, export_crcs={'display_export': 3} if name == 'msm_drm' else {},
                    depends=['supplier'] if name == 'msm_drm' else [], softdeps=[])

    def collect(self, extra=()):
        for name, data in self.files.items():
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        return m.collect(self.root, list(self.files) + list(extra), self.out, self.elf, self.marker, self.evidence)

    def test_complete_only_target_ko_and_metadata_are_copied(self):
        result = self.collect(['vendor/source/header.h'])
        self.assertTrue(result['success'])
        self.assertTrue(result['same_build_crc_verified'])
        self.assertEqual([p.name for p in self.out.rglob('*.ko')], ['msm_drm.ko'])
        self.assertFalse(list(self.out.rglob('Image')))
        manifest = json.loads((self.out / 'artifact-manifest.json').read_text())
        self.assertEqual(manifest['dependency_providers'], ['../supplier'])
        self.assertEqual(manifest['kernel_build_inputs'][0]['sha256'], m.sha(self.files[m.CORE + 'Image']))
        self.assertFalse(manifest['flashable'])
        self.assertTrue(manifest['runtime_compatibility_review_required'])

    def test_missing_dependency_symvers_is_not_silently_ignored(self):
        del self.files[self.dep_sym]
        with self.assertRaisesRegex(ValueError, 'Declared build output missing'):
            self.collect()
        self.assertFalse(json.loads((self.out / 'display-audit.json').read_text())['success'])

    def test_real_failed_cquery_default_outputs_do_not_require_dependency_ko_copies(self):
        # Real run 38140336185 declarations, including the missing llcc-qcom.ko.
        # The action input evidence is a small explicit fixture, not claimed
        # to be an aquery capture from that historical run (none was saved).
        rows = (SOURCE / 'tests/fixtures/real-declared-outputs.txt').read_text().splitlines()
        self.assertTrue(any('/llcc-qcom/llcc-qcom.ko' in x for x in rows))
        self.assertEqual(sum(x.endswith('.ko') for x in rows), 74)
        self.assertEqual(sum(x.endswith('.symvers') for x in rows), 76)
        del self.files[self.dep]  # dependency KO copy is also absent
        self.files[m.CORE + 'System.map'] = b'fixture system map\n'
        self.assertTrue(self.collect(rows)['success'])
        self.assertEqual([p.name for p in self.out.rglob('*.ko')], ['msm_drm.ko'])

    def test_candidate_ko_is_still_mandatory(self):
        del self.files[m.MODULE]
        with self.assertRaisesRegex(ValueError, 'Missing required outputs'):
            self.collect()

    def test_action_provider_inventory_must_cover_actual_imports(self):
        # No missing-file bypass: a valid file without the required symbol
        # still cannot establish the candidate's imported provider.
        self.files[self.dep_sym] = b''
        with self.assertRaisesRegex(ValueError, 'Missing import provider: supply'):
            self.collect()

    def test_failed_aquery_keeps_candidate_but_never_passes(self):
        self.evidence = {'error': 'aquery failed', 'success': False}
        with self.assertRaisesRegex(ValueError, 'Actual action input evidence unavailable'):
            self.collect()
        self.assertTrue((self.out / 'objects' / m.MODULE).is_file())
        audit = json.loads((self.out / 'display-audit.json').read_text())
        self.assertFalse(audit['success'])
        self.assertFalse(audit['same_build_crc_verified'])

    def test_crc_mismatch_fails_and_retains_candidate_and_audit(self):
        self.files[self.dep_sym] = self.files[self.dep_sym].replace(b'0x00000002', b'0x00000009')
        with self.assertRaisesRegex(ValueError, 'CRC mismatch: supply'):
            self.collect()
        self.assertTrue((self.out / 'objects' / m.MODULE).is_file())
        self.assertTrue((self.out / 'artifact-lock.json').is_file())

    def test_changed_core_contract_is_failure_with_diagnostic_output(self):
        self.files[m.CORE + 'kernel_aarch64_dot_config'] += b'CONFIG_UNEXPECTED=y\n'
        with self.assertRaisesRegex(ValueError, 'R18 config/core CRC'):
            self.collect()
        audit = json.loads((self.out / 'display-audit.json').read_text())
        self.assertFalse(audit['r18_core_contract_passed'])
        self.assertTrue(audit['same_build_crc_verified'])

    def test_reject_stale_directory(self):
        self.out.mkdir()
        (self.out / 'old.ko').write_bytes(b'old')
        with self.assertRaisesRegex(ValueError, 'stale output'):
            self.collect()
        self.assertEqual((self.out / 'old.ko').read_bytes(), b'old')

    def test_reject_path_escape(self):
        with self.assertRaisesRegex(ValueError, 'Unsafe declared path'):
            self.collect(['bazel-out/../../escape.ko'])

    def test_reject_duplicate_target_provider(self):
        self.files[m.MODULE.replace('canoe_perf_', 'canoe_consolidate_')] = self.files[m.MODULE]
        with self.assertRaisesRegex(ValueError, 'Unexpected msm_drm provider path'):
            self.collect()

    def test_missing_new_marker_rejects_old_module(self):
        self.files[m.MODULE] = b'msm_drm old uninstrumented module'
        with self.assertRaisesRegex(ValueError, 'Probe marker absent'):
            self.collect()

    def test_failed_structural_elf_audit_cannot_report_success(self):
        self.window.stop()
        with patch.object(m, 'check_window_contract', side_effect=ValueError('R27 ELF contract rejected')):
            with self.assertRaisesRegex(ValueError, 'R27 ELF contract rejected'):
                self.collect()
        audit = json.loads((self.out / 'display-audit.json').read_text())
        self.assertFalse(audit['success'])
        self.assertFalse(audit['same_build_crc_verified'])
        self.assertTrue((self.out / 'objects' / m.MODULE).is_file())

    def test_all_exact_r21_r23_r25_marker_prefixes_are_accepted(self):
        self.marker['expected_markers'].append('MYRON_R23 stage=kms_objects phase=return rc=%d')
        self.files[m.MODULE] += b'MYRON_R23 stage=kms_objects phase=return rc=%d\n\0'
        self.marker['expected_markers'].append('MYRON_R25 stage=panel_mode phase=enter')
        self.files[m.MODULE] += b'MYRON_R25 stage=panel_mode phase=enter\n\0'
        audit = self.collect()
        self.assertTrue(audit['success'])
        self.assertEqual(audit['build_id'], 'R27-DSI-LOG-WINDOWS-20261012-01')
        self.assertEqual(len(audit['markers']), 3)

    def test_r21_markers_do_not_substitute_for_missing_r23_markers(self):
        self.marker['expected_markers'].append('MYRON_R23 stage=irq_domain phase=enter')
        with self.assertRaisesRegex(ValueError, 'Probe marker absent'):
            self.collect()

    def test_lookalike_or_unapproved_marker_prefix_is_rejected(self):
        for marker in ('MYRON_R210 probe=%d', 'MYRON_R23extra probe=%d', 'MYRON_R25extra probe=%d', 'MYRON_R250 probe=%d', 'MYRON_R22 probe=%d'):
            with self.subTest(marker=marker):
                self.out = self.root / marker.split()[0]
                self.marker = {'expected_markers': [marker]}
                self.files[m.MODULE] += marker.encode() + b'\n\0'
                with self.assertRaisesRegex(ValueError, 'Missing or ambiguous expected probe markers'):
                    self.collect()

    def test_old_r21_r23_markers_do_not_substitute_for_r25(self):
        self.marker['expected_markers'].append('MYRON_R25 stage=panel_mode phase=enter')
        self.files[m.MODULE] += b'MYRON_R23 stage=panel_mode phase=enter\n\0'
        with self.assertRaisesRegex(ValueError, 'Probe marker absent'):
            self.collect()

    def test_marker_requires_exact_newline_and_nul_suffix(self):
        marker = self.marker['expected_markers'][0].encode()
        for i, suffix in enumerate((b'', b'\n', b'\0', b' extra\n\0', b'\nextra\0')):
            with self.subTest(suffix=suffix):
                self.out = self.root / ('suffix-' + str(i))
                self.files[m.MODULE] = b'msm_drm ' + marker + suffix + m.SAFE_HWFENCE_FORMAT.encode() + b'\0'
                with self.assertRaisesRegex(ValueError, 'Probe marker absent'):
                    self.collect()

    def test_manifest_marker_with_embedded_control_is_rejected(self):
        for i, control in enumerate(('\n', '\r', '\0')):
            with self.subTest(control=control):
                self.out = self.root / ('control-' + str(i))
                self.marker = {'expected_markers': ['MYRON_R25 stage=panel_mode' + control + 'extra']}
                self.files[m.MODULE] += self.marker['expected_markers'][0].encode() + b'\n\0'
                with self.assertRaisesRegex(ValueError, 'Missing or ambiguous expected probe markers'):
                    self.collect()

    def test_unsafe_hwfence_debug_format_is_rejected_even_with_safe_format(self):
        self.files[m.MODULE] += m.UNSAFE_HWFENCE_FORMAT.encode() + b'\0'
        with self.assertRaisesRegex(ValueError, 'Unsafe hwfence debug format remains'):
            self.collect()
        audit = json.loads((self.out / 'display-audit.json').read_text())
        self.assertFalse(audit['hwfence_debug_format']['unsafe_format_absent'])
        self.assertTrue(audit['hwfence_debug_format']['safe_format_present'])
        self.assertFalse(audit['success'])

    def test_safe_hwfence_debug_format_is_required(self):
        self.files[m.MODULE] = self.files[m.MODULE].replace(m.SAFE_HWFENCE_FORMAT.encode() + b'\0', b'')
        with self.assertRaisesRegex(ValueError, 'Fixed hwfence debug format absent'):
            self.collect()

    def test_other_wr_idx_debug_formats_are_not_rejected(self):
        self.files[m.MODULE] += b'other hwfence wr_idx:0x%x\n\0'
        audit = self.collect()
        self.assertTrue(audit['success'])
        self.assertTrue(audit['hwfence_debug_format']['actual_elf_instruction_review_required'])

    def test_missing_core_metadata_fails(self):
        del self.files[m.CORE + 'kernel_aarch64_Module.symvers']
        with self.assertRaisesRegex(ValueError, 'Missing required outputs'):
            self.collect()

    def test_conflicting_provider_same_crc_is_not_accepted(self):
        self.files[self.dep_sym] += b'0x00000001\tmodule_layout\tanother_provider\tEXPORT_SYMBOL\t\n'
        with self.assertRaisesRegex(ValueError, 'Conflicting/duplicate symbol provider'):
            self.collect()


class SourceContract(unittest.TestCase):
    def setUp(self):
        prior = json.loads((SOURCE / 'baseline/r25-required-markers.json').read_text())
        self.manifest = dict(expected_markers=prior + ['MYRON_R27 test=%d'], r27_window_contract=dict(
            helper='myron_r27_log_window', parameter='myron_r27_log_windows', parameter_type='bool',
            parameter_permissions='0444', parameter_default=False, exported=False, noinline=True,
            limit=60, sleep_ms=50, elf_required_callers=['sde_connector_init', 'dsi_connector_get_modes',
                'dsi_display_get_modes', 'dsi_display_get_modes_helper', 'dsi_panel_get_mode']))

    def test_source_contract_reaches_structural_elf_gate(self):
        module = SimpleNamespace(check=lambda data, manifest: dict(visited=True))
        with patch.object(m, 'load', return_value=module):
            self.assertTrue(m.check_window_contract(b'fixture', self.manifest)['visited'])

    def test_relaxed_legacy_marker_manifest_is_rejected(self):
        self.manifest['expected_markers'].pop(0)
        with self.assertRaisesRegex(ValueError, 'R25 mandatory marker set was relaxed'):
            m.check_window_contract(b'fixture', self.manifest)

    def test_changed_source_window_budget_is_rejected(self):
        self.manifest['r27_window_contract']['limit'] = 61
        with self.assertRaisesRegex(ValueError, 'source log-window contract changed'):
            m.check_window_contract(b'fixture', self.manifest)

    def test_missing_source_required_caller_is_rejected(self):
        self.manifest['r27_window_contract']['elf_required_callers'].pop()
        with self.assertRaisesRegex(ValueError, 'required caller contract differs'):
            m.check_window_contract(b'fixture', self.manifest)


class Entrypoint(unittest.TestCase):
    def test_commands_use_identical_configuration_and_exact_action_query(self):
        options = ['--config=fast', '--jobs=2', '--//kernel:variant=perf']
        build, query, actions = m.commands(['tools/bazel'], options)
        self.assertEqual(build[2:5], options)
        self.assertEqual(query[2:5], options)
        self.assertEqual(build[5:], m.TARGETS)
        self.assertTrue(query[-1].startswith('set('))
        self.assertEqual(actions[2:5], options)
        self.assertEqual(actions[-1], 'mnemonic("^KernelModule(ProcessWrapperSandbox)?$", ' + m.DISPLAY + ')')
        self.assertIn(m.DISPLAY, query[-1])
        self.assertNotIn('kernel_aarch64_modules', build)

    def test_static_plan_and_python_entrypoint(self):
        result = subprocess.run([sys.executable, str(SOURCE / 'display_probe_build.py'), '--print-plan'],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        plan = json.loads(result.stdout)
        self.assertFalse(plan['device_operations'])
        self.assertEqual(plan['targets'], m.TARGETS)

    def test_failed_build_removes_old_success_output(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            output = root / 'integration-artifacts/display-probe'
            output.mkdir(parents=True)
            (output / 'old.ko').write_bytes(b'old')
            args = SimpleNamespace(workspace=root, package=root / 'package', baseline=root / 'baseline',
                                   r18_bundle=root / 'r18', jobs=2, ram_mb=10000, dry_run=False)
            old = SimpleNamespace(verify_bundle=lambda: 'r18-lock')
            helper = SimpleNamespace(verify_bundle=lambda *a: (b'runner', {}),
                                     runner_build_configuration=lambda *a: (['bazel'], []),
                                     verify_applied_writes=lambda *a: None)
            runner = SimpleNamespace(logged=lambda *a: (_ for _ in ()).throw(RuntimeError('prepare failed')))
            with patch.object(m, 'verify_bundle', return_value='lock'), patch.object(m, 'load', side_effect=[old, helper, runner]):
                self.assertEqual(m.run(args), 1)
            self.assertFalse(output.exists())
            status = json.loads((root / 'integration-reports/r27-display-status.json').read_text())
            self.assertFalse(status['success'])
            self.assertFalse(status['compiled'])

    def test_verified_dry_run_has_no_prepare_or_compile(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            args = SimpleNamespace(workspace=root, package=root / 'package', baseline=root / 'baseline',
                                   r18_bundle=root / 'r18', jobs=2, ram_mb=10000, dry_run=True)
            old = SimpleNamespace(verify_bundle=lambda: 'r18-lock')
            helper = SimpleNamespace(verify_bundle=lambda *a: (b'runner', {}),
                                     runner_build_configuration=lambda *a: (['bazel'], ['--config=locked']))
            with patch.object(m, 'verify_bundle', return_value='lock'), patch.object(m, 'load', side_effect=[old, helper]), contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(m.run(args), 0)
            self.assertFalse((root / 'integration-artifacts/display-probe').exists())
            status = json.loads((root / 'integration-reports/r27-display-status.json').read_text())
            self.assertFalse(status['compiled'])
            self.assertFalse(status['success'])
            self.assertEqual(status['phase'], 'dry_run_only')


def graph_fixture():
    """Bazel jsonproto shape with shared path fragments and nested depsets."""
    paths = [m.CORE + 'kernel_aarch64_Module.symvers',
             'bazel-out/aarch64-fastbuild/bin/vendor/qcom/sm8850/provider/provider_Module.symvers',
             m.MODULE_SYMVERS,
             'bazel-out/aarch64-fastbuild/bin/vendor/qcom/sm8850/provider/provider.ko']
    fragments, bypath, artifacts = [], {}, []
    for i, path in enumerate(paths, 1):
        parent, prefix = 0, ''
        for component in path.split('/'):
            prefix += '/' + component
            if prefix not in bypath:
                key = len(fragments) + 1
                bypath[prefix] = key
                fragments.append({'id': key, 'label': component, 'parentId': parent})
            parent = bypath[prefix]
        artifacts.append({'id': i, 'pathFragmentId': parent})
    return {'pathFragments': fragments, 'artifacts': artifacts,
            'targets': [{'id': 1, 'label': m.DISPLAY}, {'id': 2, 'label': '//vendor/qcom/sm8850:provider'}],
            'actions': [{'targetId': 1, 'configurationId': 7, 'actionKey': 'fixture-action',
                         'mnemonic': 'KernelModule', 'inputDepSetIds': [1], 'outputIds': [3]},
                        {'targetId': 2, 'mnemonic': 'KernelModuleCpOutputs', 'outputIds': [4]}],
            'depSetOfFiles': [{'id': 1, 'directArtifactIds': [1], 'transitiveDepSetIds': [2]},
                             {'id': 2, 'directArtifactIds': [2]}]}


class ActualActionInputs(unittest.TestCase):
    def test_local_ddk_strategy_mnemonic_is_accepted_but_copy_is_not(self):
        graph = graph_fixture()
        graph['actions'][0]['mnemonic'] = 'KernelModuleProcessWrapperSandbox'
        self.assertEqual(m.action_evidence(graph)['mnemonic'], 'KernelModuleProcessWrapperSandbox')
        graph['actions'][0]['mnemonic'] = 'KernelModuleCpOutputs'
        with self.assertRaisesRegex(ValueError, 'exactly one configured'):
            m.action_evidence(graph)

    def test_resolves_only_selected_action_symvers_inputs(self):
        result = m.action_evidence(graph_fixture())
        self.assertEqual(len(result['required_symvers']), 2)
        self.assertTrue(all(x.endswith('.symvers') for x in result['required_symvers']))
        self.assertNotIn(m.MODULE_SYMVERS, result['required_symvers'])
        self.assertEqual(result['input_count'], 2)

    def test_duplicate_configured_candidate_action_is_rejected(self):
        graph = graph_fixture()
        graph['actions'].append(dict(graph['actions'][0], configurationId=8))
        with self.assertRaisesRegex(ValueError, 'exactly one configured'):
            m.action_evidence(graph)

    def test_missing_input_depset_is_rejected(self):
        graph = graph_fixture()
        graph['depSetOfFiles'].pop()
        with self.assertRaisesRegex(ValueError, 'Missing aquery input depset'):
            m.action_evidence(graph)

    def test_wrong_target_action_output_is_rejected(self):
        graph = graph_fixture()
        graph['actions'][0]['outputIds'] = [4]
        with self.assertRaisesRegex(ValueError, 'pinned target Symvers'):
            m.action_evidence(graph)


if __name__ == '__main__':
    unittest.main()
