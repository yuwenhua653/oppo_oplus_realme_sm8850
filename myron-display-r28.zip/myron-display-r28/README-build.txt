R28 DP AUX 空指针修复候选源码构建包
构建身份：R28-DP-AUX-NULL-FIX-20261012-01

R27 实机已获得故障栈。R28 在 DP AUX switch 选择中，对两个 strcmp 前的
aux_switch_node 增加非空短路判断；无节点时沿用原有无 AUX switch 分支。
增加一条 MYRON_R28 stage=dp_aux_switch_selected INFO 记录所选路径。
这是针对已定位故障的源码修复候选，尚未编译或实机验证，不代表已能完整开机。

继承的构建条件
  - 原 R27 八个修改后源码文件逐字节保留，第九个文件为 dp_display.c。
  - 原 R27 的 myron_r27_log_windows 参数和 myron_r27_log_window 函数不改名，
    默认 false、权限 0444、首次 DSI 当前任务、最多 60 次尝试、每次请求 50 ms。
    60 次是请求睡眠预算，不是墙钟时间上限；跳过不安全上下文，不保证 USB 日志送达。
  - baseline/myron-boot-r18.zip 原封不动，SHA-256：
    a3c7e97e4a28f6574a619bcc10dab8962911ed5fcef8617aeb7fc835bdbe7d13
  - 源码锁、工具链、R13 准备流程、R18 SOCCP 修复、内核配置、DT 保持原样。
  - 顶层目标仍只有 msm_drm、kernel_aarch64、kernel_release：
    //vendor/qcom/sm8850-modules/qcom/opensource/display-drivers:canoe_perf_msm_drm
    //common:kernel_aarch64
    //myron_artifact_metadata:kernel_release
  - 冷构建仍需编译内核和声明依赖；不是只编译一个 KO。

产物验证
  build / cquery / aquery 使用相同配置；按唯一 msm_drm KernelModule 动作的真实
  输入收集依赖 Symvers。缺产物、提供者冲突、CRC 或 namespace 不匹配均停止。
  R18 配置、核心 CRC、release、完整 vermagic 校验不变。新 Image 仅记录，不交付
  为测试内核；16 个 RAM 依赖不在本轮替换。

  R25 的 59 条和 R27 的全部 65 条必需日志格式均保留。R27 标记基线独立固定 hash；
  manifest 必须准确包含 65 条旧标记加一条 R28 新标记，共 66 条且无重复。
  每条格式均验证完整换行和 NUL，存在已分配只读 ELF 段及实际执行段重定位。
  仅追加字符串、缺少新标记、未被代码引用或直接使用旧 R27 KO，均不能通过。
  保留 R27 参数结构、bool 操作、默认值、helper 未导出及五个调用者的实际
  AArch64 CALL26/JUMP26 指令重定位检查；保留 hwfence 安全格式检查。
  这些结构门不替代编译后 DP 空值分支指令核对及实际 R18 + 16 个依赖 ABI 审核。

使用与产物
  将配对的 myron-display-r28.zip 原样放仓库根目录，
  build-myron-display-r28.yml 放入 .github/workflows/，手动运行 R28 workflow。
  默认 jobs=2。GitHub artifact：
    myron-r28-display-output-<run_id>
    myron-r28-display-reports-<run_id>
  产物目录仍为 integration-artifacts/display-probe/，本轮报告名统一 r28-*。
  成功后提供 output 与 reports；失败时提供 reports 和失败日志，不需重复构建。
  正式运行会先移除旧候选输出，不能让旧 KO 冒充本轮成功。

  本包不调用 ADB/fastboot，不生成分区镜像。经实际 KO 指令与 ABI 审核后，
  再制作下一轮实机测试包；不要把编译产物直接刷入。

离线检查
  python3 -m unittest discover -s tests -v
  python3 display_probe_build.py --print-plan
  测试使用明确标注的合成 ELF/aquery 样例，不是目标内核编译；另用已编译 R27 KO
  验证旧 65 条标记的代码引用可识别，同时因缺少 R28 新标记被拒绝。
  未修改的源码锁与工作流准备步骤按已成功 R27 对比，避免扩大本轮构建变更。

封包
  bundle-lock.json 固定目录内交付文件（不含自身）的路径、大小和 SHA-256。
  合并源码 patch 后生成最终 ZIP，用其 SHA-256 替换 workflow 的唯一
  __R28_BUNDLE_SHA256__。配对不符会在编译前停止。
