#!/usr/bin/env python3
"""Focused R28 source and optional AUX-switch branch checks; no target build."""
import argparse, ast, difflib, hashlib, json, re, subprocess, tempfile
from pathlib import Path

D=Path(__file__).resolve().parent
SHA=lambda b:hashlib.sha256(b).hexdigest()
MARKER=re.compile(r'("MYRON_R(?:21|23|25|27|28) (?:[^"\\]|\\.)*")')
STUB=r'''
#include <assert.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
enum dp_aux_switch_type { DP_AUX_SWITCH_BYPASS, DP_AUX_SWITCH_FSA4480, DP_AUX_SWITCH_WCD939x };
struct device_node { const char *name; };
struct dp_display_private { struct device_node *aux_switch_node; bool no_aux_switch; enum dp_aux_switch_type switch_type; };
static unsigned int log_calls;
static char message[256];
static void info(const char *fmt,...) __attribute__((format(printf,1,2)));
static void info(const char *fmt,...) {
    va_list ap; va_start(ap,fmt); vsnprintf(message,sizeof(message),fmt,ap);va_end(ap);++log_calls;
}
#define DP_DEBUG(...) ((void)0)
#define DP_INFO(...) info(__VA_ARGS__)
static void select_switch(struct dp_display_private *dp) {
'''
HARNESS=r'''
}
int main(void) {
    struct device_node fsa={"fsa4480"},wcd={"wcd939x_i2c"},other={"unrecognized"};
    struct device_node *nodes[]={NULL,&fsa,&wcd,&other};
    enum dp_aux_switch_type types[]={DP_AUX_SWITCH_BYPASS,DP_AUX_SWITCH_FSA4480,DP_AUX_SWITCH_WCD939x,DP_AUX_SWITCH_BYPASS};
    for(unsigned int i=0;i<4;i++) {
        struct dp_display_private dp={.aux_switch_node=nodes[i],.no_aux_switch=false,.switch_type=DP_AUX_SWITCH_WCD939x};
        char expected[256];
        select_switch(&dp);
        assert(dp.switch_type==types[i]);assert(dp.no_aux_switch==(i==0));assert(log_calls==i+1);
        snprintf(expected,sizeof(expected),"MYRON_R28 stage=dp_aux_switch_selected present=%d type=%d no_aux=%d\n",i!=0,types[i],i==0);
        assert(strcmp(message,expected)==0);
    }
    puts("PASS: NULL, FSA4480, WCD939x, unknown node selection and one-log format");
    return 0;
}
'''

def reverse(text,edits,name):
    for e in reversed([e for e in edits if e['file']==name]):
        assert text.count(e['after'])==1,(name,e['note'])
        text=text.replace(e['after'],e['before'],1)
    return text

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--report',required=True);args=ap.parse_args()
    m=json.loads((D/'manifest.json').read_text())
    edits=json.loads((D/'edits.json').read_text());delta=json.loads((D/'r28-edits.json').read_text())
    assert len(m['files'])==9 and len(delta)==3
    assert m['build_id']=='R28-DP-AUX-NULL-FIX-20261012-01'
    assert m['expected_marker_count']==len(m['expected_markers'])==66
    assert m['expected_markers'][:65]==m['r27_expected_markers']
    assert len(set(m['expected_markers']))==66
    assert m['r27_parameter']['name']=='myron_r27_log_windows'
    patch=[];markers=[];file_reports=[]
    for f in m['files']:
        name=Path(f['path']).name;a=(D/f['before_file']).read_bytes();b=(D/f['after_file']).read_bytes()
        assert SHA(a)==f['before_sha256'] and SHA(b)==f['after_sha256']
        assert reverse(b.decode(),edits,name)==a.decode()
        if name!='dp_display.c':
            assert name in m['r27_after_sha256']
            assert SHA(b)==m['r27_after_sha256'][name]
            assert not [e for e in delta if e['file']==name]
        else:
            assert SHA(a)=='1aeaa4c242145c5890c4eb1daed77b009ebd89af2482d89d6ada7926e8aca943'
            assert hashlib.sha1(b'blob '+str(len(a)).encode()+b'\0'+a).hexdigest()=='dd87bbc8474da110bc7eed3c98885309fefd4907'
            assert reverse(b.decode(),delta,name)==a.decode()
            assert b.count(b'dp->aux_switch_node && !strcmp(dp->aux_switch_node->name,')==2
            assert b.count(b'DP_INFO("MYRON_R28 ')==1
            assert re.findall(rb'\breturn\s+[^;]+;',a)==re.findall(rb'\breturn\s+[^;]+;',b)
            assert re.findall(rb'\bgoto\s+\w+;',a)==re.findall(rb'\bgoto\s+\w+;',b)
        literals=MARKER.findall(b.decode());found=[ast.literal_eval(x) for x in literals]
        assert len(found)==f['marker_occurrences']
        assert all(x.endswith('\n') and '\\' not in x for x in found)
        markers.extend(x[:-1] for x in found)
        patch.extend(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+f['path'],tofile='b/'+f['path']))
        file_reports.append(dict(path=f['path'],before_sha256=SHA(a),after_sha256=SHA(b),r27_after_unchanged=name!='dp_display.c'))
    assert sorted(set(markers))==m['all_source_markers']
    assert set(m['r27_all_source_markers'])<=set(markers)
    assert len(markers)==m['marker_occurrences']
    assert set(m['expected_markers'])<=set(markers)
    assert SHA(''.join(patch).encode())==m['patch_sha256']==m['patch']['sha256']==SHA((D/m['patch']['path']).read_bytes())
    text=(D/'after/dp_display.c').read_text()
    start=text.index('\tif (!dp->aux_switch_node) {',text.index('static int dp_init_sub_modules('))
    end=text.index('\n\tdp->aux = dp_aux_get',start)
    fragment=text[start:end]
    assert fragment.count('DP_INFO(')==1 and fragment.count('&& !strcmp(')==2
    with tempfile.TemporaryDirectory(prefix='r28-switch-') as tmp:
        tmp=Path(tmp);c=tmp/'selection.c';binary=tmp/'selection';c.write_text(STUB+fragment+HARNESS)
        build=subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-Wformat=2',str(c),'-o',str(binary)],capture_output=True,text=True)
        assert build.returncode==0,build.stderr
        run=subprocess.run([str(binary)],capture_output=True,text=True);assert run.returncode==0,run.stderr
    r=dict(passed=True,manifest_sha256=SHA((D/'manifest.json').read_bytes()),patch_sha256=m['patch_sha256'],
        files=file_reports,target_files=9,inherited_r27_files_exact=8,r28_delta_edits=3,
        source_marker_occurrences=len(markers),mandatory_elf_markers=66,
        branch_validation=run.stdout.strip(),branch_cases=['NULL','FSA4480','WCD939x','unknown node'],
        original_r27_helper_tests_rerun=False,compiled=False,device_operations=False,
        limits='Host C harness uses extracted selection code and mock node/DP structs; not a target kernel build, ABI check or hardware test.')
    Path(args.report).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

if __name__=='__main__':main()
