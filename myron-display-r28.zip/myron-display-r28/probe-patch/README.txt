R28 DP AUX NULL fix source bundle

Nine pinned files; first eight after files are byte-identical to R27.
dp_display.c changes only two NULL guards and one DP_INFO selection log.
Missing/empty optional switch phandle follows existing BYPASS support; all DP initialization continues.
Apply: python3 apply_probe.py --modules-root <pinned-modules> --report <external-report.json>
All nine payloads, targets and patch are checked before source replacement. Reapply preserves inode/mtime/mode.
Replacement is atomic per file, not a multi-file transaction.
R27 diagnostic parameter/helper names and contracts remain unchanged.
This bundle is source only, not compiled or hardware tested, and is not flashable.
