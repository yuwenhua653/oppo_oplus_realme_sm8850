#!/usr/bin/env python3
"""Produce a batched stock/source gap report from actual full-build artifacts."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--stage', choices=('full',), required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    report = workspace / 'integration-reports/full-r8-module-gaps.json'
    subprocess.run([
        sys.executable, str(HERE / 'batch_gap_audit.py'),
        '--stock', str(HERE / 'stock-inventory.json'),
        '--build', str(workspace / 'integration-artifacts/full'),
        '--coverage-tool', str(HERE / 'compare-myron-coverage.py'),
        '--out', str(report),
    ], check=True)
    data = json.loads(report.read_text())
    lines = [
        'Myron source build: grouped coverage gaps',
        'Scope: same-name candidates only; no stock equivalence or flashability claim.',
        'Original runtime load sets are references, not a generated autoload policy.',
        '',
    ]
    lines += [f'{key}: {value}' for key, value in data['counts'].items()]
    for group, names in data['remaining_groups'].items():
        lines += ['', f'{group} ({len(names)})', ', '.join(names)]
    (report.parent / 'full-r8-module-gaps.txt').write_text('\n'.join(lines) + '\n')
    # Known unresolved OEM gaps are reported, not erased or counted as failures.
    # Malformed/corrupt build artifacts are rejected by the inventory reader.


if __name__ == '__main__':
    main()
