#!/usr/bin/env python3
"""A narrow DT gate for the Myron Xiaomi touch framework platform node.

This verifies the reviewed binding at the existing path, not controller probing,
touch firmware, panel operation, regulator sequencing or runtime equivalence.
The fdtget executable must be the same trusted host tool as the DT merge step.
"""
import subprocess


def assert_touch_framework_contract(fdtget, blob):
    def properties(path):
        return set(subprocess.check_output(
            [str(fdtget), '-p', str(blob), path], text=True).split())

    def strings(path, name):
        return subprocess.check_output(
            [str(fdtget), '-t', 's', str(blob), path, name],
            text=True).strip().split()

    framework = '/soc/xiaomi_touch'
    states = {}
    for path in ('/', '/soc', framework):
        names = properties(path)  # Fails if the required node itself is absent.
        value = strings(path, 'status') if 'status' in names else []
        if value not in ([], ['ok'], ['okay']):
            raise ValueError('Touch framework or ancestor is unavailable: ' + path)
        states[path] = value or ['<absent: available>']
    if strings(framework, 'compatible') != ['xiaomi-touch']:
        raise ValueError('Unexpected Xiaomi touch framework binding')
    # This name is an observed Myron DT invariant; the reviewed framework probe
    # does not consume it or any regulator/GPIO properties from this node.
    if strings(framework, 'touch,name') != ['xiaomi-touch']:
        raise ValueError('Unexpected Myron touch,name baseline property')
    return {
        'path': framework,
        'compatible': ['xiaomi-touch'],
        'touch,name': ['xiaomi-touch'],
        'status_chain': states,
        'scope': 'Existing framework platform node only; no controller binding or hardware equivalence claim.',
        'controller_source_included': False,
        'hardware_tested': False,
    }
