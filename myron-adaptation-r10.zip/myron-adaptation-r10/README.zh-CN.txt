Myron r10 累计源码修正与首启准备包

目标仓库：yuwenhua653/oppo_oplus_realme_sm8850
已复核的 r9 基线：Actions 37901007114（run 13）
提交：d3055ea76d41408aa3d2228df90f8fcc6fbcc98c
r9 编译成功：586 个 .ko、584 个唯一模块名；原厂 623 个同名模块覆盖 514 个，缺口 109 个。
这只是构建与同名覆盖情况，不等于实机兼容性或必须补齐的启动模块数量。

本轮目的
r9 实际 ELF 复核发现 PD 两个回调类型不匹配。编译成功和导出/导入 CRC 检查无法覆盖所有间接回调类型。
r10 将 protocol_pd_pps_pdo_select 的两个参数修正为 unsigned int，
将 protocol_pd_get_pps_status 的两个输出指针修正为 unsigned int *。
外部导出 wrapper 保留原厂签名与指针传递行为，增加高位值、别名和错误写回回归。
同时增加实际 AArch64 ELF 回调槽与 KCFI 契约门禁。
soc/full 构建必须执行该门禁，通过后才允许报告成功；门禁 JSON 随构建产物保留。
本轮没有新增驱动；累计包含 r9 的全部源码适配。

已完成与待完成的边界
- r9 已完成目标内核编译，实际二进制复核发现的问题必须由 r10 重编译验证。
- r10 源码修改、主机回归、安装幂等性与工作流完整性检查不能替代目标编译。
- 尚未完成 boot/vendor_boot/DTBO/DLKM 的匹配装配，不能刷入。
- FT3683、OEM 显示接入、充电芯片/策略和其他 OEM 依赖仍有缺口。
- 原有 evidence/r9-* 与 drivers/tests/r9-* 目录保留历史名称；当前脚本和报告使用 r10。
- 不得伪造 vermagic/CRC 或将不兼容的原厂模块混入新内核。

使用方法
将 myron-adaptation-r10.zip、myron-adaptation-r10-README.txt 和
.github/workflows/build-myron-qcom-platform.yml 放到原仓库对应位置。
保留仓库原有 r1 文件；r10 为累计包，不需在工作流里叠加 r9。
先完成同批首启输入采集和离线检查，再集中跑下一次构建，避免额外消耗约 90 分钟 CI。
届时运行 Myron QCOM platform source build：main、stage=full、jobs=2。
检查 full-r10-status、driver-contracts、callback-contracts、module-gaps、dt-merge、binding-audit、tls 报告。

full_kernel_build=false（指 r10）
hardware_tested=false
flashable=false
