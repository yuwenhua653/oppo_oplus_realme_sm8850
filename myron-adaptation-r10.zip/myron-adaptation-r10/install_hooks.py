#!/usr/bin/env python3
"""Attach r10 after the pinned r1 preparation and before build success."""
import argparse
import hashlib
import json
from pathlib import Path

BEFORE = "8f8bf7d96dc1e29b942e4f03891e1bb6a04aee0b3bb9890919e1ff948c739181"
HERE = Path(__file__).resolve().parent


def patched(data):
    edits = [
        (
            '        logged([sys.executable, str(HERE / "prepare_workspace.py"), "--workspace", str(root)], root, reports / "prepare.log")\n',
            '        logged([sys.executable, str(HERE / "prepare_workspace.py"), "--workspace", str(root)], root, reports / "prepare.log")\n'
            '        r10 = HERE.parent / "myron-adaptation-r10"\n'
            '        logged([sys.executable, str(r10 / "run_r10.py"), "apply", "--workspace", str(root), "--stage", args.stage], root, reports / "r10-apply.log")\n',
        ),
        (
            '            status["artifact_count"] = collect(root, output.stdout.splitlines(), args.stage)\n',
            '            status["artifact_count"] = collect(root, output.stdout.splitlines(), args.stage)\n'
            '            logged([sys.executable, str(r10 / "run_r10.py"), "validate", "--workspace", str(root), "--stage", args.stage], root, reports / (args.stage + "-r10-validation.log"))\n'
            '            status["r10_validation_passed"] = True\n',
        ),
        (
            '                   "-module-dependencies.json", "-module-dependencies.log"):\n',
            '                   "-module-dependencies.json", "-module-dependencies.log",\n'
            '                   "-r10-validation.log", "-r10-status.json", "-r10-dt-merge.json",\n'
            '                   "-r10-driver-contracts.json", "-r10-callback-contracts.json",\n'
            '                   "-r10-binding-audit.json", "-r10-tls.json",\n'
            '                   "-r10-module-gaps.json", "-r10-module-gaps.txt"):\n',
        ),
    ]
    for old, new in edits:
        old, new = old.encode(), new.encode()
        if data.count(old) != 1:
            raise ValueError("Ambiguous r10 hook anchor")
        data = data.replace(old, new, 1)
    compile(data, "build_platform.py", "exec")
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", required=True, type=Path)
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args()
    runner = args.package.resolve() / "build_platform.py"
    if HERE != args.package.resolve().parent / "myron-adaptation-r10":
        raise ValueError("r10 must be beside the extracted myron-qcom-platform-r1 package")
    lock = json.loads((HERE / "bundle-lock.json").read_text())
    for entry in lock["files"]:
        rel = Path(entry["path"])
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unsafe r10 manifest path")
        actual = hashlib.sha256((HERE / rel).read_bytes()).hexdigest()
        if actual != entry["sha256"]:
            raise ValueError("r10 payload mismatch: " + entry["path"])
    data = runner.read_bytes()
    current = hashlib.sha256(data).hexdigest()
    expected_after = lock["runner_after_sha256"]
    if current == expected_after:
        state = "already_applied"
    elif current == BEFORE:
        fixed = patched(data)
        if hashlib.sha256(fixed).hexdigest() != expected_after:
            raise ValueError("r10 runner output mismatch")
        runner.write_bytes(fixed)
        state = "applied"
    else:
        raise ValueError("Unexpected r1 runner; refusing to overwrite: " + current)
    reports = args.workspace.resolve() / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    (reports / "r10-hooks.json").write_text(json.dumps({
        "status": state, "runner_sha256": expected_after,
        "bundle_lock_sha256": hashlib.sha256((HERE / "bundle-lock.json").read_bytes()).hexdigest(),
        "order": ["r1_prepare", "r10_apply", "bazel_build", "collect_and_dependency_check", "r10_validate", "success"],
        "flashable": False, "hardware_tested": False,
    }, indent=2) + "\n")
    print("r10 source adaptation and output gates installed: " + state)


if __name__ == "__main__":
    main()
