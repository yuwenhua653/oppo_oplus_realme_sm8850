#!/usr/bin/env python3
"""Exercise real runner success/failure routing with simulated subprocess exits."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest.mock import patch


def main():
    bundle = Path(__file__).resolve().parents[1]
    assert (bundle / 'abi/verify_callback_abi.py').is_file()
    assert (bundle / 'abi/stock-callback-contract.json').is_file()
    spec = importlib.util.spec_from_file_location('r10_gate_routing', bundle / 'run_r10.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    results = []
    for stage in ('soc', 'full'):
        for fail_gate in (True, False):
            with tempfile.TemporaryDirectory(prefix='myron-r10-routing-') as temporary:
                root = Path(temporary)
                artifacts = root / 'integration-artifacts' / stage
                artifacts.mkdir(parents=True)
                reports = root / 'integration-reports'
                calls = []

                def simulated_run(command, **kwargs):
                    calls.append(command)
                    if Path(command[1]).name == 'verify_callback_abi.py':
                        assert kwargs.get('check') is True, 'Gate is not mandatory'
                        assert command[command.index('--artifacts') + 1] == str(artifacts)
                        assert command[command.index('--stage') + 1] == stage
                        report = Path(command[command.index('--report') + 1])
                        report.write_text(json.dumps({'success': not fail_gate, 'simulated': True}) + '\n')
                        if fail_gate:
                            raise subprocess.CalledProcessError(1, command)
                    return subprocess.CompletedProcess(command, 0)

                argv = ['run_r10.py', 'validate', '--workspace', str(root), '--stage', stage]
                with patch.object(module.subprocess, 'run', side_effect=simulated_run), \
                        patch.object(sys, 'argv', argv), contextlib.redirect_stderr(io.StringIO()):
                    code = module.main()
                state = json.loads((reports / (stage + '-r10-status.json')).read_text())
                gate_calls = [c for c in calls if Path(c[1]).name == 'verify_callback_abi.py']
                assert len(gate_calls) == 1, (stage, 'Gate skipped or duplicated')
                assert code == (1 if fail_gate else 0), (stage, state)
                assert state['success'] is (not fail_gate), (stage, state)
                assert state.get('callback_contracts_validated', False) is (not fail_gate)
                assert (artifacts / (stage + '-r10-status.json')).read_bytes() == \
                       (reports / (stage + '-r10-status.json')).read_bytes()
                assert (artifacts / (stage + '-r10-callback-contracts.json')).read_bytes() == \
                       (reports / (stage + '-r10-callback-contracts.json')).read_bytes()
                if fail_gate:
                    assert not any(Path(c[1]).name == 'verify_binding_evidence.py' for c in calls)
                results.append({'stage': stage, 'gate_exit': 1 if fail_gate else 0,
                                'status_and_artifact_propagation': 'PASS'})
    print(json.dumps({'success': True, 'checks': results,
                      'scope': 'Real run_r10 routing; subprocess work simulated, no kernel compile.'}))


if __name__ == '__main__':
    main()
