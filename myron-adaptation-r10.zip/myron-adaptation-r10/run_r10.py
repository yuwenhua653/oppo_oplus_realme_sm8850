#!/usr/bin/env python3
"""Apply source-only adaptation, or validate outputs from this build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def check_kconfig(root, reports):
    """Run QCOM's actual config flattener with the genrule's cwd/prefix."""
    soc = root / "vendor/qcom/sm8850"
    script = soc / "flatten_kconfig.sh"
    script_bytes = script.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(script_bytes)).encode() + b"\0" + script_bytes).hexdigest()
    if blob != "1be80d05e67db781abb805cb0fe0dd6911969816":
        raise ValueError("Unexpected QCOM Kconfig flattener")
    output = reports / "r10-Kconfig.ext"
    log = reports / "r10-kconfig-preflight.log"
    report = reports / "r10-kconfig-preflight.json"
    prefix = "vendor/qcom/sm8850/"
    state = {"success": False, "source_prefix": prefix, "flattener_git_blob": blob,
             "scope": "QCOM Kconfig expansion before Bazel; not a sandbox or kernel compilation test"}
    try:
        with output.open("wb") as out, log.open("wb") as err:
            result = subprocess.run(["bash", str(script), prefix + "Kconfig.msm"], cwd=root,
                                    env={**os.environ, "KCONFIG_EXT_PREFIX": prefix},
                                    stdout=out, stderr=err, check=False)
        state["returncode"] = result.returncode
        if result.returncode:
            raise RuntimeError("QCOM Kconfig expansion failed; see " + str(log))
        data = output.read_bytes()
        lines = data.decode().splitlines()
        driver_lock = json.loads((HERE / 'drivers/source-lock.json').read_text())
        symbols = driver_lock.get('kconfig_symbols', ['MI_HARDWARE_ID', 'MIEV'])
        counts = {name: sum(line.strip() == "config " + name for line in lines)
                  for name in symbols}
        state["driver_config_counts"] = counts
        if any(count != 1 for count in counts.values()):
            raise ValueError("Expected each foundation Kconfig exactly once: " + repr(counts))
        state.update(success=True, output_sha256=hashlib.sha256(data).hexdigest())
        print("QCOM Kconfig expansion and pinned Xiaomi driver declarations: PASS")
    except Exception as error:
        state["error"] = str(error)
        raise
    finally:
        report.write_text(json.dumps(state, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("apply", "validate"))
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--stage", required=True, choices=("analyze", "soc", "dtbs", "full"))
    args = parser.parse_args()
    root = args.workspace.resolve()
    reports = root / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    status_file = reports / (args.stage + "-r10-status.json")
    state = {"adaptation": "myron-r10", "stage": args.stage, "action": args.action,
             "success": False, "flashable": False, "hardware_tested": False}
    try:
        if args.action == "apply":
            subprocess.run(["bash", str(HERE / "drivers/tests/hwid/run_hwid.sh")], check=True)
            subprocess.run(["bash", str(HERE / "drivers/tests/mca/run_mca_hwid.sh"),
                            str(HERE / "drivers/payload")], check=True)
            subprocess.run([sys.executable, str(HERE / "drivers/tests/mca/run_buffer_boundaries.py"),
                            str(HERE / "drivers/payload"), "--report",
                            str(reports / "r10-mca-buffer-boundaries.json")], check=True)
            subprocess.run(["bash", str(HERE / "drivers/tests/mca/concurrency/run_concurrency.sh"),
                            str(HERE / "drivers/payload")], check=True)
            subprocess.run([sys.executable, str(HERE / "drivers/tests/r7-common/run_charge_interface.py"),
                            str(HERE / "drivers/payload")], check=True)
            subprocess.run([sys.executable, str(HERE / "drivers/tests/r7-common/run_sysfs_rollback.py"),
                            str(HERE / "drivers/payload")], check=True)
            subprocess.run(["bash", str(HERE / "drivers/tests/r7-platform/run_platform.sh"),
                            str(HERE / "drivers/payload")], check=True)
            subprocess.run(["bash", str(HERE / "drivers/tests/r8-cp-fg/run_cp.sh"),
                            str(HERE / "drivers/payload")], check=True)
            subprocess.run(["bash", str(HERE / "drivers/tests/r8-buck-base/run_buck.sh"),
                            str(HERE / "drivers/payload")], check=True)
            extra_tests = json.loads((HERE / "host-tests-r10.json").read_text())
            for test in extra_tests:
                path = HERE / test["runner"]
                command = ([sys.executable] if path.suffix == ".py" else ["bash"]) + [str(path)]
                if test.get("payload"):
                    command.append(str(HERE / "drivers/payload"))
                subprocess.run(command, check=True)
            scripts = ["common/apply_tls.py", "dt/apply_dt.py", "drivers/apply_drivers.py"]
        else:
            scripts = []
            if args.stage in ("full", "dtbs"):
                scripts.append("dt/validate_dt.py")
            if args.stage in ("full", "soc"):
                scripts.append("drivers/validate_drivers.py")
            if args.stage == "full":
                scripts.append("coverage/check_coverage.py")
        failures = []
        for script in scripts:
            command = [sys.executable, str(HERE / script), "--workspace", str(root)]
            if args.action == "validate":
                command += ["--stage", args.stage]
            result = subprocess.run(command, cwd=root, check=False)
            if result.returncode:
                failures.append({"script": script, "returncode": result.returncode})
                if args.action == "apply":
                    break
        if failures:
            state["failures"] = failures
            raise RuntimeError("Source adaptation or output checks failed: " + ", ".join(x["script"] for x in failures))
        if args.action == "validate" and args.stage in ("soc", "full"):
            # Export CRCs do not establish the types of indirect callbacks.
            # Validate actual target ELF before either stage can become successful.
            subprocess.run([
                sys.executable, str(HERE / "abi/verify_callback_abi.py"),
                "--artifacts", str(root / "integration-artifacts" / args.stage),
                "--stage", args.stage,
                "--report", str(reports / (args.stage + "-r10-callback-contracts.json")),
            ], check=True)
            state["callback_contracts_validated"] = True
        if args.action == "validate" and args.stage == "full":
            subprocess.run([
                sys.executable, str(HERE / "bindings/verify_binding_evidence.py"),
                "--artifacts", str(root / "integration-artifacts/full"),
                "--merged-dtb", str(reports / "myron-r10-dt-merge-full/07-myron-sde-display-mtp-overlay.dtb"),
                "--source-root", str(root),
                "--output", str(reports / "full-r10-binding-audit.json"),
            ], check=True)
            subprocess.run([
                sys.executable, str(HERE / "common/validate_tls.py"),
                "--artifact-dir", str(root / "integration-artifacts/full"),
                "--report", str(reports / "full-r10-tls.json"),
            ], check=True)
            state["tls_output_validated"] = True
            state["binding_evidence_audited"] = True
            state["full_device_binding_complete"] = False
        state["success"] = True
        state["validated_scripts"] = scripts if args.action == "validate" else []
        if args.action == "apply":
            check_kconfig(root, reports)
            # Recheck the whole Kbuild/Kleaf output map after adding the three
            # SoC overlays; the earlier r1 preflight saw only the old map.
            subprocess.run([
                sys.executable,
                str(HERE.parent / "myron-qcom-platform-r1/devicetrees/check-myron-dt-wiring.py"),
                str(root / "vendor/qcom/sm8850-devicetrees"),
                "--report", str(reports / "r10-dt-wiring.json"),
            ], check=True)
            # The earlier r1 report is deliberately retained. Capture the final
            # complete tracked diff after both additive source changes too.
            for name, path in (("soc", "vendor/qcom/sm8850"), ("devicetrees", "vendor/qcom/sm8850-devicetrees")):
                subprocess.run(["git", "-C", str(root / path), "diff", "--check"], check=True)
                with (reports / ("r10-" + name + "-integration.diff")).open("wb") as output:
                    subprocess.run(["git", "-C", str(root / path), "diff", "--binary"], stdout=output, check=True)
    except Exception as error:
        state["success"] = False
        state["error"] = str(error)
        print("r10 failed: " + str(error), file=sys.stderr)
    finally:
        status_file.write_text(json.dumps(state, indent=2) + "\n")
        destination = root / "integration-artifacts" / args.stage
        if args.action == "validate" and destination.is_dir():
            for path in reports.glob(args.stage + "-r10-*.*"):
                shutil.copy2(path, destination / path.name)
    return 0 if state["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
