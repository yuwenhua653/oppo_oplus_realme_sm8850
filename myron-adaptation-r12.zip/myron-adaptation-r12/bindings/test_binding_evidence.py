#!/usr/bin/env python3
"""Focused negative controls for the binding evidence gate, using run12 inputs."""
import argparse
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('binding_evidence', HERE / 'verify_binding_evidence.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--artifacts', type=Path, required=True)
    ap.add_argument('--merged-dtb', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    checks = []
    baseline = gate.run(SimpleNamespace(artifacts=args.artifacts, merged_dtb=args.merged_dtb, source_root=None))
    assert baseline['audit_passed'] and not baseline['binding_complete']
    assert baseline['unresolved_binding_nodes'] == 3
    checks.append('real_run12_passes_with_three_explicit_remaining_nodes')
    original = json.loads((args.artifacts / 'artifact-manifest.json').read_text())
    names = {'qcom-scm.ko', 'pm8941-pwrkey.ko', 'msm_drm.ko'}
    original['files'] = [e for e in original['files'] if Path(e['file']).name in names]
    with tempfile.TemporaryDirectory(prefix='binding-test-', dir=HERE) as tmp:
        root = Path(tmp)
        source_root = root / 'source-tree'
        for row in json.loads((HERE / 'source-provenance.json').read_text()):
            if row.get('workspace_path'):
                target = source_root / row['workspace_path']
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((HERE / row['local_path']).read_bytes())
        source_opts = SimpleNamespace(artifacts=args.artifacts, merged_dtb=args.merged_dtb, source_root=source_root)
        assert gate.run(source_opts)['source_root_verified']
        checks.append('workspace_layout_and_all_nine_pinned_source_files_pass')
        (source_root / 'vendor/qcom/sm8850/drivers/firmware/qcom/qcom_scm.c').write_text('changed source\n')
        try:
            gate.run(source_opts)
            raise AssertionError('changed source accepted')
        except ValueError as e:
            assert 'Active source changed' in str(e), str(e)
        checks.append('source_mutation_requires_fresh_review')
        for item in original['files']:
            p = root / item['file']
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes((args.artifacts / item['file']).read_bytes())
        mp = root / 'artifact-manifest.json'
        mp.write_text(json.dumps(original))
        opts = SimpleNamespace(artifacts=root, merged_dtb=args.merged_dtb, source_root=None)
        scm = next(e for e in original['files'] if Path(e['file']).name == 'qcom-scm.ko')
        path = root / scm['file']
        original_bytes = path.read_bytes()
        elf = gate.Elf(path)
        caller = elf.functions['qcom_scm_probe']
        # Retarget the bridge initialization CALL26 to _printk. This models a
        # build that retains aliases/exports but no longer initializes bridge.
        changed = bytearray(original_bytes)
        modified = 0
        for h in elf.headers:
            if h[1] != 4 or h[7] != caller['section']:
                continue
            table = elf.symbol_tables[h[6]]
            replacement = next(i for i, s in enumerate(table) if s['name'] == '_printk')
            for off in range(h[4], h[4] + h[5], 24):
                address, info, _ = struct.unpack_from('<QQq', changed, off)
                if caller['value'] <= address < caller['value'] + caller['size'] and table[info >> 32]['name'] == 'qtee_shmbridge_driver_init':
                    struct.pack_into('<Q', changed, off + 8, (replacement << 32) | (info & 0xffffffff))
                    modified += 1
        assert modified == 1
        path.write_bytes(changed)
        # Keep the old manifest first: integrity violation must be caught.
        try:
            gate.run(opts)
            raise AssertionError('corruption was accepted')
        except ValueError as e:
            assert 'manifest mismatch' in str(e), str(e)
        checks.append('changed_elf_rejected_by_manifest')
        scm['sha256'] = gate.digest(changed)
        mp.write_text(json.dumps(original))
        try:
            gate.run(opts)
            raise AssertionError('missing init call was accepted')
        except ValueError as e:
            assert 'SCM integration call missing' in str(e), str(e)
        checks.append('missing_bridge_init_rejected_even_with_updated_manifest_and_unchanged_exports')
        path.write_bytes(original_bytes)
        scm['sha256'] = gate.digest(original_bytes)
        original['files'].append(dict(scm))
        mp.write_text(json.dumps(original))
        try:
            gate.run(opts)
            raise AssertionError('duplicate artifact was accepted')
        except ValueError as e:
            assert 'exactly one artifact' in str(e), str(e)
        checks.append('duplicate_scm_candidate_rejected')
    report = dict(passed=True, checks=checks, count=len(checks), hardware_tested=False)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
