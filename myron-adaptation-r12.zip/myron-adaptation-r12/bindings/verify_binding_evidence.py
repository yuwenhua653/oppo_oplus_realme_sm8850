#!/usr/bin/env python3
"""Audit four Myron DT binding differences; never certifies hardware or flashing.

Only Python's standard library is required. The SCM relocation checks distinguish
the real shared-memory implementation from an exported no-op or a added alias.
Exit 0 means the evidence check completed, NOT that remaining bindings are fixed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

HERE = Path(__file__).resolve().parent
SCM_COMPAT = 'qcom,tee-shared-memory-bridge'
BARK = ['qcom,pmk8350-pwrkey-bark', 'qcom,pmk8350-pwrkey-resin-bark']
NVT = 'novatek,vis-display'


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Elf:
    def __init__(self, path):
        self.path = path
        self.data = path.read_bytes()
        d = self.data
        if d[:6] != b'\x7fELF\x02\x01' or struct.unpack_from('<HH', d, 16) != (1, 183):
            raise ValueError('Expected ELF64 little-endian AArch64 relocatable: ' + str(path))
        offset = struct.unpack_from('<Q', d, 40)[0]
        size, count, names_index = struct.unpack_from('<HHH', d, 58)
        if size != 64 or not count or names_index >= count or offset + count * size > len(d):
            raise ValueError('Invalid ELF section table')
        self.headers = [struct.unpack_from('<IIQQQQIIQQ', d, offset + i * size) for i in range(count)]
        names = self.section(names_index)
        self.by_name = {self.string(names, h[0]): i for i, h in enumerate(self.headers)}
        self.symbols = {}
        self.symbol_tables = {}
        for i, h in enumerate(self.headers):
            if h[1] != 2:
                continue
            if h[9] != 24 or h[5] % 24:
                raise ValueError('Invalid ELF symbol table')
            strings = self.section(h[6])
            symbols = []
            for offset in range(0, h[5], 24):
                name, info, other, index, value, size = struct.unpack_from('<IBBHQQ', self.section(i), offset)
                sym = dict(name=self.string(strings, name), info=info, section=index, value=value, size=size)
                symbols.append(sym)
                if sym['name']:
                    self.symbols[sym['name']] = sym
            self.symbol_tables[i] = symbols
        self.functions = {n: s for n, s in self.symbols.items() if s['info'] & 15 == 2 and 0 < s['section'] < len(self.headers)}
        self.exports = sorted(n[10:] for n, s in self.symbols.items() if n.startswith('__ksymtab_') and s['info'] & 15 != 3 and s['section'])
        self.imports = sorted(n for n, s in self.symbols.items() if s['section'] == 0 and s['info'] >> 4 == 1)
        self.modinfo = {}
        for raw in self.section(self.by_name['.modinfo']).split(b'\0'):
            if b'=' in raw:
                k, v = raw.decode().split('=', 1)
                self.modinfo.setdefault(k, []).append(v)

    def section(self, index):
        h = self.headers[index]
        if h[4] + h[5] > len(self.data):
            raise ValueError('ELF section outside file')
        return self.data[h[4]:h[4] + h[5]]

    @staticmethod
    def string(data, offset):
        if offset >= len(data):
            raise ValueError('String outside table')
        return data[offset:data.index(b'\0', offset)].decode()

    def calls(self, function):
        caller = self.functions[function]
        result = []
        for i, h in enumerate(self.headers):
            if h[1] != 4 or h[7] != caller['section']:  # SHT_RELA, target section.
                continue
            if h[9] != 24 or h[5] % 24:
                raise ValueError('Invalid relocation table')
            symbols = self.symbol_tables[h[6]]
            data = self.section(i)
            for off in range(0, len(data), 24):
                address, info, addend = struct.unpack_from('<QQq', data, off)
                if not caller['value'] <= address < caller['value'] + caller['size']:
                    continue
                kind, target = info & 0xffffffff, symbols[info >> 32]
                if kind not in (282, 283):  # AArch64 JUMP26 / CALL26.
                    continue
                opcode = struct.unpack_from('<I', self.section(caller['section']), address)[0]
                expected = 0x14000000 if kind == 282 else 0x94000000
                if opcode & 0xfc000000 != expected:
                    raise ValueError('Call relocation does not point at B/BL')
                result.append(dict(offset=address - caller['value'], target=target['name'], relocation=kind, addend=addend))
        return result

    def evidence(self):
        return dict(file=str(self.path), sha256=digest(self.data), module_name=self.modinfo.get('name'), vermagic=self.modinfo.get('vermagic'))


def read_fdt(path):
    data = path.read_bytes()
    magic, total, off_struct, off_strings, _, _, _, _, str_size, struct_size = struct.unpack_from('>10I', data)
    if magic != 0xd00dfeed or total != len(data) or off_struct + struct_size > total or off_strings + str_size > total:
        raise ValueError('Invalid flattened device tree')
    strings = data[off_strings:off_strings + str_size]
    offset, stack, nodes = off_struct, [], {}
    while offset < off_struct + struct_size:
        token = struct.unpack_from('>I', data, offset)[0]
        offset += 4
        if token == 1:
            end = data.index(b'\0', offset)
            stack.append(data[offset:end].decode())
            offset = (end + 4) & ~3
            nodes['/' + '/'.join(stack[1:])] = {}
        elif token == 2:
            stack.pop()
        elif token == 3:
            size, name_offset = struct.unpack_from('>II', data, offset)
            offset += 8
            if offset + size > off_struct + struct_size:
                raise ValueError('DT property outside structure')
            name = strings[name_offset:strings.index(b'\0', name_offset)].decode()
            value = data[offset:offset + size]
            nodes['/' + '/'.join(stack[1:])][name] = value
            offset = (offset + size + 3) & ~3
        elif token == 9:
            if stack:
                raise ValueError('Unclosed DT node')
            return nodes
        elif token != 4:
            raise ValueError('Unknown DT token')
    raise ValueError('Missing DT end token')


def dt_matches(nodes, compatible):
    found = []
    for path, props in nodes.items():
        values = props.get('compatible', b'').rstrip(b'\0').split(b'\0')
        if compatible.encode() not in values:
            continue
        ancestors = ['/'] + ['/' + '/'.join(path.strip('/').split('/')[:i]) for i in range(1, len(path.strip('/').split('/')) + 1)]
        enabled = all(nodes[p].get('status', b'okay\0').rstrip(b'\0') in (b'ok', b'okay') for p in ancestors)
        found.append(dict(path=path, enabled_by_status_chain=enabled,
                          properties={k: v.hex() for k, v in props.items()}))
    return found


def checked_module(artifacts, manifest, filename):
    entries = [f for f in manifest['files'] if Path(f['file']).name == filename]
    if len(entries) != 1:
        raise ValueError('Expected exactly one artifact: ' + filename)
    item = entries[0]
    rel = Path(item['file'])
    path = (artifacts / rel).resolve()
    if rel.is_absolute() or '..' in rel.parts or not path.is_relative_to(artifacts.resolve()):
        raise ValueError('Unsafe artifact path')
    parsed = Elf(path)
    if digest(parsed.data) != item['sha256'] or len(parsed.data) != item['bytes']:
        raise ValueError('Artifact manifest mismatch: ' + filename)
    return parsed


def run(args):
    provenance = json.loads((HERE / 'source-provenance.json').read_text())
    for row in provenance:
        data = (HERE / row['local_path']).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if digest(data) != row['sha256'] or blob != row['git_blob_sha1']:
            raise ValueError('Pinned source evidence changed: ' + row['local_path'])
        if args.source_root and row.get('workspace_path'):
            actual = (args.source_root / row['workspace_path']).read_bytes()
            if digest(actual) != row['sha256']:
                raise ValueError('Active source changed; binding review required: ' + row['workspace_path'])
    manifest = json.loads((args.artifacts / 'artifact-manifest.json').read_text())
    scm = checked_module(args.artifacts, manifest, 'qcom-scm.ko')
    display = checked_module(args.artifacts, manifest, 'msm_drm.ko')
    pwrkey = checked_module(args.artifacts, manifest, 'pm8941-pwrkey.ko')
    expected_calls = {
        'qcom_scm_probe': ['qcom_tzmem_enable', 'qtee_shmbridge_driver_init'],
        'qtee_shmbridge_driver_init': ['qcom_tzmem_pool_new'],
        'qcom_tzmem_enable': ['qcom_scm_shm_bridge_enable'],
        'qtee_shmbridge_allocate_shm': ['qcom_tzmem_alloc', 'qcom_tzmem_to_phys'],
        'qtee_shmbridge_register': ['qcom_tzmem_shm_bridge_create_with_vmid'],
    }
    calls = {}
    for caller, targets in expected_calls.items():
        if caller not in scm.functions or scm.functions[caller]['size'] <= 4:
            raise ValueError('Real SCM function missing: ' + caller)
        calls[caller] = scm.calls(caller)
        missing = set(targets) - {c['target'] for c in calls[caller]}
        if missing:
            raise ValueError('SCM integration call missing: ' + caller + ': ' + ','.join(sorted(missing)))
    bridge_exports = ['qtee_shmbridge_is_enabled', 'qtee_shmbridge_query', 'qtee_shmbridge_register',
                      'qtee_shmbridge_deregister', 'qtee_shmbridge_allocate_shm', 'qtee_shmbridge_free_shm',
                      'qtee_shmbridge_flush_shm_buf', 'qtee_shmbridge_inv_shm_buf']
    if set(bridge_exports) - set(scm.exports):
        raise ValueError('SHM bridge export missing')
    if not any('Cqcom,scm' in a for a in scm.modinfo.get('alias', [])):
        raise ValueError('SCM has no firmware DT binding')
    nodes = read_fdt(args.merged_dtb)
    scm_nodes = dt_matches(nodes, 'qcom,scm')
    if not any(n['enabled_by_status_chain'] for n in scm_nodes):
        raise ValueError('No enabled qcom,scm node in merged DT')
    old_nodes = dt_matches(nodes, SCM_COMPAT)
    for compatible in [SCM_COMPAT, *BARK, NVT]:
        matches = dt_matches(nodes, compatible)
        if len(matches) != 1 or not matches[0]['enabled_by_status_chain']:
            raise ValueError('Reviewed binding topology changed; fresh review required: ' + compatible)
    rows = [{
        'compatible': SCM_COMPAT, 'classification': 'implementation_moved_into_scm_probe',
        'old_node_matches': old_nodes, 'new_initialization_nodes': scm_nodes,
        'implementation_present': True, 'static_initialization_chain_verified': True,
        'legacy_node_has_only_compatible': all(set(n['properties']) == {'compatible'} for n in old_nodes),
        'remaining': ['Verify successful SCM probe and TrustZone shared-memory operations on hardware.',
                      'The legacy node is not consumed by the new initialization path; allocator and firmware semantic equivalence is not certified.'],
    }]
    for compatible in BARK:
        alias = any('C' + compatible in a for a in pwrkey.modinfo.get('alias', []))
        rows.append(dict(compatible=compatible, classification='remaining_xiaomi_bark_implementation' if not alias else 'changed_requires_fresh_implementation_review',
                         dt_nodes=dt_matches(nodes, compatible), exported_alias_present=alias,
                         required_oem_interfaces=['pwrkey_irq_notifier_list', 'mi_display_pwrkey_callback_set'],
                         missing_oem_exports=sorted({'pwrkey_irq_notifier_list', 'mi_display_pwrkey_callback_set'} - set(pwrkey.exports)),
                         resolved=False, reason='Bark requires real IRQ dispatch, status-bit semantics, display callback lifetime and long-press diagnostics; no alias-only patch applied.'))
    nvt_functions = sorted(n for n in display.functions if 'vis_display' in n or n.startswith('nvt_'))
    rows.append(dict(compatible=NVT, classification='remaining_xiaomi_vis_display_implementation' if not nvt_functions else 'changed_requires_fresh_implementation_review',
                     dt_nodes=dt_matches(nodes, NVT), found_function_names=nvt_functions, resolved=False,
                     reason='Stock msm_drm includes SPI probe/remove, userspace file operations and Xiaomi DSI/SDE callbacks; pinned generic display tree lacks that implementation.'))
    return dict(schema=1, audit_passed=True, binding_complete=False, flashable=False, hardware_tested=False,
                runtime_equivalent_to_stock=False, source_files_verified=len(provenance), source_root_verified=bool(args.source_root),
                module_evidence=dict(qcom_scm=scm.evidence(), pm8941_pwrkey=pwrkey.evidence(), msm_drm=display.evidence()),
                merged_dtb_sha256=digest(args.merged_dtb.read_bytes()), scm_direct_calls=calls, bridge_exports=bridge_exports,
                findings=rows, unresolved_binding_nodes=3,
                scope='Four known run12 alias differences only; not a complete binding inventory. Remaining OEM bindings are reported, never treated as implemented.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--merged-dtb', type=Path, required=True)
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        report = run(args)
    except (ValueError, KeyError, IndexError, OSError, struct.error) as exc:
        report = dict(audit_passed=False, binding_complete=False, flashable=False, hardware_tested=False, error=str(exc))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k in ('audit_passed', 'binding_complete', 'unresolved_binding_nodes', 'error')}))
    return 0 if report['audit_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
