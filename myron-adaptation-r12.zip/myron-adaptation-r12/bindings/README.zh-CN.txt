Myron r9：4 个 run12 设备树绑定差异的源码与 ELF 复核

结果：1 项确认是实现迁移，3 个节点仍缺小米实现。没有修改驱动、添加假 alias、改变 ABI 或禁用设备树节点。

1. qcom,tee-shared-memory-bridge

固定 QCOM 源 557159b6a0d06f1c6f07ec4c1f22bc9309a113e4：
- drivers/firmware/qcom/qcom_scm.c 的 qcom_scm_probe() 直接调用 qcom_tzmem_enable()，再调用 qtee_shmbridge_driver_init()。
- qtee_shmbridge.c 的 init 创建实际 qcom_tzmem 内存池；分配/注册接口使用实际 tzmem 实现。
- modules.bzl 把桥接与内存分配实现编入 qcom-scm；不再注册匹配旧 qtee_shmbridge 节点的独立 platform_driver。
- run12 qcom-scm.ko 中存在实际函数和 8 个 QTEE 桥接导出；AArch64 CALL26 重定位证实上述初始化链、内存池分配、内存申请、桥接注册与 SCM enable 调用。
- 合并 DT 有可用 qcom,scm 节点。旧 /firmware/qtee_shmbridge 节点仅有 compatible，没有发现需转送的其它节点属性。

因此不能把旧 alias 消失算作“共享内存驱动没编译”。但静态调用关系不能证明实机 SCM probe 或 TrustZone 调用成功，不能保证固件/分配器语义与原厂完全相同。

2. qcom,pmk8350-pwrkey-bark 与 qcom,pmk8350-pwrkey-resin-bark

固定 QCOM pm8941-pwrkey.c 的 of_match_table 确实没有这两个 compatible，且 IRQ 只有通用按键处理。原厂二进制另有 pwrkey_irq_notifier_list、mi_display_pwrkey_callback_set 两个导出。

固定 Onyx 8276ba954d8076303a5ae0f7b15d4092d66bdff6 中存在这两个节点的真实处理：读取 PON_RT_STS、检测长按状态、调用小米显示 callback、bark notifier、组合按键任务诊断，并对普通电源键释放通知显示层。其实现不能仅复制 match table。

待做：移植和核验 IRQ 事件/状态语义、callback 注册/注销及模块卸载并发、notifier 消费者、小米显示处理与长按诊断依赖，再对原厂及源码构建 ELF 做接口/类型核验。Onyx 全文件仅作证据，不作为未经审查的覆盖补丁。

3. novatek,vis-display

固定 QCOM modules 源 f2ecb6a09ea56bd8ec9a0bfd2e97f45e200ab322 的 msm_drv.c 注册清单没有 vis_display。run12 msm_drm.ko 没有 vis_display/nvt 函数；原厂 msm_drm 有 SPI host probe/remove、read/write/ioctl/compat_ioctl/open/close/fasync、显示通知以及 9 个相关导出。

合并 DT 节点确实启用，包含 SPI、时钟、7 组 GPIO 和 pinctrl 信息。这是实际小米显示扩展缺口。不能直接挪用 Novatek 触摸驱动，也不能只加 MODULE_ALIAS。需要可核验的 vis_display_host 实现和 Xiaomi DSI/SDE 接入，匹配设备使用的桥片、GPIO、时序及用户态 ioctl，再做运行测试。

集成方式

将本目录整体放在 bundle/bindings/，排除 __pycache__。只需 Python 3 标准库。

python bindings/verify_binding_evidence.py \
  --artifacts "$WORKSPACE/integration-artifacts/full" \
  --merged-dtb "$WORKSPACE/integration-reports/myron-r9-dt-merge-full/07-myron-sde-display-mtp-overlay.dtb" \
  --source-root "$WORKSPACE" \
  --output "$WORKSPACE/integration-reports/full-r9-binding-audit.json"

WORKSPACE 与 run_r8.py/run_r9.py 的 --workspace 是同一根目录：其下有 vendor/qcom/sm8850、sm8850-modules、sm8850-devicetrees。

返回码 0 仅表示证据检查完成。JSON 明确 audit_passed=true、binding_complete=false、unresolved_binding_nodes=3、hardware_tested=false、flashable=false。

源码被改动、桥接初始化/内存调用丢失、关键导出丢失、产物哈希不符、多个同名产物或已审查 DT 拓扑改变会拒绝。未来更换源实现/后端时必须更新证据，不能直接豁免检查。

source-provenance.json：10 个固定源码证据的 Git blob SHA-1 与 SHA256，其中 9 个同时校验当前 workspace 文件。
run12-binding-evidence.json：已运行的源码快照、实际模块字节、CALL26 和合并 DT 证据。
stock-binding-evidence.json：原厂 pm8941-pwrkey、msm_drm 模块哈希及相关函数/导出。
negative-controls.json：正向与负向控制结果。
test_binding_evidence.py：可重复的验证脚本。

范围严格限于 run12 指出的这 4 个 alias 差异，不是全设备绑定清单，也不是实机可刷认证。
