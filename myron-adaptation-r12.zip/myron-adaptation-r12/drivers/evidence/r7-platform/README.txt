Myron r7 MCA platform / protocol interface candidate batch

Candidate modules:
  mca_protocol_class       13 stock exports + explicit unregister API
  mca_protocol_qc_class     5 stock exports
  mca_platform_loadsw_class 6 stock exports

Pinned source: unmoved21/android_kernel_xiaomi_onyx
Commit: 8276ba954d8076303a5ae0f7b15d4092d66bdff6
Six source/header payload files, with Git blob and SHA-256 provenance recorded
in integration.json. Existing r6 common headers are referenced but not rewritten.
Preserves GPL notices. No charger IC, PD/ADSP, current/voltage/thermal policy,
firmware payload, Onyx product setting or fake provider is added.

Important differences actually adapted:
  - Recover 12 protocol + 4 QC callback field offsets from original Myron ELF.
    Five loadsw field offsets already match. Names alone did not prove ABI.
  - Publish protocol ops/private data together through SRCU-protected records.
    Add protocol_class_unregister_ops and call it on QC remove. Unregister waits
    for already dispatched callbacks even after provider replacement, preventing a provider pointer into an
    unloaded QC module. Registration/unregistration are sleepable and must not
    be called from within an active protocol callback.
  - Linux 6.12 void platform remove callbacks; use DEFINE_STATIC_SRCU.
  - Loadsw validates DT lengths and unique role names, rolls back partial sysfs
    creation, removes groups before devm data is freed, reports provider errors,
    and prints the correct full integer for ibat_limit.

DT: unchanged. Collected Myron live FDT and existing overlays have QC status=ok,
loadsw status=disabled. Loading/building this module does not enable loadsw.

Do not infer full stock ABI equivalence: RESERVED protocol IDs and power-cap
unknown_0 were already present in the pinned upstream. We did not invent them,
but their complete semantics are not proven and PD consumers remain excluded.
Buckchg/FG/CP/wireless export and layout mismatches, BC12->PD dependency and
platform_base allocation defects are documented in audit.json.

Local test:
  bash tests/run_platform.sh /absolute/path/to/candidate-or-bundle/drivers/payload
For this directory itself:
  bash tests/run_platform.sh ./candidate
Tests compile the actual three C files with host kernel stubs under UBSan.
119 runtime assertions + 21 stock callback offset assertions pass.
The SRCU stub tests wait semantics with a pthread rwlock; no kernel SRCU
concurrency claim, target DDK compile claim or hardware test claim is made.

Integration: consume integration.json modules/srcs/includes/deps and candidate/.
Kconfig MYRON_MCA_PLATFORM depends on MYRON_MCA_BASE, SYSFS, OF and TREE_SRCU (the verified run10 baseline has CONFIG_TREE_SRCU=y).
Run CI same-build CRC/strong-import and exact-candidate-export checks.
The additional unregister symbol is explicitly listed as a candidate export.
No external original .ko compatibility is implied. Not flashable.
