from elftools.elf.elffile import ELFFile
from capstone import *
from pathlib import Path
import re,json,hashlib
root=Path(__file__).parent
p=Path('analysis/myron-stock/modules/modules/mca_platform_buckchg_class.ko')
src=json.loads((root/'source-functions.json').read_text());calls={x['name']:x for x in src}
h=(root/'upstream/drivers/power/supply/mca/include/mca/platform/platform_buckchg_class.h').read_text()
fields={n:ty.strip() for n,ty in re.findall(r'int \(\*(\w+)\)\((.*?)\);',h)}
rows=[]
with p.open('rb') as f:
 e=ELFFile(f);syms=e.get_section_by_name('.symtab');code=e.get_section_by_name('.text').data();cs=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
 for s in syms.iter_symbols():
  if s['st_info']['type']!='STT_FUNC' or not s.name.startswith('platform_class_buckchg_ops_') or s.name.endswith('_register'):continue
  v=s['st_value'];ins=list(cs.disasm(code[v:v+s['st_size']],v));off=None;cfi=0
  for a in ins:
   m=re.match(r'x8, \[x8(?:, #(0x[0-9a-f]+|[0-9]+))?\]',a.op_str)
   if a.mnemonic=='ldr' and m:off=int(m[1],0) if m[1] else 0
   m=re.match(r'w17, #(0x[0-9a-f]+|[0-9]+)(, lsl #16)?',a.op_str)
   if a.mnemonic in ('mov','movk') and m:cfi|=int(m[1],0)<<(16 if m[2] else 0)
  rows.append({'function':s.name,'offset':off,'cfi':hex(cfi),'field':calls.get(s.name,{}).get('field'),'signature':fields.get(calls.get(s.name,{}).get('field')),'address':hex(v)})
known={}
for r in rows:
 if r['signature']:known.setdefault(r['cfi'],set()).add(r['signature'])
print('Known signature groups:',{k:sorted(v) for k,v in known.items()})
for r in rows:
 if not r['signature']:
  opts=known.get(r['cfi']);r['signature_candidates']=sorted(opts) if opts else []
  print('NEW',r)
print('offsets missing',sorted(set(range(0,max(r['offset'] for r in rows)+8,8))-set(r['offset'] for r in rows)))
print('duplicate',[x for x in set(r['offset'] for r in rows) if sum(r['offset']==x for r in rows)>1])
(root/'stock-buck-contract.json').write_text(json.dumps({'stock_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'callbacks':rows,'cfi_signatures':{k:sorted(v) for k,v in known.items()}},indent=2)+'\n')
