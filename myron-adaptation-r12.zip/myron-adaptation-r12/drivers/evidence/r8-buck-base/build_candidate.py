from pathlib import Path
import json,re,shutil,difflib
root=Path(__file__).parent
cp='drivers/power/supply/mca/mca_platform/mca_platform_buckchg_class.c'
hp='drivers/power/supply/mca/include/mca/platform/platform_buckchg_class.h'
s=(root/'upstream'/cp).read_text();h=(root/'upstream'/hp).read_text()
contract=json.loads((root/'stock-buck-contract.json').read_text())
funcs=json.loads((root/'source-functions.json').read_text()); fmap={x['name']:x for x in funcs}
sigs={'0xc069e464':'void *data','0xc2a6c845':'void *data, int','0x4445f77a':'void *data, int *','0x549f592c':'void *data, bool *','0xb2a4ba31':'void *data, bool'}
fields=[];new=[]
for r in sorted(contract['callbacks'],key=lambda x:x['offset']):
 name=r['function'];field=name.removeprefix('platform_class_buckchg_ops_');sig=sigs[r['cfi']]
 r['resolved_field']=field;r['resolved_signature']=sig
 fields.append(f'\tint (*{field})({sig});')
 if name not in fmap:
  ty=sig.split(', ')[1];arg=(ty+'value').replace('intvalue','int value').replace('boolvalue','bool value')
  f={'name':name,'args':'unsigned int role, '+arg,'field':field,'call_args':'temp_data->data, value'}
  fmap[name]=f;new.append(f)
 if name.endswith('_set_otg'):fmap[name]['args']=fmap[name]['args'].replace('int en','bool en')
h=re.sub(r'struct platform_class_buckchg_ops \{.*?\n\};','''/* Myron stock ABI: 89 callbacks, verified against wrapper slots and the
 * 712-byte g_qcom_buckchg_ops provider object. No charging policy lives here.
 */
struct platform_class_buckchg_ops {
'''+ '\n'.join(fields)+'\n};',h,flags=re.S)
h=re.sub(r'int platform_class_buckchg_ops_get_aicl_status\([^;]*?;\n','',h)
h=h.replace('platform_class_buckchg_ops_set_otg(unsigned int role, int en)','platform_class_buckchg_ops_set_otg(unsigned int role, bool en)')
protos=''.join('int '+f['name']+'('+f['args']+');\n' for f in new)
protos+='''/* Providers must unregister before freeing ops/data or unloading. Call from
 * sleepable context outside a dispatched callback, as for registration.
 */
int platform_class_buckchg_ops_unregister(unsigned int role, void *data,
					  struct platform_class_buckchg_ops *ops);
'''
h=h.replace('#endif /*',protos+'\n#endif /*')
prefix=s[:s.index('#include <linux/module.h>')]+'''#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/srcu.h>
#include <linux/errno.h>
#include <mca/platform/platform_buckchg_class.h>

struct platform_class_buckchg_data {
	void *data;
	struct platform_class_buckchg_ops *ops;
};

static struct platform_class_buckchg_data __rcu
	*platform_buckchg_ops_data[MAX_BUCK_CHARGER];
static DEFINE_MUTEX(platform_buckchg_lock);
DEFINE_STATIC_SRCU(platform_buckchg_srcu);

/* Register/unregister from sleepable context outside a dispatched callback.
 * Keep ops and data valid until unregister returns. Replacement waits for old
 * callbacks and atomically publishes the associated ops/data pair.
 */
int platform_class_buckchg_ops_register(unsigned int role, void *data,
					struct platform_class_buckchg_ops *ops)
{
	struct platform_class_buckchg_data *entry, *old;

	if (role >= MAX_BUCK_CHARGER || !ops)
		return -1;
	entry = kmalloc(sizeof(*entry), GFP_KERNEL);
	if (!entry)
		return -ENOMEM;
	entry->data = data;
	entry->ops = ops;
	mutex_lock(&platform_buckchg_lock);
	old = rcu_replace_pointer(platform_buckchg_ops_data[role], entry,
				  lockdep_is_held(&platform_buckchg_lock));
	mutex_unlock(&platform_buckchg_lock);
	synchronize_srcu(&platform_buckchg_srcu);
	kfree(old);
	return 0;
}
EXPORT_SYMBOL(platform_class_buckchg_ops_register);

int platform_class_buckchg_ops_unregister(unsigned int role, void *data,
					  struct platform_class_buckchg_ops *ops)
{
	struct platform_class_buckchg_data *old;

	if (role >= MAX_BUCK_CHARGER || !ops)
		return -EINVAL;
	mutex_lock(&platform_buckchg_lock);
	old = rcu_dereference_protected(platform_buckchg_ops_data[role],
				       lockdep_is_held(&platform_buckchg_lock));
	if (!old || old->ops != ops || old->data != data) {
		mutex_unlock(&platform_buckchg_lock);
		/* Replacement may already have detached a still-running provider. */
		synchronize_srcu(&platform_buckchg_srcu);
		return -ENOENT;
	}
	RCU_INIT_POINTER(platform_buckchg_ops_data[role], NULL);
	mutex_unlock(&platform_buckchg_lock);
	synchronize_srcu(&platform_buckchg_srcu);
	kfree(old);
	return 0;
}
EXPORT_SYMBOL(platform_class_buckchg_ops_unregister);

'''
body=[]
for f in funcs+new:
 if f['name'].endswith('_get_aicl_status'):continue
 name,field,args,cargs=f['name'],f['field'],f['args'],f['call_args']
 body.append('int '+name+'('+args+')\n{\n'+f'''\tstruct platform_class_buckchg_data *temp_data;
	int idx, ret = -1;

	if (role >= MAX_BUCK_CHARGER)
		return -1;
	idx = srcu_read_lock(&platform_buckchg_srcu);
	temp_data = srcu_dereference(platform_buckchg_ops_data[role],
				     &platform_buckchg_srcu);
	if (temp_data && temp_data->ops && temp_data->ops->{field})
		ret = temp_data->ops->{field}({cargs});
	srcu_read_unlock(&platform_buckchg_srcu, idx);
	return ret;
}}
EXPORT_SYMBOL({name});

''')
end='''static struct platform_driver platform_class_buckchg_driver = {
	.driver = {
		.name = "platform_class_buckchg",
	},
};

static int __init platform_class_buckchg_init(void)
{
	return platform_driver_register(&platform_class_buckchg_driver);
}

static void __exit platform_class_buckchg_exit(void)
{
	struct platform_class_buckchg_data *old[MAX_BUCK_CHARGER];
	unsigned int i;

	platform_driver_unregister(&platform_class_buckchg_driver);
	mutex_lock(&platform_buckchg_lock);
	for (i = 0; i < MAX_BUCK_CHARGER; i++)
		old[i] = rcu_replace_pointer(platform_buckchg_ops_data[i], NULL,
					    lockdep_is_held(&platform_buckchg_lock));
	mutex_unlock(&platform_buckchg_lock);
	synchronize_srcu(&platform_buckchg_srcu);
	for (i = 0; i < MAX_BUCK_CHARGER; i++)
		kfree(old[i]);
}

module_init(platform_class_buckchg_init);
module_exit(platform_class_buckchg_exit);
MODULE_DESCRIPTION("platform buckchg class");
MODULE_AUTHOR("liyuze1@xiaomi.com");
MODULE_LICENSE("GPL v2");
'''
for path,data in [(cp,prefix+''.join(body)+end),(hp,h)]:
 out=root/'candidate'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(data)
(root/'stock-buck-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
patch=''
for path in [cp,hp]:
 patch+=''.join(difflib.unified_diff((root/'upstream'/path).read_text().splitlines(True),(root/'candidate'/path).read_text().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(root/'myron-buckchg.patch').write_text(patch)
print('Created candidate C/H and patch, 89 dispatch wrappers; source get_aicl_status removed, unregister added.')
