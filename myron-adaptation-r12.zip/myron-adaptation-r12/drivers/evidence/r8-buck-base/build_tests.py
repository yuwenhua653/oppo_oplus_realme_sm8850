from pathlib import Path
import json,re
root=Path(__file__).parent;test=root/'tests';test.mkdir(exist_ok=True)
contract=json.loads((root/'stock-buck-contract.json').read_text())
rows=contract['callbacks'];c=(root/'candidate/drivers/power/supply/mca/mca_platform/mca_platform_buckchg_class.c').read_text()
# Minimal userspace shims; only scheduling/wait semantics are modeled, no hardware.
shim='''#ifndef MYRON_BUCK_TEST_H
#define MYRON_BUCK_TEST_H
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#define __rcu
#define __init
#define __exit
#define GFP_KERNEL 0
#define MODULE_DESCRIPTION(x)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#define EXPORT_SYMBOL(x)
#define module_init(x)
#define module_exit(x)
#define DEFINE_MUTEX(x) pthread_mutex_t x = PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) pthread_mutex_lock(x)
#define mutex_unlock(x) pthread_mutex_unlock(x)
#define lockdep_is_held(x) 1
#define DEFINE_STATIC_SRCU(x) static pthread_rwlock_t x = PTHREAD_RWLOCK_INITIALIZER
static inline int srcu_read_lock(pthread_rwlock_t *p) { assert(!pthread_rwlock_rdlock(p)); return 0; }
static inline void srcu_read_unlock(pthread_rwlock_t *p,int i) { (void)i;assert(!pthread_rwlock_unlock(p)); }
static int sync_entered_count;
static inline void synchronize_srcu(pthread_rwlock_t *p) { __atomic_add_fetch(&sync_entered_count,1,__ATOMIC_SEQ_CST);assert(!pthread_rwlock_wrlock(p));assert(!pthread_rwlock_unlock(p)); }
#define rcu_replace_pointer(p,v,c) __atomic_exchange_n(&(p),(v),__ATOMIC_SEQ_CST)
#define rcu_dereference_protected(p,c) __atomic_load_n(&(p),__ATOMIC_SEQ_CST)
#define srcu_dereference(p,s) __atomic_load_n(&(p),__ATOMIC_SEQ_CST)
#define RCU_INIT_POINTER(p,v) __atomic_store_n(&(p),(v),__ATOMIC_SEQ_CST)
static int alloc_fail, live_allocations;
static inline void *kmalloc(size_t n,int f) { (void)f;if(alloc_fail)return NULL;void *p=malloc(n);if(p)__atomic_add_fetch(&live_allocations,1,__ATOMIC_SEQ_CST);return p; }
static inline void kfree(void *p) { if(p){__atomic_sub_fetch(&live_allocations,1,__ATOMIC_SEQ_CST);free(p);} }
struct platform_driver { struct { const char *name; } driver; };
static int registered_drivers;
static inline int platform_driver_register(struct platform_driver *p) { (void)p;registered_drivers++;return 0; }
static inline void platform_driver_unregister(struct platform_driver *p) { (void)p;registered_drivers--; }
#endif
'''
(test/'stubs/linux').mkdir(parents=True,exist_ok=True)
(test/'stubs/kernel_test.h').write_text(shim)
for h in ['module','platform_device','slab','mutex','srcu','types']:(test/'stubs/linux'/f'{h}.h').write_text('#include "../kernel_test.h"\n')
# Use the real system Linux errno header through the compiler search path.
parts=['''#include "stubs/kernel_test.h"
#include MCA_BUCK_SOURCE
static unsigned int assertions;
#define CHECK(v) do { assertions++;assert(v); } while(0)
static int token, expected_int = -2147483000;
static void *expected_data = &token;
static void *expected_out;
static int seen;
''']
for r in rows:
 n=r['resolved_field'];sig=r['resolved_signature'];off=r['offset']
 parts.append(f'_Static_assert(offsetof(struct platform_class_buckchg_ops, {n}) == {off}, "stock slot {n}");\n')
 ty=sig.removeprefix('void *data');tail=ty+('value' if '*' in ty else ' value') if ty else ''
 if ty==', int':tail=', int value'
 if ty==', bool':tail=', bool value'
 parts.append(f'static int cb_{n}(void *data{tail}) {{ CHECK(data == expected_data);seen++;')
 if '*' in ty:
  parts.append('CHECK((void *)value == expected_out);')
  parts.append('*value = '+('true' if 'bool' in ty else 'expected_int')+';')
 elif ty:parts.append('CHECK(value == '+('true' if 'bool' in ty else 'expected_int')+');')
 parts.append('return -77;}\n')
parts.append('_Static_assert(sizeof(struct platform_class_buckchg_ops) == 712, "stock provider object size");\n')
parts.append('static struct platform_class_buckchg_ops all_ops = {\n'+''.join(f' .{r["resolved_field"]} = cb_{r["resolved_field"]},\n' for r in rows)+'};\n')
parts.append('''static struct platform_class_buckchg_ops no_ops;
static void exercise_all(void) {
 int out = 0;bool bout = false;int before;
''')
for r in rows:
 name=r['function'];sig=r['resolved_signature'];arg=''
 if ', int *' in sig:arg=', &out';setup='out=0;expected_out=&out;'
 elif ', bool *' in sig:arg=', &bout';setup='bout=false;expected_out=&bout;'
 elif ', int' in sig:arg=', expected_int';setup=''
 elif ', bool' in sig:arg=', true';setup=''
 else:setup=''
 parts.append(setup+f'before=seen;CHECK({name}(0{arg}) == -77);CHECK(seen==before+1);\n')
 if 'int *' in sig:parts.append('CHECK(out==expected_int);\n')
 if 'bool *' in sig:parts.append('CHECK(bout);\n')
 parts.append(f'CHECK({name}(1{arg}) == -1);CHECK({name}(2{arg}) == -1);CHECK({name}(UINT_MAX{arg}) == -1);\n')
parts.append('}\n')
parts.append('''static pthread_mutex_t hold_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t hold_cond = PTHREAD_COND_INITIALIZER;
static int entered, released, reader_done, replace_done, unregister_done;
static int hold_cb(void *data,int *value) {
 CHECK(data==&token);CHECK(value!=NULL);
 pthread_mutex_lock(&hold_lock);entered=1;pthread_cond_broadcast(&hold_cond);
 while(!released)pthread_cond_wait(&hold_cond,&hold_lock);
 pthread_mutex_unlock(&hold_lock);*value=42;return -55;
}
static struct platform_class_buckchg_ops hold_ops={.get_online=hold_cb};
static void *reader(void *unused) { int out=0;(void)unused;int r=platform_class_buckchg_ops_get_online(0,&out);assert(r==-55 && out==42);__atomic_store_n(&reader_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *replace(void *unused) { (void)unused;assert(!platform_class_buckchg_ops_register(0,&token,&all_ops));__atomic_store_n(&replace_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *unregister_old(void *unused) { (void)unused;int r=platform_class_buckchg_ops_unregister(0,&token,&hold_ops);assert(r==-ENOENT);__atomic_store_n(&unregister_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *unregister_current(void *unused) { (void)unused;assert(!platform_class_buckchg_ops_unregister(0,&token,&hold_ops));__atomic_store_n(&unregister_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void wait_sync(int n) { struct timespec start,now;clock_gettime(CLOCK_MONOTONIC,&start);while(__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST)<n){sched_yield();clock_gettime(CLOCK_MONOTONIC,&now);assert(now.tv_sec-start.tv_sec<5);} }
static void concurrency(void) {
 pthread_t a,b,c;CHECK(!platform_class_buckchg_ops_register(0,&token,&hold_ops));
 CHECK(!pthread_create(&a,NULL,reader,NULL));
 pthread_mutex_lock(&hold_lock);while(!entered)pthread_cond_wait(&hold_cond,&hold_lock);pthread_mutex_unlock(&hold_lock);
 int baseline=__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST);
 CHECK(!pthread_create(&b,NULL,replace,NULL));wait_sync(baseline+1);
 CHECK(!__atomic_load_n(&replace_done,__ATOMIC_SEQ_CST));
 CHECK(!pthread_create(&c,NULL,unregister_old,NULL));wait_sync(baseline+2);
 CHECK(!__atomic_load_n(&unregister_done,__ATOMIC_SEQ_CST));
 pthread_mutex_lock(&hold_lock);released=1;pthread_cond_broadcast(&hold_cond);pthread_mutex_unlock(&hold_lock);
 CHECK(!pthread_join(a,NULL));CHECK(!pthread_join(b,NULL));CHECK(!pthread_join(c,NULL));
 CHECK(reader_done && replace_done && unregister_done);
 CHECK(!platform_class_buckchg_ops_unregister(0,&token,&all_ops));
 entered=released=reader_done=unregister_done=0;
 CHECK(!platform_class_buckchg_ops_register(0,&token,&hold_ops));
 CHECK(!pthread_create(&a,NULL,reader,NULL));
 pthread_mutex_lock(&hold_lock);while(!entered)pthread_cond_wait(&hold_cond,&hold_lock);pthread_mutex_unlock(&hold_lock);
 baseline=__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST);
 CHECK(!pthread_create(&c,NULL,unregister_current,NULL));wait_sync(baseline+1);
 CHECK(!__atomic_load_n(&unregister_done,__ATOMIC_SEQ_CST));
 pthread_mutex_lock(&hold_lock);released=1;pthread_cond_broadcast(&hold_cond);pthread_mutex_unlock(&hold_lock);
 CHECK(!pthread_join(a,NULL));CHECK(!pthread_join(c,NULL));CHECK(reader_done && unregister_done);
 int absent=0;CHECK(platform_class_buckchg_ops_get_online(0,&absent)==-1);
}
int main(void) {
 CHECK(!platform_class_buckchg_init());CHECK(registered_drivers==1);
 CHECK(platform_class_buckchg_ops_register(2,&token,&all_ops)==-1);
 CHECK(platform_class_buckchg_ops_register(0,&token,NULL)==-1);
 CHECK(platform_class_buckchg_ops_unregister(2,&token,&all_ops)==-EINVAL);
 CHECK(platform_class_buckchg_ops_unregister(0,&token,NULL)==-EINVAL);
 CHECK(platform_class_buckchg_ops_unregister(0,&token,&all_ops)==-ENOENT);
 CHECK(!platform_class_buckchg_ops_register(0,&token,&all_ops));
 CHECK(!platform_class_buckchg_ops_register(1,&token,&no_ops));
 exercise_all();
 alloc_fail=1;CHECK(platform_class_buckchg_ops_register(0,NULL,&no_ops)==-ENOMEM);alloc_fail=0;
 exercise_all();
 /* Guard the actual USB-sense callback, independently of get_bus_volt. */
 struct platform_class_buckchg_ops usb={.get_usb_sns_volt=cb_get_usb_sns_volt};
 CHECK(!platform_class_buckchg_ops_register(0,&token,&usb));
 int value=0;expected_out=&value;CHECK(platform_class_buckchg_ops_get_usb_sns_volt(0,&value)==-77);CHECK(value==expected_int);
 usb.get_usb_sns_volt=NULL;usb.get_bus_volt=cb_get_bus_volt;
 CHECK(platform_class_buckchg_ops_get_usb_sns_volt(0,&value)==-1);
 CHECK(platform_class_buckchg_ops_unregister(0,&token,&all_ops)==-ENOENT);
 CHECK(!platform_class_buckchg_ops_unregister(0,&token,&usb));
 CHECK(platform_class_buckchg_ops_get_online(0,&value)==-1);
 concurrency();
 CHECK(!platform_class_buckchg_ops_register(0,&token,&all_ops));
 platform_class_buckchg_exit();CHECK(!registered_drivers);CHECK(!live_allocations);
 CHECK(platform_class_buckchg_ops_get_online(0,&value)==-1);
 printf("PASS: %u assertions, 89 callback slots plus 712-byte ABI, allocation failure, role/NULL bounds, pass-through, replaced-provider unregister wait, exit cleanup\\n",assertions);
 return 0;
}
''')
(test/'test_buck.c').write_text(''.join(parts))
(test/'run_buck.sh').write_text('''#!/usr/bin/env bash
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
payload="${1:-$here/../candidate}"
payload="$(cd -- "$payload" && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf -- "$tmp"' EXIT
"${CC:-cc}" -std=gnu11 -O1 -g -Wall -Wextra -Werror -pthread -fsanitize=address,undefined -fno-omit-frame-pointer -I"$here/stubs" -I"$payload/drivers/power/supply/mca/include" -DMCA_BUCK_SOURCE="\\\"$payload/drivers/power/supply/mca/mca_platform/mca_platform_buckchg_class.c\\\"" "$here/test_buck.c" -o "$tmp/test_buck"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=1 "$tmp/test_buck"
''')
