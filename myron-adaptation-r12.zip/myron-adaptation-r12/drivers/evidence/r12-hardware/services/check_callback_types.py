#!/usr/bin/env python3
"""Compile actual new provider declarations against immutable r10 ops types."""
from pathlib import Path
import re,subprocess,json
B=Path(__file__).resolve().parent
OLD=B.parents[2]/'analysis/myron-stage-r10/source-bundle/myron-adaptation-r10/drivers/payload/drivers/power/supply/mca/include/mca'
P=B/'payload/drivers/power/supply/mca'
specs=[('pd',P/'mca_protocol/protocol_pd/qcom_tcpc/qcom_adsp_pd_protocol.c',OLD/'protocol/protocol_pd_class.h','protocol_class_pd_ops'),
 ('qc',P/'mca_qcom_subpmic_proxy/mca_qcom_subpmic_proxy.c',OLD/'protocol/protocol_qc_class.h','protocol_class_qc_ops'),
 ('bc12',P/'mca_qcom_subpmic_proxy/mca_qcom_subpmic_proxy.c',OLD/'platform/platform_bc12_class.h','platform_bc12_class_ops'),
 ('buck',P/'mca_qcom_subpmic_proxy/mca_qcom_subpmic_proxy.c',OLD/'platform/platform_buckchg_class.h','platform_class_buckchg_ops')]
outdir=B/'verification';outdir.mkdir(exist_ok=True);results=[]
for name,p,h,struct in specs:
 source=p.read_text();header=h.read_text()
 decl=re.search(r'struct '+struct+r'\s*\{.*?\n\};',header,re.S)[0]
 init=re.search(r'static struct '+struct+r'\s+\w+\s*=\s*\{.*?\n\};',source,re.S)[0]
 funcs=re.findall(r'\.\w+\s*=\s*(\w+)',init);prototypes=[]
 for fn in funcs:
  if fn=='NULL':continue
  ms=list(re.finditer(r'^static\s+([\w\s*]+?)\s+'+re.escape(fn)+r'\s*\(([^;{}]*?)\)\s*\{',source,re.M));assert len(ms)==1,(fn,len(ms))
  m=ms[0];prototypes.append('extern '+m[1]+' '+fn+'('+m[2]+');')
 prelude='#include <stdint.h>\n#include <stddef.h>\n#include <stdbool.h>\ntypedef unsigned char u8;\ntypedef unsigned short u16;\ntypedef unsigned int u32;\ntypedef unsigned long long u64;\nstruct pd_pdo;\n'
 if name=='pd':
  prelude+='struct adapter_power_cap;\nstruct usbpd_vdm_data;\n'
  prelude+=re.search(r'enum uvdm_state\s*\{.*?\n\};',header,re.S)[0]+'\n'
 code=prelude+decl+'\n'+'\n'.join(prototypes)+'\n'+init+'\n'
 out=outdir/(name+'-actual-callback-types.c');out.write_text(code)
 proc=subprocess.run(['cc','-std=gnu11','-Werror','-Wno-unused-variable','-fsyntax-only',str(out)],capture_output=True,text=True)
 results.append({'name':name,'callbacks':len(prototypes),'passed':proc.returncode==0,'diagnostics':proc.stderr})
(outdir/'callback-types.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2));raise SystemExit(0 if all(r['passed'] for r in results) else 1)
