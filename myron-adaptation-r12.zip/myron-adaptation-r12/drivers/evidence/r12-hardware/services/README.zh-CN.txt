Myron r12：MCA 服务源码候选（18 个模块）

本目录用于整合到 r10/r12 原有 SoC/DDK 编译流程。没有内核镜像、模块刷入包或自动加载名单，不能直接上机。

来源
unmoved21/android_kernel_xiaomi_onyx
提交：8276ba954d8076303a5ae0f7b15d4092d66bdff6
109 个上游源码、头文件和 Makefile 已逐个核验 Git blob SHA1。source-tree-lock.json 与 source-lock-additions.json 保存证据。
SoC PMIC GLINK 头按既有 557159b6a0d06f1c6f07ec4c1f22bc9309a113e4 核对。payload 没有复制或替换任何 r10 已有 MCA 文件；36 个原文件另有不可覆盖哈希。

新增范围
mca_adsp_glink、mca_bmd、mca_business_battery_comp、mca_business_misc_comp、mca_connector_antiburn、mca_ibat_ocp_monitor、mca_lpd_detect、mca_path_control、mca_pd_auth、mca_platform_base、mca_platform_wireless_class、mca_qcom_panel、mca_qcom_subpmic_proxy、mca_strategy_class、mca_strategy_fg_class、mca_vbat_ovp_monitor、mca_wireless_revchg、qcom_adsp_pd_protocol。

源码适配
- platform_driver.remove 改为 Linux 6.12 的 void 原型。
- ADSP PD 的 PPS select/status 以及 fixed-PDO voltage callback 与现有 r10 固定头的 unsigned 原型一致；不改变 r10 的头、布局和既有 PD 修复。
- subpmic proxy 不再声明 r10 buck 结构没有的 get_aicl_status slot；对应未使用函数一并移除，没有造兼容字段。
- 删除上游未使用、返回固定值的 qti_battery_charger_get_prop 兼容实现，保留现有真实 QTI 导出。MCA hboost notifier 的两个导出单独改用 mca_ 前缀，避免夺取现有 QTI 消费者。
- platform_base 保留真实 I2C/regmap 实现，修复未分配指针数组即写入、解析失败不传播、重复 probe initializer 和传输长度边界。
- battery PSY 修复 thermal 注册失败检查、注销、get_by_name 引用释放和 devm/manual 双重注销；thermal 读取错误向上传递。移除时解除 event 注册。
- 无线固件升级四条入口（public、onekey、download、自动 worker）在改 boost、状态和通知之前受 CONFIG_MYRON_IC_FIRMWARE_PROGRAMMING 限制。默认不启用该开关；这不代表全部充电行为已验证。

明确排除
charger_partition 依赖另一内核的 drivers/scsi/sd.h 私有布局，并硬编码分区和直接读写策略。本轮只保留证据，不编译它、不复制其私有头。
因此同时排除 10 个依赖它的策略/业务模块：mca_basic_wireless、mca_buckchg_jeita、mca_business_charger_comp、mca_charger_thermal、mca_qcom_sysfs、mca_quick_wireless、mca_smart_charge、mca_strategy_buckchg、mca_strategy_fg_comp、mca_strategy_quickchg。
没有用 stub 补上述符号。新增 strategy class 是原始注册/转发层；真实策略未注册时按源码返回失败，不能据此声称完整充电策略存在。

集成文件
1. payload/ 复制到 r12 drivers/payload/，只新增文件，拒绝覆盖 r10 同路径。
2. modules.bzl.fragment 追加到原 register_modules(registry) 函数；它已列出组合模块的所有 C 文件、MCA 头和 hwid.h/QTI GLINK 头。
3. Kconfig.fragment 加入设备 Kconfig；myron-services.config 合入配置，选 CONFIG_MYRON_MCA_SERVICES=m。
4. 合并 source-lock-additions.json 的来源、模块契约和不可覆盖哈希。契约的 required_exports 是保守必需子集，不作为实际输出全量名单。aliases 字段刻意省略，等待实际 ELF 核验；ADSP PD 确有 of MODULE_DEVICE_TABLE。
5. 保持本轮实际 ELF 全部 import/CRC、唯一导出提供者与同构建产物校验。不能用源级检查替代它们。

验证
verification/validation.json：109 源输入一致、18 模块 DDK 依赖图无环、140 个必需导出与 run14 symvers 无重复。
100 个真实 callback 声明与原 r10 ops 结构在主机编译器下通过（PD 34、QC 3、BC12 2、buck 61）；故意恢复旧 signed PPS callback 的负例被编译器拒绝。
本轮尚未交叉编译，实际 ELF/CRC 和所有硬件行为均未验证。

实机前阻碍
- MCA 与 QTI battery GLINK 使用同一个 owner 0x800A，当前 DT 的 QTI battery 节点 disabled 是互斥条件，必须保持/明确审核，不能同时注册。
- 即使 QTI 不 probe，其导出的 getter 仍可能由现有 LED/WLED 消费者调用；它把名为 battery 的电源数据视为 QTI 私有结构，而 MCA 注册的是另一结构。仍需真实接口桥接或装配方案，单纯消除重名导出不能解决此问题。
- MCA 私有 hboost notifier 与已有 QTI/haptics 消费者事件路由尚未桥接，不能声称功能等价。
- 由于完整策略依赖链仍未闭合，这 18 项不是完整充电栈，不能直接作为批量 autoload 名单。
- DT 资源、ADSP 消息协议、sysfs/电源名称冲突、异步回调与卸载生命周期仍需实际验证。部分上游 remove 只有空实现；本次只是调整原型，没有把它们伪称为完整清理逻辑。
