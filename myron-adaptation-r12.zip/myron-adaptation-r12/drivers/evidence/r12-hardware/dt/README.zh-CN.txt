R12 充电硬件与 MCA 设备树静态审查

当前结论：可以继续批量编译候选，但不能把匹配 compatible 或编译成功视为可运行充电。
只读取固定源码和已经可信校验的 stock 选择合并 DT；没有运行手机操作、加载模块或改写源包。

可信 DT 输入：
analysis/myron-r10-inputs-20261010/dt-current-audit/current-selected-merged.dtb
SHA256 c3174805b46e7679aded164edfff2c109188e16f41da49c19bd4b79223987802
这不是包含所有 bootloader fixup 的 Android runtime FDT。

范围：四份 IC 候选，MCA 已下载 36 个 C 文件的属性/compatible callsite 对照。
MCA 全源共匹配 26 个 stock 节点，其中 24 个 enabled；这些数量不能当作本轮新增可用驱动数。
当前构建选择快照：18 项 MCA 候选、11 项排除源码参考。最终 integration/真实编译尚待核对。

四个 IC：
1. HL7603：简单 DT 参数已见相符；probe 会写升压阈值。可编译检查，尚未证明 I2C、实际门槛和事件链。
2. BQ27Z561：存在多供应商逻辑，stock 新电池管理属性未被消费；resume 的 NFG OTA 路径不能仅靠缺失 DT 开关视为禁用。未报告 mutex 假阳性。
3. SC8581/SC8585：实际 stock 是 SC8585；pmid2-uvp-threshold=[350,350,100] 被单标量消费，模式相关第三值丢失；probe 错误处理需要修正。
4. SC96281：stock 的 default pinctrl、双 Hall、26×6 FOD 主表与候选两 named-state、单 hall-int2、20×4表不一致；解析失败被忽略，空 FOD 表甚至会返回成功但不写校准。固件 index1 仅证明不越界，未证明内嵌 O11U 固件属于 Myron。
精确源码行及哈希见 ic-subreview/README.zh-CN.txt 和 stock-ic-evidence.json。

MCA 当前候选中的重要未闭合行为：
- mca_wireless_revchg：非factory probe后10秒自动调度更新，满足无USB、Vcell>=3800、SOC>5等条件可调用 download_fw。并非仅手动升级入口，部署门控必须保留。
- mca_adsp_glink、qcom_subpmic_proxy、qcom_adsp_pd_protocol：节点匹配；消息布局、owner/property ID、固件ACK及shutdown/ship-mode/OTG配置尚无Myron运行证据。
- BMD、antiburn：关键GPIO/双NTC节点存在，直接参数schema已见相符，但GPIO/thermal/FG必须真实probe；返回0或注册sysfs不代表保护生效。
- mca_qcom_panel：charge-screen和5个panel引用存在；active DRM panel和screen/HBM事件链仍依赖显示实现。
- mca_platform_wireless_class：1个wireless master名单格式相符，只注册class不代表SC96281硬件可用。
- business_misc和ibat_ocp的stock节点disabled，platform_base无匹配节点；构建这些模块不增加已工作的硬件路径。

被排除的参考源码：
- charger_partition：已明确不输出，不需要为编译伪造其接口。probe工作会写charger分区header/配置，其布局与持久写语义尚未闭合。
- wired quickchg、quick wireless：stock温度表7×9，而候选宽度11，明确解析失败。
- basic wireless：adapter UUID 17组超16上限，原始公共头ADAPTER_MAX=8与stock命令表68cells不合；若将来换头文件须重新按实际include计算。
- JEITA/thermal：主表维度本身相符，但相关排除由完整依赖闭合决定，不能因DT相符就单独自动启用。

本审查不修改原厂电压/电流/温度表，不添加空回调或虚假就绪状态，不批准实机加载或刷机。
同构建ABI、probe依赖、FW写入口及真实设备行为是不同验证步骤。

MCA 当前选定编译候选：
mca_adsp_glink
mca_bmd
mca_business_battery_comp
mca_business_misc_comp
mca_connector_antiburn
mca_ibat_ocp_monitor
mca_lpd_detect
mca_path_control
mca_pd_auth
mca_platform_base
mca_platform_wireless_class
mca_qcom_panel
mca_qcom_subpmic_proxy
mca_strategy_class
mca_strategy_fg_class
mca_vbat_ovp_monitor
mca_wireless_revchg
qcom_adsp_pd_protocol

排除参考：
charger_partition
mca_basic_wireless
mca_buckchg_jeita
mca_business_charger_comp
mca_charger_thermal
mca_qcom_sysfs
mca_quick_wireless
mca_smart_charge
mca_strategy_buckchg
mca_strategy_fg_comp
mca_strategy_quickchg

PMIC glink互斥补核对：stock选择DT与run14诊断DT中，/soc/pmic-glink/battery-charger均disabled，mca,adsp_glink均ok。保留此状态；未把两份源码owner相同误判成当前已发生双probe。证据pmic-glink-parent-status.json。
