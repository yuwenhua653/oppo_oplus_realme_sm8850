四个充电 IC 候选源码的独立静态复核

范围与输入
只读取源码和已有 stock DT；没有编译、加载模块、读取手机寄存器、更新固件或刷入。
候选仓库 unmoved21/android_kernel_xiaomi_onyx，固定提交 8276ba954d8076303a5ae0f7b15d4092d66bdff6。
18 份源码/头文件/Makefile 的大小和 SHA256 全部与 source-receipt.json 一致。
stock DT：analysis/myron-r10-inputs-20261010/dt-current-audit/current-selected-merged.dtb
SHA256：c3174805b46e7679aded164edfff2c109188e16f41da49c19bd4b79223987802。
证据与复跑：stock-ic-evidence.json；python3 audit_ic_dt.py。

下文源码文件名均相对：
analysis/myron-r12-hardware/charge-ic/upstream/drivers/power/supply/mca/mca_hardware_ic/
HL = boost_ic/hl7603/hl7603.c
FG = fuelgauge_ic/bq27z561/bq27z561.c
CP = charge_pump_ic/sc8581/sc8581.c
WLS = wireless_ic/sc96281/sc96281_charger.c
WLSH = wireless_ic/sc96281/inc/sc96281_reg.h
MTP = wireless_ic/sc96281/sc96281_mtp_program.c
FW = wireless_ic/sc96281/inc/sc96281_firmware.h
解析器辅助证据：analysis/myron-r12-hardware/bundle/myron-adaptation-r12/drivers/upstream/charge/8276ba954d80/drivers/power/supply/mca/mca_common/mca_parse_dts.c。

结论
四个驱动都能找到 stock DT 的 compatible，但不能直接据此发布可加载/可刷入模块。
HL7603 的已见简单 DT 属性相符；BQ 仍有行为和固件路径差异；SC8585 的保护阈值由数组退化为标量；SC96281 有明确的 GPIO/pinctrl/FOD 协议不匹配。后两项属于具体适配缺口，不是缺采集清单。

1. HL7603
stock 节点 /soc/qcom,qupv3_1_geni_se@ac0000/i2c@a94000/hl7603@77：compatible=hl7603，reg=0x77，vout_threshold=3400，没有 support_hbm。
HL:109–125 解析 of_node、vout_threshold（默认3400）、support_hbm、条件式 hbm_vout_threshold。当前 DT 不启用 HBM 分支。
HL:134–140 校验范围并写寄存器；inc/hl7603.h:44–47 定义寄存器0x02、2850–5500、步长50。3400对应值11。
HL:184–188 在 probe 即写电压门槛，并非只做硬件识别；没有单独芯片 ID 校验。
HL:195–196 注册 MCA panel notifier；HL:158–162 在 HBM 事件中继续写门槛；CONFIG_DEBUG_FS 下还依赖 mca_debugfs_create_group（190–193）。
需要的提供者：I2C adapter/SMBus、MCA DT parser、事件链；调试配置启用时还需要 MCA debugfs。需以同构建符号/接口、真实 I2C 绑定和门槛回读验证，静态匹配不能证明 HBM 或升压实机可用。
本文件未见固件下载路径，但 probe 本身会改变硬件寄存器。

2. BQ27Z561（实际上包含多供应商 gauge 路径）
stock 节点 /soc/qcom,qupv3_1_geni_se@ac0000/i2c@a94000/bq27z561_standlone@55：compatible=ti,bq27z561_master，reg=0x55，ic_role=0，status=ok。
已见参数 bq,charge-full-design=7560、soh_th=92、cycle_th=400、cycle_step=50、resistance-id=100000，unseal_key存在且4字节。FG:4236–4242 读取这些属性，含默认值；读取 key 的失败未作为 probe 失败处理。
stock 还有 support_batt_manager_4p0、base_termv/base_termv_gl、delta_soh_compesation/delta_soh_compesation_gl；当前 FG 源码完全没有读取这些名称。只能证明此候选驱动没有相应实现，不能推断整套 MCA 的其它模块是否代为消费。
条件参数：bq,soc_decimal_rate 若存在需成对 u32（4216–4231）；support-voltage-record-level 若启用需 version_number/start_byte_address/byte_length/record_voltage（4244–4264）；co_by_gpio 若启用还需要 batt_ctl 并直接输出低电平（4273–4289）。上述开关均未出现在此 stock 节点，不能为了通过 probe 擅自补默认启用。
FG:6296 忽略 bq_parse_dt 返回值。FG:6299–6306 读制造商失败会延迟探测，但 probe_cnt 是跨设备共享静态计数（6275），达到上限走 out；FG:6339–6343 会发错误事件后仍返回0。ops 注册失败同样走 out 并最终返回0（6321–6325、6343）。因此 “probe成功/已绑定” 日志不能独立作为功能通过。
FG:6311–6319 的 probe 包含终止电流配置、关闭快充模式、厂商/固件识别及 nfg1000_boot_app_judge；不是纯只读探测。fg_set_term_config 对 BQ27Z561 写终止电流 MAC（4296–4307）。
固件路径：
  a. probe 的 nfg1000_boot_app_judge 在 support_nvt1000_ota=0 时返回（5089–5090）；stock 缺此属性，解析默认0（4270–4271）。
  b. 但 resume 在 fg_vendor=NFG1000A/B 时直接调用 nfg1000_ota_update_check（6368–6371），此调用链没有同样的 DT 开关检查。update_judge 还检查实际 pack 名 XM15、FFN 和版本条件（4834–4874）。符合条件时可以进入 update_APP（5063–5075），执行解锁、boot、认证、flash 更新（5016–5055、4711–4774）。所以“DT没有 OTA开关”不足以证明运行时不会写固件。
  c. FG:3456–3578 还包含 MPC8011B 的 record-voltage/版本写入路径；该路径受 support_voltage_record_level 与实际厂商限制，当前 DT 未启用。
  d. FG:6244–6263 / 6329 有 platform_version=3、country_version=0 和设备名3XM31时的 SOH 修改；不能把其它机型 HWID 映射照搬到 Myron。
注意：nfg1000_update_judge 的多次 mutex_lock 不是已证实死锁；其 __fg_mac_read_block 在4413行主动 unlock，属于特殊调用契约。此处已追踪被调函数，不把表面锁次数误报为缺陷。
部署前需明确实际 gauge 供应商、平台/电池选择规则及允许的非易失写入策略；覆盖 probe/resume/ops 三条入口；保留确实需要的正常寄存器配置，但不能让未验证的内嵌旧固件自动升级芯片。

3. SC8581 源码匹配 stock 的 SC8585 master
stock 节点 /soc/qcom,qupv3_1_geni_se@ac0000/i2c@a94000/sc8585_master@6e：compatible=sc8585_master，reg=0x6e，ic_role=0，status=ok；不是名称为sc8581的节点。
CP:2642–2646 包含 sc8585_master/slave 的匹配项；CP:1735–1762 用寄存器0x6e识别 SC8585/SC8581/SC8561，实际芯片 ID 仍需运行时确认。
CP:2343–2353 硬性要求 cp-int 和 cp-nlpm-gpio；当前 DT 均存在，指向 phandle48 的 GPIO68 / GPIO114。CP:2417–2435 master 会请求 nlpm并输出1、等待400ms。CP:2387–2414 还需中断控制器支持 GPIO到IRQ和下降沿IRQ。
注意 CP:2531 的 GPIO初始化错误被下一行设备探测返回值覆盖；CP:2343–2353把 GPIO供应者延迟等错误变为-1，未保留-EPROBE_DEFER；CP:2570 未检查 MCA cp ops 注册返回值。
当前 DT 保护参数：
  bat-ovp=4700，bat-ovp-alarm=4650；
  bus-ovp=[21000,12000,6000]，usb-ovp=[21000,14000,7500]，bus-ocp=[5000,5500,5000]；
  wpc-ovp=21000，out-ovp=5000，pmid2-ovp=600；
  pmid2-uvp=[350,350,100]。
CP:2356–2382 读取配置，但 pmid2-uvp-threshold 在2379–2380只读单个u32；辅助解析器47–63调用of_property_read_u32，因此只使用首值350。CP:1637所有模式均使用该标量；与 stock 的三值表达存在明确语义差异，第三项100被丢弃。不要通过删掉数组元素来掩盖差异，应追溯模式含义并适配到对应工作模式。
CP:2518–2520 还会在特定HWID将I2C地址强制改成0x6f；条件由2486–2496与40–42定义（platform_version=3、hwid=0x10004）。需要验证 Myron的真实 HWID映射，不可假设永远不会进入。
probe经CP:2547执行init_device：寄存器复位、并联模式、门控、ADC、中断、2:1工作模式及0x42寄存器写入（1662–1726）；模式切换还会重写保护阈值（895–937、1616–1640）。CP:1620–1638连续覆盖ret，早期写失败可能被后续成功掩盖。
本文件未见固件下载，但会主动改写充电保护/模式寄存器。MCA cp class、event、log、hwid 及I2C/GPIO/IRQ实现均是实际依赖。

4. SC96281：当前 DT 不兼容候选解析契约
stock 节点 /soc/qcom,qupv3_4_geni_se@1ac0000/i2c@1a8c000/sc96281@33：reg=0x33，compatible=sc,sc96281-wireless-charger，rx_role=0，project_vendor=4，support-hall=1，fw_version_index=1。
GPIO为 phandle48：sleep-rx-gpio=200、rx-int=69、pwr-det-int=57、hall-n-int=78、hall-s-int=79。
明确缺口A：stock pinctrl-names只有default，7个pinctrl phandle；WLS:3261–3277要求rx_int_pull_up状态；support-hall=1时3280–3293还要求hall_int_pull_up。两个名称都不存在。
明确缺口B：候选WLS:3318–3323只读取hall-int2；stock提供独立hall-n-int、hall-s-int。必须正确适配双Hall语义，不能任取一个GPIO或仅改属性名。
明确缺口C：stock /soc/mca_sc96281_fod_data 的 fod_params 是26行×6字符串=156项，fod_params_default为6项，还具有fod_params_2_1。候选WLSH:67–73定义最多20行、每行4列，WLS:3113–3117 / 3164–3168使用该限制；辅助解析器197–215要求项数为列数倍数且不超过row×col。因此主表156>80被拒绝，默认表6%4!=0也被拒绝。候选未读取fod_params_2_1；其结构也没有stock每行多个磁吸场景的完整表达。需迁移真正匹配的FOD数据模型和选择逻辑，不可截断stock表。
探测错误处理：WLS:3259不检查FOD解析；FOD返回值在3228–3229被第二次解析覆盖；probe:3497–3498忽略DT与IRQ初始化返回值。IRQ在3336–3436注册，work直到3500–3504才初始化，而IRQ处理器可schedule这些work（2952–2958、3012–3015）：存在初始化顺序窗口。platform ops失败经3525–3527仍返回0。应先完成并验证所有数据和work初始化，再允许IRQ触发，并正确回滚资源。
固件：FW共有3个32768字节条目，stock index1在数组范围内；FW:4124–4125将该条目注释为O11U。数组索引合法不等于 Myron的校准/固件正确；当前没有stock固件内容哈希匹配证据。
WLS:3215–3224直接按fw_version_index选内嵌固件而没有界限检查。当前值1不越界，但解析器应防止异常DT越界。
WLS:2391–2412 可依据版本判断进入mtp_program；外部bin入口2445–2461也可进入；这些入口已注册为MCA ops（2817–2823）。MTP:896–900先擦除再写代码，940–975从内嵌/传入固件指针编程。probe本身未直接调用mtp_program；不能在未检查外层策略调用者前断言“加载即刷固件”，也不能认定无自动升级风险。
probe还会设置sleep GPIO，注册reboot notifier，1秒后按power_good切换enable（WLS:3301–3309、3506–3517、2906–2920）；卸载/回滚、reboot、MCA策略联动需要同样验证。

可推进的工作与边界
可以把四份源码作为隔离的编译候选，围绕上述具体差异开发并完成同构建接口检查；不能因此把它们加入自动实机加载名单。优先解决 SC96281 的双Hall/pinctrl/FOD契约、SC8585的分模式UVP阈值、fuel-gauge及wireless的非易失写入入口控制。所有需要硬件配置的数值采用已有stock证据，不靠猜测补默认值。
分项状态：
  HL7603：可进入编译/接口验证；已见DT参数无明确冲突；实机probe即写寄存器，仍不可据此直接部署。
  BQ27Z561：可进入编译/接口验证；缺少stock新增电池管理属性语义、真实厂商/pack路径与固件入口确认，不可直接部署。
  SC8581/SC8585：可进入编译/接口验证；分模式UVP值不兼容且probe错误处理待修，不可直接部署。
  SC96281：仅可进入隔离编译/接口验证；pinctrl、双Hall、FOD均存在明确失败条件，probe错误被吞掉，未解决前不可直接部署。
以上“可进入编译验证”只是下一开发步骤，未声称已经编译通过。这18份文件也不是独立可编译的完整输入，仍依赖匹配的MCA头文件（FG还include hwid.h）、平台实现与Kbuild配置。
本报告没有证明四芯片当前都实际装配/绑定、I2C通信正常、校准正确或充电可用；完整充电链还需要MCA策略/平台/PMIC/温度/PD协同，不等价于四个KO编译成功。
