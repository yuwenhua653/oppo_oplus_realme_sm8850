#!/usr/bin/env python3
"""Evidence for three candidate wireless strategies, without compiling/loading."""
import hashlib
import importlib.util
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = ROOT/'analysis/myron-r12-hardware/mca-services'
DT = ROOT/'analysis/myron-r10-inputs-20261010/dt-current-audit/current-selected-merged.dtb'
PARSER = ROOT/'analysis/myron-stage-r10/source-bundle/myron-adaptation-r10/bindings/verify_binding_evidence.py'
spec = importlib.util.spec_from_file_location('fdt_evidence',PARSER)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
nodes = mod.read_fdt(DT)
lock = json.loads((BASE/'source-tree-lock.json').read_text())
result = {'scope':'unmodified downloaded candidate, not final preprocessed build; read-only static audit', 'repository':lock['repo'], 'commit':lock['pin'], 'dt_sha256':hashlib.sha256(DT.read_bytes()).hexdigest(), 'sources':[], 'nodes':{}}
for e in lock['entries']:
    if '/strategy_wireless/' not in e['path'] and not e['path'].endswith('include/mca/strategy/strategy_wireless_class.h'):
        continue
    p = BASE/'upstream'/e['path']
    d = p.read_bytes()
    actual = hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
    assert actual == e['sha']
    result['sources'].append({'path':str(p.relative_to(ROOT)),'bytes':len(d),'git_blob_sha1':actual,'sha256':hashlib.sha256(d).hexdigest()})

for name in ['mca_strategy_basic_wireless_class','mca_strategy_quick_wireless_class','mca_strategy_wireless_revchg_class','mca_quick_wireless_batt_para_gbl']:
    path = '/soc/'+name
    props = nodes[path]
    encoded = {}
    for k,v in props.items():
        entry = {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
        is_text = v and v.endswith(b'\0') and all(c == 0 or 32<=c<127 for c in v) and any(c!=0 for c in v)
        if is_text:
            vals = v[:-1].decode().split('\0')
            entry.update(strings=vals,string_count=len(vals))
        elif not v:
            entry['boolean_present']=True
        elif len(v)%4==0:
            entry['cells']=list(struct.unpack('>'+'I'*(len(v)//4),v))
        else:
            entry['hex']=v.hex()
        encoded[k]=entry
    result['nodes'][path]=encoded

b=result['nodes']['/soc/mca_strategy_basic_wireless_class']
q=result['nodes']['/soc/mca_strategy_quick_wireless_class']
g=result['nodes']['/soc/mca_quick_wireless_batt_para_gbl']
checks=[]
def check(node,prop,kind,row,col):
    p=result['nodes'][node][prop]
    n=p['string_count'] if kind=='strings' else len(p['cells'])
    checks.append({'node':node,'property':prop,'encoding':kind,'actual_count':n,'candidate_rows':row,'candidate_columns':col,'candidate_count_accepted':0<n<=row*col and n%col==0})
check('/soc/mca_strategy_basic_wireless_class','adapter_para','strings',16,2)
check('/soc/mca_strategy_basic_wireless_class','adapter_cmd_type_para','strings',6,2)
for i in range(6):check('/soc/mca_strategy_basic_wireless_class','adapter_cmd_type_f'+str(i),'cells',8,2)
for node,props in [('/soc/mca_strategy_quick_wireless_class',q),('/soc/mca_quick_wireless_batt_para_gbl',g)]:
    check(node,'batt_para','strings',16,3)
    for key in props:
        if key.startswith('wls_batt_para_') or key=='temp_para1':check(node,key,'strings',10,11)
result['schema_checks']=checks
result['limitations']=['No final include resolution/preprocessor audit; ADAPTER_MAX=8 is the verified downloaded header.', 'Count acceptance does not validate numeric calibration, array ordering, runtime battery choice or charging safety.']
(OUT/'wireless-strategy-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sources_verified':len(result['sources']),'schema_checks':checks},ensure_ascii=False))
