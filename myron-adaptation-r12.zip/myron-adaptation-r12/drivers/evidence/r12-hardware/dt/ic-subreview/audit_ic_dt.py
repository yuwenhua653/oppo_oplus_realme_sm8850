#!/usr/bin/env python3
"""Read-only locked-source/stock-DT evidence; no hardware operations."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
SRC = ROOT / 'analysis/myron-r12-hardware/charge-ic'
DT = ROOT / 'analysis/myron-r10-inputs-20261010/dt-current-audit/current-selected-merged.dtb'
PARSER = ROOT / 'analysis/myron-stage-r10/source-bundle/myron-adaptation-r10/bindings/verify_binding_evidence.py'
spec = importlib.util.spec_from_file_location('binding_evidence', PARSER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
nodes = module.read_fdt(DT)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def strings(value):
    return value.rstrip(b'\0').decode().split('\0')

compatibles = {'hl7603', 'ti,bq27z561_master', 'ti,bq27z561_slave', 'ti,bq28z610', 'sc8581', 'sc8585_master', 'sc8585_slave', 'sc,sc96281-wireless-charger', 'mca_sc96281_fod_data'}
result = {'scope':'read-only static source/stock DT comparison; no build, load or flash claim', 'dt': {'path': str(DT.relative_to(ROOT)), 'sha256':sha(DT)}, 'source_receipt': [], 'nodes': []}
for entry in json.loads((SRC/'source-receipt.json').read_text()):
    path = SRC/'upstream'/entry['source_path']
    assert sha(path) == entry['sha256'], path
    assert len(path.read_bytes()) == entry['bytes'], path
    result['source_receipt'].append(entry)

for path, props in nodes.items():
    comps = strings(props['compatible']) if 'compatible' in props else []
    if not compatibles.intersection(comps):
        continue
    item = {'path':path, 'compatible':comps, 'properties':{}}
    for key,value in props.items():
        prop = {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()}
        # Avoid printing the gauge key: presence/width is sufficient here.
        if key == 'unseal_key':
            prop['value_omitted'] = True
        elif key in ('compatible','status','pinctrl-names') or key.startswith('fod_params'):
            prop['strings'] = strings(value)
            prop['string_count'] = len(prop['strings'])
        elif len(value)%4 == 0 and not key.startswith('params_'):
            prop['cells'] = list(struct.unpack('>'+'I'*(len(value)//4),value))
        else:
            prop['hex'] = value.hex()
        item['properties'][key]=prop
    result['nodes'].append(item)

fw = SRC/'upstream/drivers/power/supply/mca/mca_hardware_ic/wireless_ic/sc96281/inc/sc96281_firmware.h'
txt = re.sub(r'//[^\n]*|/\*.*?\*/', '', fw.read_text(), flags=re.S)
body = txt.split('unsigned char SC96281_FIRMWARE[][32768] = {',1)[1].split('};',1)[0]
groups = re.findall(r'\{([^{}]*)\}',body,re.S)
parsed = [bytes(int(x,16) for x in re.findall(r'0x([0-9a-fA-F]+)',g)) for g in groups]
assert len(parsed)==3 and all(len(g)==32768 for g in parsed)
result['firmware']={'file':str(fw.relative_to(ROOT)),'array_rows':len(parsed),'rows':[{'index':i,'bytes':len(g),'sha256':hashlib.sha256(g).hexdigest()} for i,g in enumerate(parsed)],'stock_index':1,'index_in_bounds':True,'stock_firmware_identity_proven':False}
wireless = next(n for n in result['nodes'] if 'sc,sc96281-wireless-charger' in n['compatible'])
fod = next(n for n in result['nodes'] if 'mca_sc96281_fod_data' in n['compatible'])
result['sc96281_contract_checks'] = {
  'stock_pinctrl_names':wireless['properties']['pinctrl-names']['strings'],
  'candidate_named_states_missing': [n for n in ('rx_int_pull_up','hall_int_pull_up') if n not in wireless['properties']['pinctrl-names']['strings']],
  'candidate_hall_int2_missing':'hall-int2' not in wireless['properties'],
  'stock_dual_hall_present':all(k in wireless['properties'] for k in ('hall-n-int','hall-s-int')),
  'fod_params_strings':fod['properties']['fod_params']['string_count'],
  'fod_default_strings':fod['properties']['fod_params_default']['string_count'],
  'candidate_fod_max_strings':20*4,
  'candidate_fod_columns':4,
  'candidate_main_fod_count_valid':0 < fod['properties']['fod_params']['string_count'] <= 80 and fod['properties']['fod_params']['string_count']%4==0,
  'candidate_default_fod_count_valid':0 < fod['properties']['fod_params_default']['string_count'] <= 80 and fod['properties']['fod_params_default']['string_count']%4==0,
}
(OUT/'stock-ic-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verified_sources':len(result['source_receipt']),'dt_nodes':len(result['nodes']),'sc96281_contract_checks':result['sc96281_contract_checks']},ensure_ascii=False))
