MCA / QTI 接口独立复核与真实修复候选

本目录由独立审查产生；未修改 MCA agent 的共享源文件。

已实现的 QTI 修复
  qti_battery_charger_get_prop() 原实现通过 "battery" 等名称取得 power_supply，
  然后无条件把 drvdata 当成 battery_chg_dev。MCA 注册的同名 battery 的私有数据
  是 batt_psy_info。只保留 QTI 符号并不能证明这两套数据结构可混用。

  修复现在先检查 power_supply 的 get_property 回调是否属于 QTI 本驱动的
  battery/USB/wireless 实现；外部同名 supply 在读取 drvdata 之前返回 -ENODEV。
  同时增加参数检查，把引用保留到读取完成，成功和错误路径均正确 put。
  不使用设备名字作为数据类型证明，不返回伪造电阻值，不改变导出函数签名。

  源仓库：LineageOS/android_kernel_qcom_sm8850
  提交：557159b6a0d06f1c6f07ec4c1f22bc9309a113e4
  目标：drivers/power/supply/qti_battery_charger.c
  prepare_qti_psy_guard.py 校验原 Git blob 并输出固定修复、diff 与 SHA 清单。
  payload/ 中为可接入 root 累计源码包的候选；没有直接改外部仓库或手机。

验证
  python3 prepare_qti_psy_guard.py
  python3 test_qti_psy_guard.py
  后者提取候选源文件内的真实 getter 编译，15 个 fake power-supply 核心分支通过，
  包括外来/空回调/空私有数据拒绝、4 个 QTI 电源名正常读取、错误传播及引用配对。
  开启 -O2、-Wall、-Wextra、-Werror 和 UndefinedBehaviorSanitizer。
  这不是内核构建或 ABI 验证；实际目标 CRC/KCFI 和实机仍待 CI/运行测试。

MCA 源码复核
  所选 18 模块的 remove 回调均为 void。
  107 项可解析的 ops 函数原型与 r10 优先合并头相符；词法扫描不能代替 C 编译。
  39 个 power_supply 标识存在于 Linux v6.12 官方头；thermal API 原型相符。
  mca_vbat_ovp_monitor 隐藏的 hwid.h / CountryCN 依赖已加入 DDK。
  battery 的 devm power_supply、thermal zone 和额外 supply 引用清理修复已复核。

导出与 transport 约束
  原新增 proxy 与 run14 QTI 重复三个导出。MCA 源码现已隔离两项 hboost 名字，
  移除固定返回 100000/0 的 getter，当前显式导出扫描没有剩余重名。
  QTI notifier 的原消费者是 qcom_hv_haptics、swr_haptics_dlkm；getter 的原消费者
  是 leds_qcom_flash、qcom_spmi_wled。符号隔离不等于这些功能获得等价 MCA 实现。

  MCA glink 和 QTI charger 的 owner 都是 32778 / 0x800A，同 parent 下唯一注册。
  但 stock/run14 选中 DT 中 QTI battery-charger 节点 disabled，MCA 节点 ok，
  因此没有证据说明当前 DT 会同时 probe。后续不能未经真实桥接而同时启用二者。

范围
  编译候选接口修复，不是可刷包、不证明充电或温控完整。
  exact ACK power_supply/thermal 头未成功取到，API 参考采用已验 Git blob 的
  Linux v6.12 官方头；目标编译仍是必要验证。
