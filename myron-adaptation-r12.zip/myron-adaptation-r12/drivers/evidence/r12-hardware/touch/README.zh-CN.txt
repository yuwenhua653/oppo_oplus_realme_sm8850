Myron FT3683 控制器源码核对（r12）

结论：尚无经过匹配的控制器源码可以接入。没有创建假的 focaltech_touch_3683
编译目标，没有改名 FT3383、FT3683G/U 或通用 focaltech_fts，没有修改 r10 源码。

本轮实际核验
  MiCode/vendor_xiaomi_proprietary_touch-driver 两个指定提交的完整递归树：
  c286ab85f4982c9b5967e18405f4e2da0332ce4d：130 项，FocalTech 只有 q200/FT3383。
  57d9a0225b031f4b444251117f3ecc9deae71128：56 项，控制器为 Goodix 9916K。
  当前官方 8 分支的提交号与 r7 一致，无 myron 分支。
  精确版本、测试源文件名搜索无匹配；p11u/focaltech 仅找到固件清单。
  搜索范围有限，不能据此宣称所有公开来源永远不存在源码。

真实设备接口
  原厂模块 focaltech_touch_3683.ko，版本 FT3683:2025.07.17-001。
  原厂嵌入路径 touchfeature_v2/touch_driver/p11u/focaltech_3683/。
  实际选中的分区 DT 匹配 focal,touch-spi，节点启用。
  run14 的 focaltech_fts 匹配 focaltech,fts_ts；名字相近不构成驱动等价。

不能直接复用原厂 ko
  本工具逐个核对 run14 模块文件 SHA，并从 ELF 读取导入/导出版本。
  原厂 FT3683 的 161 项导入中，92 项 CRC 匹配，69 项不匹配。
  14 项 xiaomi_touch 接口中，10 项 CRC 匹配，4 项不匹配：
    add_common_data_to_buf
    register_touch_panel
    xiaomi_register_panel_notifier
    xiaomi_unregister_panel_notifier
  这里的 CRC 不匹配包含内核类型传播的影响，不能反向推断每个函数语义都改变。
  也不能修改 CRC/强制加载来掩盖结构、回调或 KCFI 差异。

可复用的真实参考
  MiCode p2/qts 中确有 qts_client_register、get_qts_data_helper、
  qts_ts_resume、qts_ts_suspend 四个实现，已经保存并核对 Git blob。
  它们位于 Synaptics P2 子树，不能单独变成 FT3683 控制器。
  未来接入时还需解决与高通通用 qts 的同名导出冲突及状态所有权。
  reference-only 下文件只供比对，不是完整驱动源码、固件包或部署输入。

已有工具
  python3 audit_ft3683.py
  默认使用当前工作区的原厂模块、run14 产物和 r11 DT 证据；也可通过
  --stock、--inventory、--objects、--symvers、--dt-audit 指定同一证据集合。
  输出 source-audit-r12.json。此工具不联网、不编译、不加载模块。
  工具成功退出只说明审计完成，结果仍明确为 BLOCKED_NO_MATCHED_CONTROLLER_SOURCE。

接入前尚缺
  匹配 Myron 的控制器核心、SPI/event 数据、固件/ECC/升级协议和测试 IC 实现；
  确认芯片/boot ID（包括 CID fallback）、FOD/THP、坐标事件和供电时序；
  基于当前 6.12/DDK 完整重编，使用实际 xiaomi_touch、QTS/Gunyah 头文件；
  随后才有依据建立模块目标、验证 ABI/KCFI 并进入硬件试验。
