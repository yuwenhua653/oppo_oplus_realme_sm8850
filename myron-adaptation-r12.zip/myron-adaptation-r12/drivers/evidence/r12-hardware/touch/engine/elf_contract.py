"""Read AArch64 module import versions/export CRCs from the module itself."""
from collections import defaultdict
import struct


def parse(data):
    if len(data) < 64 or data[:7] != b'\x7fELF\x02\x01\x01' or struct.unpack_from('<HH', data, 16) != (1,183):
        raise ValueError('Expected AArch64 ELF64 ET_REL')
    offset = struct.unpack_from('<Q',data,40)[0]
    size, count, index = struct.unpack_from('<HHH',data,58)
    if size != 64 or offset + 64 > len(data):
        raise ValueError('Invalid section header')
    first = struct.unpack_from('<IIQQQQIIQQ',data,offset)
    count = count or first[5]
    index = first[6] if index == 65535 else index
    if not 0 < count <= 65536 or index >= count or offset + count*64 > len(data):
        raise ValueError('Invalid section bounds')
    headers = [struct.unpack_from('<IIQQQQIIQQ',data,offset+i*64) for i in range(count)]
    def content(h):
        if h[1] == 8 or h[4]+h[5] > len(data):
            raise ValueError('Expected bounded file-backed ELF section')
        return data[h[4]:h[4]+h[5]]
    def text(blob,start):
        end = blob.find(b'\0',start)
        if start >= len(blob) or end < 0:
            raise ValueError('Unterminated ELF string')
        return blob[start:end].decode('ascii')
    names = content(headers[index])
    sections = {}
    for h in headers:
        name = text(names,h[0])
        if name in sections and name:
            raise ValueError('Duplicate ELF section name')
        sections[name] = h
    def get(name):
        return content(sections[name]) if name in sections else b''
    versions, version_records = {}, set()
    def version(name,crc,form):
        if not name or (form,name) in version_records or (name in versions and versions[name] != crc):
            raise ValueError('Empty/duplicate/conflicting import version')
        version_records.add((form,name))
        versions[name] = crc
    raw = get('__versions')
    if len(raw)%64:
        raise ValueError('Malformed versions')
    for i in range(0,len(raw),64):
        version(text(raw[i+8:i+64],0),struct.unpack_from('<Q',raw,i)[0], 'basic')
    raw_names, raw_crcs = get('__version_ext_names'),get('__version_ext_crcs')
    if raw_names or raw_crcs:
        if not raw_names.endswith(b'\0'):
            raise ValueError('Unterminated extended version names')
        entries = raw_names.rstrip(b'\0').split(b'\0')
        if len(raw_crcs) != 4*len(entries):
            raise ValueError('Malformed extended versions')
        for i,name in enumerate(entries):
            version(name.decode('ascii'),struct.unpack_from('<I',raw_crcs,i*4)[0], 'extended')
    exports, export_crcs, imports, weak = set(),{},set(),set()
    symtabs = 0
    for h in headers:
        if h[1] != 2:
            continue
        symtabs += 1
        if h[6] >= count or h[9] != 24:
            raise ValueError('Invalid symbol table')
        strings, symbols = content(headers[h[6]]),content(h)
        if len(symbols)%24:
            raise ValueError('Unaligned symbol table')
        for i in range(0,len(symbols),24):
            n, info, _, section, value, _ = struct.unpack_from('<IBBHQQ',symbols,i)
            name = text(strings,n)
            if not section and name:
                if info>>4 == 1: imports.add(name)
                if info>>4 == 2: weak.add(name)
            if section and info & 15 != 3 and name.startswith('__ksymtab_'):
                exports.add(name[len('__ksymtab_'):])
            if section and info & 15 != 3 and name.startswith('__crc_'):
                symbol = name[len('__crc_'):]
                if symbol in export_crcs:
                    raise ValueError('Duplicate export CRC symbol')
                if section == 0xfff1:
                    if value > 0xffffffff: raise ValueError('Invalid absolute CRC')
                    crc = value
                else:
                    if section >= count or text(names,headers[section][0]) not in ('__kcrctab','__kcrctab_gpl'):
                        raise ValueError('CRC symbol not in known CRC table')
                    raw = content(headers[section])
                    if value+4 > len(raw) or value%4:
                        raise ValueError('CRC symbol outside table')
                    crc = struct.unpack_from('<I',raw,value)[0]
                export_crcs[symbol] = crc
    if symtabs != 1 or exports != set(export_crcs):
        raise ValueError('Module export CRC set differs from actual exported symbols')
    if imports - versions.keys():
        raise ValueError('Strong imports without MODVERSIONS: '+', '.join(sorted(imports-versions.keys())))
    if 'module_layout' not in versions:
        raise ValueError('Missing module_layout version')
    return {'exports':export_crcs,'imports':imports,'weak_imports':weak,'versions':versions}


def symvers(raw):
    providers = {}
    for line in raw.decode().splitlines():
        fields = line.split()
        if len(fields) < 4 or fields[2] != 'vmlinux':
            raise ValueError('Unexpected vmlinux.symvers row')
        symbol, crc = fields[1], int(fields[0],16)
        if symbol in providers:
            raise ValueError('Duplicate vmlinux provider')
        providers[symbol] = crc
    if not providers or 'module_layout' not in providers:
        raise ValueError('Incomplete vmlinux export evidence')
    return providers


def verify_and_expand(roots,candidates,contracts,kernel,order_function):
    providers = defaultdict(list)
    for symbol,crc in kernel.items():
        providers[symbol].append(('vmlinux',crc))
    for name,contract in contracts.items():
        for symbol,crc in contract['exports'].items():
            providers[symbol].append((name,crc))
    expanded = {n:dict(m,depends=list(m['depends'])) for n,m in candidates.items()}
    visited, edges, reports = set(),[],[]
    def inspect(name):
        if name in visited:return
        if name not in candidates:raise ValueError('Unresolved selected hard dependency: '+name)
        visited.add(name)
        contract = contracts[name]
        matched = []
        for symbol,crc in sorted(contract['versions'].items()):
            matches = providers.get(symbol,[])
            if len(matches) != 1:
                raise ValueError('Missing/ambiguous symbol provider: '+name+':'+symbol+':'+str(matches))
            provider, provider_crc = matches[0]
            if provider_crc != crc:
                raise ValueError('Import CRC mismatch: '+name+':'+symbol)
            if provider == name:
                raise ValueError('Module imports its own versioned export: '+name+':'+symbol)
            matched.append({'symbol':symbol,'crc':hex(crc),'provider':provider})
            if provider != 'vmlinux' and provider not in expanded[name]['depends']:
                expanded[name]['depends'].append(provider)
                edges.append({'consumer':name,'provider':provider,'first_symbol':symbol,
                              'reason':'Actual ELF import provider absent from modinfo depends'})
        for dep in sorted(expanded[name]['depends']):inspect(dep)
        reports.append({'name':name,'checked_import_crcs':len(matched),'resolved_imports':matched,
                        'weak_imports_without_version':sorted(contract['weak_imports']-contract['versions'].keys()),
                        'weak_imports_with_version':sorted(contract['weak_imports'] & contract['versions'].keys())})
    for root in roots:inspect(root)
    order = order_function(roots,expanded)
    return expanded,{'passed':True,'scope':'All closure version CRCs resolved against exact vmlinux.symvers and selected module ELF export CRCs; no unrelated Module.symvers',
                     'closure_module_count':len(order),'checked_import_crcs':sum(r['checked_import_crcs'] for r in reports),
                     'symbol_provider_edges_added':edges,'modules':sorted(reports,key=lambda x:x['name']),
                     'cfi_type_compatibility_verified':False,'hardware_compatibility_verified':False}
