#!/usr/bin/env python3
"""Repeat the scoped source/ABI audit; never creates a driver or approves flashing."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'engine'))
import elf_contract

PINNED = ['c286ab85f4982c9b5967e18405f4e2da0332ce4d',
          '57d9a0225b031f4b444251117f3ecc9deae71128']
STOCK_SHA = '81dfb5eabe486e9384c15883d49844204072eeb50e5f63ef83ac329b84a608b5'
def read(path): return json.loads(path.read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
def git_blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def audit(stock, inventory_file, objects, symvers, dt_audit):
    source_trees = []
    for pin in PINNED:
        tree = read(HERE / 'evidence' / ('tree-' + pin + '.json'))
        if tree['sha'] != pin or tree['truncated']:
            raise ValueError('Unpinned or truncated source tree')
        paths = [x['path'] for x in tree['tree']]
        source_trees.append({'commit': pin, 'entries': len(paths), 'truncated': False,
                             'ft3683_paths': [p for p in paths if re.search(r'(?i)(3683|p11u)', p)],
                             'controller_directories': [p for p in paths if p.endswith('/Kconfig') and
                                                        any(x in p for x in ('focaltech', 'goodix'))]})
    refs = read(HERE / 'evidence/reference-index.json')
    for ref in refs:
        data = (HERE / ref['path']).read_bytes()
        if git_blob(data) != ref['git_blob_sha1'] or sha(data) != ref['sha256']:
            raise ValueError('Reference source changed: ' + ref['path'])
    branches = read(HERE / 'evidence/official-branches.json')
    prior = read(HERE / 'evidence/prior-r7-source-audit.json')
    old = {b['branch']: b['commit'] for b in prior['official_touch_branches']}
    unchanged = all(old.get(b['name']) == b['commit']['sha'] for b in branches) and len(old) == len(branches)
    raw = stock.read_bytes()
    if sha(raw) != STOCK_SHA: raise ValueError('Unreviewed stock controller binary')
    controller = elf_contract.parse(raw)
    inv = read(inventory_file)['inventory']
    providers = defaultdict(list)
    for symbol, crc in elf_contract.symvers(symvers.read_bytes()).items():
        providers[symbol].append({'provider': 'vmlinux', 'crc': crc})
    modules = {}
    for row in inv['selected_modules']:
        path = (objects / row['file']).resolve()
        if not path.is_relative_to(objects.resolve()): raise ValueError('Artifact path traversal')
        data = path.read_bytes()
        if sha(data) != row['sha256']: raise ValueError('Artifact SHA mismatch: ' + row['name'])
        mod = elf_contract.parse(data)
        modules[row['name']] = (row, mod)
        for symbol, crc in mod['exports'].items():
            providers[symbol].append({'provider': row['name'], 'crc': crc})
    comparisons = []
    for symbol, crc in sorted(controller['versions'].items()):
        ps = providers.get(symbol, [])
        match = len(ps) == 1 and ps[0]['crc'] == crc
        comparisons.append({'symbol': symbol, 'stock_crc': hex(crc), 'match': match,
                            'providers': [dict(p, crc=hex(p['crc'])) for p in ps]})
    exports = [{'symbol': s, 'stock_crc': hex(c),
                'candidate_providers': [dict(p, crc=hex(p['crc'])) for p in providers.get(s, [])]}
               for s, c in sorted(controller['exports'].items())]
    touch_exports = modules['xiaomi_touch'][1]['exports']
    framework = [x for x in comparisons if x['symbol'] in touch_exports]
    dt = read(dt_audit)
    dtrow = next(x for x in dt['matrix'] if x['name'] == 'focaltech_touch_3683')
    strings = sorted({s.decode() for s in re.findall(rb'[ -~]{10,}', raw)
                      if any(t in s for t in (b'p11u/focaltech_3683/', b'FT3683:', b'focaltech_ts_fw'))})
    result = {
        'schema': 'myron-r12-ft3683-source-audit-v1',
        'result': 'BLOCKED_NO_MATCHED_CONTROLLER_SOURCE',
        'source_integrated': False, 'ddk_module_created': False,
        'existing_r10_payload_modified': False, 'flashable': False,
        'official_repository': 'MiCode/vendor_xiaomi_proprietary_touch-driver',
        'pinned_trees_verified': source_trees,
        'branch_catalog': branches, 'branch_catalog_unchanged_since_r7': unchanged,
        'myron_named_branches': [b for b in branches if 'myron' in b['name']],
        'reference_files_verified': refs,
        'exact_source_search': read(HERE / 'evidence/exact-source-search.json'),
        'stock': {'sha256': STOCK_SHA, 'module': 'focaltech_touch_3683',
                  'embedded_strings': strings, 'identity_from_prior_disassembly': prior['stock_evidence'],
                  'selected_partition_dt_matches': dtrow['selected_partition_dt_matches'],
                  'hard_dependencies': dtrow['stock_hard_dependencies'], 'exports': exports},
        'run14': {'kernel_release': inv['kernel_release'], 'candidate_name_present': 'focaltech_touch_3683' in modules,
                  'stock_import_total': len(comparisons),
                  'stock_import_crc_matched': sum(x['match'] for x in comparisons),
                  'stock_import_crc_unmatched': sum(not x['match'] for x in comparisons),
                  'stock_import_comparisons': comparisons,
                  'framework_imports': framework,
                  'generic_focaltech_candidate': modules['focaltech_fts'][0]},
        'useful_upstream_helpers': {
            'p2/qts/qts_core.c': 'Actual implementations of all four QTS helper exports exist in MiCode Synaptics P2 subtree; retained as reference, not a replacement controller or approved standalone module.',
            'duplicate_export_guard': 'A future controller containing this QTS layer must not coexist with generic qts exporting qts_client_register without an explicit integration decision.'},
        'blocking_requirements': [
            'Matched p11u/focaltech_3683 controller core, SPI/events, firmware protocol and supported_ic test source.',
            'Match firmware/boot IDs including CID fallback, event packet layout, Myron FOD/THP/super-resolution and power sequencing.',
            'Compile full controller against current xiaomi_touch callback layouts and Gunyah/QTS headers; no cast-only ABI bypass.',
            'Resolve QTS ownership and duplicate exports before adding a DDK target.',
            'Keep real focal,touch-spi DT binding; do not rename FT3383/FT3683G/U or generic focaltech_fts to manufacture equivalence.'
        ],
        'limitations': ['Scoped source audit, not proof no matching source exists anywhere.',
                       'GitHub code search covers indexed default branches only.',
                       'Matching import CRC does not establish structure/callback/firmware behavior.',
                       'Selected partition DT is captured base 2 plus overlay 0; runtime bootloader changes remain outside this evidence.',
                       'No target compilation or physical touch-controller test performed.'],
        'inputs': {str(p): sha(p.read_bytes()) for p in [stock, inventory_file, symvers, dt_audit]},
        'analyzer_sha256': sha(Path(__file__).read_bytes())
    }
    return result

def main():
    root = HERE.parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stock', type=Path, default=root/'analysis/myron-stock/modules/modules/focaltech_touch_3683.ko')
    parser.add_argument('--inventory', type=Path, default=root/'analysis/myron-r10-run14/verification/modules/inventory-verified.json')
    parser.add_argument('--objects', type=Path, default=root/'analysis/myron-r10-run14/full/full/objects')
    parser.add_argument('--symvers', type=Path, default=root/'analysis/myron-r10-run14/full/full/objects/bazel-out/aarch64-fastbuild/bin/common/kernel_aarch64/vmlinux.symvers')
    parser.add_argument('--dt-audit', type=Path, default=root/'analysis/myron-r11-assembly/vendor-audit/vendor-disposition.json')
    parser.add_argument('--output', type=Path, default=HERE/'source-audit-r12.json')
    args = parser.parse_args()
    result = audit(args.stock, args.inventory, args.objects, args.symvers, args.dt_audit)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'result': result['result'], 'source_integrated': False,
                      'stock_imports': result['run14']['stock_import_total'],
                      'unmatched_import_crcs': result['run14']['stock_import_crc_unmatched'],
                      'framework_imports': len(result['run14']['framework_imports'])}, ensure_ascii=False))

if __name__ == '__main__': main()
