#!/usr/bin/env python3
"""Compile actual ops structures against actual callback declarations."""
from pathlib import Path
import re,subprocess,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
BASE=ROOT/'analysis/myron-stage-r10/source-bundle/myron-adaptation-r10/drivers/payload/drivers/power/supply/mca/include/mca/platform'
EXTRA=HERE.parent/'mca-services/upstream/drivers/power/supply/mca/include/mca/platform'
IC=HERE/'payload/drivers/power/supply/mca/mca_hardware_ic'
specs=[('cp',IC/'charge_pump_ic/sc8581/sc8581.c',BASE/'platform_cp_class.h','platform_class_cp_ops'),('fg',IC/'fuelgauge_ic/bq27z561/bq27z561.c',BASE/'platform_fg_ic_ops.h','fuelguage_ic_ops'),('wls',IC/'wireless_ic/sc96281/sc96281_core.c',EXTRA/'platform_wireless_class.h','platform_class_wireless_ops')]
outdir=HERE/'verification';outdir.mkdir(exist_ok=True)
results=[]
for name,p,h,struct in specs:
    source=p.read_text();header=h.read_text()
    decl=re.search(r'struct '+struct+r'\s*\{.*?\n\};',header,re.S)[0]
    init=re.search(r'static struct '+struct+r'\s+\w+\s*=\s*\{.*?\n\};',source,re.S)[0]
    funcs=re.findall(r'\.\w+\s*=\s*(\w+)',init)
    prototypes=[]
    for fn in funcs:
        if fn=='NULL':continue
        matches=list(re.finditer(r'^static\s+([\w\s*]+?)\s+'+re.escape(fn)+r'\s*\(([^;{}]*?)\)\s*\{',source,re.M))
        assert len(matches)==1,(fn,len(matches))
        m=matches[0];prototypes.append('extern '+m[1]+' '+fn+'('+m[2]+');')
    prelude='#include <stdint.h>\n#include <stddef.h>\n#include <stdbool.h>\ntypedef unsigned char u8;\ntypedef unsigned short u16;\ntypedef unsigned int u32;\ntypedef unsigned long long u64;\n'
    enum='' if name!='wls' else re.search(r'typedef enum \{.*?\} WLS_DEBUG_SET_FOD_TYPE;',header,re.S)[0]+'\n'
    code=prelude+enum+decl+'\n'+'\n'.join(prototypes)+'\n'+init+'\n'
    out=outdir/(name+'-actual-callback-types.c');out.write_text(code)
    p=subprocess.run(['cc','-std=gnu11','-Werror','-Wno-unused-variable','-fsyntax-only',str(out)],capture_output=True,text=True)
    results.append({'name':name,'callbacks':len(prototypes),'passed':p.returncode==0,'diagnostics':p.stderr})
(outdir/'callback-types.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2));raise SystemExit(0 if all(r['passed']for r in results) else 1)
