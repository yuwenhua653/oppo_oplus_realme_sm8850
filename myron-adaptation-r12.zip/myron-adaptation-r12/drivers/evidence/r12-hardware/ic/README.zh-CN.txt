Myron r12 实际充电 IC 源码接入增量

范围：hl7603、sc8581（含 sc8585_master/slave 真实原始驱动）、bq27z561、sc96281_charger。
来源：unmoved21/android_kernel_xiaomi_onyx，固定提交
8276ba954d8076303a5ae0f7b15d4092d66bdff6。
18 个源文件/头文件共 1,273,976 字节已逐项核对 Git blob SHA1、SHA256 和长度。
全部修改仅在本目录；原有 r10 的 23 个源模块及 PD callback 修复保持原样。

供父包整合的文件：
  integration-delta.json：18 个写入、4 个 DDK 注册项、配置、导出/别名/必要导入契约。
  payload/：实际待写入 SoC 树的源码。
  upstream/、source-receipt.json：原始源码和来源哈希。
  modules.bzl.fragment、Kconfig.fragment：文本形式的注册/配置增量。
  patches/、adaptation-changes.json：源代码变更记录。
  verification/validation.json：已执行的本地核验。

集成要求：
  - 将 modules.bzl.fragment 的 register 调用加进现有 register_modules 函数。
  - canoe_perf 配置设置 CONFIG_MYRON_CHARGE_IC=m，CONFIG_MYRON_IC_FIRMWARE_PROGRAMMING=n。
  - firmware 选项必须维持隐藏、默认 n；本轮没有校验内嵌 Onyx 固件适合 Myron。
  - 依赖 MCA services 路提供 mca_adsp_glink、mca_platform_wireless_class、mca_strategy_class 和四个缺失头。
  - mca_log_* 宏实际引用 __mca_log_*，DDK 显式依赖 mca_log，避免仅扫描函数名遗漏。
  - SC96281 输出仍为 sc96281_charger.ko。主源文件改名 sc96281_core.c，与 mtp_program.c 复合构建，避免 Kbuild 目标与输入对象自循环。
  - 原始 Makefile 随 payload 保留作来源记录；DDK 注册决定本轮输出，不要直接启用其 sc96281_comp 模块。

已做的真实 API 修正：
  - SC96281 旧 linux/mca include 路径统一到已集成的 mca include 目录。
  - BQ 的 7 个 Onyx 扩展 ops initializer 不属于已锁定的 Myron FG 表，取消暴露而不扩充/移动 Myron ABI 槽位。原始实现保留为未暴露 helper。
  - fg_get_pack_vendor 改为 Myron void 回调；仍执行原有 vendor 输出。
  - fg_get_batt_abnormal_info 使用 void(data,void*) 原型；仍填充原有 10 个整数，未做函数指针强转。
  - 基于真实头文件结构与真实函数声明，CP 35 / FG 55 / WLS 60，共 150 个 callback initializer 通过宿主 cc -Werror 类型检查。该检查不等于 AArch64 KCFI 或整内核编译验证。

固件写入防护：
  - BQ nfg1000_update_APP、nfg1000_ota_update_check 和 MPC8011B fg_update_record_voltage_level 在原始操作前返回 -EOPNOTSUPP；boot_app_judge 的 void 入口在操作前直接结束。
  - resume 同时检查 support_nvt1000_ota，避免只在 probe 检查却在 resume 绕过开关。
  - SC96281 download_fw、download_fw_from_bin、set_fw_bin 及最底层 mtp_program 在操作前返回 -EOPNOTSUPP。包括升级等待命令和二进制 buffer 写入，不能先执行再拒绝。
  - 隐藏配置默认关闭且本轮配置明确 n，8 个入口的首个可执行语句已核验为拒绝逻辑。
  - 这些限制没有模拟升级成功，也没有证明所有永久电池参数写入都被禁止。普通寄存器配置和其它寿命/SOH 操作仍需审查，不能据此直接加载到手机。

不伪造硬件适配：
  - 当前 Myron SC96281 FOD 表是 26 行、每行 6 列，Onyx 解析器最多 20 行、每行 4 列；Hall GPIO/pinctrl 名称也不同。本轮保留原数据语义，修复 FOD 与 parse_dt 错误被吞掉的问题，遇到不兼容格式应失败。
  - SC96281 工作队列初始化移到注册 IRQ 之前，避免首次中断调度未初始化的 delayed_work。固件数组下标和 FOD 内存分配加边界/错误检查。
  - 原始 SC96281 IRQ 初始化内部仍有错误汇总/清理缺陷；外部检查返回值不等于其全部内部错误已处理。后续应随最终 Hall/IRQ 接口一起修复。
  - SC8585 的 pmid2-uvp-threshold 原厂 DT 为三值数组，当前源读取标量；未擅自删除数组或改阈值。
  - 完整功能仍缺匹配充电策略及电池参数。代码可交给下一轮目标 CI 验证，不构成可刷或硬件就绪声明。

本轮未编译完整目标内核、未向手机写入、未运行硬件探测。
