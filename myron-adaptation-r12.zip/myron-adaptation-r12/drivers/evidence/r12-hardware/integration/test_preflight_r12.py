#!/usr/bin/env python3
import ast
import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import preflight_r12 as gate

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'analysis/myron-stage-r10/source-bundle/myron-adaptation-r10'


class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.bundle = Path(self.tmp.name) / 'bundle'
        shutil.copytree(BASE / 'drivers', self.bundle / 'drivers', ignore=shutil.ignore_patterns('__pycache__'))
        self.lock_path = self.bundle / 'drivers/source-lock.json'
        self.lock = json.loads(self.lock_path.read_text())
        self.lock['module_contracts']['miev'] = {'required_dependencies': [], 'required_imports': [], 'aliases': [], 'parameters': []}
        self.lock['registry_exemptions'] = {n: {'reason': 'Inherited pinned r1 validator'} for n in ['mi_fp','mi_stack','mi_ubt','printk_enhance']}
        self.save()

    def tearDown(self):
        self.tmp.cleanup()

    def save(self):
        self.lock_path.write_text(json.dumps(self.lock))

    def registry_change(self, module, field, transform):
        rel = 'drivers/xiaomi/myron/modules.bzl'
        item = next(i for i in self.lock['writes'] if i['path'] == rel)
        path = self.bundle / 'drivers' / item['payload']
        tree = ast.parse(path.read_text())
        for n in ast.walk(tree):
            if not isinstance(n, ast.Call) or not isinstance(n.func, ast.Attribute) or n.func.attr != 'register':
                continue
            kwargs = {kw.arg: kw for kw in n.keywords}
            if ast.literal_eval(kwargs['out'].value) == module + '.ko':
                kwargs[field].value = ast.parse(repr(transform(ast.literal_eval(kwargs[field].value))), mode='eval').body
                break
        else:
            self.fail('Test module missing')
        path.write_text(ast.unparse(tree) + '\n')
        item['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        self.save()

    def errors(self):
        result = gate.check(self.bundle)
        self.assertFalse(result['success'])
        return '\n'.join(result['errors'])

    def test_baseline_offline_pass_with_explicit_pending(self):
        result = gate.check(self.bundle)
        self.assertTrue(result['success'], result['errors'])
        self.assertEqual(result['registered_count'], 27)
        self.assertFalse(result['ddk_workspace_validation_complete'])
        self.assertTrue(result['pending_workspace_checks'])

    def test_omitted_exports_rejected(self):
        del self.lock['exports']['mca_sysfs']
        self.save()
        self.assertIn('Registry contract coverage mismatch', self.errors())

    def test_missing_project_header_rejected(self):
        self.registry_change('mca_sysfs', 'srcs', lambda v: [p for p in v if not p.endswith('mca_sysfs.h')])
        self.assertIn('Transitive project headers absent from DDK srcs: mca_sysfs', self.errors())

    def test_tampered_upstream_rejected(self):
        path = self.bundle / 'drivers' / self.lock['sources'][0]['payload']
        path.write_bytes(path.read_bytes() + b'\n/* mutation */\n')
        self.assertIn('Upstream hash/blob/length mismatch', self.errors())

    def test_missing_managed_dep_rejected(self):
        self.registry_change('mca_event', 'deps', lambda v: [])
        self.assertIn('Managed export provider absent from DDK deps: mca_event -> mca_sysfs', self.errors())


if __name__ == '__main__':
    unittest.main()
