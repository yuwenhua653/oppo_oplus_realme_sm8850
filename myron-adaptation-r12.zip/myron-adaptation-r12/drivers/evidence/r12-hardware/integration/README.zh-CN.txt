r12 集成审查与 portable preflight

preflight_r12.py 复制到累计包 drivers/ 下，源码 apply 后调用：
  python3 drivers/preflight_r12.py --workspace WORKSPACE --report REPORT.json
离线检查：
  python3 preflight_r12.py --bundle MERGED_BUNDLE --report REPORT.json

该工具只解析AST字面值，不执行.bzl；核对锁定来源SHA256/Git blob/长度、
适配写入SHA、registry与exports/exemptions完整集合、配置m、源码可见性、
本包/MCA传递头文件、受控导出提供者DDK依赖和依赖环。
离线模式显示外部文件/目标待workspace检查，不冒充完整DDK验证。
公共ACK/QCOM默认header组不被错误要求重复放入srcs。

5项本地测试通过：基线、漏exports、漏MCA头、坏source hash/blob、漏provider dep。
未运行完整workspace或目标内核编译。

合并重点
1. 新driver必须纳入source-lock.exports及显式module_contracts，空导出也要[]。
   不能以23个历史driver计数或旧validator成功代表全部新driver已检查。
2. 新回调 ABI scope必须显式描述；旧8项回调合同不自动覆盖新IC后台。
   保留PD回调signedness修复，不用强制cast绕过函数指针类型检查。
3. r12内置DT retention方案可行；删独立旧runner替换步骤，保留原69个源blob
   与dtbs.bzl前后hash，retention执行应早于最终DT wiring/diff和Bazel。
4. 必须从run14工作流派生。旧package_r10.py从r9派生会遗失后加入的retention。
5. 全部preflight/driver/callback门禁必须在成功状态之前执行，并上传实际结果。

完整审查在上一级 integration-review.json。
