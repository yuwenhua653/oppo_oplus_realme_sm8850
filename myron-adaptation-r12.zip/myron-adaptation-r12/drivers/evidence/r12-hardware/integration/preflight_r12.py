#!/usr/bin/env python3
"""Statically inspect the merged driver bundle; never execute Starlark or C.

Run after apply_drivers.py with --workspace for strict CI source/DDK checks.
Without --workspace, unavailable inherited/QCOM files remain explicit pending
items; the report never describes that mode as a complete DDK validation.
"""
import argparse
import ast
import collections
import hashlib
import json
from pathlib import Path, PurePosixPath
import posixpath
import re
import sys


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe(root, value):
    if not isinstance(value, str) or '\\' in value:
        raise ValueError('Noncanonical path')
    rel = PurePosixPath(value)
    if rel.is_absolute() or '..' in rel.parts or not value or str(rel) != value:
        raise ValueError('Unsafe path: ' + str(value))
    path = (root / value).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError('Path escapes root: ' + value)
    return path


def name(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', value):
        raise ValueError('Invalid module name: ' + str(value))
    return value.replace('-', '_')


def registrations(data, strict=True):
    """AST-literal registry capture. Unsupported expressions fail in our file."""
    tree = ast.parse(data)
    rows = []
    for node in ast.walk(tree):
        if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == 'register'):
            continue
        try:
            if node.args or any(k.arg is None for k in node.keywords):
                raise ValueError('Positional/dynamic register arguments')
            row = {k.arg: ast.literal_eval(k.value) for k in node.keywords}
            if len(row) != len(node.keywords):
                raise ValueError('Duplicate register keyword')
            if not isinstance(row.get('name'), str) or not isinstance(row.get('out'), str):
                raise ValueError('Register name/out must be literals')
            for key in ('srcs', 'deps', 'includes'):
                if key not in row:
                    row[key] = []
                if not isinstance(row[key], list) or not all(isinstance(x, str) for x in row[key]):
                    raise ValueError('Unsupported register list: ' + key)
            if '/' in row['out'] or not row['out'].endswith('.ko'):
                raise ValueError('Expected basename .ko output')
            row['module_name'] = name(row['out'][:-3])
            row['line'] = node.lineno
            rows.append(row)
        except (ValueError, TypeError):
            if strict:
                raise ValueError('Nonliteral/unsupported register at line ' + str(node.lineno))
    if strict:
        # The owned registry must be a simple literal register function.
        defs = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
        if len(defs) != 1 or defs[0].name != 'register_modules':
            raise ValueError('Expected one register_modules function')
        for stmt in defs[0].body:
            if not (isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call)
                    and isinstance(stmt.value.func, ast.Attribute)
                    and isinstance(stmt.value.func.value, ast.Name)
                    and stmt.value.func.value.id == 'registry'
                    and stmt.value.func.attr == 'register'):
                raise ValueError('Owned registry contains unsupported control flow')
        if any(not isinstance(n, ast.FunctionDef) for n in tree.body):
            raise ValueError('Owned registry contains top-level code')
    return rows


def configuration(data):
    tree = ast.parse(data)
    found = []
    for node in tree.body:
        if not (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == 'canoe_perf_config'):
            raise ValueError('Unsupported config code')
        if not isinstance(node.value, ast.Dict):
            raise ValueError('Expected literal configuration dict')
        keys = [ast.literal_eval(x) for x in node.value.keys]
        if len(keys) != len(set(keys)):
            raise ValueError('Duplicate config symbol')
        found.append(ast.literal_eval(node.value))
    if len(found) != 1:
        raise ValueError('Expected exactly one canoe_perf_config')
    return found[0]


def cycle_check(graph):
    active, done = [], set()
    def visit(node):
        if node in active:
            raise ValueError('DDK dependency cycle: ' + ' -> '.join(active + [node]))
        if node in done:
            return
        active.append(node)
        for dep in sorted(graph.get(node, [])):
            if dep in graph:
                visit(dep)
        active.pop()
        done.add(node)
    for node in sorted(graph):
        visit(node)


def check(bundle, workspace=None):
    drivers = bundle / 'drivers'
    lock_path = drivers / 'source-lock.json'
    lock = json.loads(lock_path.read_text())
    errors, pending = [], []
    counts = collections.Counter()
    writes = {}
    for item in lock['sources']:
        data = safe(drivers, item['payload']).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if len(data) != item['bytes'] or digest(data) != item['sha256'] or blob != item['git_blob_sha1']:
            errors.append('Upstream hash/blob/length mismatch: ' + item['payload'])
        counts['upstream_sources'] += 1
    for item in lock['writes']:
        if item['path'] in writes:
            errors.append('Duplicate write path: ' + item['path'])
        data = safe(drivers, item['payload']).read_bytes()
        safe(drivers / 'payload', item['path'])
        if digest(data) != item['sha256']:
            errors.append('Write payload hash mismatch: ' + item['path'])
        writes[item['path']] = data
        counts['write_payloads'] += 1
    soc = workspace / 'vendor/qcom/sm8850' if workspace else None
    if soc:
        for rel, data in writes.items():
            target = safe(soc, rel)
            if not target.is_file() or target.read_bytes() != data:
                errors.append('Applied workspace file differs/missing: ' + rel)
    def content(rel):
        safe(drivers / 'payload', rel)
        if rel in writes:
            return writes[rel]
        if soc:
            path = safe(soc, rel)
            if path.is_file():
                return path.read_bytes()
        path = safe(drivers / 'payload', rel)
        return path.read_bytes() if path.is_file() else None
    registry_rel = 'drivers/xiaomi/myron/modules.bzl'
    config_rel = 'configs/canoe_perf.bzl'
    if registry_rel not in writes or config_rel not in writes:
        errors.append('Registry/config not covered by locked writes')
    rows = registrations(content(registry_rel).decode())
    config = configuration(content(config_rel).decode())
    by_name, by_target = {}, {}
    for row in rows:
        n, target = row['module_name'], row['name']
        safe(drivers / 'payload', target)
        if n in by_name or target in by_target:
            errors.append('Duplicate registered output/name: ' + n)
        by_name[n] = row
        by_target[target] = row
        if config.get(row.get('config')) != 'm':
            errors.append('Registered module config not selected as m: ' + n)
    exports = lock['exports']
    exemptions = lock.get('registry_exemptions', {})
    if set(exports) & set(exemptions):
        errors.append('Contract/exemption overlap')
    for n, row in exemptions.items():
        if not isinstance(row, dict) or not row.get('reason'):
            errors.append('Exemption missing explicit reason: ' + n)
    if set(by_name) != set(exports) | set(exemptions):
        errors.append('Registry contract coverage mismatch: missing=' + repr(sorted(set(by_name) - set(exports) - set(exemptions)))
                      + ' stale=' + repr(sorted((set(exports) | set(exemptions)) - set(by_name))))
    contracts = lock.get('module_contracts', {})
    # hwid has a separately named existing contract; miev can have an explicit
    # empty required contract. No count or historical23 bypass is accepted.
    missing_contracts = set(exports) - set(contracts)
    if lock.get('hwid_contract'):
        missing_contracts.discard('hwid')
    if missing_contracts:
        errors.append('Exported module lacks explicit contract: ' + ','.join(sorted(missing_contracts)))
    provider = collections.defaultdict(list)
    for n, symbols in exports.items():
        for symbol in symbols:
            provider[symbol].append(n)
    for symbol, names in provider.items():
        if len(names) != 1:
            errors.append('Duplicate managed export provider: ' + symbol)

    external_rows = {}
    external_scan_unparsed = []
    if soc:
        # Only parse AST literals. No load(), function or unknown registry code runs.
        for path in sorted(soc.rglob('*.bzl')):
            if path.relative_to(soc).as_posix() == registry_rel:
                continue
            try:
                for row in registrations(path.read_text(), strict=False):
                    target = row['name']
                    if target in external_rows and external_rows[target]['out'] != row['out']:
                        errors.append('Ambiguous external DDK target: ' + target)
                    external_rows[target] = row
            except (SyntaxError, UnicodeDecodeError, ValueError):
                external_scan_unparsed.append(str(path.relative_to(soc)))
    graph = {t: set(row['deps']) for t, row in by_target.items()}
    for target, row in external_rows.items():
        if target not in graph:
            graph[target] = set(row['deps'])
    # Only the selected owned modules and their dependencies participate;
    # unrelated disabled alternatives in the SoC registry are not this graph.
    reachable, todo = set(), list(by_target)
    while todo:
        target = todo.pop()
        if target in reachable:
            continue
        reachable.add(target)
        todo.extend(graph.get(target, set()))
    cycle_check({target: deps for target, deps in graph.items() if target in reachable})
    known = set(by_target) | set(external_rows)
    for n, row in by_name.items():
        for dep in row['deps']:
            if dep not in known:
                issue = 'External DDK target not statically resolved: ' + n + ' -> ' + dep
                (errors if soc else pending).append(issue)
    def reaches(target, wanted, seen=None):
        seen = set() if seen is None else seen
        if target in seen:
            return False
        seen.add(target)
        return wanted in graph.get(target, set()) or any(reaches(d, wanted, seen) for d in graph.get(target, set()))
    header_rows = []
    include_re = re.compile(r'^\s*#\s*include\s*([<"])([^>"\n]+)[>"]', re.M)
    for n, row in by_name.items():
        allsrc = set(row['srcs'])
        source_texts = []
        for rel in row['srcs']:
            raw = content(rel)
            if raw is None:
                (errors if soc else pending).append('Registered src unavailable: ' + n + ' -> ' + rel)
            elif rel.endswith('.c'):
                source_texts.append(raw.decode(errors='replace'))
            if soc and not safe(soc, rel).is_file():
                errors.append('Registered src not visible in actual workspace: ' + n + ' -> ' + rel)
        # Inspect all source files and recursively resolved project headers;
        # conditionals are deliberately a conservative superset of sandbox needs.
        queue, visited, missing_headers = list(row['srcs']), set(), set()
        while queue:
            rel = queue.pop()
            if rel in visited:
                continue
            visited.add(rel)
            raw = content(rel)
            if raw is None or not rel.endswith(('.c', '.h')):
                continue
            for delimiter, header in include_re.findall(raw.decode(errors='replace')):
                lookup = ([posixpath.dirname(rel)] if delimiter == '"' else []) + row['includes']
                found = []
                for prefix in lookup:
                    cand = posixpath.normpath(posixpath.join(prefix, header))
                    try:
                        data = content(cand)
                    except ValueError:
                        continue
                    if data is not None and cand not in found:
                        found.append(cand)
                if len(found) > 1 and len({digest(content(x)) for x in found}) > 1:
                    errors.append('Ambiguous project include: ' + n + ':' + rel + ':' + header)
                if not found:
                    if header.startswith('mca/'):
                        errors.append('Unresolved MCA project include: ' + n + ':' + rel + ':' + header)
                    continue
                target = found[0]
                # Public QCOM/ACK headers may be provided by DDK header groups.
                # Enforce srcs membership only for headers owned by this bundle
                # or the MCA project, not arbitrary external header recursion.
                controlled = (target in writes or safe(drivers / 'payload', target).is_file()
                              or target.startswith('drivers/power/supply/mca/'))
                if not controlled:
                    continue
                if target not in allsrc:
                    missing_headers.add(target)
                if target not in visited:
                    queue.append(target)
        if missing_headers:
            errors.append('Transitive project headers absent from DDK srcs: ' + n + ': ' + ','.join(sorted(missing_headers)))
        header_rows.append({'module': n, 'resolved_files': len(visited), 'missing_srcs_headers': sorted(missing_headers)})
        required = set(contracts.get(n, {}).get('required_imports', []))
        text = '\n'.join(source_texts)
        text = re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S)
        # Source references to other managed exports also need provider deps,
        # even if a required_imports list accidentally omitted that symbol.
        required.update(s for s in provider if re.search(r'\b' + re.escape(s) + r'\s*\(', text))
        for symbol in sorted(required):
            for source_module in provider.get(symbol, []):
                if source_module == n or source_module not in by_name:
                    continue
                target = by_name[source_module]['name']
                if not reaches(row['name'], target):
                    errors.append('Managed export provider absent from DDK deps: ' + n + ' -> ' + source_module + ' (' + symbol + ')')
        for dep_name in contracts.get(n, {}).get('required_dependencies', []):
            matches = [r['name'] for r in [*by_target.values(), *external_rows.values()] if r['module_name'] == dep_name]
            if len(set(matches)) == 1:
                if not reaches(row['name'], matches[0]):
                    errors.append('Required module dependency absent from DDK deps: ' + n + ' -> ' + dep_name)
            elif soc:
                errors.append('Required module dependency has no unique registry target: ' + n + ' -> ' + dep_name)
            else:
                pending.append('Required external module dependency awaits workspace: ' + n + ' -> ' + dep_name)
    return {'schema': 1, 'success': not errors, 'mode': 'workspace_strict' if soc else 'offline_partial',
            'source_lock_sha256': digest(lock_path.read_bytes()), 'registered_modules': sorted(by_name),
            'registered_count': len(by_name), 'contract_modules': sorted(exports), 'contract_count': len(exports),
            'explicit_exemptions': exemptions, 'source_checks': dict(counts), 'headers': header_rows,
            'external_literal_registry_targets': len(external_rows), 'external_files_unparsed': external_scan_unparsed,
            'errors': sorted(set(errors)), 'pending_workspace_checks': sorted(set(pending)),
            'ddk_workspace_validation_complete': bool(soc) and not errors,
            'limits': ['No target compilation, MODVERSIONS, KCFI, probe or runtime validation.',
                       'External symbols not exported by managed drivers remain subject to mandatory actual-build ELF/provider checks.',
                       'AST literal external registry capture is fail-closed for unresolved required targets; no Starlark execution.',
                       'Owned-payload/MCA project includes are conservatively checked, including inactive conditional branches; external default DDK header groups are not reinterpreted.'],
            'hardware_tested': False, 'flashable': False}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bundle', type=Path, default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--workspace', type=Path)
    ap.add_argument('--report', type=Path, required=True)
    args = ap.parse_args()
    try:
        report = check(args.bundle.resolve(), args.workspace.resolve() if args.workspace else None)
    except (OSError, ValueError, KeyError, TypeError, SyntaxError) as exc:
        report = {'schema': 1, 'success': False, 'errors': [type(exc).__name__ + ': ' + str(exc)], 'flashable': False}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('success', 'mode', 'registered_count', 'contract_count', 'errors') if k in report}))
    return 0 if report['success'] else 1


if __name__ == '__main__':
    sys.exit(main())
