#!/usr/bin/env python3
"""Read-only audit: all managed contracts and source-declared metadata vs run16 ELF."""
import ast, collections, hashlib, importlib.util, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DR=ROOT/'work/myron-adaptation-r12/drivers'
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('driver_gate',DR/'validate_drivers.py')
vd=importlib.util.module_from_spec(spec);spec.loader.exec_module(vd)
lock=json.loads((DR/'source-lock.json').read_text())
manifest=json.loads((ROOT/'full/full/artifact-manifest.json').read_text())
mods=collections.defaultdict(list)
for f in manifest['files']:
 p=ROOT/'full/full'/f['file']
 if p.suffix=='.ko':mods[p.stem.replace('-','_')].append((p,f))
registry={}
for node in ast.walk(ast.parse((DR/'payload/drivers/xiaomi/myron/modules.bzl').read_text())):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='register':
  d={k.arg:ast.literal_eval(k.value) for k in node.keywords}
  registry[d['out'][:-3].replace('-','_')]=d
writes={w['path']:w for w in lock['writes']}
def plain(text):
 return re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S)
def source_metadata(paths):
 aliases=set();params=set();exports=set();evidence=[]
 for path in paths:
  if not path.endswith('.c'):continue
  w=writes[path];p=DR/w['payload'];raw=p.read_bytes()
  assert hashlib.sha256(raw).hexdigest()==w['sha256'],path
  text=plain(raw.decode())
  aliases.update(re.findall(r'MODULE_ALIAS\s*\(\s*"([^"]+)"\s*\)',text))
  params.update(n+':'+t for n,t in re.findall(r'\bmodule_param\s*\(\s*(\w+)\s*,\s*(\w+)\s*,',text))
  exports.update(re.findall(r'\bEXPORT_SYMBOL(?:_GPL)?\s*\(\s*(\w+)\s*\)',text))
  tables=[]
  for bus,name in re.findall(r'MODULE_DEVICE_TABLE\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',text):
   m=re.search(r'\b'+re.escape(name)+r'\s*\[\s*\]\s*=\s*\{',text)
   assert m,(path,bus,name)
   start=m.end()-1;level=0;end=None
   for i in range(start,len(text)):
    if text[i]=='{':level+=1
    elif text[i]=='}':
     level-=1
     if not level:end=i+1;break
   assert end,(path,name)
   body=text[start:end]
   if bus=='of':
    assert not re.search(r'\.(?:name|type)\s*=',body),(path,'complex OF matching needs review')
    ids=re.findall(r'\.compatible\s*=\s*"([^"]+)"',body)
    for x in ids:aliases.update(['of:N*T*C'+x,'of:N*T*C'+x+'C*'])
   elif bus=='i2c':
    ids=re.findall(r'\{\s*"([^"]+)"\s*,',body)
    aliases.update('i2c:'+x for x in ids)
   else:raise AssertionError(('unhandled bus',bus,path))
   tables.append({'bus':bus,'table':name,'ids':ids})
  evidence.append({'file':path,'sha256':w['sha256'],'tables':tables})
 return aliases,params,exports,evidence
rows=[]
for n,ex in lock['exports'].items():
 assert len(mods[n])==1,n
 p,f=mods[n][0];raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==f['sha256'],n
 v=vd.elf(raw);c=lock.get('module_contracts',{}).get(n,{})
 sa,sp,se,ev=source_metadata(registry[n]['srcs'])
 aa=set(v['info'].get('alias',[]));ap=set(v['info'].get('parmtype',[]))
 deps=set(','.join(v['info'].get('depends',[])).split(','))-{''}
 errors={}
 if 'aliases' in c and set(c['aliases'])!=aa:errors['contract_aliases']={'expected':c['aliases'],'actual':sorted(aa)}
 if 'parameters' in c and set(c['parameters'])!=ap:errors['contract_parameters']={'expected':c['parameters'],'actual':sorted(ap)}
 if sa!=aa:errors['source_aliases']={'source':sorted(sa),'actual':sorted(aa)}
 if sp!=ap:errors['source_parameters']={'source':sorted(sp),'actual':sorted(ap)}
 if c.get('exports_policy','exact')=='exact' and set(ex)!=v['exports']:errors['contract_exports']={'expected':ex,'actual':sorted(v['exports'])}
 elif not set(ex).issubset(v['exports']):errors['contract_exports']='missing required export'
 if not v['exports'].issubset(se):errors['source_exports']={'unexpected':sorted(v['exports']-se)}
 missing=set(c.get('required_imports',[]))-v['imports']
 if missing:errors['imports']=sorted(missing)
 missing=set(c.get('required_dependencies',[]))-deps
 if missing:errors['dependencies']=sorted(missing)
 rows.append({'name':n,'file':f['file'],'sha256':f['sha256'],'aliases':sorted(aa),'parameters':sorted(ap),'exports':sorted(v['exports']),'dependencies':sorted(deps),'source_export_declarations_not_emitted':sorted(se-v['exports']),'source_metadata':ev,'mismatches':errors})
report={'schema':1,'passed':not any(r['mismatches'] for r in rows),'modules_checked':len(rows),'source_alias_and_parameter_derivation':'Literal MODULE_DEVICE_TABLE(of/i2c) plus MODULE_ALIAS and module_param; all emitted exports must have source EXPORT_SYMBOL declarations. Conditional exports may be absent. Does not claim runtime hardware behavior.','modules':rows}
(OUT/'all-contracts-source-elf-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'modules':len(rows),'mismatches':[{r['name']:r['mismatches']} for r in rows if r['mismatches']]}))
