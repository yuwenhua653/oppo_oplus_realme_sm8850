#!/usr/bin/env python3
"""Read-only run16 integrity and selected ELF import CRC audit."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'full/full'
BUNDLE=ROOT/'work/myron-adaptation-r12'
spec=importlib.util.spec_from_file_location('driver_validator',BUNDLE/'drivers/validate_drivers.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
manifest=json.loads((ART/'artifact-manifest.json').read_text())
selection=json.loads((ART/'module-selection.json').read_text())
rows=manifest['files'];seen=set();providers=collections.defaultdict(set);objects={};symvers_count=0
for row in rows:
 rel=Path(row['file']);p=(ART/rel).resolve()
 assert not rel.is_absolute() and '..' not in rel.parts and p.is_relative_to(ART.resolve())
 assert row['file'] not in seen;seen.add(row['file'])
 data=p.read_bytes()
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['file']
 if p.suffix=='.ko': objects[row['file']]=v.elf(data)
 if p.suffix=='.symvers' and '/canoe_perf_dtb_build/' not in p.as_posix():
  symvers_count+=1
  for line in data.decode().splitlines():
   fs=line.split()
   if len(fs)>=3:providers[fs[1]].add(int(fs[0],16))
errors=[];checked=0;selected_exports=collections.defaultdict(list);names=[];vermagics=set()
built_by_path={row['file']:row for row in selection['all_built']}
for selected_path in selection['selected']:
 row=built_by_path[selected_path]
 f='objects/'+row['file'];p=objects[f];names.append(row['name'])
 assert row['sha256']==hashlib.sha256((ART/f).read_bytes()).hexdigest()
 assert p['info']['name']==[row['name']]
 vermagics.update(p['info']['vermagic'])
 missing=p['imports']-p['versions'].keys()
 if missing:errors.append({'module':row['name'],'missing_crc':sorted(missing)})
 for symbol,crc in p['versions'].items():
  checked+=1
  if providers.get(symbol)!={crc}:errors.append({'module':row['name'],'symbol':symbol,'actual_crc':hex(crc),'provider_crcs':sorted(map(hex,providers.get(symbol,set())))})
 for symbol in p['exports']:selected_exports[symbol].append(row['name'])
collisions={symbol:sorted(mods) for symbol,mods in sorted(selected_exports.items()) if len(mods)>1}
report={'passed':not errors,'manifest_verified_files':len(rows),'all_built_ko':len(objects),'selected_ko':len(names),'selected_unique_names':len(set(names)),'vermagics':sorted(vermagics),'same_build_symvers_files':symvers_count,'checked_selected_import_crcs':checked,'errors':errors,'diagnostic_candidate_duplicate_export_symbols':collisions,'not_deployment_set':bool(collisions),'flashable':False,'hardware_tested':False,'scope':'Actual immutable run16 objects; complete file hashes and selected module import CRCs. Broad diagnostic selection can include mutually-exclusive providers; no autoload or boot validation.'}
(ROOT/'postbuild-review/all-outputs-integrity-and-crc.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:val for k,val in report.items() if k!='diagnostic_candidate_duplicate_export_symbols'}))
print('diagnostic_duplicate_export_symbols',len(collisions))
raise SystemExit(0 if report['passed'] else 1)
