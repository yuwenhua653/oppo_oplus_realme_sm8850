Myron R13 MCA 服务与电池读取审查

结论
本轮没有再加入新的11个被排除模块。固定来源源码的依赖图显示，3个模块直接引用charger_partition，另外7个通过smart_charge/无线类/thermal的导出间接依赖它。charger_partition本身是第11项。只添加Makefile或删除模块依赖不能闭合符号；返回常量、跳过温限/持久读取也不等价于适配。

service-dependency-audit.json逐项保存引用符号、来源行、通往charger_partition的路径；15份排除模块C输入都与原source-lock的固定SHA一致。此图是源文本对已知导出符号的静态引用分析，未做完整预处理或交叉编译，不能当成真实ELF import。

动态provider缺口
1. 当前编译的strategy_fg_class仅是分发表；真正strategy_class_fg_ops_register由未编译mca_strategy_fg_comp执行。
2. battery PSY需要的usb/wireless名字由未编译mca_business_charger_comp注册。QTI battery charger在选定DT中disabled，不能假定其提供这些电源；更不能同时打开两个owner相同的GLINK驱动绕过。
3. battery的input_suspend voter由未编译buck策略创建。
4. 当前active consumers访问FG、BUCK_CHARGE、QUICK_CHARGE、BASIC_WIRELESS四类strategy，但其provider均未编译。这类枚举/名字路由不体现在.modinfo depends，零harddependency缺失不等于运行链已闭合。

可行后续拆分点
smart_charge唯一直接分区读取是mishow，仅位于O8/O9专用分支。可进一步做明确的产品功能分离，以实际Myron产品信息约束行为；本轮没有为减少依赖删除该分支，也没有伪造mishow。即使分离它，FG/business_charger的持久参数语义仍需处理，而且quickwired/quickwireless/basicwireless仍有已知DT表格维度问题。

本轮真正修改：mca_battery_psy.c
- 未注册FG返回-1、不就绪返回0时，读取返回-ENODATA。
- 缺少信息或PSY返回-ENODEV，不再以0返回未初始化结果。
- USB/wireless ONLINE错误在status判断前传播；SOC负错误/超100时不再推断正常充电状态。
- SOC错误不再替换为15%，health错误不再改为GOOD，current/charge_type错误不再丢弃。
- CAPACITY_LEVEL先检查CAPACITY读取错误，避免错误路径把零初始化误当0%并报告CRITICAL。
- 电压仍mV转µV，电流/温度/容量等原映射保持；仅成功才提交返回值。
- 6个已公布、原来空实现的读取属性及factory分支未提供的属性明确返回-ENODATA，允许power_supply uevent跳过；未知正常属性仍返回-EINVAL。
- 日志失败字段明确-1，不读取栈上未初始化数据；未实现SOH明确-1。
- 保留已有显式fake_power模式，没有把它作为失败fallback启用。
- probe、PSY注册顺序、public ABI、DT和持久数据均未更改；cached get仍在deinit put一次，重复deinit不会双put。
- setter路径未在本轮范围：仍有空实现。完整strategy ops注册/撤销并发和bool charging_done API无法携带错误等剩余问题未宣称已修好。

验证
run_battery_psy.py从真实payload提取8个实际函数，主机cc -Werror + UBSan执行179个用例，涵盖缺provider、错误传播、SOC/状态/容量等级边界、数值单位、模型字符串、明确fake模式、日志和引用释放。
另外完整遍历源码中真实公布的25个属性，覆盖正常、factory、未注册FG、缺USB四种情况；遵守uevent仅跳过ENODATA/ENODEV的约定，未将真实EIO等错误伪装为无数据。
另10项负例（包括整个旧run16版本）在同一host测试中触发runtime断言，证明不是空测试。文件battery-host-tests.json/battery-negative-tests.json保存结果。
这不能替代整个DDK交叉编译、同构建CRC/KCFI合同或实机验证。

集成
已直接更改共享bundle中的mca_battery_psy.c和drivers/tests/r13-battery/run_battery_psy.py。
其他source-lock哈希、host-tests清单、fastcheck路由由主agent统一更新。
