#!/usr/bin/env python3
"""Verify the precise run15 service repairs; this is NOT a target build.

The original r12 archive is the comparison base. The wireless file must differ
only in the four guard blocks: tabs/braces and `return ;` -> `return;`. The
ADSP file must differ only by directly including mod_devicetable.h. A local
include-graph audit also reports OF table users relying on transitive headers.
No replacement kernel types or APIs are compiled.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import zipfile


WIRELESS = "drivers/power/supply/mca/mca_strategy/strategy_wireless/mca_wireless_revchg.c"
ADSP = "drivers/power/supply/mca/mca_common/mca_adsp_glink.c"
OLD_GUARD = """    /* Do not alter boost rails or start flash programming before the
     * separately reviewed IC firmware-programming opt-in. */
    if (!IS_ENABLED(CONFIG_MYRON_IC_FIRMWARE_PROGRAMMING))
        return -EOPNOTSUPP;"""
NEW_GUARD = """\t/* Do not alter boost rails or start flash programming before the
\t * separately reviewed IC firmware-programming opt-in. */
\tif (!IS_ENABLED(CONFIG_MYRON_IC_FIRMWARE_PROGRAMMING)) {
\t\treturn -EOPNOTSUPP;
\t}"""
INCLUDES = re.compile(r'^\s*#\s*include\s*[<"]([^>"\n]+)', re.M)
TABLE = re.compile(r"struct\s+of_device_id\s+\w+\s*\[")
OF_HEADERS = {"linux/of.h", "linux/mod_devicetable.h"}


def validate_sources(wireless, adsp):
    assert wireless.count(NEW_GUARD) == 3, "Expected three braced, tab-indented integer guards"
    assert wireless.count(NEW_GUARD.replace("return -EOPNOTSUPP;", "return;")) == 1, "Expected one braced, tab-indented worker guard"
    assert wireless.count("CONFIG_MYRON_IC_FIRMWARE_PROGRAMMING") == 4
    assert "#include <linux/mod_devicetable.h>" in adsp, "ADSP lacks direct of_device_id definition header"
    assert TABLE.search(adsp), "ADSP table unexpectedly absent"


def check(payload, original_zip=None):
    after = {p: (payload / p).read_text() for p in (WIRELESS, ADSP)}
    validate_sources(after[WIRELESS], after[ADSP])
    before = {}
    negative_controls = []
    if original_zip:
        with zipfile.ZipFile(original_zip) as archive:
            before = {p: archive.read("myron-adaptation-r12/drivers/payload/" + p).decode()
                      for p in (WIRELESS, ADSP)}
        assert before[WIRELESS].count(OLD_GUARD) == 3
        old_void = OLD_GUARD.replace("return -EOPNOTSUPP;", "return ;")
        new_void = NEW_GUARD.replace("return -EOPNOTSUPP;", "return;")
        assert before[WIRELESS].count(old_void) == 1
        expected = before[WIRELESS].replace(OLD_GUARD, NEW_GUARD).replace(old_void, new_void)
        assert after[WIRELESS] == expected, "Wireless patch differs outside the four guarded entries"
        assert after[ADSP] == before[ADSP].replace(
            "#include <linux/of_device.h>",
            "#include <linux/mod_devicetable.h>\n#include <linux/of_device.h>"), "ADSP patch differs outside required include"
        for path in (WIRELESS, ADSP):
            candidate = dict(after)
            candidate[path] = before[path]
            try:
                validate_sources(candidate[WIRELESS], candidate[ADSP])
            except AssertionError as error:
                negative_controls.append({"original_r12_file": path, "status": "rejected", "reason": str(error)})
            else:
                raise AssertionError("Original failing source was not rejected: " + path)

    paths = sorted(payload.rglob("*.c"))
    guards = []
    for path in paths:
        for lineno, line in enumerate(path.read_text(errors="replace").splitlines(), 1):
            if re.search(r"if\s*\(.*CONFIG_MYRON_IC_FIRMWARE_PROGRAMMING", line):
                assert line.startswith("\t"), f"Non-kernel indentation at {path}:{lineno}"
                guards.append({"path": str(path.relative_to(payload)), "line": lineno})
    assert len(guards) == 12, f"Unexpected firmware guard count {len(guards)}"

    search_roots = [payload, payload / "include",
                    payload / "drivers/power/supply/mca/include"]

    def of_path(path, visited=None):
        visited = set() if visited is None else visited
        if path in visited:
            return None
        visited.add(path)
        includes = INCLUDES.findall(path.read_text(errors="replace"))
        direct = next((name for name in includes if name in OF_HEADERS), None)
        if direct:
            return [str(path.relative_to(payload)), direct]
        for name in includes:
            local = next((candidate for root in [path.parent] + search_roots
                          if (candidate := root / name).is_file()), None)
            if local:
                chain = of_path(local, visited)
                if chain:
                    return [str(path.relative_to(payload))] + chain
        return None

    of_users = []
    for path in paths:
        text = path.read_text(errors="replace")
        if not TABLE.search(text):
            continue
        direct = sorted(OF_HEADERS.intersection(INCLUDES.findall(text)))
        chain = of_path(path)
        of_users.append({"path": str(path.relative_to(payload)), "direct": direct,
                         "payload_include_chain": chain,
                         "status": "direct" if direct else "local_transitive" if chain
                         else "kernel_transitive_or_unresolved"})
    mca_unresolved = [item for item in of_users if "/mca/" in item["path"]
                      and item["status"] == "kernel_transitive_or_unresolved"]
    assert not mca_unresolved, mca_unresolved
    changed = {path: {"before_sha256": hashlib.sha256(before[path].encode()).hexdigest(),
                      "after_sha256": hashlib.sha256(after[path].encode()).hexdigest()}
               for path in before}
    patch = "".join("".join(difflib.unified_diff(before[p].splitlines(True),
                                                  after[p].splitlines(True),
                                                  fromfile="a/" + p, tofile="b/" + p))
                    for p in before)
    return {"status": "pass", "scope": "source repair integrity, not target compilation",
            "changes": changed, "negative_controls": negative_controls, "wireless_guards_repaired": 4,
            "firmware_guard_count": len(guards), "firmware_guards": guards,
            "of_device_table_users": of_users,
            "mca_unresolved_of_definition": mca_unresolved}, patch


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload", type=Path, required=True)
    parser.add_argument("--original-zip", type=Path)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result, patch = check(args.payload.resolve(), args.original_zip.resolve() if args.original_zip else None)
    args.report.write_text(json.dumps(result, indent=2) + "\n")
    args.report.with_suffix(".patch").write_text(patch)
    print(json.dumps({"status": result["status"], "guards": result["firmware_guard_count"],
                      "of_table_users": len(result["of_device_table_users"]),
                      "negative_controls": len(result["negative_controls"])}))


if __name__ == "__main__":
    main()
