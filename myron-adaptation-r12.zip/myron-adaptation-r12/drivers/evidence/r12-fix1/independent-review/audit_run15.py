#!/usr/bin/env python3
"""Read-only evidence audit of run15; reads immutable uploaded r12 ZIP."""
import ast,collections,hashlib,json,pathlib,re,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=pathlib.Path(__file__).resolve().parent
REPORTS=ROOT/'reports/kernel_workspace/myron-platform-r1/integration-reports'
logpath=REPORTS/'full.log'
lines=logpath.read_text().splitlines()
zip_path=ROOT/'original-delivery/repo-files/myron-adaptation-r12.zip'
with zipfile.ZipFile(zip_path) as z:
 registry=z.read('myron-adaptation-r12/drivers/payload/drivers/xiaomi/myron/modules.bzl').decode()
 lock=json.loads(z.read('myron-adaptation-r12/drivers/source-lock.json'))
rows=[]
for n in ast.walk(ast.parse(registry)):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='register':
  rows.append({k.arg:ast.literal_eval(k.value) for k in n.keywords})
by_name={r['name']:r for r in rows}
by_out={r['out'].removesuffix('.ko'):r for r in rows}
new=lock['new_r12_modules']
if isinstance(new[0],dict): raise ValueError('Unexpected module declaration schema')
new=[x.removesuffix('.ko') for x in new]
failed={}
for i,line in enumerate(lines,1):
 m=re.search(r'ERROR: .*Building DDK module \(trim\) (//\S+) failed:',line)
 if m: failed[m[1].split(':canoe_perf/',1)[1]]={'label':m[1],'line':i}
assert len(failed)==3
blocked={}
def trace(name,stack=()):
 if name in failed: return [name]
 if name not in by_name or name in stack: return None
 for dep in by_name[name].get('deps',[]):
  t=trace(dep,stack+(name,))
  if t: return [name]+t
for row in rows:
 if row['name'] in failed: continue
 t=trace(row['name'])
 if t: blocked[row['out'].removesuffix('.ko')]=t
candidates=[]
for name in sorted(new):
 r=by_out[name]
 state='failed_compile' if r['name'] in failed else 'blocked_by_failed_dependency' if name in blocked else 'no_failure_diagnostic_not_individually_verified'
 candidates.append({'module':name,'label':'//vendor/qcom/sm8850:canoe_perf/'+r['name'],'assessment':state,'dependency_path':blocked.get(name), 'progress_line_evidence':[i for i,l in enumerate(lines,1) if 'Building DDK module' in l and ':canoe_perf/'+r['name']+';' in l]})
warning_categories=collections.Counter()
for l in lines:
 if 'Warning (' in l: warning_categories['DTC:'+l.split('Warning (',1)[1].split(')',1)[0]]+=1
 elif 'warning:' in l:
  if 'Kconfig' in l or '.config:' in l: warning_categories['Kconfig']+=1
  elif 'deprecated' in l: warning_categories['deprecation']+=1
  elif 'within block comment' in l: warning_categories['comment']+=1
  else: warning_categories['other_compiler_or_vm']+=1
error_lines=[{'line':i,'text':l} for i,l in enumerate(lines,1) if re.search(r'(^ERROR:| error:|^fatal error:)',l)]
status=json.loads((REPORTS/'full-status.json').read_text())
from datetime import datetime
wall=(datetime.fromisoformat(status['finished_utc'].replace('Z','+00:00'))-datetime.fromisoformat(status['started_utc'].replace('Z','+00:00'))).total_seconds()
result={
 'schema':'myron-run15-independent-audit-v1',
 'inputs':{'full_log_sha256':hashlib.sha256(logpath.read_bytes()).hexdigest(),'original_source_zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest()},
 'observed_build':{'success':False,'top_level_targets_succeeded':2,'top_level_targets_requested':3,'bazel_elapsed_seconds':4971.782,'critical_path_seconds':2655.33,'runner_wrapper_wall_seconds':wall,'registered_custom_modules':len(rows),'new_modules':len(new),'keep_going':True,'source_preflight_mode':'workspace_strict','source_preflight_success':True,'output_validation_reached':False},
 'failed_targets':list(failed.values()),'compiler_error_counts':dict(collections.Counter('incomplete_of_device_id' if 'incomplete element type' in e['text'] else 'undeclared_fg_enum' if 'undeclared identifier' in e['text'] else 'misleading_indentation' if 'misleading indentation' in e['text'] else 'compiler_error_limit' if 'too many errors' in e['text'] else 'build_summary' for e in error_lines)),
 'new_module_assessments':candidates,
 'blocked_new_modules':blocked,
 'warning_counts':dict(warning_categories),
 'timing_evidence':{'common_kernel_longest_reported_action_seconds':1407,'dtb_kernel_longest_reported_action_seconds':264,'post_failure_peach_v2_longest_reported_action_seconds':1055,'post_failure_kiwi_v2_longest_reported_action_seconds':630,'scope':'action durations overlap and are not whole-job timestamps; do not sum these as exact total time'},
 'fourth_failure_class_observed':False,
 'limitations':['BQ compiler stopped at its default error limit; later code errors could be hidden.','The 4 dependency-blocked target translation units were not validated by this run.','Progress lines are sampled at 30-second intervals; absent module names do not prove lack of execution or success.','No BEP/action-level outcome file or retained new ELF artifact manifest was collected after the failed build.','Remaining 15 new targets have no failure diagnostic; this does not establish their CRC/KCFI/runtime validity.']}
(OUT/'run15-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(OUT/'compiler-errors.txt').write_text('\n'.join(f"{x['line']}: {x['text']}" for x in error_lines)+'\n')
(OUT/'priority-targets.txt').write_text('\n'.join(x['label'] for x in candidates)+'\n')
print(json.dumps({'failed':len(failed),'blocked':list(blocked),'other_new':sum(x['assessment'].startswith('no_failure') for x in candidates),'warnings':sum(warning_categories.values()),'wrapper_seconds':wall},ensure_ascii=False))
