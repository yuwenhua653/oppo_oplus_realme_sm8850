Run 15 独立复核（只读构建日志与原始 r12 包）

结论
1. full.log 只有 3 个失败的 DDK 目标：mca_wireless_revchg、bq27z561、mca_adsp_glink。
   直接原因分别是 4 处 Wmisleading-indentation、缺失 FG_IC_PROP_* 枚举、未得到 struct of_device_id 完整定义。
   BQ 在第 19 个缺失标识后达到错误上限；错误上限后的源文件内容未由本次编译证明无错。
2. --keep_going 已开启，但不能跨过失败依赖编译消费者。
   mca_path_control 被 mca_wireless_revchg 阻断；mca_qcom_subpmic_proxy、qcom_adsp_pd_protocol、sc96281_charger 被 mca_adsp_glink 阻断。
   新增 22 个模块中：3 个明确编译失败，4 个被失败依赖阻断，另 15 个无失败诊断。
   因构建失败后 collect/validate 没有执行，没有这些新模块的 ELF/CRC/KCFI 审计产物，不能宣布另 19 个或另 15 个完整验证通过。
3. 未观察到第 4 类构建失败。Kconfig IPA3/RMNET 等警告、设备树警告及 qseecom 弃用提示没有导致此次失败。
   full-r12-status.json 的 success=true 对应 action=apply；full-status.json 才是本轮总体失败状态。

实际耗时证据
- build_platform 包装阶段：2026-10-10 06:32:46 UTC 至 07:56:13 UTC，5007 秒（83 分 27 秒）。
- Bazel build 自报：4971.782 秒（82 分 51.782 秒），critical path 2655.33 秒。
- common:kernel_aarch64 单个动作的最后进度已到 1407 秒；优先编译新驱动的冷构建仍需它。
- 首个失败后仍继续其它独立目标，包括 WLAN peach-v2（动作进度到 1055 秒）、kiwi-v2（630 秒），以及显示、相机、图形等。
- 这些是不同动作的计时，存在并行，不能直接相加，也没有足够证据承诺修订流程固定几分钟完成。
- 当前工作流没有跨 job 的 Bazel cache restore/save。新的一轮 Actions 不会自动复用本次已结束 runner 的 out。

最小流程改进建议
A. 同步源代码前，运行独立 host-only 检查：包哈希、项目头/注册声明静态审计、针对此次三类真实失败的回归检查。
   不能原样调用 run_r12.py apply：其后半段要求实际 pinned common/SoC/DT 工作区。
   原先的 callback/ownership 等主机测试已经在本次 Actions 执行且通过；简单重复旧测试不能阻止这次失败。
   静态/提取片段检查的通过也不能替代整文件 AArch64 编译。
B. 完成 apply 和 workspace_strict 检查之后，先以同一个 output_base、同一套 configuration/资源 flags 编译新增 22 个显式 DDK 标签（本目录 priority-targets.txt）。
   保留 --keep_going，让彼此独立的新模块尽量一次暴露错误。失败时停止，不再启动全平台目标。
   建议额外带上被修改的 qti_battery_charger（共 23 个优先请求目标），其源码有新的 ownership guard。
   全部通过后，再用原来的 full 命令，保持相同 job/workspace/out，不 clean，可复用匹配动作的结果。
   两次 --batch 调用有分析/启动开销；不能承诺总成功构建耗时一定减少。确定收益是新增模块失败后不继续全量外围目标。
C. 保留两个阶段的独立日志和状态。可增加 Bazel build event JSON，使下次按目标区分 success/failed/dependency-blocked，避免从抽样进度行猜测成功数量。
   full 的 ELF 依赖、CRC、唯一导出、KCFI 和设备树验证必须继续保留；优先构建通过不能绕过它们。

被依赖阻断模块补充只读审计
- 4 模块对应 5 个 C 文件，共 7479 行。
- 扫描了实际可达项目头中的 MCA/FG/WLS/ADSP 等常量与 185 处可解析项目 API 调用参数数量，未找到另一处缺失项目常量或调用参数数量冲突。
- 包含设备表的 4 个源文件均显式包含 linux/of.h，没有同类漏掉 of_device_id 定义的问题。
- 简单的未加花括号 if 缩进扫描没有发现与本次 4 处相同的紧邻模式。
- 此为有边界的源码审查，不是预处理、C 类型推导、整文件编译或 ELF 验证，不表示被阻断模块已编译成功。
- 运行期问题仍存在，例如 path_control probe 未检查 kcalloc 返回即 memset，SC96281 IRQ 失败处理不完整。这些不是此次构建失败原因，也未在独立审计中修改。

文件
- run15-review.json：原始日志与 ZIP 哈希、失败目标、22 项逐项结论、依赖阻断链、警告统计、耗时。
- compiler-errors.txt：全部明确编译错误和失败摘要行。
- priority-targets.txt：从原始 r12 registry 生成的新增 22 个 DDK 标签。
- audit_run15.py：可重跑的只读日志/依赖审计脚本。
- blocked-source-scan.json / scan_blocked_sources.py：被阻断文件的有限静态审计。
