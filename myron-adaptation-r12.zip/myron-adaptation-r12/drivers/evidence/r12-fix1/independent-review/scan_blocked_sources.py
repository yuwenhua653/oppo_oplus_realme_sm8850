#!/usr/bin/env python3
"""Heuristic read-only audit, not preprocessing/type checking or compilation."""
import pathlib,re,json,hashlib
BASE=pathlib.Path(__file__).resolve().parents[1]/'work/myron-adaptation-r12/drivers/payload'
MCA=BASE/'drivers/power/supply/mca'
paths=[MCA/'mca_hardware_monitor/mca_path_control.c',MCA/'mca_qcom_subpmic_proxy/mca_qcom_subpmic_proxy.c',MCA/'mca_protocol/protocol_pd/qcom_tcpc/qcom_adsp_pd_protocol.c',MCA/'mca_hardware_ic/wireless_ic/sc96281/sc96281_core.c',MCA/'mca_hardware_ic/wireless_ic/sc96281/sc96281_mtp_program.c']
INCLUDES=[MCA/'include', BASE/'include',BASE/'drivers/misc/hwid']
def clean(s): return re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"',lambda m:'\n'*m[0].count('\n'),s,flags=re.S)
def closure(p,seen=None):
 if seen is None: seen=set()
 if p in seen: return seen
 seen.add(p)
 s=re.sub(r'/\*.*?\*/|//[^\n]*','',p.read_text(errors='replace'),flags=re.S)
 for q,name in re.findall(r'^\s*#\s*include\s*([<"])([^>"]+)[>"]',s,re.M):
  choices=([p.parent/name] if q=='"' else [])+[x/name for x in INCLUDES]
  for x in choices:
   if x.is_file(): closure(x,seen);break
 return seen

def balanced_args(s,start):
 depth=1;i=start;beg=i;args=[]
 while i<len(s) and depth:
  c=s[i]
  if c in '([{':depth+=1
  elif c in ')]}':depth-=1
  if (c==',' and depth==1) or depth==0: args.append(s[beg:i].strip());beg=i+1
  i+=1
 return args,i

results=[]
for p in paths:
 raw=p.read_text();s=clean(raw);headers=closure(p)-{p};h='\n'.join(clean(x.read_text(errors='replace')) for x in sorted(headers))
 known=set(re.findall(r'\b[A-Z_][A-Z_0-9]+\b',h))
 defs=set(re.findall(r'^\s*#\s*define\s+([A-Z_][A-Z_0-9]+)',s,re.M))
 for b in re.findall(r'\benum\b[^\{;]*\{(.*?)\}',s,re.S): defs.update(re.findall(r'\b[A-Z_][A-Z_0-9]+\b',b))
 unknown=sorted(set(re.findall(r'\b(?:FG|MCA|WIRELESS|WLS|ADSP|HW|PLATFORM|CP|PD|TYPEC)_[A-Z_0-9]+\b',s))-known-defs)
 # Declarations immediately ending in ';' from reachable project headers.
 proto={}
 for m in re.finditer(r'\b((?:mca_|platform_class_|protocol_class_)[A-Za-z_0-9]+)\s*\(',h):
  args,end=balanced_args(h,m.end())
  if re.match(r'\s*;',h[end:]) and '...' not in args:
   proto[m[1]]=0 if args in (['void'],['']) else len(args)
 wrong=[]; checked=0; unknowncalls=set()
 for m in re.finditer(r'\b((?:mca_|platform_class_|protocol_class_)[A-Za-z_0-9]+)\s*\(',s):
  args,end=balanced_args(s,m.end());name=m[1]
  if re.match(r'\s*\{',s[end:]):continue
  if name in proto:
   checked+=1;argc=0 if args==[''] else len(args)
   if argc!=proto[name]:wrong.append({'name':name,'actual_argc':argc,'header_argc':proto[name],'line':s[:m.start()].count('\n')+1})
  else: unknowncalls.add(name)
 results.append({'source':str(p.relative_to(BASE)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reachable_project_headers':len(headers),'candidate_missing_project_constants':unknown,'project_api_calls_arity_checked':checked,'arity_mismatches':wrong,'calls_not_classified_as_reachable_header_prototypes':sorted(unknowncalls),'has_of_device_id_table':bool(re.search(r'struct\s+of_device_id\s+\w+\s*\[',s)),'explicit_of_or_mod_devicetable_include':bool(re.search(r'^\s*#include\s*<linux/(?:of|mod_devicetable)\.h>',raw,re.M))})
report={'method':'Heuristic symbol/arity scan of 5 C translation units belonging to 4 dependency-blocked targets; reachable project headers only. Does not run the kernel preprocessor, evaluate conditional macros, infer types or certify compilation.','results':results}
p=pathlib.Path(__file__).with_name('blocked-source-scan.json');p.write_text(json.dumps(report,indent=2)+'\n')
for r in results:print(r['source'],r['candidate_missing_project_constants'],r['arity_mismatches'],r['calls_not_classified_as_reachable_header_prototypes'])
