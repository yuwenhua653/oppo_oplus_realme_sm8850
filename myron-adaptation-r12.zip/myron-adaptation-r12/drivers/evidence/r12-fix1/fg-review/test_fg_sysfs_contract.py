#!/usr/bin/env python3
"""Check the full BQ sysfs namespace and compile its real table/handlers.

This is a host syntax/dispatch contract check, not an arm64 kernel build or
hardware simulation. Kernel device types have a minimal host envelope; BQ
fields and all called BQ function declarations come from the actual payload.
"""
import argparse
import hashlib
import json
import re
import subprocess
import tempfile
from pathlib import Path


BQ = Path('drivers/power/supply/mca/mca_hardware_ic/fuelgauge_ic/bq27z561')
FG_H = Path('drivers/power/supply/mca/include/mca/platform/platform_fg_ic_ops.h')
SYSFS_H = Path('drivers/power/supply/mca/include/mca/common/mca_sysfs.h')


def enum_block(text, name):
    match = re.search(r'\benum\s+' + re.escape(name) + r'\s*\{[^}]*\};', text)
    if not match:
        raise AssertionError('Missing enum: ' + name)
    return match.group()


def enum_members(block):
    body = block[block.index('{') + 1:block.rindex('}')]
    values = [v.strip() for v in body.split(',') if v.strip()]
    assert all(re.fullmatch(r'FG_IC_PROP_\w+', v) for v in values), values
    assert len(set(values)) == len(values), 'Duplicate enum member'
    return values


def table_block(text):
    match = re.search(r'struct mca_sysfs_attr_info fg_sysfs_field_tbl\[\]\s*=\s*\{.*?\n\};', text, re.S)
    assert match, 'Missing full BQ sysfs attribute table'
    return match.group()


def function_block(text, name):
    match = re.search(r'(?m)^static\s+[^;{}=]*?\b' + re.escape(name) + r'\s*\([^;{}]*\)\s*\{', text)
    assert match, 'No actual function definition: ' + name
    start = match.start()
    end = match.end()
    depth = 1
    while depth:
        if text[end] == '{':
            depth += 1
        elif text[end] == '}':
            depth -= 1
        end += 1
    return text[start:end]


def table_entries(table):
    result = re.findall(r'mca_sysfs_attr_(ro|rw|wo)\(fg_sysfs,\s*(0[0-7]+),\s*(FG_IC_PROP_\w+),\s*(\w+)\)', table)
    assert len(result) == len(re.findall(r'\bmca_sysfs_attr_\w+\(', table)), 'Unparsed attribute row'
    return result


def assert_contract(candidate, upstream_header, upstream_c):
    members = enum_members(enum_block(upstream_header, 'mca_fg_ic_prop'))
    assert enum_members(enum_block(candidate, 'bq27z561_sysfs_prop')) == members, 'Onyx numeric tag ordering changed'
    table = table_block(candidate)
    assert table == table_block(upstream_c), 'Attribute order, modes, names or tag mapping changed'
    references = set(re.findall(r'\bFG_IC_PROP_\w+', candidate.replace(enum_block(candidate, 'bq27z561_sysfs_prop'), '')))
    assert references <= set(members), 'Undefined property tags: ' + str(references - set(members))
    handlers = [function_block(candidate, n) for n in ('fg_sysfs_show', 'fg_sysfs_store')]
    for name, handler in zip(('fg_sysfs_show', 'fg_sysfs_store'), handlers):
        cases = re.findall(r'\bcase\s+(FG_IC_PROP_\w+)\s*:', handler)
        assert cases == re.findall(r'\bcase\s+(FG_IC_PROP_\w+)\s*:', function_block(upstream_c, name)), 'Dispatch cases changed: ' + name
        assert len(cases) == len(set(cases)), 'Duplicate switch case: ' + name
    assert set(row[2] for row in table_entries(table)) <= set(re.findall(r'\bcase\s+(FG_IC_PROP_\w+)\s*:', handlers[0])), 'Attribute has no read dispatch'
    return members, references, table, handlers


def host_translation_unit(source, bq_header, sysfs_header, members, table, handlers):
    body = '\n\n'.join(handlers)
    chip = re.search(r'struct bq_fg_chip\s*\{(.*?)\n\};', bq_header, re.S).group(1)
    # Preserve the exact declaration of each field used by the real handlers.
    used_fields = sorted(set(re.findall(r'\binfo->(\w+)', body)))
    chip = re.sub(r'/\*.*?\*/', '', chip, flags=re.S)
    decls = [line.strip() + ';' for line in chip.split(';') if line.strip()]
    fields = []
    for name in used_fields:
        matches = [d for d in decls if re.search(r'\b' + name + r'\b', d)]
        assert len(matches) == 1, (name, matches)
        fields.append(matches[0])

    calls = sorted(set(re.findall(r'\b(fg_\w+)\s*\(', body)) - {'fg_sysfs_show', 'fg_sysfs_store'})
    prototypes = []
    for call in calls:
        definition = function_block(source, call)
        prototypes.append(re.sub(r'^static\s+', 'extern ', definition.split('{', 1)[0].strip()) + ';')

    required_macros = set(re.findall(r'\bFG_MAC_CMD_\w+', body))
    bq_enums = re.findall(r'enum\s+\w+\s*\{[^}]*\};', bq_header)
    command_enums = [b for b in bq_enums if any(re.search(r'\b' + name + r'\b', b) for name in required_macros)]
    assert required_macros <= set(re.findall(r'\bFG_MAC_CMD_\w+', '\n'.join(command_enums)))
    mca_struct = re.search(r'struct mca_sysfs_attr_info\s*\{[^}]*\};', sysfs_header).group()
    macro_start = sysfs_header.index('#define mca_sysfs_attr_ro')
    macro_end = sysfs_header.index('struct mca_debugfs_attr_data;', macro_start)
    macros = sysfs_header[macro_start:macro_end]
    asserts = '\n'.join(f'_Static_assert({name} == {i}, "tag_{name}");' for i, name in enumerate(members))
    prelude = r'''
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#define PAGE_SIZE 4096
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define __maybe_unused __attribute__((unused))
struct device;
struct attribute { const char *name; unsigned int mode; };
struct device_attribute {
    struct attribute attr;
    ssize_t (*show)(struct device *, struct device_attribute *, char *);
    ssize_t (*store)(struct device *, struct device_attribute *, const char *, size_t);
};
#define __ATTR(_name, _mode, _show, _store) { .attr = { .name = #_name, .mode = (_mode) }, .show = (_show), .store = (_store) }
extern void *dev_get_drvdata(const struct device *);
extern int scnprintf(char *, size_t, const char *, ...) __attribute__((format(printf, 3, 4)));
extern int kstrtoint(const char *, unsigned int, int *);
extern ssize_t strscpy(char *, const char *, size_t);
'''
    prelude += mca_struct + '\n' + macros
    prelude += 'extern struct mca_sysfs_attr_info *mca_sysfs_lookup_attr(const char *, struct mca_sysfs_attr_info *, int);\n'
    prelude += 'struct bq_fg_chip {\n' + '\n'.join(fields) + '\n};\n'
    prelude += '\n'.join(command_enums) + '\n' + '\n'.join(prototypes) + '\n'
    prelude += 'static ssize_t fg_sysfs_show(struct device *, struct device_attribute *, char *);\n'
    prelude += 'static ssize_t fg_sysfs_store(struct device *, struct device_attribute *, const char *, size_t);\n'
    return prelude + enum_block(source, 'bq27z561_sysfs_prop') + '\n' + asserts + '\n' + table + '\n#define FG_SYSFS_ATTRS_SIZE ARRAY_SIZE(fg_sysfs_field_tbl)\n' + body + '\n', calls, used_fields


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', type=Path, help='Convenience alternative to --payload and --upstream')
    parser.add_argument('--payload', type=Path)
    parser.add_argument('--upstream', type=Path)
    parser.add_argument('--report', type=Path)
    parser.add_argument('--cc', default='cc')
    args = parser.parse_args()
    payload = args.payload or (args.bundle / 'drivers/payload' if args.bundle else None)
    upstream = args.upstream or (args.bundle / 'drivers/upstream' if args.bundle else None)
    if payload is None or upstream is None:
        parser.error('Supply --payload and --upstream, or --bundle')
    source = (payload / BQ / 'bq27z561.c').read_text()
    upstream_c = (upstream / 'r12-ic' / BQ / 'bq27z561.c').read_text()
    upstream_h = (upstream / FG_H).read_text()
    members, refs, table, handlers = assert_contract(source, upstream_h, upstream_c)
    unit, calls, fields = host_translation_unit(source, (payload / BQ / 'inc/bq27z561.h').read_text(), (payload / SYSFS_H).read_text(), members, table, handlers)
    with tempfile.TemporaryDirectory(prefix='myron-fg-sysfs-') as temp:
        path = Path(temp) / 'fg_sysfs_contract.c'
        path.write_text(unit)
        # Kbuild disables pointer-sign warnings for kernel C. Preserve that
        # baseline here: Onyx has several existing int/u32 output aliases.
        command = [args.cc, '-std=gnu11', '-Wall', '-Wextra', '-Werror', '-Wno-pointer-sign', '-fsyntax-only', '-fmax-errors=0', str(path)]
        result = subprocess.run(command, text=True, capture_output=True)
        assert result.returncode == 0, result.stderr
    negative = {}
    block = enum_block(source, 'bq27z561_sysfs_prop')
    mutants = {
        'r12_missing_entire_enum': source.replace(block, ''),
        'missing_late_property_beyond_error_limit': source.replace('\tFG_IC_PROP_CHARGE_ABSOC,\n', '', 1),
        'changed_numeric_order': source.replace('\tFG_IC_PROP_ACTUAL_POWER,\n\tFG_IC_PROP_ACTUAL_POWER_B,', '\tFG_IC_PROP_ACTUAL_POWER_B,\n\tFG_IC_PROP_ACTUAL_POWER,'),
        'wrong_attribute_tag_mapping': source.replace('FG_IC_PROP_CHIP_OK, chip_ok)', 'FG_IC_PROP_VOL, chip_ok)', 1),
        'removed_late_switch_case': source.replace('\tcase FG_IC_PROP_CHARGE_ABSOC:', '\tcase FG_IC_PROP_MAX:', 1),
    }
    for name, mutant in mutants.items():
        try:
            assert_contract(mutant, upstream_h, upstream_c)
        except AssertionError:
            negative[name] = 'rejected'
        else:
            raise AssertionError('Negative control unexpectedly passed: ' + name)
    entries = table_entries(table)
    report = {
        'status': 'pass',
        'scope': 'host syntax and full sysfs numeric/name/dispatch contract; not target arm64 compilation or runtime proof',
        'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
        'original_enum_items_including_max': len(members),
        'all_source_property_identifiers_resolved': len(refs),
        'original_table_rows_preserved': len(entries),
        'real_show_store_functions_compiled': 2,
        'actual_bq_called_function_prototypes_checked': len(calls),
        'actual_bq_struct_field_declarations_checked': len(fields),
        'compiler': args.cc,
        'warnings_as_errors': True,
        'error_limit_disabled': True,
        'kernel_baseline_warning_options': ['-Wno-pointer-sign'],
        'negative_controls': negative,
        'known_upstream_semantics_preserved': [
            'avercurrent and average_current both map to FG_IC_PROP_AVERAGE_CURRENT; no change made in this compile fix',
            'read-write dod_count has no writer switch case upstream; no change made in this compile fix',
        ],
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
