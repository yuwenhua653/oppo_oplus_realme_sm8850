BQ27Z561 编译修复（run15）

根因：此前为保留 Myron 的 fuelguage_ic_ops 布局重写公共头时，没有保留 Onyx 的 mca_fg_ic_prop 枚举；r12 BQ27Z561 sysfs 表仍引用该枚举。Clang 的默认报错上限只显示前 19 个；实际上驱动共使用 106 个不同属性标识。

修复：在 BQ27Z561 .c 的 sysfs 区域恢复私有 bq27z561_sysfs_prop 枚举。完整 107 项（含 MAX）按归档 Onyx 的原始名称和数字顺序恢复，不修改公共 FG 头，不改变 Myron 的回调布局，不删除属性、switch 或功能，不引入 stub。
来源：unmoved21/android_kernel_xiaomi_onyx@8276ba954d8076303a5ae0f7b15d4092d66bdff6 的 drivers/power/supply/mca/include/mca/platform/platform_fg_ic_ops.h；归档 Git blob 4f6630aebdbb6f866914a4c54845d1639814d765。

验证：test_fg_sysfs_contract.py --payload <bundle>/drivers/payload --upstream <bundle>/drivers/upstream --report <report.json>
- 核对 107 个原枚举及数字顺序，106 个使用标识全部已定义；
- 原始 sysfs 106 行的顺序、权限、名称、tag 映射完全保持；
- show/store 的全部 switch case 保持；
- 将真实 sysfs 表及完整 show/store 函数送入主机 C 编译器，使用 110 个真实被调函数原型、23 个真实 BQ 结构字段声明；
- 开启 -Werror 并取消报错数量上限；延续 Kbuild 的 -Wno-pointer-sign 基线，因为 Onyx 本就存在 int/u32 指针混用；没有为产品构建新加屏蔽选项；
- 5 个负例全部被拒绝：旧 r12 整枚举缺失、末尾 CHARGE_ABSOC 缺失、数字顺序变化、属性映射变化、末尾 switch 错误；
- 公共 platform_fg_ic_ops.h 字节保持不变。

限定：主机类型封装只覆盖 sysfs 片段，不能等同整个目标 arm64 模块编译或硬件验证。错误位置后的其他 callback/driver 尾部做过源码检查，现有模块回调类型测试仍需保留。原 Onyx 的 avercurrent/average_current 双名称映射与 dod_count 无写分支等行为在本次编译修复中保持；未扩展为设备运行功能修复。
