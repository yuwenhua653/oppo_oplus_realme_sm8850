Myron r7: MCA common-service audit / charge-interface candidate

Selected module: mca_charge_interface (one callback registry/sysfs framework).
Candidate paths are relative to the SoC tree. Copy candidate/ only into payload;
use integration.json for DDK registration, source hashes, exact export/dep gates.
Shared r6 mca_log/sysfs/event headers are dependencies and are not overwritten.
No DT node is enabled here, no charging IC or policy or ADSP/SMEM is implemented.

Source provenance
- Existing pinned and Git-blob-verified Onyx files:
  unmoved21/android_kernel_xiaomi_onyx
  @8276ba954d8076303a5ae0f7b15d4092d66bdff6
  drivers/power/supply/mca/mca_common/mca_charge_interface.c
  drivers/power/supply/mca/include/mca/common/mca_charge_interface.h
- Onyx import history recorded in r6 provenance.json identifies Xiaomi's
  dijun-v-oss origin. This audit does not label Onyx source official Myron code.
- Original GPL notices preserved; hashes of upstream and candidate files are
  in integration.json. myron-mca-interface.patch records all 20 changes.

Proven stock contracts
- Actual Myron mca_charge_interface.ko SHA256:
  b43cd47db4f537800ceaf3f0bd370eac7659436945b17bdf128ac0669d5fa572
- Exact export: mca_charge_if_ops_register. No aliases or module parameters.
- Dependencies: mca_log, mca_sysfs, mca_event.
- Stock AArch64 calls prove alternating setter/getter pairs in a 112-byte
  struct: set/get suspend @16/24, enable @32/40, input current @48/56,
  charge current @64/72, power @80/88, ship mode @96/104. Onyx grouped all
  setters before getters, which is incompatible. Header order now matches.
- All 19 charge type names and order match stock .rodata relocation strings.
- Stock callback after input_suspend writes emits type=2, event=16, NULL.
  Onyx shared MCA_EVENT_BATTERY_STS_CHANGE=17 is wrong for this consumer.
  Use an explicitly documented local Myron constant. Other shared IDs remain
  unaudited; no global enum renumbering or invented event mapping was made.
- disassembly/ and audit.json preserve the exact instruction offsets.

Other fixes
- Bounds-check ops index and common setter type.
- Validate kstrtouint before invoking setters; return real callback errors.
- Bound every write, including shipmode, before copying. Explicit token widths.
- Bound and initialize sysfs output; terminate callback strings within128bytes.
- Handle absent buck backend when reading shipmode; avoid strlen-2 underflow.
- platform_driver.remove uses void (verified primary Linux v6.12 header).
  Exact ACK pinned header retrieval was unavailable, so target CI compilation
  remains required.

Meaningful host verification (not a kernel or phone test)
- tests/run_charge_interface.py compiles the actual complete candidate C and
  header against host kernel-service mocks with -Wall -Wextra -Werror plus
  ASan and UBSan. 16,789 checks, 15 stock ABI assertions, 8,193 input lengths.
- Tests check callback dispatch, all charge types, integer parse failures,
  backend errors, absent buck backend, nonterminated callback output, sysfs
  buffer initialization, bounded writes, and exact stock notification16.
- Restoring the old header causes stock offset assertion failure; restoring
  the unchecked shipmode branch causes bounded-input rejection failure.
- All 21 stock strong import names have providers in actual run10 symvers or
  the seven r6 foundational candidates (name check, not stock ABI approval).
- Target CI must build the module and require exact exports, all strong import
  CRCs, dependencies and parameters. No claim that target build has run.

Deferred modules (audit.json)
- mca_charge_mievent: stock table61 records, Onyx50. Indexed API cannot be
  safely assumed equivalent. Do not silently relabel charging faults.
- mca_qcom_panel: stock events58/59 vs Onyx62/63, and pinned QCOM notifier
  header has no HBM events. Do not invent HBM IDs or claim support.
- mca_qcom_smem: Myron shared-memory item/record layout not yet proven.
- mca_adsp_glink: Myron firmware wire opcodes/layout not yet proven.

Remaining limitations
The registry has no unregister interface. Backend lifetime and concurrency,
complete event mapping, userspace compatibility, target kernel ABI and hardware
behavior require later validation. Callback writers must honor the existing
128-byte output contract. This candidate does not implement charging hardware
or alter voltage/current/thermal thresholds. flashable=false.

Review follow-up: required r7 sysfs rollback overlay
- Independent review found r6 mca_sysfs_create_link_group could retain the
  freshly registered sysfs group if creating its symlink failed. A failed
  charge-interface probe will not receive a remove callback.
- sysfs-overlay/drivers/payload contains the minimally changed existing
  mca_sysfs.c. Copy this overlay too; r6 files are untouched.
- sysfs-overlay.json contains the root source-lock write entry, prior/new
  candidate SHA256 values and exact patch. Existing source provenance remains
  valid; exports and dependencies are unchanged.
- On second-stage failure the helper removes only its newly created group.
  It does not remove any group if first-stage creation failed and does not
  remove a preexisting symlink when link creation reports EEXIST.
- tests/run_sysfs_rollback.py runs the actual create/remove helper bodies with
  ASan/UBSan and53 checks: success/teardown, four errno failures at both stages,
  existing group/link preservation, invalid/missing prerequisites.
- The unmodified r6 helper fails the same tests. This supplements the common
  interface test's sysfs mocks; it does not prove real kernel runtime lifetime.
