// SPDX-License-Identifier: GPL-2.0
/*
 * mca_hwid.c
 *
 * get hwid infomation interface for power module
 *
 * Copyright (c) 2024-2024 Xiaomi Technologies Co., Ltd.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 */
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <mca/common/mca_hwid.h>
#include <mca/common/mca_log.h>
#include <hwid.h>

#ifndef MCA_LOG_TAG
#define MCA_LOG_TAG "mca_hwid"
#endif

static struct mca_hwid *phwid;
static DEFINE_MUTEX(hwid_lock);

const struct mca_hwid *mca_get_hwid_info(void)
{
	struct mca_hwid *info;

	mutex_lock(&hwid_lock);
	info = phwid;
	if (!info) {
		info = kzalloc(sizeof(*info), GFP_KERNEL);
		if (!info) {
			mca_log_err("kzalloc phwid failed\n");
			goto out;
		}
		info->platform_version = get_hw_version_platform();
		info->country_version = get_hw_country_version();
		info->major_version = get_hw_version_major();
		info->minor_version = get_hw_version_minor();
		info->build_version = get_hw_version_build();
		info->product_adc = get_hw_project_adc();
		info->build_adc = get_hw_build_adc();
		info->hwid_value = get_hw_id_value();
		info->product_name = product_name_get();
		/* Publish only a complete record, under the same lock as readers. */
		phwid = info;
		mca_log_info(
			"platform_version: %d, country_version: %d, major_version: %d, minor_version: %d, build_version: %d",
			info->platform_version, info->country_version,
			info->major_version, info->minor_version,
			info->build_version);
	}
out:
	mutex_unlock(&hwid_lock);
	return info;
}
EXPORT_SYMBOL(mca_get_hwid_info);

MODULE_DESCRIPTION("mca get hwid info");
MODULE_AUTHOR("wangyun5@xiaomi.com");
MODULE_LICENSE("GPL v2");
