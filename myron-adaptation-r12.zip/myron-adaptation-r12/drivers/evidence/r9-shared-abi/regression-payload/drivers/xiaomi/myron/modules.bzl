# SPDX-License-Identifier: GPL-2.0-only
# Myron experimental source modules. Loaded in the SoC root Bazel package.
def register_modules(registry):
    registry.register(
        name = "drivers/input/fingerprint/mi_fp",
        out = "mi_fp.ko",
        config = "CONFIG_FINGERPRINT_MI_FP",
        srcs = [
            "drivers/input/fingerprint/mi_fp/fp_driver.c",
            "drivers/input/fingerprint/mi_fp/fp_platform.c",
            "drivers/input/fingerprint/mi_fp/fp_netlink.c",
            "drivers/input/fingerprint/mi_fp/fp_input.c",
            "drivers/input/fingerprint/mi_fp/fp_driver.h",
            "drivers/input/fingerprint/mi_fp/fp_ultra.h",
        ],
        deps = ["drivers/soc/qcom/panel_event_notifier"],
    )
    registry.register(
        name = "drivers/xiaomi/mi_stack",
        out = "mi_stack.ko",
        config = "CONFIG_MI_STACK",
        srcs = ["drivers/xiaomi/mi_stack/mi_stack.c"],
    )
    registry.register(
        name = "drivers/xiaomi/mi_ubt",
        out = "mi_ubt.ko",
        config = "CONFIG_MI_UBT",
        srcs = ["drivers/xiaomi/mi_ubt/mi_ubt.c"],
    )
    registry.register(
        name = "drivers/xiaomi/printk_enhance",
        out = "printk_enhance.ko",
        config = "CONFIG_PRINTK_ENHANCE",
        srcs = ["drivers/xiaomi/printk_enhance/printk_enhance.c"],
    )
    registry.register(
        name = "drivers/misc/hwid/hwid",
        out = "hwid.ko",
        config = "CONFIG_MI_HARDWARE_ID",
        srcs = [
            "drivers/misc/hwid/hwid.c",
            "drivers/misc/hwid/hwid.h",
            "include/soc/qcom/socinfo.h",
        ],
        includes = ["include"],
        deps = ["drivers/soc/qcom/socinfo"],
    )
    registry.register(
        name = "drivers/misc/miev/miev",
        out = "miev.ko",
        config = "CONFIG_MIEV",
        srcs = [
            "drivers/misc/miev/midevice.c",
            "drivers/misc/miev/midevice.h",
            "drivers/misc/miev/mievent.c",
            "include/miev/mievent.h",
        ],
        includes = ["include"],
    )
    registry.register(
        name = "drivers/input/touchscreen/xiaomi/xiaomi_touch",
        out = "xiaomi_touch.ko",
        config = "CONFIG_TOUCHSCREEN_XIAOMI_TOUCHFEATURE",
        srcs = [
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_core.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_device.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_evdev.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_knock_data.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_mode.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_operations.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_proc.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_sys.c",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch.h",
            "drivers/input/touchscreen/xiaomi/xiaomi_touch_type_common.h",
            "include/linux/soc/qcom/panel_event_notifier.h",
            "include/miev/mievent.h",
        ],
        includes = [
            "include",
        ],
        deps = [
            "drivers/soc/qcom/panel_event_notifier",
            "drivers/misc/miev/miev",
        ],
        copts = [
            "-DTOUCH_THP_SUPPORT",
            "-DTOUCH_FOD_SUPPORT",
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_sysfs",
        out = "mca_sysfs.ko",
        config = "CONFIG_MYRON_MCA_BASE",
        srcs = [
            "drivers/power/supply/mca/mca_common/mca_sysfs.c",
            "drivers/power/supply/mca/include/mca/common/mca_sysfs.h",
        ],
        includes = [
            "drivers/power/supply/mca/include",
        ],
        deps = [
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_event",
        out = "mca_event.ko",
        config = "CONFIG_MYRON_MCA_BASE",
        srcs = [
            "drivers/power/supply/mca/mca_common/mca_event.c",
            "drivers/power/supply/mca/include/mca/common/mca_sysfs.h",
            "drivers/power/supply/mca/include/mca/common/mca_event.h",
        ],
        includes = [
            "drivers/power/supply/mca/include",
        ],
        deps = [
            "drivers/power/supply/mca/mca_common/mca_sysfs",
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_log",
        out = "mca_log.ko",
        config = "CONFIG_MYRON_MCA_BASE",
        srcs = [
            "drivers/power/supply/mca/mca_common/mca_log.c",
            "drivers/power/supply/mca/include/mca/common/mca_sysfs.h",
            "drivers/power/supply/mca/include/mca/common/mca_event.h",
            "drivers/power/supply/mca/include/mca/common/mca_log.h",
        ],
        includes = [
            "drivers/power/supply/mca/include",
        ],
        deps = [
            "drivers/power/supply/mca/mca_common/mca_event",
            "drivers/power/supply/mca/mca_common/mca_sysfs",
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_parse_dts",
        out = "mca_parse_dts.ko",
        config = "CONFIG_MYRON_MCA_BASE",
        srcs = [
            "drivers/power/supply/mca/mca_common/mca_parse_dts.c",
            "drivers/power/supply/mca/include/mca/common/mca_log.h",
            "drivers/power/supply/mca/include/mca/common/mca_parse_dts.h",
        ],
        includes = [
            "drivers/power/supply/mca/include",
        ],
        deps = [
            "drivers/power/supply/mca/mca_common/mca_log",
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_voter",
        out = "mca_voter.ko",
        config = "CONFIG_MYRON_MCA_BASE",
        srcs = [
            "drivers/power/supply/mca/mca_common/mca_voter.c",
            "drivers/power/supply/mca/include/mca/common/mca_log.h",
            "drivers/power/supply/mca/include/mca/common/mca_voter.h",
        ],
        includes = [
            "drivers/power/supply/mca/include",
        ],
        deps = [
            "drivers/power/supply/mca/mca_common/mca_log",
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_workqueue",
        out = "mca_workqueue.ko",
        config = "CONFIG_MYRON_MCA_BASE",
        srcs = [
            "drivers/power/supply/mca/mca_common/mca_workqueue.c",
            "drivers/power/supply/mca/include/mca/common/mca_log.h",
        ],
        includes = [
            "drivers/power/supply/mca/include",
        ],
        deps = [
            "drivers/power/supply/mca/mca_common/mca_log",
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_hwid",
        out = "mca_hwid.ko",
        config = "CONFIG_MYRON_MCA_BASE",
        srcs = [
            "drivers/power/supply/mca/mca_common/mca_hwid.c",
            "drivers/power/supply/mca/include/mca/common/mca_hwid.h",
            "drivers/power/supply/mca/include/mca/common/mca_log.h",
            "drivers/misc/hwid/hwid.h",
        ],
        includes = [
            "drivers/power/supply/mca/include",
            "drivers/misc/hwid",
        ],
        deps = [
            "drivers/misc/hwid/hwid",
            "drivers/power/supply/mca/mca_common/mca_log",
        ],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_common/mca_charge_interface",
        out = "mca_charge_interface.ko",
        config = "CONFIG_MYRON_MCA_INTERFACE",
        srcs = ["drivers/power/supply/mca/mca_common/mca_charge_interface.c", "drivers/power/supply/mca/include/mca/common/mca_charge_interface.h", "drivers/power/supply/mca/include/mca/common/mca_log.h", "drivers/power/supply/mca/include/mca/common/mca_sysfs.h", "drivers/power/supply/mca/include/mca/common/mca_event.h"],
        includes = ["drivers/power/supply/mca/include"],
        deps = ["drivers/power/supply/mca/mca_common/mca_log", "drivers/power/supply/mca/mca_common/mca_sysfs", "drivers/power/supply/mca/mca_common/mca_event"],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_protocol/mca_protocol_class",
        out = "mca_protocol_class.ko",
        config = "CONFIG_MYRON_MCA_PLATFORM",
        srcs = ["drivers/power/supply/mca/mca_protocol/mca_protocol_class.c", "drivers/power/supply/mca/include/mca/protocol/protocol_class.h"],
        includes = ["drivers/power/supply/mca/include"],
        deps = [],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_protocol/protocol_qc/mca_protocol_qc_class",
        out = "mca_protocol_qc_class.ko",
        config = "CONFIG_MYRON_MCA_PLATFORM",
        srcs = ["drivers/power/supply/mca/mca_protocol/protocol_qc/mca_protocol_qc_class.c", "drivers/power/supply/mca/include/mca/common/mca_event.h", "drivers/power/supply/mca/include/mca/common/mca_log.h", "drivers/power/supply/mca/include/mca/protocol/protocol_qc_class.h", "drivers/power/supply/mca/include/mca/protocol/protocol_class.h"],
        includes = ["drivers/power/supply/mca/include"],
        deps = ["drivers/power/supply/mca/mca_protocol/mca_protocol_class"],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_platform/mca_platform_loadsw_class",
        out = "mca_platform_loadsw_class.ko",
        config = "CONFIG_MYRON_MCA_PLATFORM",
        srcs = ["drivers/power/supply/mca/mca_platform/mca_platform_loadsw_class.c", "drivers/power/supply/mca/include/mca/platform/platform_loadsw_class.h", "drivers/power/supply/mca/include/mca/common/mca_log.h", "drivers/power/supply/mca/include/mca/common/mca_parse_dts.h", "drivers/power/supply/mca/include/mca/common/mca_sysfs.h"],
        includes = ["drivers/power/supply/mca/include"],
        deps = ["drivers/power/supply/mca/mca_common/mca_sysfs", "drivers/power/supply/mca/mca_common/mca_log", "drivers/power/supply/mca/mca_common/mca_parse_dts"],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_platform/mca_platform_cp_class",
        out = "mca_platform_cp_class.ko",
        config = "CONFIG_MYRON_MCA_PLATFORM",
        srcs = ["drivers/power/supply/mca/mca_platform/mca_platform_cp_class.c", "drivers/power/supply/mca/include/mca/platform/platform_cp_class.h", "drivers/power/supply/mca/include/mca/common/mca_log.h", "drivers/power/supply/mca/include/mca/common/mca_parse_dts.h", "drivers/power/supply/mca/include/mca/common/mca_sysfs.h"],
        includes = ["drivers/power/supply/mca/include"],
        deps = ["drivers/power/supply/mca/mca_common/mca_sysfs", "drivers/power/supply/mca/mca_common/mca_log", "drivers/power/supply/mca/mca_common/mca_parse_dts"],
    )
    registry.register(
        name = "drivers/power/supply/mca/mca_platform/mca_platform_buckchg_class",
        out = "mca_platform_buckchg_class.ko",
        config = "CONFIG_MYRON_MCA_PLATFORM",
        srcs = ["drivers/power/supply/mca/mca_platform/mca_platform_buckchg_class.c", "drivers/power/supply/mca/include/mca/platform/platform_buckchg_class.h"],
        includes = ["drivers/power/supply/mca/include"],
        deps = [],
    )
