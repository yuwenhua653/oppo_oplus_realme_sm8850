#!/usr/bin/env python3
"""Reproduce bounded PD/BC12/charger partition source preflight evidence."""
from pathlib import Path
import json, hashlib, re

ROOT = Path(__file__).resolve().parent
BASE = 'drivers/power/supply/mca/'
paths = {
    'pd': BASE + 'mca_protocol/protocol_pd/mca_protocol_pd_class.c',
    'bc12': BASE + 'mca_platform/mca_platform_bc12_class.c',
    'partition': BASE + 'mca_shared_memory/charger_partition.c',
}
text = {k: (ROOT/'upstream'/v).read_text() for k,v in paths.items()}

def evidence(key, literal):
    data = text[key]
    assert literal in data, (key,literal)
    return {'path': paths[key], 'line': data[:data.index(literal)].count('\n')+1,
            'source': literal}

provenance = json.loads((ROOT/'provenance.json').read_text())
for p in provenance:
    b = (ROOT/'upstream'/p['path']).read_bytes()
    assert hashlib.sha256(b).hexdigest() == p['sha256']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest() == p['blob_sha1']

findings = [
    {'id':'pd-storage-dependency', 'result':'blocker',
     'finding':'PD PPS max-power calculation directly consumes charger_partition_get_eu_model; the current r7 source build has no charger_partition implementation.',
     'evidence':[evidence('pd','charger_partition_get_eu_model(&is_eu_model);')]},
    {'id':'pd-policy', 'result':'unverified_device_semantics',
     'finding':'PD contains power-bucket policy, country-mode behavior, advertised current and voltage thresholds. Generic protocol wrappers being ABI compatible does not prove this policy matches Myron.',
     'evidence':[evidence('pd','if (is_eu_model && type == XM_CHARGER_TYPE_PD_VERIFY)'),
                 evidence('pd','if ((power >= 96 && adv_curr == 4800) || (power >= 96 && adv_curr == 5000))'),
                 evidence('pd','pwr_cap.cap[i].max_voltage >= 11001)')]},
    {'id':'pd-empty-implementations', 'result':'inherited_in_stock_see_stock_audit',
     'finding':'Pinned PD source contains two success-returning empty adapter implementations. Fresh stock ELF comparison in stock-audit.json confirms stock has the same two-instruction bodies: these are not an Onyx-only defect and are not a standalone blocker, while neither body implements adapter information or max-power calculation.',
     'evidence':[evidence('pd','static int protocol_class_pd_get_max_power(void *data, unsigned int *max_power)\n{\n\treturn 0;\n}'),
                 evidence('pd','static int protocol_class_pd_get_adapter_info(void *data, struct adapter_vendor_info *info)\n{\n\treturn 0;\n}')]},
    {'id':'pd-multiport', 'result':'unverified_device_semantics',
     'finding':'The pinned PD source always chooses port zero before its port-scan loop. Myron behavior must be checked before changing or accepting this.',
     'evidence':[evidence('pd','static unsigned int protocol_pd_update_port_num(void)\n{\n\tint snk_src_mode = TYPEC_UNATTACH;\n\tint i;\n\treturn 0;')]},
    {'id':'bc12-pd-dependency', 'result':'blocker',
     'finding':'BC12 has a strong PD symbol dependency; suppressing multiport at runtime does not remove its ELF import. No fake PD provider or unsupported split is supplied.',
     'evidence':[evidence('bc12','(void)protocol_class_pd_get_pd_active(TYPEC_PORT_1, &pd_active);')]},
    {'id':'partition-writes-on-probe', 'result':'blocker',
     'finding':'charger_partition is an active storage driver. Scheduled probe work can rewrite the partition header and later reset info_1; it is not a harmless read-only EU-mode helper.',
     'evidence':[evidence('partition','cdb[0] = WRITE_10;'),
                 evidence('partition','header->initialized = 1;\n\theader->avaliable = 1;'),
                 evidence('partition','charger_partition_get_info_1();\n\tcharger_partition_set_info_1();\n\tcharger_partition_get_info_1();'),
                 evidence('partition','schedule_delayed_work(&charger_partition->charger_partition_work, 0);')]},
    {'id':'partition-layout', 'result':'unverified_device_semantics',
     'finding':'The pinned source picks partition number 25 only for platform version 9, otherwise 22; it validates the charger volume name but storage layout, format and firmware ownership still need a Myron-specific contract.',
     'evidence':[evidence('partition','#define CHARGER_PART_NUMBER_V9 25'),
                 evidence('partition','#define CHARGER_PART_NUMBER_DEFAULT 22'),
                 evidence('partition','if (strncmp(part->bd_meta_info->volname, "charger",') ]},
    {'id':'partition-unload', 'result':'source_defect',
     'finding':'The upstream partition remove path uses non-synchronous cancellation and kfree on a devm_kzalloc-owned object, while retaining a global pointer; a real integration needs lifetime fixes.',
     'evidence':[evidence('partition','charger_partition = devm_kzalloc('),
                 evidence('partition','cancel_delayed_work(&charger_partition->charger_partition_work);'),
                 evidence('partition','kfree(charger_partition);')]},
    {'id':'partition-strategy-dependency', 'result':'blocker',
     'finding':'Partition EU-mode read dispatches to mca_strategy_func_process, widening the source dependency closure beyond PD + BC12; event values and strategy behavior have not been validated.',
     'evidence':[evidence('partition','mca_strategy_func_process(STRATEGY_FUNC_TYPE_FG,')]},
]

report={
    'schema':1, 'stage':'r8', 'scope':'PD, BC12, charger partition bounded source feasibility review',
    'decision':'defer_all_three_no_candidate_installed',
    'upstream':{'repository':'unmoved21/android_kernel_xiaomi_onyx','commit':'8276ba954d8076303a5ae0f7b15d4092d66bdff6'},
    'sources_verified':len(provenance), 'source_provenance':'provenance.json',
    'source_exports':{k:sorted(set(re.findall(r'EXPORT_SYMBOL(?:_GPL)?\((\w+)\)',v))) for k,v in text.items()},
    'stock_evidence_status':'Fresh stock ELF comparison is in stock-audit.json; it supersedes source-only uncertainty for callback slots, PDO record size, empty helpers and partition dependency differences.',
    'stock_audit':'stock-audit.json',
    'r7_known_pd_missing_exports':['protocol_class_pd_get_support_keep_pdo'],
    'findings':findings,
    'prerequisites_for_integration':[
        'Compare PD callback offsets including get_support_keep_pdo with actual Myron stock ELF and real provider table.',
        'Validate adapter_power_cap, PDO/VDM data layouts and semantic values, including PPS policy against stock.',
        'Establish charger partition format, on-disk mutation semantics, block bounds, serialization and firmware/strategy ownership before including its active driver.',
        'Implement real provider lifecycle and probe failure unwind; remove/registration cannot leave callbacks or notifier references alive.',
        'Compile and validate full dependency closure with same-build symbol CRC checks before any device test.'
    ],
    'validation':{'source_git_blob_sha1_and_sha256':True,'target_build':False,'hardware_tested':False,'flashable':False},
}
(ROOT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'decision':report['decision'],'sources_verified':len(provenance),'findings':len(findings)}))
