#!/usr/bin/env python3
"""Produce ELF-backed contract differences; no candidate implementation emitted."""
from pathlib import Path
import json, re, hashlib

ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT/'stock-disassembly.json').read_text())
src=json.loads((ROOT/'audit.json').read_text())
pd=data['mca_protocol_pd_class']
part=data['charger_partition']
source=(ROOT/'upstream/drivers/power/supply/mca/mca_protocol/protocol_pd/mca_protocol_pd_class.c').read_text()
header=(ROOT/'upstream/drivers/power/supply/mca/include/mca/protocol/protocol_pd_class.h').read_text()
body=header.split('struct protocol_class_pd_ops {',1)[1].split('\n};',1)[0]
fields=re.findall(r'int \(\*(\w+)\)',body)

def ins(module, fn, offset):
    return next({'function':fn, 'section':module['functions'][fn]['section'], **i}
                for i in module['functions'][fn]['instructions'] if i['offset']==offset)

rows=[]
for name in pd['exports']:
    if name in ['protocol_class_pd_register_ops','protocol_class_pd_get_port_num']:
        continue
    f=pd['functions'][name]
    candidate=[]
    for i in f['instructions']:
        target='x8' if name=='protocol_class_pd_get_pdos' else 'x9'
        m=re.fullmatch(r'ldr\t('+target+r'), \[\1(?:, #(0x[0-9a-f]+|\d+))?\]',i['instruction'])
        if m and (name!='protocol_class_pd_get_pdos' or i['offset']==0x1520):
            candidate.append((i,int(m[2],0) if m[2] else 0))
    assert candidate,name
    i,off=candidate[0]
    # get_pdos is not a one-callback wrapper: its first indirect call is get_pdos,
    # followed by get_pd_verifed. Other exported dispatches have one matching ldr.
    if name=='protocol_class_pd_get_pdos':
        assert i['offset']==0x1520 and off==0x120
    else:
        assert len(candidate)==1,(name,candidate)
    block=re.search(r'\b'+name+r'\([^;]+?\n\{.*?\n\}',source,re.S)
    callback=re.search(r'temp_data->ops->(\w+)\(',block.group()) if block else None
    field=callback[1] if callback else None
    source_off=fields.index(field)*8 if field else None
    rows.append({'function':name,'source_callback':field,'source_offset':source_off,
                 'stock_offset':off,'source_matches_stock':source_off==off,
                 'evidence':ins(pd,name,i['offset'])})

assert len(rows)==51
delta={}
for source_key,stock_name in [('pd','mca_protocol_pd_class'),('bc12','mca_platform_bc12_class'),('partition','charger_partition')]:
    a=set(src['source_exports'][source_key]);b=set(data[stock_name]['exports'])
    delta[stock_name]={'missing_from_source':sorted(b-a),'extra_in_source':sorted(a-b)}

for name in ['protocol_class_pd_get_max_power','protocol_class_pd_get_adapter_info']:
    assert [x['instruction'] for x in pd['functions'][name]['instructions']]==['mov\tw0, wzr','ret\t']
assert 'charger_partition_get_eu_model' not in pd['imports']
assert 'protocol_class_pd_get_pd_active' in data['mca_platform_bc12_class']['imports']
assert 'scsi_execute_cmd' in part['imports']
assert 'mca_strategy_func_process' in part['imports']

report={
 'schema':1,
 'decision':'PD, BC12 and charger_partition remain deferred; no patch or candidate installed',
 'method':'pyelftools ELF symbols/relocations plus Capstone AArch64 instruction decoding; not a target execution test',
 'stock':{k:{'path':v['path'],'sha256':v['sha256'],'export_count':len(v['exports']),
             'imports':v['imports'],'depends':[x[8:] for x in v['modinfo'] if x.startswith('depends=')],
             'vermagic':[x[9:] for x in v['modinfo'] if x.startswith('vermagic=')]} for k,v in data.items()},
 'source_export_delta':delta,
 'pd_callback_slots':rows,
 'pd_callback_summary':{'stock_callbacks_examined':len(rows),
      'matching_source_offsets':sum(x['source_matches_stock'] for x in rows),
      'different_existing_source_offsets':sum(x['source_offset'] is not None and not x['source_matches_stock'] for x in rows),
      'stock_callbacks_absent_from_source':sum(x['source_offset'] is None for x in rows)},
 'pd_findings':[
  {'id':'stock-pd-no-partition-import','finding':'The stock PD module does not import charger_partition_get_eu_model or depend on charger_partition. That dependency belongs to the selected Onyx source and is not intrinsic to Myron PD.',
   'evidence':'Complete stock ELF imports and .modinfo depends are recorded above.'},
  {'id':'empty-functions-inherited','finding':'The two success-returning empty adapter helpers are present in stock too. They are not an Onyx-only regression or a standalone reason to reject matching stock behavior; they still do not implement adapter information or maximum-power calculation.',
   'evidence':{n:pd['functions'][n] for n in ['protocol_class_pd_get_max_power','protocol_class_pd_get_adapter_info']}},
  {'id':'callback-layout-mismatch','finding':'Stock moves get_has_dp to byte 240; request_vdm_cmd through get_pd_verifed are shifted by 8 bytes versus the source. Stock appends get_support_keep_pdo at byte 400. Adding an exported function alone would not repair the ABI.',
   'evidence':'pd_callback_slots contains all 51 callback load offsets.'},
  {'id':'pdo-layout-mismatch','finding':'Stock get_pdos processes seven 16-byte records (112 bytes), reads a discriminator at offset 12 and branches on 0/3. Source struct pd_pdo contains only three int fields (12 bytes). The meaning/name of the fourth field is not asserted without provider/header evidence.',
   'evidence':[ins(pd,'protocol_class_pd_get_pdos',x) for x in [0x1568,0x1598,0x15a4,0x15bc,0x15c4,0x1674]]},
  {'id':'pdo-policy-mismatch','finding':'Stock get_pdos is 1044 bytes and filters/transforms provider records, including an offset-8 value update after consulting get_pd_verifed. The selected public implementation is a direct callback forwarding wrapper. Restoring this behavior requires verified provider/data semantics.',
   'evidence':[ins(pd,'protocol_class_pd_get_pdos',x) for x in [0x1520,0x15dc,0x15fc,0x1610,0x1620,0x165c]]},
  {'id':'multiport-difference','finding':'Stock notifier evaluates the sink/source callback at byte 360 for both port records and can select port 1. Source protocol_pd_update_port_num returns zero before scanning, so that simplification is not stock equivalent.',
   'evidence':[ins(pd,'protocol_pd_notify_cb',x) for x in [0x3700,0x374c,0x378c,0x37a0,0x37ac]]},
 ],
 'bc12_findings':[
  {'finding':'Its one export and two callback offsets match source; it still imports real PD get_pd_active and requires correct lifecycle cleanup before inclusion.',
   'callback_slots':[
      {'source_field':'bc12_det_en','stock_offset':0,'evidence':ins(data['mca_platform_bc12_class'],'platform_class_bc12_det_en',0x188)},
      {'source_field':'get_charge_type','stock_offset':8,'evidence':ins(data['mca_platform_bc12_class'],'platform_class_bc12_get_real_type',0x264)}
   ]}
 ],
 'partition_findings':[
  {'id':'real-storage-writes','finding':'Stock itself constructs SCSI opcode 0x2a (WRITE_10), supplies a 4096-byte buffer and calls scsi_execute_cmd. This confirms active storage semantics rather than a harmless data-only dependency.',
   'evidence':[ins(part,'charger_scsi_write_partition',x) for x in [0x478,0x484,0x4b0,0x4d8]]},
  {'id':'header-rewrite','finding':'Stock header validation writes initialized/available words and calls charger_scsi_write_partition. Work invokes header validation after locating the charger partition.',
   'evidence':[ins(part,'check_charger_partition_header',x) for x in [0xf18,0xf24,0xf30]]+[ins(part,'charger_partition_work',0x18d8)]},
  {'id':'partition-index-difference','finding':'Stock work initializes partition index to 25 unconditionally. The selected public source conditionally chooses 25 for platform version 9 and 22 otherwise; a Myron port must account for this difference.',
   'evidence':[ins(part,'charger_partition_work',x) for x in [0x1820,0x1838]]},
  {'id':'dependency-closure','finding':'The actual stock module imports mca_strategy_func_process and mca_event_block_notify alongside SCSI APIs; using this full module requires strategy/event contract and storage ownership validation.',
   'evidence':'Complete stock ELF imports and .modinfo depends are recorded above.'},
  {'id':'missing-exports','finding':'The selected source also lacks stock batt_emerg_sn read/write and write_eu_model exports.',
   'evidence':delta['charger_partition']},
 ],
 'validation':{'stock_sha256_recomputed':True,'all_51_pd_callback_offsets_recorded':True,
               'candidate_written':False,'target_compiled':False,'hardware_tested':False,'flashable':False},
}
for v in data.values():
 assert hashlib.sha256(Path(v['path']).read_bytes()).hexdigest()==v['sha256']
(ROOT/'stock-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'callbacks':report['pd_callback_summary'],'stock_modules':len(data),'decision':report['decision']},indent=2))
