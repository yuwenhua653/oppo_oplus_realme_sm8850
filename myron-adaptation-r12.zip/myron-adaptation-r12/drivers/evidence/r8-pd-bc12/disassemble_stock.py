#!/usr/bin/env python3
from pathlib import Path
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN
import json, hashlib

ROOT=Path(__file__).resolve().parent
STOCK=ROOT.parents[2]/'myron-stock/modules/modules'
names=['mca_protocol_pd_class','mca_platform_bc12_class','charger_partition']
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
records={}
for name in names:
 p=STOCK/(name+'.ko')
 with p.open('rb') as f:
  elf=ELFFile(f); syms=elf.get_section_by_name('.symtab')
  relocs={}
  for sec in elf.iter_sections():
   if isinstance(sec,RelocationSection):
    rsym=elf.get_section(sec['sh_link'])
    for rel in sec.iter_relocations():
     relocs[(sec['sh_info'],rel['r_offset'])]=rsym.get_symbol(rel['r_info_sym']).name
  funcs={}
  for sym in syms.iter_symbols():
   if sym['st_info']['type']!='STT_FUNC' or not isinstance(sym['st_shndx'],int):continue
   sec=elf.get_section(sym['st_shndx']); off=sym['st_value'];size=sym['st_size']
   instr=[]
   for ins in md.disasm(sec.data()[off:off+size],off):
    item={'offset':ins.address,'instruction':f'{ins.mnemonic}\t{ins.op_str}'}
    r=relocs.get((sym['st_shndx'],ins.address))
    if r:item['relocation']=r
    instr.append(item)
   funcs[sym.name]={'section':sec.name,'offset':off,'size':size,'instructions':instr}
  exports=sorted({s.name[len('__ksymtab_'):] for s in syms.iter_symbols() if s.name.startswith('__ksymtab_') and s['st_info']['type']!='STT_SECTION'})
  imports=sorted({s.name for s in syms.iter_symbols() if s['st_shndx']=='SHN_UNDEF' and s.name and s['st_info']['bind']!='STB_WEAK'})
  mod=elf.get_section_by_name('.modinfo').data().decode().split('\0')
  record={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'exports':exports,'imports':imports,'modinfo':mod,'functions':funcs}
  records[name]=record
  (ROOT/(name+'.disasm.txt')).write_text('\n\n'.join(f"{k} ({v['section']}+0x{v['offset']:x}, size {v['size']}):\n"+'\n'.join(f"  {i['offset']:08x}: {i['instruction']}"+(' ; '+i['relocation'] if i.get('relocation') else '') for i in v['instructions']) for k,v in funcs.items())+'\n')
(ROOT/'stock-disassembly.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({k:{'sha256':v['sha256'],'exports':len(v['exports']),'imports':len(v['imports']),'functions':len(v['functions'])} for k,v in records.items()},indent=2))
