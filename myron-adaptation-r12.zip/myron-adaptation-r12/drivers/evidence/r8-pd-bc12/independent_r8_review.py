#!/usr/bin/env python3
"""Independent stock-byte -> candidate header/wrapper check (no generated expected header)."""
from pathlib import Path
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN
import hashlib,json,re

ROOT=Path(__file__).resolve().parent
REV=ROOT.parent
STOCK=ROOT.parents[2]/'myron-stock/modules/modules'
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)

def get_functions(path):
 with path.open('rb') as f:
  e=ELFFile(f); out={}
  for s in e.get_section_by_name('.symtab').iter_symbols():
   if s['st_info']['type']=='STT_FUNC' and isinstance(s['st_shndx'],int):
    sec=e.get_section(s['st_shndx']);a=s['st_value'];b=a+s['st_size']
    out[s.name]=[{'address':i.address,'mnemonic':i.mnemonic,'args':i.op_str} for i in md.disasm(sec.data()[a:b],a)]
  return out

def stock_call_info(ins):
 calls=[i for i,x in enumerate(ins) if x['mnemonic']=='blr']
 if len(calls)!=1:return None
 end=calls[0];reg=ins[end]['args'];load=[]
 for x in ins[:end]:
  m=re.fullmatch(reg+r', \['+reg+r'(?:, #(0x[0-9a-f]+|\d+))?\]',x['args'])
  if x['mnemonic']=='ldr' and m:load.append((x,int(m[1],0) if m[1] else 0))
 if not load:return None
 item,slot=load[-1];cfi=0
 for x in ins[:end]:
  m=re.fullmatch(r'w17, #(0x[0-9a-f]+|\d+)(?:, lsl #(\d+))?',x['args'])
  if x['mnemonic']=='movk' and m:cfi|=int(m[1],0) << int(m[2] or 0)
 return {'slot':slot,'cfi':hex(cfi),'callback_load':item,'call':ins[end],
         'argument_instructions':[x for x in ins if item['address']<x['address']<ins[end]['address']]}

results={}
for label,sub,mod,struct in [
 ('buck','buck-base','mca_platform_buckchg_class','platform_class_buckchg_ops'),
 ('cp','cp-fg','mca_platform_cp_class','platform_class_cp_ops')]:
 root=REV/sub; c=root/f'candidate/drivers/power/supply/mca/mca_platform/{mod}.c'
 h=root/f'candidate/drivers/power/supply/mca/include/mca/platform/{"platform_buckchg_class" if label=="buck" else "platform_cp_class"}.h'
 content=c.read_text();header=h.read_text();sf=STOCK/(mod+'.ko')
 head=header.split('struct '+struct+' {',1)[1].split('\n};',1)[0]
 fields=re.findall(r'int \(\*(\w+)\)\(([^;]*)\);',head)
 lookup={n:{'offset':idx*8,'signature':' '.join(sig.split())} for idx,(n,sig) in enumerate(fields)}
 funcs=get_functions(sf); rows=[]; errors=[]
 for m in re.finditer(r'^(?:extern )?int (\w+)\(([^;]*?)\)\n\{(.*?)^\}',content,re.M|re.S):
  name,params,body=m.groups()
  if name not in funcs:continue
  stock=stock_call_info(funcs[name])
  if not stock:continue
  if name=='platform_class_cp_set_fsw':
   assert 'ret = platform_cp_set_fsw_locked(role, fsw);' in body
   assert 'mutex_lock(&platform_cp_dev_lock);' in body and 'mutex_unlock(&platform_cp_dev_lock);' in body
   body=re.search(r'^static int platform_cp_set_fsw_locked\([^;]*?\)\n\{(.*?)^\}',content,re.M|re.S)[1]
  cb=re.findall(r'temp_data->ops->(\w+)\((.*?)\)',body,re.S)
  if len(cb)!=1:
   errors.append({'function':name,'error':'expected one identifiable callback forwarding call','callbacks':cb});continue
  field,args=cb[0];args=re.sub(r'\s+','',args);ent=lookup[field]
  names=[re.search(r'(\w+)\s*$',p)[1] for p in params.split(',')]
  forwarded=names[1:]
  expected_args=','.join(['temp_data->data']+forwarded if label=='buck' else forwarded+['temp_data->data'])
  row={'function':name,'field':field,'candidate_signature':ent['signature'],
       'candidate_offset':ent['offset'],'forwarded_arguments':args,'stock':stock,
       'offset_match':ent['offset']==stock['slot'],
       'all_caller_arguments_forwarded_in_order':args==expected_args}
  if not row['offset_match']:errors.append({'function':name,'error':'callback offset mismatch'})
  if args!=expected_args:errors.append({'function':name,'error':'forwarding differs from full caller arguments plus provider data','expected':expected_args,'actual':args})
  rows.append(row)
 # Type anchors are existing pinned public callback signatures, checked against
 # their separately decoded stock call-site fingerprints, not the new headers.
 anchors=({'void *data':'platform_class_buckchg_ops_is_init_ok',
           'void *data, int':'platform_class_buckchg_ops_set_input_curr_lmt',
           'void *data, int *':'platform_class_buckchg_ops_get_online',
           'void *data, bool':'platform_class_buckchg_ops_set_hiz',
           'void *data, bool *':'platform_class_buckchg_ops_is_charge_done'} if label=='buck' else
          {'bool, void *data':'platform_class_cp_set_charging_enable',
           'bool *, void *data':'platform_class_cp_get_charging_enabled',
           'u32 *, void *data':'platform_class_cp_get_battery_voltage',
           'int *, void *data':'platform_class_cp_get_bus_temperature',
           'int, void *data':'platform_class_cp_set_mode',
           'void *data':'platform_class_cp_dump_register',
           'int, bool *, void *data':'platform_class_cp_get_int_stat',
           'int, bool, void *data':'platform_class_cp_enable_ovpgate_with_check'})
 cfi_anchors={sig:{'function':fn,'cfi':stock_call_info(funcs[fn])['cfi']} for sig,fn in anchors.items()}
 upstream_header=root/'upstream'/h.relative_to(root/'candidate')
 ubody=upstream_header.read_text().split('struct '+struct+' {',1)[1].split('\n};',1)[0]
 ufields={n:' '.join(sig.split()) for n,sig in re.findall(r'int \(\*(\w+)\)\(([^;]*)\);',ubody)}
 by_function={x['function']:x for x in rows}
 for sig,fn in anchors.items():
  field=by_function[fn]['field']; assert ufields[field]==sig,(fn,ufields[field],sig)
  cfi_anchors[sig]['pinned_upstream_field']=field
  cfi_anchors[sig]['pinned_upstream_signature']=ufields[field]
 for row in rows:
  sig=row['candidate_signature']; row['type_cfi_match']=row['stock']['cfi']==cfi_anchors[sig]['cfi']
  if not row['type_cfi_match']:errors.append({'function':row['function'],'error':'signature CFI differs from known source anchor'})
 results[label]={'stock_sha256':hashlib.sha256(sf.read_bytes()).hexdigest(),
   'candidate_c_sha256':hashlib.sha256(c.read_bytes()).hexdigest(),
   'candidate_header_sha256':hashlib.sha256(h.read_bytes()).hexdigest(),
   'header_callback_count':len(fields),'rows_checked':len(rows),'rows':rows,'errors':errors,'cfi_anchors':cfi_anchors,
   'method':'Read stock ELF function bytes directly; locate indirect-branch register, trace its last self-relative LDR and decode KCFI immediates. Compare with independently parsed actual candidate header order and actual wrapper forwarding expression.'}

report={'schema':1,'scope':'Independent r8 buck/CP ABI and wrapper review',
        'status':'pass_no_new_blocking_findings','modules':results,
        'findings':[
          {'severity':'informational','module':'buck','finding':'All 89 stock callback byte offsets, KCFI type equivalence classes and full caller argument forwarding match the candidate. Eight new wrappers forward to real provider callbacks, without policy values or fake success bodies.'},
          {'severity':'informational','module':'buck','finding':'USB sense-voltage wrapper tests and dispatches get_usb_sns_volt itself. Registration publishes one immutable ops/data pair; replacement, matching unregister, mismatched unregister and module-exit drain SRCU before freeing detached entries. Existing provider API requires sleepable registration/unregistration outside a callback.'},
          {'severity':'informational','module':'cp','finding':'All 45 stock callback offsets and KCFI type classes match. New vout2out_uvp is bool-first/data-last and matches stock bool canonicalization. Existing u32* callbacks retain their distinct KCFI class from int* callbacks.'},
          {'severity':'nonblocking_scope_limit','module':'cp','finding':'Provider registration/lifetime still follows the public implementation; it is not SRCU protected like buck. This is explicitly deferred until real hardware provider integration, and is not evidence that hot provider replacement/unload is safe.'},
        ],
        'host_tests_independently_rerun':{
            'buck':{'exit_code':0,'runtime_assertions':1380,'abi_offset_assertions':89,'sanitizers':['address','undefined'],'notes':'pthread rwlock models the SRCU wait property; not a kernel SRCU stress test'},
            'cp':{'exit_code':0,'runtime_assertions':287,'abi_offset_assertions':45,'sanitizers':['undefined']}
        },
        'limitations':['A callback KCFI hash demonstrates type equivalence classes, not full firmware or hardware semantics.',
                       'Candidate host tests model kernel services; target build and hardware runtime remain separate gates.']}
(ROOT/'independent-r8-review.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(not x['errors'] for x in results.values()),'Independent ABI/forwarding failure'
print(json.dumps({k:{'callbacks':v['header_callback_count'],'rows_checked':v['rows_checked'],'errors':v['errors']} for k,v in results.items()},indent=2))
