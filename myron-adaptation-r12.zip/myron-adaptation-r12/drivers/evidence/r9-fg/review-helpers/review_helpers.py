#!/usr/bin/env python3
import pathlib,json,hashlib,struct,subprocess,tempfile,ctypes,re
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN
R=pathlib.Path(__file__).resolve().parent
H=R.parent.parent/'helpers'; P=H/'candidate'; stockdir=pathlib.Path('analysis/myron-stock/modules/modules')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
x=ctypes.CDLL('libxxhash.so.0');x.XXH64.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_uint64];x.XXH64.restype=ctypes.c_uint64
def prefix_hash(t):
 b=(t+'.normalized').encode();return x.XXH64(b,len(b),0)&0xffffffff
with (stockdir/'mca_charge_mievent.ko').open('rb') as f:
 e=ELFFile(f);symbols={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()}
 tables={}
 for name in ['g_charge_mievent_info','g_upload_type_plug_info','g_upload_type_time_info']:
  s=symbols[name];d=e.get_section(s['st_shndx']).data()[s['st_value']:s['st_value']+s['st_size']];tables[name]=d
 assert len(tables['g_charge_mievent_info'])==61*560
 assert len(tables['g_upload_type_plug_info'])==53*8
 assert len(tables['g_upload_type_time_info'])==8*16
 kcfi={}
 for name,mangle in [('mca_charge_mievent_report','_ZTSFvu3i32PvS_E'),('mca_charge_mievent_set_state','_ZTSFv24charge_mievent_state_eleu3i32E')]:
  s=symbols[name];d=e.get_section(s['st_shndx']).data();v=int.from_bytes(d[s['st_value']-4:s['st_value']],'little');assert v==prefix_hash(mangle);kcfi[name]=hex(v)
records=[]
for i in range(61):
 raw=tables['g_charge_mievent_info'][i*560:(i+1)*560];code=struct.unpack_from('<i',raw)[0]; upload,index,kind,count=struct.unpack_from('<4i',raw,64)
 assert upload in [0,1] and kind in [0,1,2]
 assert 0<=index<(53 if upload==0 else 8)
 assert 0<=count<=16
 for b in [raw[4:34],raw[34:64]]+[raw[80+k*30:110+k*30] for k in range(count)]: assert b'\0' in b
 records.append({'position':i,'event_code':code,'upload_type':upload,'type_index':index,'data_type':kind,'data_count':count})
# Compile the real candidate C and directly dump its arrays for byte comparison;
# expectations come only from this independent ELF decode, not owner's JSON.
probe='''#include "kernel_test.h"
#include "drivers/power/supply/mca/mca_common/mca_qcom_smem.c"
#include "drivers/power/supply/mca/mca_common/mca_charge_mievent.c"
int main(void) {
 fwrite(g_charge_mievent_info,sizeof(g_charge_mievent_info),1,stdout);
 fwrite(g_upload_type_plug_info,sizeof(g_upload_type_plug_info),1,stdout);
 fwrite(g_upload_type_time_info,sizeof(g_upload_type_time_info),1,stdout);
 return 0;
}
'''
with tempfile.TemporaryDirectory(prefix='helper-review-') as tmp:
 p=pathlib.Path(tmp);(p/'probe.c').write_text(probe)
 cc=['cc','-std=gnu11','-Wno-unused-function','-Wno-unused-variable','-I'+str(H/'tests/stubs'),'-I'+str(P),'-I'+str(P/'drivers/power/supply/mca/include'),str(p/'probe.c'),'-o',str(p/'probe')]
 subprocess.run(cc,check=True,capture_output=True)
 actual=subprocess.check_output([str(p/'probe')]);expected=b''.join(tables.values());assert actual==expected
 smemprobe='''#include "kernel_test.h"
#include "drivers/power/supply/mca/mca_common/mca_qcom_smem.c"
int main(void) {
 struct mca_smem_battery_info b={0};
 assert(sizeof(b)==36 && offsetof(struct mca_smem_battery_info,zero_speed_start_mode)==32);
 for (int error=-4095;error<0;error++) {
   alloc_result=-EEXIST;smem_pointer=ERR_PTR(error);smem_size=100;
   assert(mca_qcom_smem_init()==-EPROBE_DEFER);
   assert(mca_qcom_smem_is_zero_speed()==-ENODEV);
 }
 for (size_t n=0;n<36;n++) {
   smem_pointer=&b;smem_size=n;
   assert(mca_qcom_smem_init()==-EINVAL);
   assert(mca_qcom_smem_is_zero_speed()==-ENODEV);
 }
 smem_size=4096;assert(!mca_qcom_smem_init());
 b.zero_speed_start_mode=UINT32_MAX;assert(mca_qcom_smem_is_zero_speed()==-1);
 b.zero_speed_start_mode=0x80000000U;assert(mca_qcom_smem_is_zero_speed()==INT32_MIN);
 mca_qcom_smem_exit();assert(mca_qcom_smem_is_zero_speed()==-ENODEV);
 return 0;
}
'''
 (p/'probe.c').write_text(smemprobe);subprocess.run(cc,check=True,capture_output=True);subprocess.run([str(p/'probe')],check=True)
with (stockdir/'mca_qcom_smem.ko').open('rb') as f:
 e=ELFFile(f);symbols={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()};s=symbols['mca_qcom_smem_is_zero_speed'];d=e.get_section(s['st_shndx']).data();v=int.from_bytes(d[s['st_value']-4:s['st_value']],'little');assert v==prefix_hash('_ZTSFu3i32vE');kcfi[s.name]=hex(v)
 ins=list(md.disasm(d[s['st_value']:s['st_value']+s['st_size']],s['st_value']));assert any(i.mnemonic=='ldr' and i.op_str=='w0, [x8, #0x20]' for i in ins)
 s=symbols['init_module'];d=e.get_section(s['st_shndx']).data();ins=list(md.disasm(d[s['st_value']:s['st_value']+s['st_size']],s['st_value']));ops={i.op_str for i in ins if i.mnemonic=='mov'}
 assert {'w0, #-1','w1, #0x51','w2, #0x24'}<=ops
run=subprocess.run(['bash',str(H/'tests/run_helpers.sh'),str(P)],capture_output=True,text=True);assert run.returncode==0,run.stderr
(R/'host-review.log').write_text(run.stdout+run.stderr)
report={'schema':1,'reviewer':'r9_fg independent helper review','status':'pass_no_blocking_findings','candidate_files':[{'path':str(p.relative_to(H)),'sha256':sha(p)} for p in sorted(P.rglob('*')) if p.is_file()], 'stock_files':[{'path':str(stockdir/(n+'.ko')),'sha256':sha(stockdir/(n+'.ko'))} for n in ['mca_qcom_smem','mca_charge_mievent']], 'raw_table_bytes_equal':True,'mievent_record_count':61,'plug_rules':53,'timer_rules':8,'records':records,'public_kcfi':kcfi,'smem':{'stock_getter_offset':32,'stock_alloc_bytes':36,'host_any':True,'item_id':81,'error_pointer_values_tested':4095,'undersized_lengths_tested':36,'borrowed_mapping_not_freed':True,'full_word_values_preserved':True},'host_test_output':run.stdout.strip(),'intentional_hardening':['SMEM rejects NULL/error/short mappings before publication and never frees the borrowed qcom mapping.','Mievent locks rate-limit state and saturates counts instead of allowing integer overflow.','String inputs are bounded and NULL checked before event reservation; failures do not produce misleading partial events.','Transport callbacks execute after unlocking; accepted-event reservations are consumed even on allocation/transport failure, consistent with stock pre-transport accounting.'],'limits':['Host stubs do not establish target-kernel or real-hardware correctness.','Mievent time remains boottime; precise seconds versus stock coarse boottime may shift a rate-limit boundary by less than a coarse clock tick.','The scalar SMEM getter retains the signed int ABI; high-bit u32 values return corresponding negative bit patterns.'],'blocking_findings':[]}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS independent helper review: exact 61/53/8 raw tables; all 4095 ERR_PTR values; all 36 short lengths; stock SMEM offset/size and 3 public KCFI; '+run.stdout.strip())
