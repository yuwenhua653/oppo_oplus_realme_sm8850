#!/usr/bin/env python3
"""Independently decode stock ELF slots and compare the candidate ABI contract."""
import ctypes,hashlib,json,pathlib,re
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN
R=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('analysis/myron-stock/modules/modules')
rows=json.loads((R/'callback-contract.json').read_text())
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN)
x=ctypes.CDLL('libxxhash.so.0');x.XXH64.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_uint64];x.XXH64.restype=ctypes.c_uint64
def h(t):
 b=t.encode();return x.XXH64(b,len(b),0)&0xffffffff
with (S/'mca_platform_fg_ic_ops.ko').open('rb') as fp:
 e=ELFFile(fp);symbols={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()}
 exports=sorted(n.replace('__ksymtab_','') for n in symbols if n.startswith('__ksymtab_'))
 results=[]
 for r in rows:
  sym=symbols[r['name']];data=e.get_section(sym['st_shndx']).data();ins=list(md.disasm(data[sym['st_value']:sym['st_value']+sym['st_size']],sym['st_value']))
  assert ins[0].mnemonic=='cmp' and ins[0].op_str=='w0, #1'
  fields=[i for i in ins if i.mnemonic=='ldr' and re.fullmatch(r'x9, \[x9(?:, #(0x[0-9a-f]+|\d+))?\]',i.op_str)]
  assert len(fields)==1,(r['name'],fields)
  m=re.search(r'#([^]]+)',fields[0].op_str);slot=int(m[1],0) if m else 0;assert slot==r['slot']
  lo=next(i for i in ins if i.mnemonic=='movk' and i.op_str.startswith('w17, #') and 'lsl' not in i.op_str)
  hi=next(i for i in ins if i.mnemonic=='movk' and i.op_str.startswith('w17, #') and 'lsl #16' in i.op_str)
  kcfi=int(lo.op_str.split('#')[1],0)|(int(hi.op_str.split('#')[1].split(',')[0],0)<<16)
  assert kcfi==int(r['kcfi'],16)==h(r['callback_mangled'])
  wrapper=int.from_bytes(data[sym['st_value']-4:sym['st_value']],'little')
  assert wrapper==int(r['wrapper_kcfi'],16)==h(r['wrapper_mangled'])
  # Caller argument x1/w1 is forwarded; x0 is loaded from registered data.
  assert any(i.mnemonic=='ldr' and i.op_str=='x0, [x8]' for i in ins)
  assert all(not re.match(r'[xw]1,',i.op_str) or (r['arg_type']=='bool' and i.mnemonic=='and' and i.op_str=='w1, w1, #1') for i in ins)
  results.append(dict(symbol=r['name'],slot=slot,callback_kcfi=hex(kcfi),wrapper_kcfi=hex(wrapper),wrapper_start=sym['st_value']))
 sym=symbols['platform_fg_ic_ops_register']; data=e.get_section(sym['st_shndx']).data();register_kcfi=int.from_bytes(data[sym['st_value']-4:sym['st_value']],'little')
 assert register_kcfi==h('_ZTSFu3i32u3u32PvP16fuelguage_ic_opsE.normalized')
with (S/'bq27z561.ko').open('rb') as fp:
 e=ELFFile(fp);st=e.get_section_by_name('.symtab');symbols=list(st.iter_symbols());ops=next(s for s in symbols if s.name=='g_bq_fg_ops');assert ops['st_size']==536
 rels={r['r_offset']-ops['st_value']:r for sec in e.iter_sections() if isinstance(sec,RelocationSection) and sec['sh_info']==ops['st_shndx'] for r in sec.iter_relocations() if ops['st_value']<=r['r_offset']<ops['st_value']+ops['st_size']}
 data=e.get_section(ops['st_shndx']).data();assert 136 not in rels;assert data[ops['st_value']+136:ops['st_value']+144]==b'\0'*8
 provider=[]
 for r in rows:
  rel=rels.get(r['slot'])
  if rel is None: provider.append(dict(slot=r['slot'],symbol=r['name'],provider_null=True));continue
  rs=st.get_symbol(rel['r_info_sym']);p=next(s for s in symbols if s['st_shndx']==rs['st_shndx'] and s['st_value']==rel['r_addend'] and s['st_size'])
  d=e.get_section(p['st_shndx']).data();kcfi=int.from_bytes(d[p['st_value']-4:p['st_value']],'little');assert kcfi==int(r['kcfi'],16),(r,p.name,hex(kcfi))
  provider.append(dict(slot=r['slot'],symbol=p.name,kcfi=hex(kcfi)))
  if r['name'] in ['platform_fg_ops_get_batt_abnormal_info','platform_fg_ops_set_reboot_vol_thr']:
   asm='\n'.join(f'{i.address:04x}: {i.mnemonic} {i.op_str}' for i in md.disasm(d[p['st_value']:p['st_value']+p['st_size']],p['st_value']))
   (R/(p.name+'.disasm.txt')).write_text(asm+'\n')
   assert ('mov w2, #0x84' if 'abnormal' in p.name else 'strb w1, [sp, #0xe]') in asm
out={'schema':1,'status':'pass','stock':[{'path':str(S/n),'sha256':hashlib.sha256((S/n).read_bytes()).hexdigest()} for n in ['mca_platform_fg_ic_ops.ko','bq27z561.ko']], 'exports':exports,'wrapper_callbacks':results,'provider_callbacks':provider,'provider_table_bytes':536,'reserved_slot':{'offset':136,'provider_null':True,'signature_unknown':True},'register_kcfi':hex(register_kcfi),'hash_method':'Low 32 bits of xxHash64(normalized Itanium type name), seed 0; independent wrapper and provider prefix verification.','method_source':'https://lists.llvm.org/pipermail/llvm-commits/Week-of-Mon-20240819/1433310.html','notes':['bq27z561 abnormal-info output is opaque and receives a 0x84-byte copy; no field layout or policy is implemented here.','Bool/char/u8 normalize identically in this KCFI scheme; bool setters retain full wrapper and provider execution evidence, KCFI alone does not distinguish these C spellings.']}
assert len(exports)==67
(R/'stock-elf-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: 66 wrappers/slots and 66 KCFI pairs; 64 non-null provider callback prefixes; 536-byte provider ABI; register KCFI')
