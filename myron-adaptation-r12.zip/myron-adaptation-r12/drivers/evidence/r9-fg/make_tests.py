import pathlib,json,shutil
R=pathlib.Path(__file__).resolve().parent
T=R/'tests';T.mkdir(exist_ok=True)
shutil.copytree('analysis/myron-stage-r8/review/buck-base/tests/stubs',T/'stubs',dirs_exist_ok=True)
p=T/'stubs/kernel_test.h';s=p.read_text().replace('MYRON_BUCK_TEST_H','MYRON_FG_TEST_H').replace('static int registered_drivers;','static int registered_drivers, register_error;').replace('(void)p;registered_drivers++;return 0;','(void)p;if(register_error)return register_error;registered_drivers++;return 0;');p.write_text(s)
(T/'stubs/linux/types.h').write_text('#include "../kernel_test.h"\ntypedef uint8_t u8;\n')
rows=json.loads((R/'callback-contract.json').read_text())
s='''#include "stubs/kernel_test.h"
#include MCA_FG_SOURCE
static unsigned int assertions;
#define CHECK(v) do { __atomic_add_fetch(&assertions,1,__ATOMIC_SEQ_CST);assert(v); } while(0)
static int token, other_token, expected_int = -2147483000;
static void *expected_data = &token, *expected_out;
static int expected_slot, seen;
static bool expected_bool;
static char expected_char = 0x5a;
static u8 expected_byte = 0xff;
static const char sentinel[] = "real-provider-result";
_Static_assert(FG_IC_MAX == 2, "stock role count");
_Static_assert(sizeof(struct fuelguage_ic_ops) == 536, "stock provider table size");
_Static_assert(offsetof(struct fuelguage_ic_ops, reserved_136) == 136, "stock unexposed slot");
'''
for r in rows:
 at=r['arg_type'];rt=r['return_type'];f=r['field'];args='void *data'+(', '+at+'value' if at and '*' in at else ', '+at+' value' if at else '')
 s+=f'_Static_assert(offsetof(struct fuelguage_ic_ops, {f}) == {r["slot"]}, "stock slot {f}");\n'
 s+=f'static {rt} cb_{f}({args}) {{ CHECK(data == expected_data);CHECK(expected_slot == {r["slot"]});seen++;'
 if at and '*' in at:
  s+='CHECK((void *)value == expected_out);'
  if at=='int *': s+='*value = expected_int;'
  elif at=='bool *': s+='*value = expected_bool;'
  elif at=='char *': s+='*value = expected_char;'
  elif at=='void *': s+='((unsigned char *)value)[131] = 0xa5;'
  elif at=='const char **': s+='*value = sentinel;'
  else: raise Exception(at)
 elif at=='int': s+='CHECK(value == expected_int);'
 elif at=='bool': s+='CHECK(value == expected_bool);'
 elif at=='u8': s+='CHECK(value == expected_byte);'
 if rt=='int': s+='return -77;'
 elif rt=='unsigned long': s+='return 0x12345678abcdef01UL;'
 s+='}\n'
s+='static struct fuelguage_ic_ops all_ops={\n'+''.join(f'.{r["field"]}=cb_{r["field"]},\n' for r in rows)+'};\nstatic struct fuelguage_ic_ops no_ops;\n'
s+='''static void exercise_all(unsigned int role, unsigned int empty) {
 int out = 0, before;
 bool bout = false;
 char cout = 0;
 unsigned char opaque[140] = {0};
 const char *sout = NULL;
'''
for r in rows:
 at=r['arg_type'];rt=r['return_type'];name=r['name'];v=rt=='void'
 prep='';post='';arg=''
 if at=='int *': prep='out=0;expected_out=&out;';arg=', &out';post='CHECK(out==expected_int);'
 elif at=='bool *': prep='bout=!expected_bool;expected_out=&bout;';arg=', &bout';post='CHECK(bout==expected_bool);'
 elif at=='char *': prep='cout=0;expected_out=&cout;';arg=', &cout';post='CHECK(cout==expected_char);'
 elif at=='void *': prep='opaque[131]=0;expected_out=opaque;';arg=', opaque';post='CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);'
 elif at=='const char **': prep='sout=NULL;expected_out=&sout;';arg=', &sout';post='CHECK(sout==sentinel);'
 elif at=='int': arg=', expected_int'
 elif at=='bool': arg=', expected_bool'
 elif at=='u8': arg=', expected_byte'
 good='-77' if rt=='int' else '0x12345678abcdef01UL'
 s+=prep+f'expected_slot={r["slot"]};before=seen;'
 call=f'{name}(role{arg})'
 s+=(call+';' if v else 'CHECK('+call+'=='+good+');')+'CHECK(seen==before+1);'+post+'\n'
 for failrole in ['empty','2','UINT_MAX']:
  call=f'{name}({failrole}{arg})';s+='before=seen;'+(call+';' if v else 'CHECK('+call+'=='+('(unsigned long)-EOPNOTSUPP' if rt=='unsigned long' else '-EOPNOTSUPP')+');')+'CHECK(seen==before);'+post+'\n'
s+='}\n'
b=pathlib.Path('analysis/myron-stage-r8/review/buck-base/tests/test_buck.c').read_text()
con=b[b.index('static pthread_mutex_t hold_lock'):b.index('int main(void)')]
con=con.replace('platform_class_buckchg_ops_register','platform_fg_ic_ops_register').replace('platform_class_buckchg_ops_unregister','platform_fg_ic_ops_unregister').replace('platform_class_buckchg_ops_get_online','platform_fg_ops_get_rsoc').replace('struct platform_class_buckchg_ops','struct fuelguage_ic_ops').replace('.get_online=','.fg_ic_get_rsoc=').replace('== -1','== -EOPNOTSUPP').replace('==-1','==-EOPNOTSUPP')
s+=con
s+='''int main(void) {
 register_error=-EIO;CHECK(platform_fg_init()==-EIO);CHECK(!registered_drivers);
 register_error=0;CHECK(!platform_fg_init());CHECK(registered_drivers==1);
 CHECK(platform_fg_ic_ops_register(2,&token,&all_ops)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_register(UINT_MAX,&token,&all_ops)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_register(0,&token,NULL)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_register(0,NULL,&all_ops)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_unregister(2,&token,&all_ops)==-EINVAL);
 CHECK(platform_fg_ic_ops_unregister(0,&token,NULL)==-EINVAL);
 CHECK(platform_fg_ic_ops_unregister(0,NULL,&all_ops)==-EINVAL);
 CHECK(platform_fg_ic_ops_unregister(0,&token,&all_ops)==-ENOENT);
 CHECK(!platform_fg_ic_ops_register(0,&token,&all_ops));
 CHECK(!platform_fg_ic_ops_register(1,&other_token,&no_ops));
 expected_bool=true;exercise_all(0,1);
 expected_bool=false;expected_int=INT_MAX;expected_byte=0x80;exercise_all(0,1);
 alloc_fail=1;CHECK(platform_fg_ic_ops_register(0,&other_token,&no_ops)==-ENOMEM);alloc_fail=0;
 exercise_all(0,1);
 CHECK(platform_fg_ic_ops_unregister(0,&other_token,&all_ops)==-ENOENT);
 expected_byte=0x7f;exercise_all(0,1);
 expected_byte=0x00;exercise_all(0,1);
 CHECK(!platform_fg_ic_ops_unregister(0,&token,&all_ops));
 CHECK(!platform_fg_ic_ops_register(1,&other_token,&all_ops));
 expected_data=&other_token;expected_bool=true;expected_int=INT_MIN;exercise_all(1,0);
 CHECK(!platform_fg_ic_ops_unregister(1,&other_token,&all_ops));
 expected_data=&token;
 concurrency();
 CHECK(!platform_fg_ic_ops_register(0,&token,&all_ops));
 CHECK(!platform_fg_ic_ops_register(1,&token,&all_ops));
 platform_fg_exit();CHECK(!registered_drivers);CHECK(!live_allocations);
 int value=0;CHECK(platform_fg_ops_get_rsoc(0,&value)==-EOPNOTSUPP);
 CHECK(platform_fg_ops_get_rsoc(1,&value)==-EOPNOTSUPP);
 printf("PASS: %u assertions, 66 callback slots, 536-byte ABI and 2 roles, opaque/boolean/signed/64-bit forwarding, NULL/role bounds, allocation failure, SRCU replacement/unregister wait, module cleanup\\n",assertions);
 return 0;
}
'''
(T/'test_fg.c').write_text(s)
b=pathlib.Path('analysis/myron-stage-r8/review/buck-base/tests/run_buck.sh').read_text().replace('MCA_BUCK_SOURCE','MCA_FG_SOURCE').replace('mca_platform_buckchg_class.c','mca_platform_fg_ic_ops.c').replace('test_buck','test_fg')
(T/'run_fg.sh').write_text(b);(T/'run_fg.sh').chmod(0o755)
