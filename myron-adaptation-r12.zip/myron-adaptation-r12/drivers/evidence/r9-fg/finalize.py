import pathlib,json,hashlib,re,subprocess,tempfile,shutil,difflib
R=pathlib.Path(__file__).resolve().parent
C='drivers/power/supply/mca/mca_platform/mca_platform_fg_ic_ops.c';H='drivers/power/supply/mca/include/mca/platform/platform_fg_ic_ops.h'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((R/'callback-contract.json').read_text());stock=json.loads((R/'stock-elf-verification.json').read_text())
exports=sorted(re.findall(r'EXPORT_SYMBOL\((\w+)\)',(R/'candidate'/C).read_text()))
assert set(exports)==set(stock['exports'])|{'platform_fg_ic_ops_unregister'}
up_exports=sorted(re.findall(r'EXPORT_SYMBOL\((\w+)\)',(R/'upstream'/C).read_text()))
sources=[];writes=[];patch=''
for f in [C,H]:
 d=json.loads((R/'upstream'/(f+'.source.json')).read_text());sources.append({'repository':'unmoved21/android_kernel_xiaomi_onyx','commit':'8276ba954d8076303a5ae0f7b15d4092d66bdff6','path':f,'blob_sha1':d['sha'],'sha256':sha(R/'upstream'/f),'bytes':(R/'upstream'/f).stat().st_size,'candidate_sha256':sha(R/'candidate'/f)})
 writes.append({'path':f,'source':'candidate/'+f,'sha256':sha(R/'candidate'/f)})
 patch+=''.join(difflib.unified_diff((R/'upstream'/f).read_text().splitlines(True),(R/'candidate'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
(R/'myron-fg.patch').write_text(patch)
limits=['Source-build candidate only; not target-DDK-built or hardware tested by this review.',
'No fuel-gauge I2C IC provider, battery strategy, fuel-gauge property enum ABI, device-tree enablement, or electrical policy is implemented.',
'Stock get_batt_info and get_batt_abnormal_info remain opaque provider buffers. bq27z561 abnormal-info copies 0x84 bytes; callers must provide correctly sized objects. This module does not reinterpret or synthesize them.',
'Table slot 136 has no exported dispatcher and is NULL in stock bq27z561. It is reserved as an opaque NULL pointer; unknown callback semantics are not implemented.',
'Provider ops must remain immutable and both ops/data remain live until unregister returns. Registration/unregister are sleepable and must not be invoked within an FG callback.',
'Host SRCU tests model reader grace periods with pthread locks; they establish ordering behavior, not target-kernel or hardware validation.']
mod={'name':'mca_platform_fg_ic_ops','registration_name':'drivers/power/supply/mca/mca_platform/mca_platform_fg_ic_ops','out':'mca_platform_fg_ic_ops.ko','config':'CONFIG_MYRON_MCA_PLATFORM','srcs':[C,H],'includes':['drivers/power/supply/mca/include'],'deps':[],'expected_exports':exports,'required_dependencies':[],'aliases':[],'parameters':[],'required_imports':[],'stock_sha256':stock['stock'][0]['sha256']}
integ={'schema':1,'upstream':{'repository':'unmoved21/android_kernel_xiaomi_onyx','commit':'8276ba954d8076303a5ae0f7b15d4092d66bdff6'},'sources':sources,'modules':[mod],'writes':writes,'tests':{'runner':'tests/run_fg.sh','argument':'PAYLOAD','standalone_stubs':True},'limitations':limits,'flashable':False,'hardware_tested':False}
(R/'integration.json').write_text(json.dumps(integ,indent=2)+'\n')
run=subprocess.run(['bash',str(R/'tests/run_fg.sh')],text=True,capture_output=True);(R/'host-tests.log').write_text(run.stdout+run.stderr);assert run.returncode==0,run.stderr
negative=[]
changes=[
 ('wrong_same_type_dispatch',C,'ret = info->ops->fg_ic_get_rsoc(info->data, value);','ret = info->ops->fg_ic_get_curr(info->data, value);'),
 ('truncate_u8_threshold_to_bool',C,'ret = info->ops->fg_ic_set_reboot_vol_thr(info->data, value);','ret = info->ops->fg_ic_set_reboot_vol_thr(info->data, !!value);'),
 ('swap_stock_callback_slots',H,'\tint (*fg_ic_get_rsoc)(void *data, int *value);\n\tint (*fg_ic_get_curr)(void *data, int *value);','\tint (*fg_ic_get_curr)(void *data, int *value);\n\tint (*fg_ic_get_rsoc)(void *data, int *value);'),
 ('wrong_abnormal_info_type',H,'void (*fg_ic_get_batt_abnormal_info)(void *data, void *value);','int (*fg_ic_get_batt_abnormal_info)(void *data, int *value);'),
]
for name,file,old,new in changes:
 with tempfile.TemporaryDirectory(prefix='fg-negative-') as tmp:
  payload=pathlib.Path(tmp)/'candidate';shutil.copytree(R/'candidate',payload);p=payload/file;text=p.read_text();assert text.count(old)==1,(name,old);p.write_text(text.replace(old,new))
  n=subprocess.run(['bash',str(R/'tests/run_fg.sh'),str(payload)],capture_output=True,text=True)
  assert n.returncode!=0,name
  # Preserve just the diagnostically relevant line, not random temp paths.
  msg=next((l for l in n.stderr.splitlines() if 'Assertion' in l or 'error:' in l),n.stderr.splitlines()[0] if n.stderr else '')
  negative.append({'mutation':name,'rejected':True,'exit_code':n.returncode,'diagnostic':msg.replace(tmp,'<temporary>')})
(R/'negative-controls.json').write_text(json.dumps(negative,indent=2)+'\n')
audit={'schema':1,'status':'source_candidate_validated','module':'mca_platform_fg_ic_ops','stock_exports':67,'candidate_exports':68,'source_missing_stock':sorted(set(stock['exports'])-set(exports)),'added_stock_dispatchers':sorted(set(stock['exports'])-set(up_exports)),'removed_non_stock_dispatchers':sorted(set(up_exports)-set(stock['exports'])),'callback_count':66,'layout_bytes':536,'role_count':2,'public_and_callback_kcfi_match':True,'raw_elf_verification':'stock-elf-verification.json','semantic_fixes':['Correct stock table order; reserve byte 136 without guessing a callback signature.','Restore nine missing stock APIs; remove nine non-stock APIs.','get_pack_vendor is void, not int, for both callback and wrapper.','get_batt_abnormal_info is void(void *, void *); forwards opaque provider buffer.','set_reboot_vol_thr forwards full u8 threshold; never booleanizes it. Provider strb evidence and 00/7f/80/ff tests are mandatory.','Both stock roles preserve dispatch failures and exact provider returns, including 64-bit unsigned return values.','Atomic ops/data registration, SRCU grace periods for replacement, unregister, and module exit.'],'validation':{'host_test_log':'host-tests.log','runtime_assertions':5460,'compile_time_layout_assertions':69,'negative_controls':len(negative),'target_ddk_build':False,'hardware_tested':False,'flashable':False},'limitations':limits}
(R/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
(R/'provenance.json').write_text(json.dumps({'upstream':integ['upstream'],'sources':sources,'stock':stock['stock'],'method_source':stock['method_source']},indent=2)+'\n')
print('FG integration finalized:',len(exports),'exports;',len(rows),'callbacks;',run.stdout.strip(),';',len(negative),'negative controls')
