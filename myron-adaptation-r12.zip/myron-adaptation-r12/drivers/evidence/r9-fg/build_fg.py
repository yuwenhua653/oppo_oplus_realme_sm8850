import pathlib,re,json,hashlib,shutil,ctypes
R=pathlib.Path(__file__).resolve().parent
U=pathlib.Path('analysis/myron-stage-r8/review/cp-fg/upstream')
C='drivers/power/supply/mca/mca_platform/mca_platform_fg_ic_ops.c';H='drivers/power/supply/mca/include/mca/platform/platform_fg_ic_ops.h'
for f in [C,H]:
 for sub in ['upstream','candidate']:
  p=R/sub/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(U/f,p)
 shutil.copy2(U/(f+'.source.json'),R/'upstream'/(f+'.source.json'))
rows=json.loads((R/'stock-contract-raw.json').read_text())
# These callback prototypes are proven by stock dispatch argument forwarding,
# callback KCFI, and provider function-prefix KCFI (bq27z561).
types={
 '0x549f592c':('int','bool *','_ZTSFu3i32PvPu2u8E','_ZTSFu3i32u3u32Pu2u8E'),
 '0x6f19f500':('int','void *','_ZTSFu3i32PvS0_E','_ZTSFu3i32u3u32PvE'),
 '0xfffee5e4':('void','void *','_ZTSFvPvS_E','_ZTSFvu3u32PvE'),
 '0xc069e464':('int',None,'_ZTSFu3i32PvE','_ZTSFu3i32u3u32E'),
 '0x4445f77a':('int','int *','_ZTSFu3i32PvPS_E','_ZTSFu3i32u3u32PS_E'),
 '0xc2a6c845':('int','int','_ZTSFu3i32PvS_E','_ZTSFu3i32u3u32S_E'),
 '0xb2a4ba31':('int','bool','_ZTSFu3i32Pvu2u8E','_ZTSFu3i32u3u32u2u8E'),
 '0x9459a139':('int','const char **','_ZTSFu3i32PvPPKu2u8E','_ZTSFu3i32u3u32PPKu2u8E'),
 '0xef81b7d':('void',None,'_ZTSFvPvE','_ZTSFvu3u32E'),
 '0x25bd98a0':('void','int *','_ZTSFvPvPu3i32E','_ZTSFvu3u32Pu3i32E'),
 '0x41b78b02':('unsigned long',None,'_ZTSFu3u64PvE','_ZTSFu3u64u3u32E'),
}
x=ctypes.CDLL('libxxhash.so.0');x.XXH64.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_uint64];x.XXH64.restype=ctypes.c_uint64
def hash_type(m):
 b=(m+'.normalized').encode();return hex(x.XXH64(b,len(b),0)&0xffffffff)
for r in rows:
 rt,at,cm,wm=types[r['kcfi']]
 assert hash_type(cm)==r['kcfi'],(r,cm,hash_type(cm))
 assert hash_type(wm)==r['wrapper_kcfi'],(r,wm,hash_type(wm))
 if r['name'].endswith(('set_verify_digest','get_verify_digest','get_batt_sn')): at='char *'
 if r['name'].endswith('set_reboot_vol_thr'): at='u8'
 r.update(return_type=rt,arg_type=at,callback_mangled=cm+'.normalized',wrapper_mangled=wm+'.normalized')
# A slot at byte 136 has no exported dispatcher, and is zero in stock bq27z561.
header='''/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _MCA_PLATFORM_PLATFORM_FG_IC_OPS_H_
#define _MCA_PLATFORM_PLATFORM_FG_IC_OPS_H_
#include <linux/types.h>

enum mca_fg_ic_role {
\tFG_IC_MASTER = 0,
\tFG_IC_SLAVE,
\tFG_IC_MAX,
};
#define FG_SITE_MAX FG_IC_MAX

/* Stock Myron ABI: 67 pointer slots (536 bytes on arm64).
 * Slot 136 is unexposed and NULL in the stock BQ27Z561 provider. Its function
 * signature is not inferred; leave the reserved slot NULL in source providers.
 * Battery info/abnormal info are opaque provider buffers, not an int value.
 */
struct fuelguage_ic_ops {
'''
slots={r['slot']:r for r in rows}
for slot in range(0,536,8):
 if slot not in slots: header+='\tvoid *reserved_136;\n';continue
 r=slots[slot];args='void *data'+(', '+r['arg_type']+'value' if r['arg_type'] and '*' in r['arg_type'] else ', '+r['arg_type']+' value' if r['arg_type'] else '')
 header+=f'\t{r["return_type"]} (*{r["field"]})({args});\n'
header+='};\n\n/* Sleepable context only. Do not register/unregister inside an FG callback.\n * Keep the ops table immutable and ops/data live until unregister returns.\n */\n'
header+='int platform_fg_ic_ops_register(unsigned int ic_role, void *data,\n\t\t\t\tstruct fuelguage_ic_ops *ops);\n'
header+='int platform_fg_ic_ops_unregister(unsigned int ic_role, void *data,\n\t\t\t\t  struct fuelguage_ic_ops *ops);\n'
for r in rows:
 args='unsigned int ic_role'+(', '+r['arg_type']+'value' if r['arg_type'] and '*' in r['arg_type'] else ', '+r['arg_type']+' value' if r['arg_type'] else '')
 r['declaration']=f'{r["return_type"]} {r["name"]}({args})';header+=r['declaration']+';\n'
header+='\n#endif /* _MCA_PLATFORM_PLATFORM_FG_IC_OPS_H_ */\n'
(R/'candidate'/H).write_text(header)
source=(U/C).read_text().split('#include')[0]+'''#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/srcu.h>
#include <linux/errno.h>
#include <mca/platform/platform_fg_ic_ops.h>

struct fuelguage_info {
\tvoid *data;
\tstruct fuelguage_ic_ops *ops;
};
static struct fuelguage_info __rcu *g_fg_ic_ops[FG_IC_MAX];
static DEFINE_MUTEX(platform_fg_lock);
DEFINE_STATIC_SRCU(platform_fg_srcu);

/* Atomically publish the ops/data pair; wait before old provider reclamation.
 * Register/unregister must not run from inside a dispatched FG callback.
 */
int platform_fg_ic_ops_register(unsigned int ic_role, void *data,
\t\t\t\tstruct fuelguage_ic_ops *ops)
{
\tstruct fuelguage_info *entry, *old;

\tif (ic_role >= FG_IC_MAX || !data || !ops)
\t\treturn -EOPNOTSUPP;
\tentry = kmalloc(sizeof(*entry), GFP_KERNEL);
\tif (!entry)
\t\treturn -ENOMEM;
\tentry->data = data;
\tentry->ops = ops;
\tmutex_lock(&platform_fg_lock);
\told = rcu_replace_pointer(g_fg_ic_ops[ic_role], entry,
\t\t\t\t  lockdep_is_held(&platform_fg_lock));
\tmutex_unlock(&platform_fg_lock);
\tsynchronize_srcu(&platform_fg_srcu);
\tkfree(old);
\treturn 0;
}
EXPORT_SYMBOL(platform_fg_ic_ops_register);

int platform_fg_ic_ops_unregister(unsigned int ic_role, void *data,
\t\t\t\t  struct fuelguage_ic_ops *ops)
{
\tstruct fuelguage_info *old;

\tif (ic_role >= FG_IC_MAX || !data || !ops)
\t\treturn -EINVAL;
\tmutex_lock(&platform_fg_lock);
\told = rcu_dereference_protected(g_fg_ic_ops[ic_role],
\t\t\t\t       lockdep_is_held(&platform_fg_lock));
\tif (!old || old->ops != ops || old->data != data) {
\t\tmutex_unlock(&platform_fg_lock);
\t\t/* A replacement can have detached a still-running old provider. */
\t\tsynchronize_srcu(&platform_fg_srcu);
\t\treturn -ENOENT;
\t}
\tRCU_INIT_POINTER(g_fg_ic_ops[ic_role], NULL);
\tmutex_unlock(&platform_fg_lock);
\tsynchronize_srcu(&platform_fg_srcu);
\tkfree(old);
\treturn 0;
}
EXPORT_SYMBOL(platform_fg_ic_ops_unregister);

'''
for r in rows:
 rt=r['return_type'];v=rt=='void';fail='return;' if v else 'return -EOPNOTSUPP;'
 source+=r['declaration']+'\n{\n\tstruct fuelguage_info *info;\n\tint idx;\n'
 if not v: source+=f'\t{rt} ret = -EOPNOTSUPP;\n'
 source+=f'\n\tif (ic_role >= FG_IC_MAX)\n\t\t{fail}\n\tidx = srcu_read_lock(&platform_fg_srcu);\n\tinfo = srcu_dereference(g_fg_ic_ops[ic_role], &platform_fg_srcu);\n\tif (info && info->ops && info->ops->{r["field"]})\n\t\t'+('' if v else 'ret = ')+f'info->ops->{r["field"]}(info->data'+(', value' if r['arg_type'] else '')+');\n\tsrcu_read_unlock(&platform_fg_srcu, idx);\n'
 if not v: source+='\treturn ret;\n'
 source+='}\nEXPORT_SYMBOL('+r['name']+');\n\n'
source+='''static struct platform_driver platform_fg_ops_driver = {
\t.driver = {
\t\t.name = "platform_fg_ops",
\t},
};

static int __init platform_fg_init(void)
{
\treturn platform_driver_register(&platform_fg_ops_driver);
}

static void __exit platform_fg_exit(void)
{
\tstruct fuelguage_info *old[FG_IC_MAX];
\tunsigned int role;

\tplatform_driver_unregister(&platform_fg_ops_driver);
\tmutex_lock(&platform_fg_lock);
\tfor (role = 0; role < FG_IC_MAX; role++)
\t\told[role] = rcu_replace_pointer(g_fg_ic_ops[role], NULL,
\t\t\t\t\tlockdep_is_held(&platform_fg_lock));
\tmutex_unlock(&platform_fg_lock);
\tsynchronize_srcu(&platform_fg_srcu);
\tfor (role = 0; role < FG_IC_MAX; role++)
\t\tkfree(old[role]);
}
module_init(platform_fg_init);
module_exit(platform_fg_exit);
MODULE_DESCRIPTION("platform fg ops");
MODULE_AUTHOR("liyuze1@xiaomi.com");
MODULE_LICENSE("GPL v2");
'''
(R/'candidate'/C).write_text(source)
(R/'callback-contract.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Generated',len(rows),'callbacks, types verified against stock hashes')
