r7 独立 review（四模块范围）

结论：在所记录源码快照内，两个具体阻断均已修复；无未解决的本轮 blocker。

1. charge_interface 的 sysfs 链接创建失败会遗留 group。
   common sysfs overlay 已在第二阶段失败时回滚刚创建的 group。
   独立重跑实际 helper 失败注入测试：53 checks，ASan/UBSan 通过。

2. protocol_class 的替换者可让旧 provider 的 unregister 提前返回，
   导致仍执行的旧 callback 与销毁并发。
   mismatch/absent 路径现于解锁后等待 SRCU。
   独立确定性复现：修复前 false / exit1，修复后 true / exit0。
   平台实际 C 测试：119 assertions、21 个回调偏移通过。

其他检查：生产 QC ops 使用 designated initializers，其余三个候选没有具体
provider initializer；loadsw 的 DT 边界、部分失败清理和 devm 释放顺序通过检查；
charge_interface 本地输入/输出边界检查通过，原测试 16,789 checks。

这些结果不是目标 DDK/KCFI 编译或实机充电验证。QC/loadsw/charge_interface
下层 provider 生命周期尚未适配；不得据此接入可热卸载硬件后端。SRCU 同步注册/
注销不能从被派发 callback 内调用。charge getter 无容量参数，后端必须遵守
128-byte 缓冲区约定。完整限制与哈希见 review.json。
