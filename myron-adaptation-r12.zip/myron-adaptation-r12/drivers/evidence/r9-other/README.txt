R9 non-MCA additions: ir_spi, stm_st54se_gpio, ACK tls.

IR/ST54 candidates are under candidate/. Originals under upstream/ are hash checked.
Host runner tests/run_other.sh compiles both full C candidates with ASan/UBSan and real pthread locking. LeakSanitizer is disabled because the managed runtime cannot inspect /proc threads; explicit alloc counters must reach zero.

TLS hooks: common/apply_tls.py --workspace WORKSPACE (after r1 prepare; --check preflight), then common/validate_tls.py --artifact-dir COLLECTED_FULL. TLS selects hidden bool STREAM_PARSER=y, so no strparser.ko; all other crypto/socket selects already y. Defconfig insertion respects net/Kconfig ordering before XFRM.

Stock ST54 semantics were independently verified from raw ELF: probe owns GPIO, sets nRESET high; multi-open is allowed; SET0 is a no-op; SET1 sets high; release does not free GPIO. Public source default ESE_CONF_GPIO_OPEN_RELEASE must NOT be used.

No target build/hardware result claimed. No device tree change or flash package.
