from pathlib import Path
import json
R=Path(__file__).resolve().parent;T=R/'tests';S=T/'stubs';S.mkdir(parents=True,exist_ok=True)
common=r'''#ifndef HELPERS_KERNEL_TEST_H
#define HELPERS_KERNEL_TEST_H
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
typedef uint32_t u32;typedef unsigned char u8;typedef int64_t time64_t;
#define __init
#define __exit
#define EXPORT_SYMBOL(x)
#define EXPORT_SYMBOL_GPL(x)
#define MODULE_DESCRIPTION(x)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#define module_init(x)
#define module_exit(x)
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define DEFINE_MUTEX(x) pthread_mutex_t x=PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) pthread_mutex_lock(x)
#define mutex_unlock(x) pthread_mutex_unlock(x)
#define READ_ONCE(x) __atomic_load_n(&(x),__ATOMIC_ACQUIRE)
#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v),__ATOMIC_RELEASE)
#define IS_ERR_OR_NULL(x) (!(x) || (uintptr_t)(x)>(uintptr_t)-4096)
#define ERR_PTR(x) ((void *)(intptr_t)(x))
#define EPROBE_DEFER 517
#define mca_log_err(...) do {} while(0)
#define mca_log_info(...) do {} while(0)
#define mca_log_jirabot(...) do {} while(0)
#define QCOM_SMEM_HOST_ANY 0xffffffff
static int alloc_result,smem_alloc_calls,smem_get_calls;
static size_t smem_size,allocated_size;
static void *smem_pointer;
static int qcom_smem_alloc(unsigned h,unsigned id,size_t n) {
 assert(h==QCOM_SMEM_HOST_ANY && id==0x51);smem_alloc_calls++;allocated_size=n;return alloc_result;
}
static void *qcom_smem_get(unsigned h,unsigned id,size_t *n) {
 assert(h==QCOM_SMEM_HOST_ANY && id==0x51 && n);smem_get_calls++;*n=smem_size;return smem_pointer;
}
static time64_t test_now;
static time64_t ktime_get_boottime_seconds(void) { return test_now; }
struct mca_event_notify_data { const char *event;int event_len; };
static atomic_int uevent_count,alloc_count,destroy_count,write_count;
static int event_alloc_fail,add_fail_at;
static void mca_event_report_uevent(const struct mca_event_notify_data *n) {
 assert(!strcmp(n->event,"MCA_LOG_FULL_EVENT") && n->event_len==18);uevent_count++;
}
struct test_field { char key[64];char text[160];long number;int type; };
struct misight_mievent { unsigned id;int fields;struct test_field field[17]; };
static struct misight_mievent last_event;
static pthread_mutex_t capture_lock=PTHREAD_MUTEX_INITIALIZER;
static struct misight_mievent *cdev_tevent_alloc(unsigned id) {
 alloc_count++;if(event_alloc_fail)return NULL;
 struct misight_mievent *e=calloc(1,sizeof(*e));assert(e);e->id=id;return e;
}
static int cdev_tevent_add_str(struct misight_mievent *e,const char *key,const char *val) {
 assert(e && key && val && e->fields<17);
 if(add_fail_at && e->fields+1==add_fail_at)return -ENOMEM;
 struct test_field *f=&e->field[e->fields++];snprintf(f->key,sizeof(f->key),"%s",key);snprintf(f->text,sizeof(f->text),"%s",val);f->type=1;return 0;
}
static int cdev_tevent_add_int(struct misight_mievent *e,const char *key,long val) {
 assert(e && key && e->fields<17);
 if(add_fail_at && e->fields+1==add_fail_at)return -ENOMEM;
 struct test_field *f=&e->field[e->fields++];snprintf(f->key,sizeof(f->key),"%s",key);f->number=val;f->type=0;return 0;
}
static int cdev_tevent_write(struct misight_mievent *e) {
 pthread_mutex_lock(&capture_lock);last_event=*e;write_count++;pthread_mutex_unlock(&capture_lock);return 0;
}
static void cdev_tevent_destroy(struct misight_mievent *e) { destroy_count++;free(e); }
#endif
'''
(S/'kernel_test.h').write_text(common)
for p in ['linux/module.h','linux/kernel.h','linux/types.h','linux/time64.h','linux/err.h','linux/compiler.h','linux/soc/qcom/smem.h','linux/string.h','linux/mutex.h','linux/ktime.h','mca/common/mca_log.h','mca/common/mca_event.h','miev/mievent.h']:
 f=S/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('#include "kernel_test.h"\n')
test=r'''#include "kernel_test.h"
#include "drivers/power/supply/mca/mca_common/mca_qcom_smem.c"
#include "drivers/power/supply/mca/mca_common/mca_charge_mievent.c"
static unsigned checks;
#define CHECK(x) do { checks++;assert(x); } while(0)
static void smem_tests(void) {
 struct mca_smem_battery_info b={0};
 CHECK(sizeof(b)==36);CHECK(offsetof(struct mca_smem_battery_info,zero_speed_start_mode)==32);
 CHECK(mca_qcom_smem_is_zero_speed()==-ENODEV);
 alloc_result=-ENOMEM;CHECK(mca_qcom_smem_init()==-EPROBE_DEFER);CHECK(smem_get_calls==0);CHECK(allocated_size==36);
 alloc_result=-EEXIST;smem_pointer=ERR_PTR(-EPROBE_DEFER);CHECK(mca_qcom_smem_init()==-EPROBE_DEFER);
 smem_pointer=NULL;CHECK(mca_qcom_smem_init()==-EPROBE_DEFER);
 smem_pointer=&b;smem_size=35;CHECK(mca_qcom_smem_init()==-EINVAL);
 smem_size=36;CHECK(mca_qcom_smem_init()==0);CHECK(mca_qcom_smem_is_zero_speed()==0);
 b.zero_speed_start_mode=1;CHECK(mca_qcom_smem_is_zero_speed()==1);
 b.zero_speed_start_mode=0x1020304;CHECK(mca_qcom_smem_is_zero_speed()==0x1020304);
 mca_qcom_smem_exit();CHECK(mca_qcom_smem_is_zero_speed()==-ENODEV);CHECK(b.zero_speed_start_mode==0x1020304);
 alloc_result=0;CHECK(mca_qcom_smem_init()==0);mca_qcom_smem_exit();
}
'''
j=json.loads((R/'stock-mievent-table.json').read_text())
test+='static const struct charge_mievent_info expected[] = {\n'
for v in j['g_charge_mievent_info']:
 test+=' { '+', '.join(json.dumps(v[k]) for k in ['event_code','event_type','event_describe','upload_type','type_index','data_type','data_count'])+', { '+', '.join(json.dumps(x) for x in v['para_name'])+' } },\n'
test+='};\n'
test+=r'''
static void mievent_tests(void) {
 int values[16];char *strings[16];char text[]="firmware failure";
 for(int i=0;i<16;i++){values[i]=i*17-60;strings[i]=text;}
 CHECK(sizeof(struct charge_mievent_info)==560);
 CHECK(sizeof(expected)==sizeof(g_charge_mievent_info));
 CHECK(!memcmp(expected,g_charge_mievent_info,sizeof(expected)));
 CHECK(CHARGE_DFX_MAX_NUM==61);CHECK(PLUG_TYPE_MAX_NUM==53);CHECK(TIME_TYPE_MAX_NUM==8);
 CHECK(CHARGE_DFX_SOC_NOT_FULL==12);CHECK(CHARGE_DFX_WLS_FW_UPGRADE_FAIL==45);
 CHECK(CHARGE_DFX_BATTERY_OCD==48);CHECK(CHARGE_DFX_BATTERY_CYCLECOUNT==53);
 for(int i=0;i<61;i++) {
  const struct charge_mievent_info *r=&expected[i];
  void *data=r->data_type==MIEVENT_DATA_TYPE_STRING ? (void *)strings : (void *)values;
  mca_charge_mievent_set_state(MIEVENT_STATE_END,i);int before=write_count;
  mca_charge_mievent_report(i,data,r->data_count);
  CHECK(write_count==before+1);CHECK(last_event.id==(unsigned)r->event_code);
  CHECK(!strcmp(last_event.field[0].key,r->event_type));CHECK(!strcmp(last_event.field[0].text,r->event_describe));
  int n=r->data_type==MIEVENT_DATA_TYPE_NULL?0:r->data_count;
  CHECK(last_event.fields==n+1);
  for(int k=0;k<n;k++) {
   CHECK(!strcmp(last_event.field[k+1].key,r->para_name[k]));
   if(r->data_type==MIEVENT_DATA_TYPE_INT)CHECK(last_event.field[k+1].number==values[k]);
   else CHECK(!strcmp(last_event.field[k+1].text,text));
  }
 }
 int before=write_count;
 mca_charge_mievent_report(-1,values,1);mca_charge_mievent_report(61,values,1);
 mca_charge_mievent_report(0,values,-1);mca_charge_mievent_report(0,values,2);mca_charge_mievent_report(0,NULL,1);
 strings[0]=NULL;mca_charge_mievent_report(45,strings,1);
 char longbuf[129];memset(longbuf,'x',128);longbuf[128]=0;strings[0]=longbuf;mca_charge_mievent_report(45,strings,1);
 CHECK(write_count==before);strings[0]=text;
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);mca_charge_mievent_report(0,values,1);
 CHECK(write_count==before+1);mca_charge_mievent_report(0,values,1);CHECK(write_count==before+1);
 mca_charge_mievent_set_state(MIEVENT_STATE_PLUG,1);mca_charge_mievent_report(0,values,1);CHECK(write_count==before+1);
 mca_charge_mievent_set_state(MIEVENT_STATE_PLUG,0);mca_charge_mievent_report(0,values,1);CHECK(write_count==before+2);
 // The stock 3-report CP limit and 5-report slow-charge limit.
 mca_charge_mievent_set_state(MIEVENT_STATE_END,1);before=write_count;
 for(int i=0;i<10;i++)mca_charge_mievent_report(1,values,1);CHECK(write_count==before+3);
 mca_charge_mievent_set_state(MIEVENT_STATE_END,46);before=write_count;
 for(int i=0;i<10;i++)mca_charge_mievent_report(46,values,5);CHECK(write_count==before+5);
 // Timer index 7 must be one week, not Onyx's uninitialized zero interval.
 mca_charge_mievent_set_state(MIEVENT_STATE_END,60);test_now=1;before=write_count;
 mca_charge_mievent_report(60,NULL,0);mca_charge_mievent_report(60,NULL,0);CHECK(write_count==before+1);
 test_now=604800;mca_charge_mievent_report(60,NULL,0);CHECK(write_count==before+1);
 test_now=604801;mca_charge_mievent_report(60,NULL,0);CHECK(write_count==before+2);
 // Allocation/append failures release every successfully allocated object.
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);before=destroy_count;event_alloc_fail=1;
 mca_charge_mievent_report(0,values,1);CHECK(destroy_count==before);event_alloc_fail=0;
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);before=write_count;int d=destroy_count;add_fail_at=1;
 mca_charge_mievent_report(0,values,1);CHECK(write_count==before);CHECK(destroy_count==d+1);add_fail_at=0;
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);d=destroy_count;add_fail_at=2;
 mca_charge_mievent_report(0,values,1);CHECK(write_count==before);CHECK(destroy_count==d+1);add_fail_at=0;
}
static void *race_report(void *p) { int v=1;(void)p;for(int i=0;i<10000;i++)mca_charge_mievent_report(1,&v,1);return NULL; }
static void race_test(void) {
 pthread_t threads[8];mca_charge_mievent_set_state(MIEVENT_STATE_END,1);int before=write_count;
 for(int i=0;i<8;i++)CHECK(!pthread_create(&threads[i],NULL,race_report,NULL));
 for(int i=0;i<8;i++)CHECK(!pthread_join(threads[i],NULL));
 CHECK(write_count==before+3);CHECK(g_upload_type_plug_info[1].count==3);
}
int main(int argc,char **argv) {
 if(argc==2 && !strcmp(argv[1],"--table")) { fwrite(g_charge_mievent_info,sizeof(g_charge_mievent_info),1,stdout);return 0; }
 smem_tests();mievent_tests();race_test();printf("helpers: %u checks passed; 61 stock records, 80000 concurrent requests\n",checks);return 0;
}
'''
(T/'test_helpers.c').write_text(test)
(T/'run_helpers.sh').write_text('''#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
payload=${1:?payload directory required}
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
cc -std=gnu11 -Wall -Wextra -Werror -Wno-unused-function -Wno-unused-variable -Wno-sign-compare -Wno-misleading-indentation -pthread -fsanitize=undefined -fno-sanitize-recover=all -I"$here/stubs" -I"$payload" -I"$payload/drivers/power/supply/mca/include" "$here/test_helpers.c" -o "$tmp/test_helpers"
"$tmp/test_helpers"
''')
