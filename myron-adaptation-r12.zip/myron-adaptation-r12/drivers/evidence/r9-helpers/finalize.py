from pathlib import Path
import json,hashlib,re,struct,ctypes,subprocess
from elftools.elf.elffile import ELFFile
R=Path(__file__).resolve().parent;P='drivers/power/supply/mca/'
stock=json.loads((R/'stock-disassembly.json').read_text())
table=json.loads((R/'stock-mievent-table.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
records=json.loads((R/'source-response.json').read_text())
sources=[]
for r in records:
 p=R/'upstream'/r['path'];b=p.read_bytes()
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['sha']
 record={'repository':'unmoved21/android_kernel_xiaomi_onyx','commit':'8276ba954d8076303a5ae0f7b15d4092d66bdff6','path':r['path'],'blob_sha1':r['sha'],'sha256':sha(p),'bytes':len(b)}
 dump(p.with_name(p.name+'.source.json'),record)
 cp=R/'candidate'/r['path']
 if cp.exists():record['candidate_sha256']=sha(cp);sources.append(record)

# Derive the complete fixed-width table directly from ELF, without consuming
# the adaptation generator. All strings are inline fixed arrays in the stock.
with Path(stock['mca_charge_mievent']['path']).open('rb') as f:
 e=ELFFile(f);symbols={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()}
 tables={}
 for n,stride in [('g_charge_mievent_info',560),('g_upload_type_plug_info',8),('g_upload_type_time_info',16)]:
  s=symbols[n];b=e.get_section(s['st_shndx']).data()[s['st_value']:s['st_value']+s['st_size']]
  assert len(b)%stride==0
  tables[n]={'section':e.get_section(s['st_shndx']).name,'offset':s['st_value'],'size':len(b),'stride':stride,'count':len(b)//stride,'sha256':hashlib.sha256(b).hexdigest()}
  if n=='g_charge_mievent_info':
   rows=[]
   for pos in range(0,len(b),560):
    c=b[pos:pos+560];v={'index':pos//560,'event_code':struct.unpack_from('<i',c)[0],'event_type':c[4:34].split(b'\0')[0].decode(),'event_describe':c[34:64].split(b'\0')[0].decode()}
    v.update(zip(['upload_type','type_index','data_type','data_count'],struct.unpack_from('<iiii',c,64)))
    v['para_name']=[c[80+i*30:110+i*30].split(b'\0')[0].decode() for i in range(v['data_count'])];rows.append(v)
   assert rows==table[n]
  elif n.endswith('plug_info'): assert [list(struct.unpack_from('<ii',b,p)) for p in range(0,len(b),8)]==table[n]
  else: assert [list(struct.unpack_from('<qii',b,p)) for p in range(0,len(b),16)]==table[n]

x=ctypes.CDLL('libxxhash.so.0');x.XXH64.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.c_uint64];x.XXH64.restype=ctypes.c_uint64
expected={'mca_qcom_smem_is_zero_speed':'_ZTSFu3i32vE','mca_charge_mievent_report':'_ZTSFvu3i32PvS_E','mca_charge_mievent_set_state':'_ZTSFv24charge_mievent_state_eleu3i32E'}
kcfi={}
for mod in ['mca_qcom_smem','mca_charge_mievent']:
 with Path(stock[mod]['path']).open('rb') as f:
  e=ELFFile(f)
  for s in e.get_section_by_name('.symtab').iter_symbols():
   if s.name not in expected:continue
   prefix=struct.unpack_from('<I',e.get_section(s['st_shndx']).data(),s['st_value']-4)[0]
   mangled=(expected[s.name]+'.normalized').encode();want=x.XXH64(mangled,len(mangled),0)&0xffffffff
   assert prefix==want,(s.name,hex(prefix),hex(want))
   kcfi[s.name]={'stock_kcfi':hex(prefix),'declared_type_kcfi':hex(want),'mangled_normalized':mangled.decode(),'matches':True}

mods=[]
for name,h in [('mca_qcom_smem','mca_smem.h'),('mca_charge_mievent','mca_charge_mievent.h')]:
 st=stock[name]
 deps=['mca_log']+(['smem'] if name=='mca_qcom_smem' else ['mca_event','miev'])
 regdeps=[P+'mca_common/mca_log']+(['drivers/soc/qcom/smem'] if name=='mca_qcom_smem' else [P+'mca_common/mca_event','drivers/misc/miev/miev'])
 srcs=[P+'mca_common/'+name+'.c',P+'include/mca/common/'+h,P+'include/mca/common/mca_log.h']
 if name=='mca_charge_mievent':srcs += [P+'include/mca/common/mca_event.h','include/miev/mievent.h']
 imports=['qcom_smem_alloc','qcom_smem_get'] if name=='mca_qcom_smem' else ['cdev_tevent_alloc','cdev_tevent_add_int','cdev_tevent_add_str','cdev_tevent_write','cdev_tevent_destroy','mca_event_report_uevent']
 mods.append({'name':name,'registration_name':P+'mca_common/'+name,'out':name+'.ko','config':'CONFIG_MYRON_MCA_PLATFORM','srcs':srcs,'includes':[P+'include','include'],'deps':regdeps,'expected_exports':st['exports'],'required_dependencies':deps,'aliases':[],'parameters':[],'required_imports':imports,'stock_sha256':st['sha256']})
for m in mods:
 p=R/'candidate'/(P+'mca_common/'+m['name']+'.c')
 assert sorted(set(re.findall(r'EXPORT_SYMBOL(?:_GPL)?\((\w+)\)',p.read_text())))==m['expected_exports']
writes=[{'path':str(p.relative_to(R/'candidate')),'source':str(p.relative_to(R)),'sha256':sha(p)} for p in sorted((R/'candidate').rglob('*')) if p.is_file()]
integration={'schema':1,'upstream':{'repository':'unmoved21/android_kernel_xiaomi_onyx','commit':'8276ba954d8076303a5ae0f7b15d4092d66bdff6'},'sources':sources,'modules':mods,'writes':writes,'tests':{'runner':'tests/run_helpers.sh','argument':'PAYLOAD','standalone_stubs':True},'limitations':[
 'Source-build candidates only; not target-DDK-built or hardware-tested in this review.',
 'SMEM exports only the stock Myron zero-speed getter. Onyx verify/cell-SN APIs and bytes 0x24/0x25 are not assumed present.',
 'SMEM item 0x51 is a borrowed mapping: exit deliberately does not repeat the stock kfree bug. Short mappings fail and no pointer is published on errors.',
 'Mievent retains all 61 Myron numeric records and initial 53 plug/eight timer settings, including the stock event-19 NULL-data-type/one-count combination.',
 'Mievent adds locked/saturating rate limits, prevalidation of null/overlong string elements, and transport append-failure cleanup. Failed allocation still consumes the reserved stock report allowance.',
 'Mievent uses boottime seconds. Stock uses coarse boottime; boundary sampling granularity can differ. It does not implement charging decisions.',
 'No DT changes, hardware ICs, charger storage writes, or charging-policy modules are enabled.',
 'Panel and wireless remain deferred for documented provider/enum-type blockers.'
 ],'flashable':False,'hardware_tested':False}
dump(R/'integration.json',integration)
test=subprocess.run(['bash',str(R/'tests/run_helpers.sh'),str(R/'candidate')],text=True,capture_output=True)
(R/'tests/host-results.log').write_text(test.stdout+test.stderr);assert test.returncode==0,test.stderr
audit={'schema':1,'status':'two_helpers_ready_for_source_build','stock':{k:{'sha256':v['sha256'],'exports':v['exports'],'imports':v['imports'],'depends':[a[8:] for a in v['modinfo'] if a.startswith('depends=')]} for k,v in stock.items()},'kcfi':kcfi,'mievent_tables':tables,'validation':{'host_tests':test.stdout.strip(),'stock_table_records':61,'stock_plug_entries':53,'stock_timer_entries':8,'source_blob_sha1_verified':8,'candidate_sources':4,'source_modules':2,'target_compiled':False,'hardware_tested':False},'deliberate_differences':integration['limitations'],'deferred':{
 'mca_qcom_panel':{'target_reference':'LineageOS/android_kernel_qcom_sm8850@557159b6a0d06f1c6f07ec4c1f22bc9309a113e4','findings':['Target panel enum lacks the Myron HBM on/off extension (stock numeric types 5/6).','Stock panel event dispatcher sends MCA type 7 with event 0x3a/0x3b; r8 Onyx-derived shared header uses 0x3e/0x3f.','Target notifier unregister clears a slot but does not wait for handlers fetched before unlock; direct client devm remove risks stale callback private data.','Stock exported screen/HBM getters return zero even though event callbacks update fields; Onyx getters read state, so behavior is not identical.'],'candidate_installed':False},
 'mca_platform_wireless_class':{'dispatches_audited':66,'ops_table_bytes':528,'slot_gaps':[],'findings':['All 66 dispatch slot offsets and callback KCFI hashes are preserved in wireless-contract.json.','Stock has nine exports absent from Onyx and multiple source-only extensions.','set_enable_mode forwards mode32,bool,data, not the two-argument Onyx callback; its 0x7db8e812 callback type requires the real named mode enum.','get_debug_fod_type callback hash 0xa1a7d707 does not match the selected Onyx enum name/type proof.','rx/tx error getters forward two u8 pointers plus data, not one.','get_rx_brg_status output is one-byte pointed type (0xb87fa2fc), not the source int pointer.','New wrappers cannot be safely published until exact enum identities and callback parameter widths are verified.'],'candidate_installed':False}
 }}
dump(R/'audit.json',audit)
print(json.dumps({'modules':[m['name'] for m in mods],'writes':len(writes),'kcfi':kcfi,'test':test.stdout.strip()},indent=2))
