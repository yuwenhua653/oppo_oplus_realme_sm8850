from pathlib import Path
import json,re,hashlib,shutil
R=Path(__file__).resolve().parent
P='drivers/power/supply/mca/'
def write(p,s):
 f=R/'candidate'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
smem='''// SPDX-License-Identifier: GPL-2.0
/* Myron SMEM battery information. Derived from the pinned Xiaomi MCA source.
 * The Myron stock ABI exports one int(void) getter and owns a 36-byte item.
 * The returned qcom_smem_get mapping is borrowed and must never be kfree'd.
 */
#include <linux/module.h>
#include <linux/types.h>
#include <linux/err.h>
#include <linux/compiler.h>
#include <linux/soc/qcom/smem.h>
#include <mca/common/mca_log.h>
#include <mca/common/mca_smem.h>

#ifndef MCA_LOG_TAG
#define MCA_LOG_TAG "mca_smem"
#endif
#define SMEM_ID_VENDOR_BATTERY_INFO 0x51
struct mca_smem_battery_info {
 u32 reserved[8];
 u32 zero_speed_start_mode;
};
static struct mca_smem_battery_info *batt_info;

int mca_qcom_smem_is_zero_speed(void)
{
 struct mca_smem_battery_info *info = READ_ONCE(batt_info);
 if (!info)
  return -ENODEV;
 return READ_ONCE(info->zero_speed_start_mode);
}
EXPORT_SYMBOL(mca_qcom_smem_is_zero_speed);

static int __init mca_qcom_smem_init(void)
{
 struct mca_smem_battery_info *info;
 size_t size = 0;
 int ret;
 ret = qcom_smem_alloc(QCOM_SMEM_HOST_ANY, SMEM_ID_VENDOR_BATTERY_INFO,
                       sizeof(*info));
 if (ret < 0 && ret != -EEXIST) {
  mca_log_err("unable to allocate battery SMEM: %d\\n", ret);
  return -EPROBE_DEFER;
 }
 info = qcom_smem_get(QCOM_SMEM_HOST_ANY, SMEM_ID_VENDOR_BATTERY_INFO, &size);
 if (IS_ERR_OR_NULL(info)) {
  mca_log_err("unable to acquire battery SMEM\\n");
  return -EPROBE_DEFER;
 }
 if (size < sizeof(*info))
  return -EINVAL;
 WRITE_ONCE(batt_info, info);
 return 0;
}
module_init(mca_qcom_smem_init);
static void __exit mca_qcom_smem_exit(void)
{
 WRITE_ONCE(batt_info, NULL);
}
module_exit(mca_qcom_smem_exit);
MODULE_DESCRIPTION("mca get smem info");
MODULE_AUTHOR("liuliang10@xiaomi.com");
MODULE_LICENSE("GPL v2");
'''
write(P+'mca_common/mca_qcom_smem.c',smem)
write(P+'include/mca/common/mca_smem.h','''/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _MCA_COMMON_MCA_SMEM_H_
#define _MCA_COMMON_MCA_SMEM_H_
int mca_qcom_smem_is_zero_speed(void);
#endif
''')

# Restore the Myron numeric event ABI from its complete ELF data table. The
# public Onyx implementation provides the encoding/transport algorithm, but its
# 50 positional IDs cannot be used with Myron callers expecting 61 IDs.
table=json.loads((R/'stock-mievent-table.json').read_text())
src=(R/'upstream'/P/'mca_common/mca_charge_mievent.c').read_text()
hdr=(R/'upstream'/P/'include/mca/common/mca_charge_mievent.h').read_text()
codes={n:int(v) for n,v in re.findall(r'(MIEVENT_CODE_\w+) = (\d+)',hdr)}
oldrows=re.findall(r'\{\s*\.event_code\s*=\s*(\w+).*?\.type_index\s*=\s*(\w+).*?\},',src,re.S)
# The stock numeric IDs, not Onyx order, are authoritative. Existing symbolic
# names keep their meanings by resolving through their fixed event code.
enum=re.search(r'enum charge_mievent_type_index \{(.*?)\};',hdr,re.S)
names=re.findall(r'\bCHARGE_DFX_\w+',enum[1])[:-1]
source_entries=re.findall(r'\.event_code\s*=\s*(\w+)',src)
old_code_names={codes[c]:n for c,n in zip(source_entries,names)}
new=[]
for v in table['g_charge_mievent_info']:
 name=old_code_names.get(v['event_code'],'CHARGE_DFX_MYRON_EVENT_'+str(v['event_code']))
 new.append('    '+name+' = '+str(v['index'])+',')
hdr=hdr[:enum.start()]+ 'enum charge_mievent_type_index {\n'+'\n'.join(new)+'\n    CHARGE_DFX_MAX_NUM = 61,\n};'+hdr[enum.end():]
# Public plug IDs must match the stock table too. Match source meanings via
# original upload type and event-code constants.
old_to_code={name:codes[code] for code,name in oldrows if name.startswith('PLUG_TYPE_')}
start=hdr.index('enum mievent_upload_type_plug_ele {');end=hdr.index('\n};',start)+3
plug_names={v:k for k,v in old_to_code.items()}
new=['    '+plug_names.get(v['event_code'],'PLUG_TYPE_MYRON_EVENT_'+str(v['event_code']))+' = '+str(v['type_index'])+',' for v in table['g_charge_mievent_info'] if v['upload_type']==0]
hdr=hdr[:start]+'enum mievent_upload_type_plug_ele {\n'+'\n'.join(new)+'\n    PLUG_TYPE_MAX_NUM = 53,\n};'+hdr[end:]
write(P+'include/mca/common/mca_charge_mievent.h',hdr)
pos=src.index('static struct charge_mievent_info')
src=src[:pos]
# The report implementation is always real: its DDK target depends on miev.
src=src.replace('#if IS_ENABLED(CONFIG_MIEV)\n#include <miev/mievent.h>\n#endif','#include <miev/mievent.h>\n#include <linux/mutex.h>\n#include <linux/ktime.h>')
src=src.replace('#if IS_ENABLED(CONFIG_MIEV)\n','')
src+='/* Positional event ABI decoded from Myron stock; all 61 records retained. */\nstatic const struct charge_mievent_info g_charge_mievent_info[] = {\n'
for v in table['g_charge_mievent_info']:
 src+=' { /* ID '+str(v['index'])+' */\n'
 for key in ['event_code','event_type','event_describe','upload_type','type_index','data_type','data_count']:
  src+='  .'+key+' = '+json.dumps(v[key])+',\n'
 src+='  .para_name = { '+', '.join(json.dumps(x) for x in v['para_name'])+' },\n },\n'
src+='};\nstatic struct mievent_upload_type_plug g_upload_type_plug_info[PLUG_TYPE_MAX_NUM] = {\n'
src+=''.join(' { %d, %d },\n'%tuple(v) for v in table['g_upload_type_plug_info'])+'};\n'
src+='static struct mievent_upload_type_time g_upload_type_time_info[TIME_TYPE_MAX_NUM] = {\n'
src+=''.join(' { %d, %d, %d },\n'%tuple(v) for v in table['g_upload_type_time_info'])+'};\n'
src+='''
static DEFINE_MUTEX(mca_mievent_lock);

/* Only the rate-limit state is locked. Transport and event notifications can
 * sleep or call consumers, and must run after releasing the lock. Saturated
 * counts cannot wrap back into an unlimited-report state.
 */
static bool mca_mievent_reserve(const struct charge_mievent_info *info)
{
 bool report = false;
 time64_t now;
 int i = info->type_index;
 mutex_lock(&mca_mievent_lock);
 if (info->upload_type == MIEVENT_UPLOAD_TYPE_PLUG &&
     i >= 0 && i < PLUG_TYPE_MAX_NUM) {
  if (g_upload_type_plug_info[i].count < g_upload_type_plug_info[i].max_count) {
   g_upload_type_plug_info[i].count++;
   report = true;
  }
 } else if (info->upload_type == MIEVENT_UPLOAD_TYPE_TIME &&
            i >= 0 && i < TIME_TYPE_MAX_NUM) {
  now = ktime_get_boottime_seconds();
  if (!g_upload_type_time_info[i].count ||
      now - g_upload_type_time_info[i].time_last >=
                g_upload_type_time_info[i].time_interval) {
   g_upload_type_time_info[i].time_last = now;
   g_upload_type_time_info[i].count = 1;
   report = true;
  }
 }
 mutex_unlock(&mca_mievent_lock);
 return report;
}

void mca_charge_mievent_report(int event_index, void *data, int size)
{
 const struct charge_mievent_info *info;
 struct misight_mievent *event;
 struct mca_event_notify_data notice = { "MCA_LOG_FULL_EVENT", 18 };
 int *values = data;
 char **strings = data;
 int i, ret;

 if (event_index < 0 || event_index >= ARRAY_SIZE(g_charge_mievent_info))
  return;
 info = &g_charge_mievent_info[event_index];
 if (size != info->data_count || (size && !data))
  return;
 if (info->data_type == MIEVENT_DATA_TYPE_STRING) {
  for (i = 0; i < size; i++)
   if (!strings[i] || strnlen(strings[i], MIEVENT_STRING_MAX_LEN) >=
                                      MIEVENT_STRING_MAX_LEN)
    return;
 }
 if (!mca_mievent_reserve(info))
  return;
 mca_event_report_uevent(&notice);
 event = cdev_tevent_alloc(info->event_code);
 if (!event) {
  mca_log_err("cdev_tevent_alloc failed\\n");
  return;
 }
 ret = cdev_tevent_add_str(event, info->event_type, info->event_describe);
 for (i = 0; !ret && i < size; i++) {
  if (info->data_type == MIEVENT_DATA_TYPE_INT)
   ret = cdev_tevent_add_int(event, info->para_name[i], values[i]);
  else if (info->data_type == MIEVENT_DATA_TYPE_STRING)
   ret = cdev_tevent_add_str(event, info->para_name[i], strings[i]);
 }
 if (!ret)
  cdev_tevent_write(event);
 cdev_tevent_destroy(event);
}
EXPORT_SYMBOL_GPL(mca_charge_mievent_report);

void mca_charge_mievent_set_state(enum charge_mievent_state_ele state, int value)
{
 const struct charge_mievent_info *info;
 int i;
 mutex_lock(&mca_mievent_lock);
 if (state == MIEVENT_STATE_PLUG && !value) {
  for (i = 0; i < PLUG_TYPE_MAX_NUM; i++)
   g_upload_type_plug_info[i].count = 0;
 } else if (state == MIEVENT_STATE_END && value >= 0 &&
            value < ARRAY_SIZE(g_charge_mievent_info)) {
  info = &g_charge_mievent_info[value];
  i = info->type_index;
  if (info->upload_type == MIEVENT_UPLOAD_TYPE_PLUG && i < PLUG_TYPE_MAX_NUM)
   g_upload_type_plug_info[i].count = 0;
  else if (info->upload_type == MIEVENT_UPLOAD_TYPE_TIME && i < TIME_TYPE_MAX_NUM) {
   g_upload_type_time_info[i].time_last = 0;
   g_upload_type_time_info[i].count = 0;
  }
 }
 mutex_unlock(&mca_mievent_lock);
}
EXPORT_SYMBOL_GPL(mca_charge_mievent_set_state);
MODULE_DESCRIPTION("mca charge mievent");
MODULE_AUTHOR("lvxiaofeng@xiaomi.com");
MODULE_LICENSE("GPL v2");
'''
write(P+'mca_common/mca_charge_mievent.c',src)
