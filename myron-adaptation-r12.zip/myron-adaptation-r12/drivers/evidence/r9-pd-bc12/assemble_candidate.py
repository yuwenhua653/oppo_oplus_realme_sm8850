from pathlib import Path
import json,re,shutil,hashlib
R=Path(__file__).resolve().parent
U=R/'upstream'; C=R/'candidate'
PD='drivers/power/supply/mca/mca_protocol/protocol_pd/mca_protocol_pd_class.c'
PH='drivers/power/supply/mca/include/mca/protocol/protocol_pd_class.h'
BC='drivers/power/supply/mca/mca_platform/mca_platform_bc12_class.c'
BH='drivers/power/supply/mca/include/mca/platform/platform_bc12_class.h'
for p in [PD,PH,BC,BH]:
 (C/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(U/p,C/p)
def replace_fn(s,name,body):
 m=re.search(r'(?m)^(?:static )?(?:unsigned int|int|void|ssize_t)\s+(?:__exit\s+)?'+name+r'\s*\(',s)
 assert m,name
 b=s.index('{',m.start());level=1;i=b+1
 while level:
  if s[i]=='{':level+=1
  elif s[i]=='}':level-=1
  i+=1
 return s[:m.start()]+body+s[i:]
h=(C/PH).read_text();h=h.replace('\tint max_current;\n};','\tint max_current;\n\t/* Stock provider record discriminator: 0=fixed, 3=augmented. */\n\tint pdo_type;\n};',1)
line='\tint (*protocol_pd_get_has_dp)(bool *has_dp, void *data);\n'
h=h.replace(line,'');h=h.replace('\tint (*protocol_pd_request_vdm_cmd)',line+'\tint (*protocol_pd_request_vdm_cmd)')
h=h.replace('\tint (*protocol_pd_get_zimi_cypress_flag)(int *zimi_cypress_flag, void *data);','\tint (*protocol_pd_get_zimi_cypress_flag)(int *zimi_cypress_flag, void *data);\n\tint (*protocol_pd_get_support_keep_pdo)(int *support, void *data);')
h=h.replace('int protocol_class_pd_get_port_num(void);','int protocol_class_pd_get_support_keep_pdo(unsigned int port_num, int *support);\n/* Sleepable context, outside dispatched PD callbacks; unregister before free. */\nint protocol_class_pd_unregister_ops(unsigned int port_num, struct protocol_class_pd_ops *ops, void *data);\nint protocol_class_pd_get_port_num(void);')
h=h.replace('(*protocol_pd_fixed_pdo_set_vol)(int volt','(*protocol_pd_fixed_pdo_set_vol)(unsigned int volt')
(C/PH).write_text(h)
s=(C/PD).read_text().replace('#include <mca/shared_memory/charger_partition_class.h>','#include <linux/srcu.h>\n#include <linux/limits.h>\n#include <linux/string.h>')
start=s.index('static struct protocol_class_pd_ops_data g_protocol_pd_data')
end=s.index('int protocol_class_pd_get_pps_max_power',start)
s=s[:start]+'''static struct protocol_class_pd_ops_data __rcu *g_protocol_pd_data[TYPEC_PORT_MAX];
static DEFINE_MUTEX(g_pd_provider_lock);
DEFINE_STATIC_SRCU(g_pd_provider_srcu);
static DEFINE_MUTEX(g_pd_probe_lock);
static DEFINE_MUTEX(g_pd_state_lock);
static bool g_pd_bound;
static unsigned int g_cur_port;
static struct notifier_block g_pd_class_ntf, g_connect_nb, g_type_change_nb;
static int device_max_power;
static int support_mode;
static unsigned int max_apdo_max;
static int protocol_class_pps_get_pwr_cap(void *data, struct adapter_power_cap_info *pwr_cap);

'''+s[end:]
# Convert all 50 public dispatch wrappers to a paired snapshot protected by SRCU.
rx=re.compile(r'(?m)^int (protocol_class_pd_\w+)\(([^\n]*(?:\n\s+[^\n]*)?)\)\n\{\n\tstruct protocol_class_pd_ops_data \*temp_data = protocol_class_pd_get_ops_data\(port_num\);.*?\n\}',re.S)
# bounded per-function regex rather than greedy parameter matching
count=0
for name in re.findall(r'^int (protocol_class_pd_\w+)\(',s,re.M):
 m=re.search(r'^int '+name+r'\((.*?)\)\n\{(.*?)\n\}',s,re.M|re.S)
 if not m or 'protocol_class_pd_get_ops_data(port_num)' not in m.group(2):continue
 cb=re.search(r'protocol_class_pd_invalid_ops\(temp_data, (\w+)\)',m.group(2)).group(1)
 call=re.search(r'return (temp_data->ops->.*?);',m.group(2),re.S).group(1)
 params=m.group(1);args=[x.strip() for x in params.replace('\n',' ').split(',')]
 pointers=[re.search(r'(\w+)$',x).group(1) for x in args if '*' in x]
 guards=['port_num >= TYPEC_PORT_MAX']+['!'+x for x in pointers]
 if name.endswith('get_current_state'):guards+=['len <= 0']
 if name.endswith('request_vdm_cmd'):
  guards=['port_num >= TYPEC_PORT_MAX','(!data && data_len)']
 body='int '+name+'('+params+')\n{\n\tstruct protocol_class_pd_ops_data *temp_data;\n\tint idx, ret = -1;\n\n\tif ('+' || '.join(guards)+')\n\t\treturn -EINVAL;\n\tidx = srcu_read_lock(&g_pd_provider_srcu);\n\ttemp_data = srcu_dereference(g_protocol_pd_data[port_num], &g_pd_provider_srcu);\n\tif (!protocol_class_pd_invalid_ops(temp_data, '+cb+'))\n\t\tret = '+call+';\n\tsrcu_read_unlock(&g_pd_provider_srcu, idx);\n\treturn ret;\n}'
 s=s[:m.start()]+body+s[m.end():];count+=1
assert count==50,count
s=replace_fn(s,'protocol_class_pd_get_pdos',r'''int protocol_class_pd_get_pdos(unsigned int port_num, struct pd_pdo *pdos, int count)
{
	struct protocol_class_pd_ops_data *entry;
	struct pd_pdo raw[PROTOCOL_PD_MAX_PDO_NUMS] = { 0 };
	int idx, ret = -1, i, verified = 0;

	if (port_num >= TYPEC_PORT_MAX || !pdos || count < 1 ||
	    count > PROTOCOL_PD_MAX_PDO_NUMS)
		return -EINVAL;
	idx = srcu_read_lock(&g_pd_provider_srcu);
	entry = srcu_dereference(g_protocol_pd_data[port_num], &g_pd_provider_srcu);
	if (protocol_class_pd_invalid_ops(entry, protocol_pd_get_pdos))
		goto out;
	ret = entry->ops->protocol_pd_get_pdos(raw, count, entry->data);
	if (ret)
		goto out;
	/* Stock walks 16-byte records without compacting their indices. Clear
	 * rejected output slots so stale caller data cannot become a capability. */
	memset(pdos, 0, sizeof(*pdos) * count);
	for (i = 0; i < count; i++) {
		if (raw[i].pdo_type == 0) {
			pdos[i] = raw[i];
			continue;
		}
		if (raw[i].pdo_type != 3 || raw[i].max_current < 500 ||
		    raw[i].max_volt > 22000)
			continue;
		if (raw[i].max_current > 1700 &&
		    (s64)raw[i].max_volt * raw[i].max_current <= 22000000 &&
		    entry->ops->protocol_pd_get_pd_verifed)
			entry->ops->protocol_pd_get_pd_verifed(&verified, entry->data);
		/* Stock's tentative 1700mA destination store is overwritten by
		 * the following full raw-record copy (ELF .text 0x165c -> 0x158c).
		 * Preserve that effective behavior; do not invent a new limit. */
		pdos[i] = raw[i];
	}
 out:
	srcu_read_unlock(&g_pd_provider_srcu, idx);
	return ret;
}''')
s=replace_fn(s,'protocol_class_pd_get_port_num','''int protocol_class_pd_get_port_num(void)
{
	return READ_ONCE(g_cur_port);
}''')
s=replace_fn(s,'protocol_class_pd_register_ops',r'''int protocol_class_pd_register_ops(unsigned int port_num, struct protocol_class_pd_ops *ops, void *data)
{
	struct protocol_class_pd_ops_data *entry, *old;

	if (port_num >= TYPEC_PORT_MAX || !ops)
		return -EINVAL;
	entry = kmalloc(sizeof(*entry), GFP_KERNEL);
	if (!entry)
		return -ENOMEM;
	entry->ops = ops;
	entry->data = data;
	mutex_lock(&g_pd_provider_lock);
	old = rcu_replace_pointer(g_protocol_pd_data[port_num], entry,
				  lockdep_is_held(&g_pd_provider_lock));
	mutex_unlock(&g_pd_provider_lock);
	synchronize_srcu(&g_pd_provider_srcu);
	kfree(old);
	return 0;
}''')
insert=r'''
int protocol_class_pd_unregister_ops(unsigned int port_num, struct protocol_class_pd_ops *ops, void *data)
{
	struct protocol_class_pd_ops_data *old;

	if (port_num >= TYPEC_PORT_MAX || !ops)
		return -EINVAL;
	mutex_lock(&g_pd_provider_lock);
	old = rcu_dereference_protected(g_protocol_pd_data[port_num],
				       lockdep_is_held(&g_pd_provider_lock));
	if (!old || old->ops != ops || old->data != data) {
		mutex_unlock(&g_pd_provider_lock);
		synchronize_srcu(&g_pd_provider_srcu);
		return -ENOENT;
	}
	RCU_INIT_POINTER(g_protocol_pd_data[port_num], NULL);
	mutex_unlock(&g_pd_provider_lock);
	synchronize_srcu(&g_pd_provider_srcu);
	kfree(old);
	return 0;
}
EXPORT_SYMBOL(protocol_class_pd_unregister_ops);

int protocol_class_pd_get_support_keep_pdo(unsigned int port_num, int *support)
{
	struct protocol_class_pd_ops_data *entry;
	int idx, ret = -1;

	if (port_num >= TYPEC_PORT_MAX || !support)
		return -EINVAL;
	idx = srcu_read_lock(&g_pd_provider_srcu);
	entry = srcu_dereference(g_protocol_pd_data[port_num], &g_pd_provider_srcu);
	if (!protocol_class_pd_invalid_ops(entry, protocol_pd_get_support_keep_pdo))
		ret = entry->ops->protocol_pd_get_support_keep_pdo(support, entry->data);
	srcu_read_unlock(&g_pd_provider_srcu, idx);
	return ret;
}
EXPORT_SYMBOL(protocol_class_pd_get_support_keep_pdo);
'''
s=s.replace('EXPORT_SYMBOL(protocol_class_pd_register_ops);','EXPORT_SYMBOL(protocol_class_pd_register_ops);\n'+insert)
s=s.replace('g_cur_port,','READ_ONCE(g_cur_port),')
# These two bodies already exist in the pinned source and stock. Make limitation explicit.
s=s.replace('static int protocol_class_pd_get_max_power','/* Inherited stock no-op (verified .text 0x2350); no new functionality claimed. */\nstatic int protocol_class_pd_get_max_power')
s=s.replace('static int protocol_class_pd_get_adapter_info','/* Inherited stock no-op (verified .text 0x2770); no new functionality claimed. */\nstatic int protocol_class_pd_get_adapter_info')
# Safe conversion shared by fixed and PPS capability aggregation.
helper=r'''static int protocol_pd_pdo_power(const struct pd_pdo *pdo, int *power)
{
	s64 result = (s64)pdo->max_volt * pdo->max_current / 1000;

	if (pdo->max_volt < 0 || pdo->min_volt < 0 || pdo->max_current < 0 ||
	    result > INT_MAX)
		return -ERANGE;
	*power = result;
	return 0;
}

'''
s=s.replace('static int protocol_class_pd_get_pwr_cap',helper+'static int protocol_class_pd_get_pwr_cap',1)
s=s.replace('pwr_cap->cap[pwr_cap->nums].max_power = pdos[i].max_volt * pdos[i].max_current / 1000;', 'if (protocol_pd_pdo_power(&pdos[i], &pwr_cap->cap[pwr_cap->nums].max_power))\n\t\t\treturn -ERANGE;')
s=s.replace('if (pwr_cap == NULL || pwr_cap->nums == 0)','if (!pwr_cap || !curr || pwr_cap->nums <= 0 || pwr_cap->nums > ADAPTER_CAP_MAX_NR)')
s=s.replace('for (i = 0; i < ADAPTER_CAP_MAX_NR; i++) {','for (i = 0; i < pwr_cap->nums; i++) {',1)
s=replace_fn(s,'protocol_class_pps_adapter_get_max_power',r'''/* Exact stock mapping table (.rodata 0x0, 20 little-endian words). */
static int protocol_pd_map_power(int power, int adv_curr, int type)
{
	static const int map[][2] = {
		{50,50}, {55,55}, {60,65}, {65,65}, {67,67},
		{90,90}, {96,100}, {100,100}, {120,120}, {210,210},
	};
	int i;

	if (type == XM_CHARGER_TYPE_PD_VERIFY)
		return power;
	if (power >= 96 && (adv_curr == 4800 || adv_curr == 5000))
		return 100;
	for (i = 0; i < ARRAY_SIZE(map); i++)
		if (power == map[i][0])
			return map[i][1];
	if (power >= 210) return 210;
	if (power >= 120) return 120;
	if (power >= 100) return 100;
	if (power >= 90) return 90;
	if (power >= 67) return 67;
	if (power >= 65) return 65;
	if (power >= 55) return 55;
	if (power >= 50) return 50;
	return power;
}

static int protocol_class_pps_adapter_get_max_power(void *data, unsigned int *max_power)
{
	struct adapter_power_cap_info pwr_cap = { 0 };
	int type = XM_CHARGER_TYPE_UNKNOW, power = 0, adv_curr = 0, i, ret;

	if (!max_power)
		return -EINVAL;
	*max_power = 0;
	ret = protocol_class_pd_get_pd_type(READ_ONCE(g_cur_port), &type);
	if (ret)
		return ret;
	if (type != XM_CHARGER_TYPE_PPS && type != XM_CHARGER_TYPE_PD_VERIFY)
		return 0;
	ret = protocol_class_pps_get_pwr_cap(NULL, &pwr_cap);
	if (ret)
		return ret;
	for (i = 0; i < pwr_cap.nums; i++) {
		if (support_mode == 2 && type == XM_CHARGER_TYPE_PPS &&
		    pwr_cap.cap[i].max_voltage >= 11001)
			continue;
		power = max(power, pwr_cap.cap[i].max_power / 1000);
	}
	protocol_class_pps_adapter_get_adv_current(&pwr_cap, MCA_PPS_MAX_VOL_10V, &adv_curr);
	power = protocol_pd_map_power(power, adv_curr, type);
	*max_power = min(power, device_max_power);
	return 0;
}''')
s=s.replace('\tint i;\n\treturn 0;\n\n\tfor (i = 0; i < TYPEC_PORT_MAX;', '\tint i;\n\n\tfor (i = 0; i < TYPEC_PORT_MAX;')
s=s.replace('\t\tprotocol_class_pd_get_snk_src_mode(i, &snk_src_mode);','\t\tsnk_src_mode = TYPEC_UNATTACH;\n\t\tif (protocol_class_pd_get_snk_src_mode(i, &snk_src_mode))\n\t\t\tcontinue;')
s=s.replace('g_cur_port = protocol_pd_update_port_num();','WRITE_ONCE(g_cur_port, protocol_pd_update_port_num());')
# Additional stock notifiers and sticky max until disconnect.
pos=s.index('enum pd_attr_list')
s=s[:pos]+r'''static unsigned int protocol_pd_record_max(unsigned int power)
{
	unsigned int result;
	mutex_lock(&g_pd_state_lock);
	max_apdo_max = max(max_apdo_max, power);
	result = max_apdo_max;
	mutex_unlock(&g_pd_state_lock);
	return result;
}

static int protocol_pd_connect_cb(struct notifier_block *nb, unsigned long action, void *data)
{
	if (action == MCA_EVENT_USB_DISCONNECT) {
		mutex_lock(&g_pd_state_lock);
		max_apdo_max = 0;
		mutex_unlock(&g_pd_state_lock);
	}
	return NOTIFY_DONE;
}

static int protocol_type_change_cb(struct notifier_block *nb, unsigned long action, void *data)
{
	unsigned int power = 0;
	if (action == MCA_EVENT_CHARGE_CAP_CHANGE &&
	    !protocol_class_pps_adapter_get_max_power(NULL, &power))
		protocol_pd_record_max(power);
	return NOTIFY_DONE;
}

'''+s[pos:]
s=s.replace('protocol_class_pps_adapter_get_max_power(NULL, (unsigned int *)(&val));','protocol_class_pps_adapter_get_max_power(NULL, (unsigned int *)(&val));\n\t\tval = protocol_pd_record_max(val);')
s=replace_fn(s,'protocol_pd_class_probe',r'''static int protocol_pd_class_probe(struct platform_device *pdev)
{
	int ret;

	mutex_lock(&g_pd_probe_lock);
	if (g_pd_bound) {
		ret = -EBUSY;
		goto out;
	}
	mca_parse_dts_u32(pdev->dev.of_node, "max_power", (u32 *)&device_max_power, 0);
	mca_parse_dts_u32(pdev->dev.of_node, "support_mode", (u32 *)&support_mode, 0);
	if (device_max_power < 0 || support_mode < 0) {
		ret = -EINVAL;
		goto out;
	}
	WRITE_ONCE(g_cur_port, 0);
	mutex_lock(&g_pd_state_lock);
	max_apdo_max = 0;
	mutex_unlock(&g_pd_state_lock);
	ret = protocol_class_register_ops(ADAPTER_PROTOCOL_PD, &g_protocol_pd_ops, NULL);
	if (ret) goto out;
	ret = protocol_class_register_ops(ADAPTER_PROTOCOL_PPS, &g_protocol_pps_ops, NULL);
	if (ret) goto unregister_pd;
	g_pd_class_ntf.notifier_call = protocol_pd_notify_cb;
	g_connect_nb.notifier_call = protocol_pd_connect_cb;
	g_type_change_nb.notifier_call = protocol_type_change_cb;
	ret = mca_event_block_notify_register(MCA_EVENT_TYPE_TYPEC_PORT_STATUS, &g_pd_class_ntf);
	if (ret) goto unregister_pps;
	ret = mca_event_block_notify_register(MCA_EVENT_TYPE_CHARGER_CONNECT, &g_connect_nb);
	if (ret) goto unregister_port;
	ret = mca_event_block_notify_register(MCA_EVENT_TYPE_CHARGE_TYPE, &g_type_change_nb);
	if (ret) goto unregister_connect;
	ret = pd_sysfs_create_files();
	if (ret) goto unregister_type;
	g_pd_bound = true;
	platform_set_drvdata(pdev, &g_pd_bound);
	goto out;
 unregister_type:
	mca_event_block_notify_unregister(MCA_EVENT_TYPE_CHARGE_TYPE, &g_type_change_nb);
 unregister_connect:
	mca_event_block_notify_unregister(MCA_EVENT_TYPE_CHARGER_CONNECT, &g_connect_nb);
 unregister_port:
	mca_event_block_notify_unregister(MCA_EVENT_TYPE_TYPEC_PORT_STATUS, &g_pd_class_ntf);
 unregister_pps:
	protocol_class_unregister_ops(ADAPTER_PROTOCOL_PPS, &g_protocol_pps_ops, NULL);
 unregister_pd:
	protocol_class_unregister_ops(ADAPTER_PROTOCOL_PD, &g_protocol_pd_ops, NULL);
 out:
	mutex_unlock(&g_pd_probe_lock);
	return ret;
}''')
s=replace_fn(s,'protocol_pd_class_remove',r'''static void protocol_pd_class_remove(struct platform_device *pdev)
{
	mutex_lock(&g_pd_probe_lock);
	if (platform_get_drvdata(pdev)) {
		mca_sysfs_remove_files(SYSFS_DEV_3, pd_class_sysfs_field_tbl, PD_SYSFS_ATTRS_SIZE);
		mca_event_block_notify_unregister(MCA_EVENT_TYPE_CHARGE_TYPE, &g_type_change_nb);
		mca_event_block_notify_unregister(MCA_EVENT_TYPE_CHARGER_CONNECT, &g_connect_nb);
		mca_event_block_notify_unregister(MCA_EVENT_TYPE_TYPEC_PORT_STATUS, &g_pd_class_ntf);
		protocol_class_unregister_ops(ADAPTER_PROTOCOL_PPS, &g_protocol_pps_ops, NULL);
		protocol_class_unregister_ops(ADAPTER_PROTOCOL_PD, &g_protocol_pd_ops, NULL);
		g_pd_bound = false;
		platform_set_drvdata(pdev, NULL);
	}
	mutex_unlock(&g_pd_probe_lock);
}''')
s=replace_fn(s,'protocol_pd_class_exit',r'''static void __exit protocol_pd_class_exit(void)
{
	struct protocol_class_pd_ops_data *old[TYPEC_PORT_MAX];
	int i;

	platform_driver_unregister(&protocol_pd_class_driver);
	mutex_lock(&g_pd_provider_lock);
	for (i = 0; i < TYPEC_PORT_MAX; i++)
		old[i] = rcu_replace_pointer(g_protocol_pd_data[i], NULL,
					   lockdep_is_held(&g_pd_provider_lock));
	mutex_unlock(&g_pd_provider_lock);
	synchronize_srcu(&g_pd_provider_srcu);
	for (i = 0; i < TYPEC_PORT_MAX; i++)
		kfree(old[i]);
}''')
(C/PD).write_text(s)
# BC12 provider lifetime and protocol registration ownership.
b=(C/BC).read_text().replace('#include <linux/device.h>','#include <linux/device.h>\n#include <linux/mutex.h>\n#include <linux/srcu.h>')
b=b.replace('static struct platform_class_bc12_ops_data g_bc12_ops_data[BC12_MAX_ROLE];','static struct platform_class_bc12_ops_data __rcu *g_bc12_ops_data[BC12_MAX_ROLE];\nstatic DEFINE_MUTEX(g_bc12_lock);\nDEFINE_STATIC_SRCU(g_bc12_srcu);')
b=replace_fn(b,'platform_bc12_class_ops_register',r'''int platform_bc12_class_ops_register(unsigned int role, struct platform_bc12_class_ops *ops, void *data)
{
	struct platform_class_bc12_ops_data *entry, *old;
	if (role >= BC12_MAX_ROLE || !ops) return -EINVAL;
	entry = kmalloc(sizeof(*entry), GFP_KERNEL);
	if (!entry) return -ENOMEM;
	entry->ops = ops;
	entry->data = data;
	mutex_lock(&g_bc12_lock);
	old = rcu_replace_pointer(g_bc12_ops_data[role], entry, lockdep_is_held(&g_bc12_lock));
	mutex_unlock(&g_bc12_lock);
	synchronize_srcu(&g_bc12_srcu);
	kfree(old);
	return 0;
}''')
start=b.index('static struct platform_class_bc12_ops_data *\nplatform_class_bc12_get_ops_data')
end=b.index('static unsigned int\nplatform_class_bc12_get_role',start)
b=b[:start]+r'''int platform_bc12_class_ops_unregister(unsigned int role, struct platform_bc12_class_ops *ops, void *data)
{
	struct platform_class_bc12_ops_data *old;
	if (role >= BC12_MAX_ROLE || !ops) return -EINVAL;
	mutex_lock(&g_bc12_lock);
	old = rcu_dereference_protected(g_bc12_ops_data[role], lockdep_is_held(&g_bc12_lock));
	if (!old || old->ops != ops || old->data != data) {
		mutex_unlock(&g_bc12_lock);
		synchronize_srcu(&g_bc12_srcu);
		return -ENOENT;
	}
	RCU_INIT_POINTER(g_bc12_ops_data[role], NULL);
	mutex_unlock(&g_bc12_lock);
	synchronize_srcu(&g_bc12_srcu);
	kfree(old);
	return 0;
}
EXPORT_SYMBOL(platform_bc12_class_ops_unregister);

static int platform_class_bc12_ops_det_en(unsigned int role, int en)
{
	struct platform_class_bc12_ops_data *entry;
	int idx, ret = -1;
	if (role >= BC12_MAX_ROLE) return -EINVAL;
	idx = srcu_read_lock(&g_bc12_srcu);
	entry = srcu_dereference(g_bc12_ops_data[role], &g_bc12_srcu);
	if (entry && entry->ops->bc12_det_en)
		ret = entry->ops->bc12_det_en(en, entry->data);
	srcu_read_unlock(&g_bc12_srcu, idx);
	return ret;
}

static int platform_class_bc12_ops_get_chg_type(unsigned int role, int *value)
{
	struct platform_class_bc12_ops_data *entry;
	int idx, ret = -1;
	if (role >= BC12_MAX_ROLE || !value) return -EINVAL;
	idx = srcu_read_lock(&g_bc12_srcu);
	entry = srcu_dereference(g_bc12_ops_data[role], &g_bc12_srcu);
	if (entry && entry->ops->get_charge_type)
		ret = entry->ops->get_charge_type(value, entry->data);
	srcu_read_unlock(&g_bc12_srcu, idx);
	return ret;
}

'''+b[end:]
b=b.replace('struct platform_class_bc12_info *platform_class_bc12;','struct platform_class_bc12_info *platform_class_bc12;\n\tint ret;')
b=b.replace('(void)protocol_class_register_ops(ADAPTER_PROTOCOL_BC12, &g_bc12_ops,\n\t\t\t\t\t  platform_class_bc12);','ret = protocol_class_register_ops(ADAPTER_PROTOCOL_BC12, &g_bc12_ops,\n\t\t\t\t\t  platform_class_bc12);\n\tif (ret)\n\t\treturn ret;')
b=replace_fn(b,'platform_class_bc12_remove',r'''static void platform_class_bc12_remove(struct platform_device *pdev)
{
	struct platform_class_bc12_info *info = platform_get_drvdata(pdev);
	if (!info) return;
	protocol_class_unregister_ops(ADAPTER_PROTOCOL_BC12, &g_bc12_ops, info);
	platform_set_drvdata(pdev, NULL);
}''')
b=replace_fn(b,'platform_class_bc12_exit',r'''static void __exit platform_class_bc12_exit(void)
{
	struct platform_class_bc12_ops_data *old[BC12_MAX_ROLE];
	int i;
	platform_driver_unregister(&platform_bc12_class_driver);
	mutex_lock(&g_bc12_lock);
	for (i = 0; i < BC12_MAX_ROLE; i++)
		old[i] = rcu_replace_pointer(g_bc12_ops_data[i], NULL, lockdep_is_held(&g_bc12_lock));
	mutex_unlock(&g_bc12_lock);
	synchronize_srcu(&g_bc12_srcu);
	for (i = 0; i < BC12_MAX_ROLE; i++) kfree(old[i]);
}''')
(C/BC).write_text(b)
h=(C/BH).read_text().replace('#endif /*','/* Sleepable context outside callback; unregister before freeing provider. */\nint platform_bc12_class_ops_unregister(unsigned int role, struct platform_bc12_class_ops *ops, void *data);\n\n#endif /*')
(C/BH).write_text(h)
print('candidate written; shared r8 headers must be overlaid for host compile')
