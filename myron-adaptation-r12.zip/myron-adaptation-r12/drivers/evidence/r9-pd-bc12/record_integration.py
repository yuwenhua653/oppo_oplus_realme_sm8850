from pathlib import Path
import json,re,hashlib
R=Path(__file__).resolve().parent;C=R/'candidate'
PD='drivers/power/supply/mca/mca_protocol/protocol_pd/mca_protocol_pd_class.c';PH='drivers/power/supply/mca/include/mca/protocol/protocol_pd_class.h';BC='drivers/power/supply/mca/mca_platform/mca_platform_bc12_class.c';BH='drivers/power/supply/mca/include/mca/platform/platform_bc12_class.h'
base=R.parents[2]/'myron-stage-r8/review/pd-bc12'
stock=json.load(open(base/'stock-disassembly.json'));audit=json.load(open(base/'stock-audit.json'))
prov={p['path']:p for p in json.load(open(R/'upstream-provenance.json'))}
H='drivers/power/supply/mca/include/mca/'
modules=[]
for path,header,name,compat,deps,headers in [
 (PD,PH,'mca_protocol_pd_class','mca,protocol_pd',['mca_common/mca_sysfs','mca_common/mca_log','mca_common/mca_parse_dts','mca_common/mca_event','mca_protocol/mca_protocol_class'],['common/mca_sysfs.h','common/mca_log.h','common/mca_parse_dts.h','common/mca_event.h','protocol/protocol_class.h']),
 (BC,BH,'mca_platform_bc12_class','mca,bc12_class',['mca_common/mca_log','mca_protocol/mca_protocol_class','mca_protocol/protocol_pd/mca_protocol_pd_class'],['common/mca_log.h','protocol/protocol_class.h','protocol/protocol_pd_class.h'])]:
 exports=sorted(set(re.findall(r'EXPORT_SYMBOL\((\w+)\)',(C/path).read_text())))
 st=stock[name];missing=sorted(set(st['exports'])-set(exports));assert not missing,missing
 modules.append({'name':name,'module':name,'registration_name':path[:-2],'out':name+'.ko','config':'CONFIG_MYRON_MCA_PLATFORM','srcs':[path,header]+[H+h for h in headers],'includes':['drivers/power/supply/mca/include'],'deps':['drivers/power/supply/mca/'+d for d in deps],'expected_exports':exports,'stock_exports':st['exports'],'source_export_delta':{'added':sorted(set(exports)-set(st['exports'])),'missing':missing},'expected_aliases':[],'expected_parameters':[],'aliases':[],'parameters':[],'required_dependencies':[d.split('/')[-1] for d in deps],'stock_sha256':st['sha256'],'dt_compatible':compat})
sources=[];writes=[]
for path in [PD,PH,BC,BH]:
 p=prov[path];up=(R/'upstream'/path).read_bytes();c=(C/path).read_bytes();blob=hashlib.sha1(b'blob '+str(len(up)).encode()+b'\0'+up).hexdigest();assert blob==p['blob_sha1'];assert hashlib.sha256(up).hexdigest()==p['sha256'];sha=hashlib.sha256(c).hexdigest()
 sources.append({'path':path,'source_path':path,'repository':p['repository'],'commit':p['commit'],'git_blob_sha1':blob,'blob_sha1':blob,'upstream_sha256':p['sha256'],'sha256':p['sha256'],'candidate_sha256':sha,'modified':True})
 writes.append({'path':path,'source':'candidate/'+path,'sha256':sha})
h=(C/PH).read_text();sig=dict(re.findall(r'int \(\*(\w+)\)\((.*?)\);',re.search(r'struct protocol_class_pd_ops \{(.*?)\n\};',h,re.S).group(1),re.S));contracts=[]
for row in audit['pd_callback_slots']:
 cb=row['source_callback'] or 'protocol_pd_get_support_keep_pdo';fn=stock['mca_protocol_pd_class']['functions'][row['function']];hh=0;found=False
 for i in fn['instructions']:
  if i['instruction'].startswith('movk\tw17,'):
   m=re.search(r'#0x([a-f0-9]+)(?:, lsl #(\d+))?',i['instruction']);v=int(m.group(1),16);shift=int(m.group(2) or 0);hh=(hh&~(65535<<shift))|(v<<shift);found=True
  if found and i['instruction'].startswith('blr'):break
 contracts.append({'wrapper':row['function'],'callback':cb,'offset':row['stock_offset'],'signature':'int ('+' '.join(sig[cb].split())+')','stock_kcfi':f'0x{hh:08x}'})
(R/'pd-callback-contract.json').write_text(json.dumps({'stock_sha256':stock['mca_protocol_pd_class']['sha256'],'callbacks':contracts,'note':'KCFI values decoded from original AArch64 callback checks. Source offsets/prototype forwarding tested; target compiler-generated KCFI still needs CI artifact validation.'},indent=2)+'\n')
review={'schema':1,'decision':'two source candidates ready for gated target build; no hardware providers or DT activation','stock':{k:{'sha256':v['sha256'],'exports':v['exports'],'imports':v['imports'],'modinfo':v['modinfo']} for k,v in stock.items() if k!='charger_partition'},'verified_semantics':[
'51 PD callbacks occupy stock slots 0..400, has_dp moved to240, keep_pdo int-pointer callback appended400; two BC12 slots remain0/8.',
'PDO records16bytes, min0/max4/current8/discriminator12. Stock get_pdos .text145c..186c accepts fixed0 and APDO3 current>=500,maxvoltage<=22000; preserves indices.',
'Stock .text165c writes1700mA to caller output then1660 jumps158c; raw16byte copy at1594 overwrites it. Candidate preserves effective raw current while retaining verified callback side-effect invocation.',
'Power table .rodata0x0 size80: (50,50),(55,55),(60,65),(65,65),(67,67),(90,90),(96,100),(100,100),(120,120),(210,210); PD_VERIFY bypasses map; PPS>=96W with4800/5000mA maps100W; other values floor through210/120/100/90/67/65/55/50.',
'Stock lacks partition import; candidate removes selected-source EU partition dependency, reproduces verified-type direct power behavior.',
'Three stock notifier roles: port status8 selects first active sink/source/audio port, charger connect0 clears sticky max onUSBdisconnect0, charge type1 updates sticky max oncap change6.',
'Probe initialization precedes externally visible registrations; port event synchronously fired during registration remains visible. All partial failures unwind; remove detaches sysfs before notifier/adapter providers.',
'ActualC execution uses1159 assertions (all51dispatches, filtering/map boundaries, dualport, provider faults, sixprobe failures, immediate-register event, actual callback waiting onPD unregister/replacement andBC unregister) plus57 compile-time ABI assertions.'
], 'deliberate_safety_deltas':[
'Reject invalid ports, null output buffers, nonpositive state buffer lengths, and PDO counts outside1..7 before callbacks; stock could overrun its7entry stack scratch forlarger counts.',
'Zero rejected PDO output slots rather than retain caller old contents; no new voltage/current is fabricated.',
'Use64-bit PDO power multiplication and reject negative or overflowing capability values instead of signed overflow.',
'Provider snapshot pair usesSRCU; unregister/replace waitsforinflight callback, and new unregister APIs permit properproviderremove. Sourceprovidersmustcallunregisterbeforefree.',
'Propagate provider/capability errors in PPS animation-power helper, ratherthan claimcomputedpoweronfailure.',
'Failure rollback/singletonprobe guard andexplicit sysfs/notifier unregister cleanup extendstocklifecycle.'
], 'retained_limitations':[
'Two success-returning PD generic adapter methods are unchanged upstream ANDstock no-ops; thiscandidate doesnot claim toimplementmaxpower/adapterinformationthroughthosemethods.',
'No targetbuild, KCFI/CRC validation orhardwareexecution performed here; CI must validate new importsincludingcommon sysfs_remove_files.',
'HostSRCU modeled withpthread rwlock; kernelSRCU runtime stress isnot covered.',
'No chargerpartition, chargingIC, protocolhardwareproviderorDTnodeenablement; this is frameworksourceintegration, not a flashablekernel.'
], 'validation':{'actual_C_host_tests':True,'target_DDK_build':False,'hardware_tested':False,'flashable':False}}
(R/'source-review.json').write_text(json.dumps(review,indent=2)+'\n')
integration={'schema':1,'scope':'Myron PD and BC12 protocol class frameworks with stock ABI/policy evidence and provider lifecycle','repository':'unmoved21/android_kernel_xiaomi_onyx','commit':'8276ba954d8076303a5ae0f7b15d4092d66bdff6','modules':modules,'sources':sources,'writes':writes,'test_runner':'tests/run_pd_bc12.sh PAYLOAD','tests':{'runner':'tests/run_pd_bc12.sh','argument':'PAYLOAD'},'required_kernel_config':['TREE_SRCU'],'shared_prerequisites':['r9 shared adapter_power_cap min_voltage@8/max_voltage@12','r9 transactional mca_sysfs_create_files and mca_sysfs_remove_files export'],'validation':{'actual_C_host_tests':'1159 runtime assertions +57 compile-time ABI assertions; ASan+UBSan; provider unregistration/replacement waiting modeled withpthread rwlock','target_DDK_build':False,'hardware_tested':False,'flashable':False},'evidence':['source-review.json','pd-callback-contract.json'],'limitations':review['retained_limitations']}
(R/'integration.json').write_text(json.dumps(integration,indent=2)+'\n')
print(json.dumps({'modules':[(m['name'],len(m['expected_exports'])) for m in modules],'sources':len(sources)},indent=2))
