from pathlib import Path
import re,shutil,json
R=Path(__file__).resolve().parent;T=R/'tests';T.mkdir(exist_ok=True)
shutil.copytree(R.parents[2]/'myron-stage-r8/review/cp-fg/tests/stubs',T/'stubs',dirs_exist_ok=True)
p=T/'stubs/kernel_test.h';s=p.read_text();s=s.replace('typedef uint32_t u32;','typedef uint32_t u32;\ntypedef int64_t s64;\n#define READ_ONCE(x) __atomic_load_n(&(x),__ATOMIC_SEQ_CST)\n#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v),__ATOMIC_SEQ_CST)\n#define min(x,y) ((x)<(y)?(x):(y))\n#define max(x,y) ((x)>(y)?(x):(y))\n#define NOTIFY_OK 1\n#define NOTIFY_DONE 0\n#define EPROBE_DEFER 517\n#define SYSFS_DEV_3 "typec"\nstruct notifier_block { int (*notifier_call)(struct notifier_block*,unsigned long,void*); };')
s=s.replace('static inline int mca_parse_dts_u32(const struct device_node *d,const char *s,u32 *v,u32 def) { (void)d;(void)s;(void)def;*v=(u32)dt_num;return 0; }','static int dt_power=120,dt_mode;\nstatic inline int mca_parse_dts_u32(const struct device_node *d,const char *s,u32 *v,u32 def) { (void)d;(void)def;*v=!strcmp(s,"max_power")?dt_power:dt_mode;return 0; }')
s=s.replace('#endif','''static int notify_count,notify_fail_at,notify_live,notify_unregistered,notify_trigger;
static inline int mca_event_block_notify_register(unsigned int n,struct notifier_block *nb) { (void)n;(void)nb;notify_count++;if(notify_count==notify_fail_at)return -EIO;notify_live++;if(notify_trigger&&n==8)nb->notifier_call(nb,0,NULL);return 0; }
static inline int mca_event_block_notify_unregister(unsigned int n,struct notifier_block *nb) { (void)n;(void)nb;notify_live--;notify_unregistered++;return 0; }
static inline int mca_sysfs_create_files(const char *n,struct mca_sysfs_attr_info *a,int len) { (void)n;(void)a;(void)len;sysfs_create_count++;return sysfs_fail_at==sysfs_create_count?-ENOMEM:0; }
static inline void mca_sysfs_remove_files(const char *n,struct mca_sysfs_attr_info *a,int len) { (void)n;(void)a;(void)len;sysfs_remove_count++; }
static bool multi_bc12;
static inline bool of_property_read_bool(struct device_node *n,const char *s) { (void)n;(void)s;return multi_bc12; }
#endif''')
p.write_text(s)
(T/'stubs/linux/limits.h').write_text('#include "../kernel_test.h"\n')
# mca event real enum with mocks from the shim; retain actual enum values.
(T/'stubs/mca/common/mca_event.h').unlink()
h=(R/'candidate/drivers/power/supply/mca/include/mca/protocol/protocol_pd_class.h').read_text()
orig=(R/'upstream/drivers/power/supply/mca/mca_protocol/protocol_pd/mca_protocol_pd_class.c').read_text()
callbacks=re.findall(r'int \(\*(\w+)\)\((.*?)\);',re.search(r'struct protocol_class_pd_ops \{(.*?)\n\};',h,re.S).group(1),re.S)
stock=json.load(open(R.parents[2]/'myron-stage-r8/review/pd-bc12/stock-audit.json'))['pd_callback_slots']
code=['#include "kernel_test.h"','#include <mca/protocol/protocol_pd_class.h>','#include <mca/common/mca_event.h>','static int checks;','#define CHECK(x) do { checks++;if(!(x)){fprintf(stderr,"FAIL %s:%d: %s\\n",__FILE__,__LINE__,#x);abort();}}while(0)','static void *expect_ptrs[8]; static long expect_vals[8]; static int seen,expected_data;','static int protocol_regs,protocol_fail_at;','static struct adapter_protocol_class_ops *protocol_ops[ADAPTER_PROTOCOL_MAX]; static void *protocol_data[ADAPTER_PROTOCOL_MAX];',
'int protocol_class_register_ops(unsigned int p,struct adapter_protocol_class_ops *o,void *d) { protocol_regs++;if(protocol_regs==protocol_fail_at)return -EIO;protocol_ops[p]=o;protocol_data[p]=d;return 0; }',
'int protocol_class_unregister_ops(unsigned int p,struct adapter_protocol_class_ops *o,void *d) { if(protocol_ops[p]!=o||protocol_data[p]!=d)return -ENOENT;protocol_ops[p]=NULL;protocol_data[p]=NULL;return 0; }',
'#define match_table pd_match_table','#include MCA_PD_SOURCE','#undef match_table','#define match_table bc12_match_table','#include MCA_BC12_SOURCE','#undef match_table']
for row in stock:
 cb=row['source_callback'] or 'protocol_pd_get_support_keep_pdo'
 code.append(f'_Static_assert(offsetof(struct protocol_class_pd_ops,{cb})=={row["stock_offset"]},"stock slot {cb}");')
code+=['_Static_assert(sizeof(struct protocol_class_pd_ops)==408,"51 stock callbacks");','_Static_assert(sizeof(struct pd_pdo)==16,"stock PDO stride");','_Static_assert(offsetof(struct pd_pdo,pdo_type)==12,"stock PDO discriminator");','_Static_assert(offsetof(struct adapter_power_cap,min_voltage)==8,"stock cap min");','_Static_assert(offsetof(struct adapter_power_cap,max_voltage)==12,"stock cap max");']
funcs=[]
for idx,(cb,args) in enumerate(callbacks):
 args=' '.join(args.split());parts=args.split(', ')
 names=[re.search(r'(\w+)$',a).group(1) for a in parts]
 body=[f'CHECK({names[-1]}==&expected_data);',f'seen={idx+1};']
 for i,(a,n) in enumerate(zip(parts[:-1],names[:-1])):
  body.append('CHECK(pdos!=NULL);' if cb=='protocol_pd_get_pdos' and n=='pdos' else f'CHECK((void*){n}==expect_ptrs[{i}]);' if '*' in a else f'CHECK((long){n}==expect_vals[{i}]);')
 body.append(f'return {idx+17};')
 code.append(f'static int cb_{idx}({args}) {{'+''.join(body)+'}')
 if cb=='protocol_pd_get_support_keep_pdo':fn='protocol_class_pd_get_support_keep_pdo';params='unsigned int port_num, int *support'
 else:
  m=re.search(r'^int (protocol_class_pd_\w+)\((.*?)\)\n\{(.*?)\n\}',orig,re.M|re.S)
  matches=[x for x in re.finditer(r'^int (protocol_class_pd_\w+)\((.*?)\)\n\{(.*?)\n\}',orig,re.M|re.S) if f'temp_data, {cb})' in x.group(3)]
  assert len(matches)==1,(cb,len(matches));fn=matches[0].group(1);params=' '.join(matches[0].group(2).split())
 funcs.append((idx,cb,fn,params))
code.append('static struct protocol_class_pd_ops full_ops = {'+''.join(f'.{cb}=cb_{idx},' for idx,(cb,args) in enumerate(callbacks))+'};')
code.append('static void test_dispatch(void) { struct protocol_class_pd_ops missing=full_ops; CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);')
for idx,cb,fn,params in funcs:
 parts=params.split(', '); call=['0'];decl=[];init=[]
 for j,a in enumerate(parts[1:]):
  n=re.search(r'(\w+)$',a).group(1);t=a[:a.rfind(n)].strip()
  if '*' in t:
   typ=t.replace('*','').strip();decl.append(f'{typ} arg{j}[8]={{0}};');call.append(f'arg{j}');init.append(f'expect_ptrs[{j}]=arg{j};')
  else:
   v='7' if n in ('count','data_len') else '32' if n=='len' else '1' if t=='bool' else str(j+2)
   call.append(v);init.append(f'expect_vals[{j}]={v};')
 code.append('{'+''.join(decl+init)+f'seen=0;CHECK({fn}('+','.join(call)+f')=={idx+17});CHECK(seen=={idx+1});')
 bad=call.copy();bad[0]='TYPEC_PORT_MAX';code.append(f'CHECK({fn}('+','.join(bad)+')==-EINVAL);')
 code.append(f'missing.{cb}=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK({fn}('+','.join(call)+f')==-1);missing.{cb}=full_ops.{cb};CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);'+'}')
code.append('CHECK(protocol_class_pd_unregister_ops(0,&full_ops,&expected_data)==0); CHECK(protocol_class_pd_unregister_ops(0,&full_ops,&expected_data)==-ENOENT); }')
code.append('_Static_assert(__builtin_types_compatible_p(__typeof__(((struct protocol_class_pd_ops*)0)->protocol_pd_fixed_pdo_set_vol),int (*)(unsigned int,void*)),"stock fixed voltage unsigned callback");')
code.append('#include "semantic_tests.inc"')
(T/'test_pd_bc12.c').write_text('\n'.join(code)+'\n')
print(len(callbacks),'generated callbacks')
