from pathlib import Path
import re,json
r=Path(__file__).resolve().parent;p=r/'candidate/drivers/power/supply/mca'
h=(p/'include/mca/platform/platform_cp_class.h').read_text();slots=json.loads((r/'cp-slots.json').read_text())
lines=['#include "kernel_test.h"','#include CP_SOURCE_FILE','static int checks;','#define CHECK(x) do { checks++; assert(x); } while (0)','static int iv, channel = -7, sentinel; static bool bv; static int calls, cbret=-EIO;']
for row in slots:
 field=row['field'];off=row['offset'];fun=row['function']
 lines.append(f'_Static_assert(offsetof(struct platform_class_cp_ops, {field}) == {off}, "stock slot {off}: {field}");')
 argstr=re.search(r'\(\*'+field+r'\)\(([^;]+)\);',h)[1];args=argstr.split(',')
 argtypes=[x.strip().replace(' *data',' *') for x in args]
 params=[];checks=['CHECK(data == &sentinel);','calls++;']
 for i,t in enumerate(argtypes):
  if 'void' in t: params.append('void *data');continue
  params.append(f'{t} a{i}')
  if '*' in t: checks.append(f'CHECK((void *)a{i} == (void *)&'+('bv' if 'bool' in t else 'iv')+');')
  else: checks.append(f'CHECK(a{i} == '+('true' if t=='bool' else 'channel')+');')
 lines.append('static int cb_'+field+'('+', '.join(params)+') { '+' '.join(checks)+' return cbret; }')
lines.append('static int read_current(u32 *out, void *data) { *out = data == &sentinel ? 1300 : 700; return 0; }')
lines.append('static int read_present(bool *out, void *data) { (void)data; *out = true; return 0; }')
lines.append('static int enable_adc(bool en, void *data) { (void)en;(void)data; return cbret; }')
lines.append('static int uvp_false(bool en, void *data) { CHECK(!en); CHECK(data == &sentinel); return -ERANGE; }')
lines+=['int main(void) {','struct platform_class_cp_ops ops={0}, empty={0};','struct device_node node={0}; struct platform_device pdev={ .dev.of_node=&node };','struct platform_cp_dev cp={ .dev=&pdev.dev };','struct device dev={0}; char buf[4096]; int idx=0;','CHECK(CP_ROLE_MAX==3);','CHECK(platform_class_cp_register_ops(3,&ops,&sentinel)==-EOPNOTSUPP);','CHECK(platform_class_cp_register_ops(0,NULL,&sentinel)==-EOPNOTSUPP);','CHECK(platform_class_cp_register_ops(0,&ops,NULL)==-EOPNOTSUPP);']
for row in slots:lines.append(f'ops.{row["field"]}=cb_{row["field"]};')
lines.append('CHECK(platform_class_cp_register_ops(0,&ops,&sentinel)==0);')
for row in slots:
 fun=row['function'];proto=re.search(r'int '+fun+r'\(([^;]+)\);',h)[1]
 args=proto.split(',');call=['0']
 for a in args[1:]:
  a=a.strip()
  if '*' in a:call.append('&bv' if 'bool' in a else '&iv')
  else:call.append('true' if 'bool' in a else 'channel')
 lines += [f'calls=0; CHECK({fun}('+', '.join(call)+')==cbret); CHECK(calls==1);',f'CHECK({fun}('+', '.join(['3']+call[1:])+')==-1);']
lines+=['CHECK(platform_class_cp_register_ops(0,&empty,&sentinel)==0);','CHECK(platform_class_cp_set_vout2out_uvp(0,true)==-1);','CHECK(platform_class_cp_register_ops(0,&ops,&sentinel)==0);','ops.cp_set_vout2out_uvp=uvp_false; CHECK(platform_class_cp_register_ops(2,&ops,&sentinel)==0); CHECK(platform_class_cp_set_vout2out_uvp(2,false)==-ERANGE); ops.cp_set_vout2out_uvp=cb_cp_set_vout2out_uvp;', '/* DT input must not escape three fixed role slots. */','dt_num=4;dt_count=4;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);','dt_num=0;dt_count=0;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);','dt_num=2;dt_count=1;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);','dt_num=3;dt_count=3;dt_index_fail=2;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);','dt_index_fail=-1;CHECK(platform_cp_dev_parse_dt(&cp)==0);','cp.cp_dir_list[0]="unknown";CHECK(cp_sysfs_create_group(&cp)==-EINVAL); CHECK(sysfs_create_count==0);','cp.cp_dir_list[0]="master_slave";CHECK(cp_sysfs_create_group(&cp)==-EINVAL);','cp.cp_dir_list[0]="cp_master";cp.cp_dir_list[1]="other_master";CHECK(cp_sysfs_create_group(&cp)==-EINVAL);','cp.cp_dir_list[1]="cp_slave";sysfs_fail_at=2;CHECK(cp_sysfs_create_group(&cp)==-ENOMEM);CHECK(sysfs_remove_count==1);','sysfs_create_count=0;sysfs_remove_count=0;sysfs_fail_at=0;CHECK(cp_sysfs_create_group(&cp)==0);CHECK(sysfs_create_count==3);','for(int i=0;i<3;i++)CHECK(*(int*)dev_get_drvdata(cp.sysfs_dev[i])==i);','cp_sysfs_remove_groups(&cp);CHECK(sysfs_remove_count==3);','/* Sysfs must never publish data when the hardware callback failed. */','dev.data=&idx;','struct device_attribute batt={.attr.name="batt_present"},bus={.attr.name="vbus"},fsw={.attr.name="fsw"},ovp={.attr.name="ovpgate"};','memset(buf,0x5a,sizeof(buf));','ops.cp_get_battery_present=read_present;CHECK(cp_sysfs_show(&dev,&batt,buf)==2);CHECK(!strcmp(buf,"1\\n"));','ops.cp_enable_adc=enable_adc;cbret=-EIO;memset(buf,0x5a,sizeof(buf));CHECK(cp_sysfs_show(&dev,&bus,buf)==-EIO);CHECK(buf[0]==0x5a);','CHECK(cp_sysfs_store(&dev,&ovp,"bad",3)==-EINVAL);CHECK(cp_sysfs_store(&dev,&fsw,"-1",2)==-EINVAL);','CHECK(cp_sysfs_store(&dev,&fsw,"500",3)==-ENODEV);','/* Late link failure rolls back all role devices and singleton publication. */','sysfs_create_count=0;sysfs_remove_count=0;link_fail=1;CHECK(platform_cp_class_probe(&pdev)==-ENOMEM);CHECK(sysfs_remove_count==3);CHECK(g_platform_cp_dev==NULL);free(platform_get_drvdata(&pdev));','link_fail=0;sysfs_create_count=0;sysfs_remove_count=0;CHECK(platform_cp_class_probe(&pdev)==0);CHECK(g_platform_cp_dev!=NULL);','/* A failed forced-frequency operation cannot latch an unexecuted override. */','channel=500;cbret=-EIO;CHECK(cp_sysfs_store(&dev,&fsw,"500",3)==-EIO);CHECK(g_platform_cp_dev->force_fsw==0);','cbret=0;CHECK(cp_sysfs_store(&dev,&fsw,"500",3)==3);CHECK(g_platform_cp_dev->force_fsw==500);','calls=0;CHECK(platform_class_cp_set_fsw(0,700)==0);CHECK(calls==0);','channel=0;CHECK(cp_sysfs_store(&dev,&fsw,"0",1)==1);CHECK(g_platform_cp_dev->force_fsw==0);','platform_cp_class_remove(&pdev);CHECK(sysfs_remove_count==3);CHECK(link_remove_count==1);CHECK(g_platform_cp_dev==NULL);free(platform_get_drvdata(&pdev));','/* Preserve the stock two-role current aggregation. */','ops.cp_get_bus_current=read_current;CHECK(platform_class_cp_register_ops(1,&ops,&iv)==0);','CHECK(platform_class_cp_get_ibus_total(&iv)==0);CHECK(iv==2000);','CHECK(platform_class_cp_get_ibus_delta(&iv)==0);CHECK(iv==600);','printf("PASS: %d actual CP assertions; 45 compile-time stock callback offsets\\n", checks); return 0; }']
(r/'tests/test_cp.c').write_text('\n'.join(lines)+'\n')
