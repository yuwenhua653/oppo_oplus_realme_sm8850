from pathlib import Path
import re,json
r=Path(__file__).resolve().parent;p=Path('drivers/power/supply/mca')
s=(r/'upstream'/p/'mca_platform/mca_platform_cp_class.c').read_text();h=(r/'upstream'/p/'include/mca/platform/platform_cp_class.h').read_text()
stock=json.loads((r/'mca_platform_cp_class.stock.json').read_text()); stockset=set(stock['exports']); extras=set(re.findall(r'EXPORT_SYMBOL\((\w+)\)',s))-stockset
# Remove unsupported Onyx extensions rather than expose callbacks beyond the stock table.
for f in extras:
 s,n=re.subn(r'int '+f+r'\([^{}]+\)\n\{.*?\n\}\nEXPORT_SYMBOL\('+f+r'\);\n','',s,flags=re.S);assert n==1,(f,n)
 h,n=re.subn(r'int '+f+r'\([^;]+;\n','',h);assert n==1
new='''int platform_class_cp_set_vout2out_uvp(unsigned int role, bool en)
{
	struct platform_cp_class_ops_data *temp_data =
		platform_cp_class_get_ic_ops(role);

	if (platform_cp_ops_invalid(temp_data, cp_set_vout2out_uvp))
		return -1;

	return temp_data->ops->cp_set_vout2out_uvp(en, temp_data->data);
}
EXPORT_SYMBOL(platform_class_cp_set_vout2out_uvp);

'''
s=s.replace('static int platform_cp_dev_parse_dt',new+'static int platform_cp_dev_parse_dt',1)
h=h.replace('#endif /*', 'int platform_class_cp_set_vout2out_uvp(unsigned int role, bool en);\n#endif /*')
# Every slot is tied to a stock wrapper load; 272 is the special fsw wrapper.
slots=json.loads((r/'cp-slots.json').read_text())+[{'function':'platform_class_cp_set_fsw','offset':272}]
fields={m.group(1):m.group(0) for m in re.finditer(r'\tint \(\*(cp_\w+)\)\([^;]+;',h)};fields['cp_set_vout2out_uvp']='\tint (*cp_set_vout2out_uvp)(bool, void *data);'
newfields=[]
for row in sorted(slots,key=lambda x:x['offset']):
 body=re.search(r'(?:extern )?int '+row['function']+r'\([^{}]+\)\n\{(.*?)\n\}',s,re.S).group(1)
 field=re.search(r'platform_cp_ops_invalid\(temp_data, (\w+)\)',body).group(1)
 row['field']=field;newfields.append(fields[field])
assert len(newfields)==45 and sorted(x['offset'] for x in slots)==list(range(0,360,8))
h=re.sub(r'(struct platform_class_cp_ops \{).*?(\n\};)',lambda m:m[1]+'\n'+ '\n'.join(newfields)+m[2],h,count=1,flags=re.S)
(r/'cp-slots.json').write_text(json.dumps(slots,indent=2)+'\n')
# Source class owns no IC policy. Harden bounds and user-facing error paths.
s=s.replace('#include <linux/platform_device.h>','#include <linux/platform_device.h>\n#include <linux/mutex.h>\n#include <linux/err.h>')
s=s.replace('int cp_num;','u32 cp_num;').replace('static struct platform_cp_dev *g_platform_cp_dev;','static struct platform_cp_dev *g_platform_cp_dev;\nstatic DEFINE_MUTEX(platform_cp_dev_lock);')
s=s.replace('count: %d, %d\\n','count: %d, %u\\n')
s=s.replace('if (count != cp->cp_num)\n\t\tmca_log_err("cp_num can\'t match cp_dir_list count\\n");','if (count < 1 || count > CP_ROLE_MAX ||\n\t    cp->cp_num < 1 || cp->cp_num > CP_ROLE_MAX ||\n\t    count != cp->cp_num)\n\t\treturn -EINVAL;')
def replace_function(name,text):
 global s
 pat=r'(?:static )?(?:ssize_t|int|void) '+name+r'\([^;{}]+\)\n\{.*?\n\}'
 s,n=re.subn(pat,lambda m:text,s,count=1,flags=re.S);assert n==1,name
replace_function('cp_sysfs_show','''static ssize_t cp_sysfs_show(struct device *dev, struct device_attribute *attr,
			     char *buf)
{
	struct mca_sysfs_attr_info *attr_info;
	int *index = dev_get_drvdata(dev);
	union platform_cp_propval val = { 0 };
	int ret;
	bool is_bool = false;

	attr_info = mca_sysfs_lookup_attr(attr->attr.name, cp_sysfs_field_tbl,
					  CP_SYSFS_ATTRS_SIZE);
	if (!attr_info || !index || *index < 0 || *index >= CP_ROLE_MAX)
		return -EINVAL;
	if (attr_info->sysfs_attr_name == CP_PROP_VBUS ||
	    attr_info->sysfs_attr_name == CP_PROP_VUSB ||
	    attr_info->sysfs_attr_name == CP_PROP_IBUS ||
	    attr_info->sysfs_attr_name == CP_PROP_VPACK) {
		ret = platform_class_cp_enable_adc(*index, true);
		if (ret)
			return ret;
	}
	switch (attr_info->sysfs_attr_name) {
	case CP_PROP_CHIP_OK:
		ret = platform_class_cp_get_present(*index, &val.boolval);
		is_bool = true;
		break;
	case CP_PROP_VBUS:
		ret = platform_class_cp_get_bus_voltage(*index, &val.intval);
		break;
	case CP_PROP_VUSB:
		ret = platform_class_cp_get_usb_voltage(*index, &val.intval);
		break;
	case CP_PROP_IBUS:
		ret = platform_class_cp_get_bus_current(*index, &val.intval);
		break;
	case CP_PROP_BATT_PRESENT:
		ret = platform_class_cp_get_battery_present(*index, &val.boolval);
		is_bool = true;
		break;
	case CP_PROP_BATT_TEMP:
		ret = platform_class_cp_get_battery_temperature(*index, &val.intval);
		break;
	case CP_PROP_VPACK:
		ret = platform_class_cp_get_battery_voltage(*index, &val.intval);
		break;
	case CP_PROP_OVPGATE:
		ret = platform_class_cp_get_ovpgate_status(*index, &val.boolval);
		is_bool = true;
		break;
	case CP_PROP_FSW:
		ret = platform_class_cp_get_fsw(*index, &val.intval);
		break;
	case CP_PROP_TDIE:
		ret = platform_class_cp_get_tdie(*index, &val.intval);
		break;
	default:
		return -EINVAL;
	}
	if (ret)
		return ret;
	return sysfs_emit(buf, "%d\\n", is_bool ? val.boolval : val.intval);
}''')
# Keep the established force-fsw behaviour; serialize access with removal and sysfs writes.
oldstart=s.index('int platform_class_cp_set_fsw(');oldend=s.index('\nEXPORT_SYMBOL(platform_class_cp_set_fsw);',oldstart)
body=s[oldstart:oldend].replace('int platform_class_cp_set_fsw(', 'static int platform_cp_set_fsw_locked(')
s=s[:oldstart]+body+'''
int platform_class_cp_set_fsw(unsigned int role, int fsw)
{
	int ret;

	mutex_lock(&platform_cp_dev_lock);
	ret = platform_cp_set_fsw_locked(role, fsw);
	mutex_unlock(&platform_cp_dev_lock);
	return ret;
}'''+s[oldend:]
replace_function('cp_sysfs_store','''static ssize_t cp_sysfs_store(struct device *dev, struct device_attribute *attr,
			      const char *buf, size_t count)
{
	struct mca_sysfs_attr_info *attr_info;
	int *index = dev_get_drvdata(dev);
	int val, ret, old_force;

	attr_info = mca_sysfs_lookup_attr(attr->attr.name, cp_sysfs_field_tbl,
					  CP_SYSFS_ATTRS_SIZE);
	if (!attr_info || !index || *index < 0 || *index >= CP_ROLE_MAX)
		return -EINVAL;
	ret = kstrtoint(buf, 10, &val);
	if (ret)
		return ret;
	switch (attr_info->sysfs_attr_name) {
	case CP_PROP_OVPGATE:
		ret = platform_class_cp_enable_ovpgate(*index, val);
		break;
	case CP_PROP_FSW:
		if (val < 0)
			return -EINVAL;
		mutex_lock(&platform_cp_dev_lock);
		if (!g_platform_cp_dev) {
			mutex_unlock(&platform_cp_dev_lock);
			return -ENODEV;
		}
		old_force = g_platform_cp_dev->force_fsw;
		g_platform_cp_dev->force_fsw = -val;
		ret = platform_cp_set_fsw_locked(*index, val);
		if (ret)
			g_platform_cp_dev->force_fsw = old_force;
		mutex_unlock(&platform_cp_dev_lock);
		break;
	default:
		return -EINVAL;
	}
	return ret ? ret : count;
}''')
# Port tested r7 loadsw role resolution/rollback without changing the DT.
ls=Path('analysis/myron-stage-r7/bundle/myron-adaptation-r7/drivers/payload/drivers/power/supply/mca/mca_platform/mca_platform_loadsw_class.c').read_text()
part=ls[ls.index('static void loadsw_sysfs_remove_groups'):ls.index('static int platform_loadsw_class_probe')]
part=part.replace('loadsw','cp').replace('LOADSW','CP')
replace_function('cp_sysfs_create_group',part.strip())
replace_function('platform_cp_sysfs_show','''static ssize_t platform_cp_sysfs_show(struct device *dev,
				      struct device_attribute *attr, char *buf)
{
	struct mca_sysfs_attr_info *attr_info;
	int val = 0, ret;

	attr_info = mca_sysfs_lookup_attr(attr->attr.name,
					  platform_cp_sysfs_field_tbl,
					  PLATFORM_CP_SYSFS_ATTRS_SIZE);
	if (!attr_info)
		return -EINVAL;
	switch (attr_info->sysfs_attr_name) {
	case CP_PROP_IBUS_DELTA:
		ret = platform_class_cp_get_ibus_delta(&val);
		break;
	case CP_RORP_IBUS_TOTAL:
		ret = platform_class_cp_get_ibus_total(&val);
		break;
	case CP_PROP_WORK_MODE:
		return -EOPNOTSUPP;
	default:
		return -EINVAL;
	}
	return ret ? ret : sysfs_emit(buf, "%d\\n", val);
}''')
replace_function('platform_cp_sysfs_store','''static ssize_t platform_cp_sysfs_store(struct device *dev,
				       struct device_attribute *attr,
				       const char *buf, size_t count)
{
	/* Upstream has no operation for this attribute. Never report a write. */
	return -EOPNOTSUPP;
}''')
s=s.replace('g_platform_cp_dev = l_dev;\n\n\tcp_sysfs_create_group(l_dev);\n\tplatform_cp_sysfs_create_group(l_dev->dev);','''mutex_lock(&platform_cp_dev_lock);
	if (g_platform_cp_dev) {
		mutex_unlock(&platform_cp_dev_lock);
		return -EBUSY;
	}
	g_platform_cp_dev = l_dev;
	mutex_unlock(&platform_cp_dev_lock);

	rc = cp_sysfs_create_group(l_dev);
	if (rc)
		goto clear_dev;
	rc = platform_cp_sysfs_create_group(l_dev->dev);
	if (rc) {
		cp_sysfs_remove_groups(l_dev);
		goto clear_dev;
	}''')
s=s.replace('static int platform_cp_class_remove(struct platform_device *pdev)\n{\n\treturn 0;\n}', '''static void platform_cp_class_remove(struct platform_device *pdev)
{
	struct platform_cp_dev *cp = platform_get_drvdata(pdev);

	mca_sysfs_remove_link_group("charger", "chargerpump", cp->dev,
				    &platform_cp_sysfs_attr_group);
	cp_sysfs_remove_groups(cp);
	mutex_lock(&platform_cp_dev_lock);
	if (g_platform_cp_dev == cp)
		g_platform_cp_dev = NULL;
	mutex_unlock(&platform_cp_dev_lock);
}''')
# Add rollback label only to probe.
start=s.index('static int platform_cp_class_probe');end=s.index('static void platform_cp_class_remove',start)
pr=s[start:end];pr=pr.replace('\n\treturn 0;\n}', '\n\treturn 0;\n\nclear_dev:\n\tmutex_lock(&platform_cp_dev_lock);\n\tg_platform_cp_dev = NULL;\n\tmutex_unlock(&platform_cp_dev_lock);\n\treturn rc;\n}');s=s[:start]+pr+s[end:]
for path,data in [(p/'mca_platform/mca_platform_cp_class.c',s),(p/'include/mca/platform/platform_cp_class.h',h)]:
 f=r/'candidate'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(data)
print('candidate CP',len(re.findall(r'EXPORT_SYMBOL\(',s)), 'exports; 45 stock callback slots; non-stock removed:',sorted(extras))
