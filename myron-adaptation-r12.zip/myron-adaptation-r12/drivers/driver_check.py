#!/usr/bin/env python3
"""Compile this revision's locked changed DDK modules and their dependencies.

This is an optional targeted compile gate, not the full platform output audit.
No flash image or reusable deployment artifact is collected here.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import sys
import time
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_file(root, name):
    rel = PurePosixPath(name)
    if (not name or str(rel) != name or rel.is_absolute() or
            any(part in (".", "..") for part in rel.parts)):
        raise ValueError("Unsafe locked path: " + name)
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Locked path escapes root: " + name)
    return path


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_bundle(bundle, runner_path):
    """Authenticate scripts and metadata against the already verified ZIP's lock."""
    raw = (bundle / "bundle-lock.json").read_bytes()
    lock = json.loads(raw)
    seen = set()
    for entry in lock["files"]:
        name = entry["path"]
        if name in seen:
            raise ValueError("Duplicate bundle-lock path: " + name)
        seen.add(name)
        if digest(safe_file(bundle, name).read_bytes()) != entry["sha256"]:
            raise ValueError("Bundle payload mismatch: " + name)
    required = {"drivers/source-lock.json", "drivers/build_new_modules.py", "run_r12.py",
                "drivers/driver_check.py"}
    if not required.issubset(seen):
        raise ValueError("Bundle lock does not cover the driver-check inputs")
    runner = runner_path.read_bytes()
    if digest(runner) != lock["runner_after_sha256"]:
        raise ValueError("Unexpected prepared build_platform.py")
    return runner, {"bundle_lock_sha256": digest(raw), "runner_sha256": digest(runner)}


def runner_build_configuration(data, root, jobs, ram_mb):
    """Use the exact three configuration assignments from the locked full runner.

    This avoids maintaining a second flags/output_base definition. The runner's
    SHA is checked before this function is called; no arbitrary user code or
    unverified source enters this extraction.
    """
    tree = ast.parse(data)
    functions = [node for node in tree.body
                 if isinstance(node, ast.FunctionDef) and node.name == "main"]
    if len(functions) != 1:
        raise ValueError("Cannot locate locked runner main")
    assignments = {}
    for node in ast.walk(functions[0]):
        if (isinstance(node, ast.Assign) and len(node.targets) == 1 and
                isinstance(node.targets[0], ast.Name) and
                node.targets[0].id in ("bazel", "configuration", "options")):
            name = node.targets[0].id
            if name in assignments:
                raise ValueError("Ambiguous runner configuration: " + name)
            assignments[name] = node
    if set(assignments) != {"bazel", "configuration", "options"}:
        raise ValueError("Incomplete locked runner build configuration")
    body = sorted(assignments.values(), key=lambda node: node.lineno)
    scope = {"root": root, "args": SimpleNamespace(jobs=jobs, ram_mb=ram_mb)}
    exec(compile(ast.Module(body=body, type_ignores=[]), "locked-runner-options", "exec"),
         {"__builtins__": {"str": str}}, scope)
    bazel, options = scope["bazel"], scope["options"]
    if (not isinstance(bazel, list) or not isinstance(options, list) or
            not all(isinstance(value, str) for value in bazel + options)):
        raise ValueError("Invalid runner command configuration")
    expected_base = "--output_base=" + str(root / "out/bazel-integration")
    if expected_base not in bazel or bazel[0] != str(root / "tools/bazel"):
        raise ValueError("Unexpected runner Bazel/output_base")
    if "--keep_going" not in options or any(
            option.split("=", 1)[0] in ("--nobuild", "--check_up_to_date", "--check_tests_up_to_date") or
            option in ("--build=false", "--build=0") for option in options):
        raise ValueError("driver-check requires an actual keep-going build")
    return bazel, options


def resolve_changed_targets(bundle, root=None):
    drivers = bundle / "drivers"
    raw = (drivers / "source-lock.json").read_bytes()
    lock = json.loads(raw)
    names = lock.get("changed_r13_modules")
    helper = load_module("myron_driver_check_registry", drivers / "build_new_modules.py")
    entries = [entry for entry in lock["writes"] if entry["path"] == helper.REGISTRY]
    if len(entries) != 1:
        raise ValueError("Registry must have exactly one locked write")
    entry = entries[0]
    registry = (safe_file(drivers, entry["payload"]) if root is None else
                safe_file(root / "vendor/qcom/sm8850", helper.REGISTRY))
    data = registry.read_bytes()
    if digest(data) != entry["sha256"]:
        raise ValueError("Registry does not match this revision's source lock")
    labels = helper.labels_from_registry(data.decode(), names)
    if any(name not in lock["module_contracts"] for name in names):
        raise ValueError("Changed module lacks a managed module contract")
    return names, labels, {"source_lock_sha256": digest(raw),
                           "registry_sha256": digest(data)}


def verify_applied_writes(bundle, root):
    lock = json.loads((bundle / "drivers/source-lock.json").read_text())
    seen = set()
    for entry in lock["writes"]:
        name = entry["path"]
        if name in seen:
            raise ValueError("Duplicate applied source path: " + name)
        seen.add(name)
        path = safe_file(root / "vendor/qcom/sm8850", name)
        if digest(path.read_bytes()) != entry["sha256"]:
            raise ValueError("Applied source differs from current lock: " + name)
    return len(seen)


def run_check(root, package, bundle, jobs=2, ram_mb=10000):
    root, package, bundle = root.resolve(), package.resolve(), bundle.resolve()
    reports = root / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    # A retry must not expose a previous driver-check success or build log.
    for name in ("driver-check-status.json", "driver-check-prepare.log",
                 "driver-check-apply.log", "driver-check-build.log"):
        (reports / name).unlink(missing_ok=True)
    state = {"stage": "driver-check", "scope": "targeted_compile_only",
             "success": False, "compiled": False, "analysis_only": False,
             "full_platform_validated": False, "flashable": False,
             "hardware_tested": False, "deployment_artifacts_collected": False,
             "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
             "limitations": ["Only the locked changed DDK targets and their normal dependencies are built.",
                             "This does not run the full 45-module, CRC, callback, DT or binding acceptance gates.",
                             "The kernel and shared dependencies may still need a substantial cold build."]}
    path = reports / "driver-check-status.json"
    path.write_text(json.dumps(state, indent=2) + "\n")
    try:
        if jobs < 1 or ram_mb < 2048:
            raise ValueError("Use at least one job and 2048 MiB RAM")
        runner_path = package / "build_platform.py"
        runner_data, metadata = verify_bundle(bundle, runner_path)
        state.update(metadata)
        names, targets, metadata = resolve_changed_targets(bundle)
        state.update(metadata, modules=names, build_targets=targets)
        bazel, options = runner_build_configuration(runner_data, root, jobs, ram_mb)
        runner = load_module("myron_locked_full_runner", runner_path)
        state["phase"] = "prepare_workspace"
        runner.logged([sys.executable, str(package / "prepare_workspace.py"), "--workspace", str(root)],
                      root, reports / "driver-check-prepare.log")
        state["phase"] = "apply_current_bundle"
        # Existing apply handles the entire revision; soc controls validation
        # selection only. We intentionally do not call its full validate action.
        runner.logged([sys.executable, str(bundle / "run_r12.py"), "apply",
                       "--workspace", str(root), "--stage", "soc"],
                      root, reports / "driver-check-apply.log")
        applied_names, applied_targets, applied_metadata = resolve_changed_targets(bundle, root)
        if (applied_names, applied_targets, applied_metadata) != (names, targets, metadata):
            raise ValueError("Target plan changed while applying source bundle")
        state["applied_source_files_verified"] = verify_applied_writes(bundle, root)
        command = bazel + ["build"] + options + targets
        state.update(phase="build_changed_ddk_targets", command=command)
        path.write_text(json.dumps(state, indent=2) + "\n")
        print("driver-check: compile " + str(len(targets)) +
              " locked changed modules and their dependencies; this is not full acceptance", flush=True)
        runner.logged(command, root, reports / "driver-check-build.log")
        state.update(success=True, compiled=True, phase="targeted_compile_complete")
    except Exception as error:
        state["error"] = str(error)
        print("driver-check ERROR: " + str(error), file=sys.stderr, flush=True)
    finally:
        state["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        path.write_text(json.dumps(state, indent=2) + "\n")
    return 0 if state["success"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, default=HERE.parent)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--ram-mb", type=int, default=10000)
    args = parser.parse_args()
    return run_check(args.workspace, args.package, args.bundle, args.jobs, args.ram_mb)


if __name__ == "__main__":
    sys.exit(main())
