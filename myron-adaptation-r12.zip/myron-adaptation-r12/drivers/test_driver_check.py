#!/usr/bin/env python3
"""Host control-flow regressions. Bazel and source application are mocked."""
import argparse
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent


def module_at(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--before-runner", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    driver = module_at("tested_driver_check", HERE / "driver_check.py")
    installer = module_at("actual_install_hooks", args.bundle / "install_hooks.py")
    original_runner = args.before_runner.read_bytes()
    assert hashlib.sha256(original_runner).hexdigest() == installer.BEFORE
    runner_data = installer.patched(original_runner)
    source_lock = json.loads((args.bundle / "drivers/source-lock.json").read_text())
    # This fixture can run during parallel source editing. Its isolated hashes
    # describe the copied files; release-lock verification remains a separate
    # packaging gate and is not claimed by these mocked orchestration tests.
    for entry in source_lock["writes"]:
        entry["sha256"] = driver.digest((args.bundle / "drivers" / entry["payload"]).read_bytes())
    if "changed_r13_modules" not in source_lock:
        # Until the parent packages its final revision, use the explicitly
        # requested list in this isolated fixture; never edit the release lock.
        source_lock["changed_r13_modules"] = [
            "mca_adsp_glink", "mca_path_control", "sc96281_charger",
            "mca_business_battery_comp", "sc8581"]
    checks = []
    with tempfile.TemporaryDirectory(prefix="myron-driver-check-") as td:
        base = Path(td)
        bundle = base / "myron-adaptation-r13"
        package = base / "myron-qcom-platform-r1"
        bundle.mkdir()
        package.mkdir()
        (bundle / "drivers").mkdir()
        shutil.copy2(HERE / "driver_check.py", bundle / "drivers/driver_check.py")
        shutil.copy2(args.bundle / "drivers/build_new_modules.py", bundle / "drivers/build_new_modules.py")
        shutil.copytree(args.bundle / "drivers/payload", bundle / "drivers/payload")
        for entry in source_lock["writes"]:
            dest = bundle / "drivers" / entry["payload"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(args.bundle / "drivers" / entry["payload"], dest)
        (bundle / "run_r12.py").write_text("# Source application deliberately mocked in host tests.\n")
        (package / "build_platform.py").write_bytes(runner_data)
        (package / "prepare_workspace.py").write_text("# Preparation deliberately mocked in host tests.\n")
        registry_entry = next(entry for entry in source_lock["writes"]
                              if entry["path"] == "drivers/xiaomi/myron/modules.bzl")
        registry_path = bundle / "drivers" / registry_entry["payload"]
        registry_original = registry_path.read_bytes()

        def lock_fixture(lock):
            (bundle / "drivers/source-lock.json").write_text(json.dumps(lock))
            entries = [{"path": str(path.relative_to(bundle)), "sha256": driver.digest(path.read_bytes())}
                       for path in sorted(bundle.rglob("*"))
                       if path.is_file() and path.name != "bundle-lock.json" and "__pycache__" not in path.parts]
            (bundle / "bundle-lock.json").write_text(json.dumps({"files": entries,
                "runner_after_sha256": driver.digest((package / "build_platform.py").read_bytes())}))

        real_load = driver.load_module

        def run_case(name, failure=None, lock=None, expected=True):
            root = base / name
            root.mkdir()
            effective = copy.deepcopy(source_lock if lock is None else lock)
            registry_path.write_bytes(registry_original)
            (package / "build_platform.py").write_bytes(runner_data)
            lock_fixture(effective)
            calls = []

            def fake_logged(command, cwd, logpath):
                assert cwd == root
                if str(package / "prepare_workspace.py") in command:
                    phase = "prepare"
                    assert not calls
                elif str(bundle / "run_r12.py") in command:
                    phase = "apply"
                    assert calls == ["prepare"]
                    assert command[2] == "apply" and command[-2:] == ["--stage", "soc"]
                    for entry in effective["writes"]:
                        destination = root / "vendor/qcom/sm8850" / entry["path"]
                        destination.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(bundle / "drivers" / entry["payload"], destination)
                    if failure == "applied_registry":
                        (root / "vendor/qcom/sm8850" / registry_entry["path"]).write_text("tampered")
                    if failure == "applied_source":
                        changed = next(entry for entry in effective["writes"] if entry["path"] != registry_entry["path"])
                        (root / "vendor/qcom/sm8850" / changed["path"]).write_text("stale source")
                else:
                    phase = "build"
                    assert calls == ["prepare", "apply"]
                    assert command[0] == str(root / "tools/bazel")
                    assert "--output_base=" + str(root / "out/bazel-integration") in command
                    assert "build" in command and "--keep_going" in command and "--nobuild" not in command
                    assert "--jobs=2" in command and "--local_ram_resources=10000" in command
                    assert "--//build/kernel/kleaf:allow_ddk_unsafe_headers" in command
                    actual = [part for part in command if part.startswith("//vendor/")]
                    expected_labels = real_load("fixture_registry", bundle / "drivers/build_new_modules.py").labels_from_registry(
                        registry_original.decode(), effective["changed_r13_modules"])
                    assert actual == expected_labels
                    assert "//vendor/qcom/sm8850:myron_platform_lab" not in command
                calls.append(phase)
                logpath.write_text("simulated " + phase + "\n")
                if phase == failure:
                    raise RuntimeError("Simulated " + phase + " command failed (17)")

            def fake_load(module_name, path):
                if path == package / "build_platform.py":
                    return SimpleNamespace(logged=fake_logged)
                return real_load(module_name, path)

            reports = root / "integration-reports"
            reports.mkdir()
            # Old successful state must never survive any new failed attempt.
            (reports / "driver-check-status.json").write_text('{"success":true,"compiled":true}')
            (reports / "driver-check-build.log").write_text("OLD SUCCESS\n")
            if failure == "bundle_hash":
                (bundle / "run_r12.py").write_text("unexpected edit")
            with patch.object(driver, "load_module", side_effect=fake_load):
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    code = driver.run_check(root, package, bundle)
            state = json.loads((reports / "driver-check-status.json").read_text())
            assert (code == 0) == expected, state
            assert state["success"] is expected and state["compiled"] is expected
            assert state["scope"] == "targeted_compile_only"
            assert not state["full_platform_validated"] and not state["flashable"]
            assert not state["deployment_artifacts_collected"] and not state["hardware_tested"]
            assert not (root / "integration-artifacts").exists()
            if not expected:
                assert state.get("error")
                if failure in ("prepare", "apply", "build"):
                    assert "failed (17)" in state["error"]
                if (reports / "driver-check-build.log").exists():
                    assert "OLD SUCCESS" not in (reports / "driver-check-build.log").read_text()
            if expected:
                assert calls == ["prepare", "apply", "build"]
                assert state["applied_source_files_verified"] == len(effective["writes"])
            checks.append({"case": name, "result": "PASS", "commands": calls})

        run_case("prepare_then_apply_then_one_real_build_command")
        for fail in ("prepare", "apply", "build", "bundle_hash", "applied_registry", "applied_source"):
            run_case(fail + "_failure_propagates", failure=fail, expected=False)
        for name, changed in (("missing_changed_list", None), ("empty_changed_list", []),
                              ("unknown_target", ["not_registered"]),
                              ("duplicate_target", ["sc8581", "sc8581"])):
            modified = copy.deepcopy(source_lock)
            if changed is None:
                modified.pop("changed_r13_modules")
            else:
                modified["changed_r13_modules"] = changed
            run_case(name, lock=modified, expected=False)
        modified = copy.deepcopy(source_lock)
        modified["module_contracts"].pop(modified["changed_r13_modules"][0])
        run_case("unmanaged_changed_target", lock=modified, expected=False)
        # Exact option extraction from the pinned full runner, including output
        # base, without invoking the runner's broad/full main function.
        root = base / "flags"
        bazel, options = driver.runner_build_configuration(runner_data, root, 4, 6000)
        assert "--jobs=4" in options and "--local_ram_resources=6000" in options
        assert "--output_base=" + str(root / "out/bazel-integration") in bazel
        checks.append({"case": "locked_full_runner_exact_dynamic_options", "result": "PASS"})
        for option in ("--nobuild", "--nobuild=true", "--check_up_to_date", "--build=false"):
            changed = runner_data.replace(b'"--keep_going"', ('"--keep_going", "' + option + '"').encode())
            try:
                driver.runner_build_configuration(changed, root, 2, 10000)
            except ValueError:
                checks.append({"case": "reject_analysis_or_dry_run_" + option, "result": "PASS"})
            else:
                raise AssertionError("Accepted non-compilation option: " + option)
        missing_flag = runner_data.replace(b'"--keep_going"', b'"--nokeep_going"')
        try:
            driver.runner_build_configuration(missing_flag, root, 2, 10000)
        except ValueError:
            checks.append({"case": "require_keep_going", "result": "PASS"})
        else:
            raise AssertionError("Accepted missing keep_going")
    report = {"success": True, "scope": "host_control_flow_only",
              "target_compiled": False, "bazel_mocked": True,
              "before_runner_sha256": driver.digest(original_runner),
              "test_count": len(checks), "checks": checks}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
