/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _MCA_COMMON_MCA_SMEM_H_
#define _MCA_COMMON_MCA_SMEM_H_
int mca_qcom_smem_is_zero_speed(void);
#endif
