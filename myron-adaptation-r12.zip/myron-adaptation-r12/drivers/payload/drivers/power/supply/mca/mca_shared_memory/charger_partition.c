// SPDX-License-Identifier: GPL-2.0-only
/*
 * Myron charger partition provider, Linux 6.12 public block API.
 * The exported ABI and disk structures come from Xiaomi Onyx commit
 * 8276ba954d8076303a5ae0f7b15d4092d66bdff6. Storage/lifetime implementation
 * is new: no private sd.h, guessed partition number, formatting or boot reset.
 * This is a storage provider; OEM sysfs policy and startup notifications are
 * deliberately not registered without a verified Myron policy contract.
 */
#include <linux/blkdev.h>
#include <linux/err.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/of.h>
#include <linux/platform_device.h>
#include <linux/sched/task.h>
#include <linux/string.h>
#include <mca/shared_memory/charger_partition_class.h>

#define CP_BLOCK 4096U
#define CP_MIN_BYTES (CHARGER_PARTITION_INFO_LAST * CP_BLOCK)

static char *block_path;
static char *partition_uuid;
static unsigned int format_version = ~0U;
static bool allow_writes;
module_param(block_path, charp, 0400);
MODULE_PARM_DESC(block_path, "Explicit charger partition block path; no default");
module_param(partition_uuid, charp, 0400);
MODULE_PARM_DESC(partition_uuid, "Required observed GPT partition UUID");
module_param(format_version, uint, 0400);
MODULE_PARM_DESC(format_version, "Required observed charger header version");
module_param(allow_writes, bool, 0400);
MODULE_PARM_DESC(allow_writes, "Enable existing-format transactions; default read-only");

/* Storage remains alive across device removal until the owner's dealloc.
 * A live transaction pins THIS_MODULE. Callers must pair alloc/dealloc on
 * the same task; another task receives EBUSY/EPERM, never a shared buffer.
 */
static DEFINE_MUTEX(cp_lock);
static struct file *cp_file;
static struct task_struct *cp_owner;
static u8 cp_host, cp_info;
static u32 cp_size;
static bool cp_poisoned;
static u8 cp_data[CP_BLOCK] __aligned(8);
static u8 cp_header[CP_BLOCK] __aligned(8);
static u8 cp_write_block[CP_BLOCK] __aligned(8);

static int cp_io(bool write, u8 info, void *data)
{
	loff_t pos = (loff_t)info * CP_BLOCK;
	ssize_t done;
	int ret;

	if (!cp_file)
		return -ENODEV;
	if (cp_poisoned)
		return -EIO;
	if (info >= CHARGER_PARTITION_INFO_LAST ||
	    pos + CP_BLOCK > bdev_nr_bytes(file_bdev(cp_file)))
		return -ERANGE;
	if (write && !allow_writes)
		return -EROFS;
	if (write)
		done = kernel_write(cp_file, data, CP_BLOCK, &pos);
	else {
		/* Firmware may update the partition outside Linux's page cache.
		 * All our writes were fsynced; discard cached clean pages before read.
		 */
		invalidate_bdev(file_bdev(cp_file));
		done = kernel_read(cp_file, data, CP_BLOCK, &pos);
	}
	/* A short write is not retried: on-disk state is now uncertain. */
	ret = done < 0 ? (int)done : done == CP_BLOCK ? 0 : -EIO;
	if (!ret && write)
		ret = vfs_fsync(cp_file, 0);
	if (ret && write)
		cp_poisoned = true;
	return ret;
}

static int cp_check_header(void)
{
	charger_partition_header *h = (void *)cp_header;
	int ret = cp_io(false, CHARGER_PARTITION_HEADER, cp_header);

	if (ret)
		return ret;
	if (h->magic != CHARGER_PARTITION_MAGIC ||
	    h->version != format_version || h->initialized != 1)
		return -EUCLEAN;
	return h->avaliable == 1 ? 0 : -EBUSY;
}

static int cp_arguments(u8 host, u8 info, u32 size)
{
	/* The metadata header is not a caller data record. */
	return host != CHARGER_PARTITION_HOST_KERNEL ||
	       !info || info >= CHARGER_PARTITION_INFO_LAST ||
	       !size || size >= CP_BLOCK ? -EINVAL : 0;
}

static int cp_owned(u8 host, u8 info, u32 size)
{
	if (cp_owner != current)
		return -EPERM;
	if (host != cp_host || info != cp_info || size != cp_size)
		return -EINVAL;
	return 0;
}

int charger_partition_alloc(u8 host, u8 info, uint32_t size)
{
	charger_partition_header *h = (void *)cp_header;
	int ret = cp_arguments(host, info, size);

	if (ret)
		return ret;
	mutex_lock(&cp_lock);
	if (cp_owner) {
		ret = -EBUSY;
		goto out;
	}
	ret = cp_check_header();
	if (ret)
		goto out;
	if (!try_module_get(THIS_MODULE)) {
		ret = -ENODEV;
		goto out;
	}
	/* Read-only diagnostics never modify the persistent availability word.
	 * This word is not an inter-processor atomic lock; firmware exclusion
	 * still has to be established before write mode is used on a phone.
	 */
	if (allow_writes) {
		h->avaliable = 0;
		ret = cp_io(true, CHARGER_PARTITION_HEADER, cp_header);
		if (ret) {
			module_put(THIS_MODULE);
			goto out;
		}
	}
	cp_owner = current;
	get_task_struct(cp_owner);
	cp_host = host;
	cp_info = info;
	cp_size = size;
	memset(cp_data, 0, sizeof(cp_data));
out:
	mutex_unlock(&cp_lock);
	return ret;
}
EXPORT_SYMBOL(charger_partition_alloc);

int charger_partition_dealloc(u8 host, u8 info, uint32_t size)
{
	charger_partition_header *h = (void *)cp_header;
	bool release = false;
	int ret;

	mutex_lock(&cp_lock);
	ret = cp_owned(host, info, size);
	if (ret)
		goto out;
	if (!cp_file)
		ret = -ENODEV;
	else if (cp_poisoned)
		ret = -EIO;
	else if (allow_writes) {
		/* Preserve all other header bytes; never clear busy after uncertain I/O. */
		ret = cp_io(false, CHARGER_PARTITION_HEADER, cp_header);
		if (!ret && (h->magic != CHARGER_PARTITION_MAGIC ||
			     h->version != format_version || h->initialized != 1 ||
			     h->avaliable != 0))
			ret = -EUCLEAN;
		if (!ret) {
			h->avaliable = 1;
			ret = cp_io(true, CHARGER_PARTITION_HEADER, cp_header);
		}
		if (ret)
			cp_poisoned = true;
	}
	put_task_struct(cp_owner);
	cp_owner = NULL;
	memset(cp_data, 0, sizeof(cp_data));
	release = true;
out:
	mutex_unlock(&cp_lock);
	if (release)
		module_put(THIS_MODULE);
	return ret;
}
EXPORT_SYMBOL(charger_partition_dealloc);

void *charger_partition_read(u8 host, u8 info, uint32_t size)
{
	void *result = NULL;

	mutex_lock(&cp_lock);
	if (!cp_owned(host, info, size) && !cp_io(false, info, cp_data))
		result = cp_data;
	mutex_unlock(&cp_lock);
	return result;
}
EXPORT_SYMBOL(charger_partition_read);

int charger_partition_write(u8 host, u8 info, void *buf, uint32_t size)
{
	int ret;

	mutex_lock(&cp_lock);
	ret = cp_owned(host, info, size);
	if (ret)
		goto out;
	if (!buf) {
		ret = -EINVAL;
		goto out;
	}
	if (!allow_writes) {
		ret = -EROFS;
		goto out;
	}
	/* Read fills the complete block so bytes outside the API record survive.
	 * The buffer returned by read may itself be passed to write.
	 */
	ret = cp_io(false, info, cp_write_block);
	if (ret)
		goto out;
	memcpy(cp_write_block, buf, size);
	ret = cp_io(true, info, cp_write_block);
out:
	mutex_unlock(&cp_lock);
	return ret;
}
EXPORT_SYMBOL(charger_partition_write);

/* Keep an entire read/modify/write in one transaction, propagate both I/O
 * and deallocation failures, and never overwrite caller output on error.
 */
static int cp_fields(u8 info, size_t offset, u32 *values, size_t count, bool write)
{
	u32 copy[2];
	void *record;
	u32 size = info == CHARGER_PARTITION_INFO_1 ?
		sizeof(charger_partition_info_1) : sizeof(charger_partition_info_2);
	int ret, end;

	if (!values || !count || count > ARRAY_SIZE(copy) ||
	    offset + count * sizeof(u32) > size)
		return -EINVAL;
	if (write && !allow_writes)
		return -EROFS;
	ret = charger_partition_alloc(CHARGER_PARTITION_HOST_KERNEL, info, size);
	if (ret)
		return ret;
	record = charger_partition_read(CHARGER_PARTITION_HOST_KERNEL, info, size);
	if (!record) {
		ret = -EIO;
	} else if (write) {
		memcpy((u8 *)record + offset, values, count * sizeof(u32));
		ret = charger_partition_write(CHARGER_PARTITION_HOST_KERNEL, info, record, size);
	} else {
		memcpy(copy, (u8 *)record + offset, count * sizeof(u32));
	}
	end = charger_partition_dealloc(CHARGER_PARTITION_HOST_KERNEL, info, size);
	if (!ret)
		ret = end;
	if (!ret && !write)
		memcpy(values, copy, count * sizeof(u32));
	return ret;
}

#define CP_INFO1_READ(name, member) \
int name(int *out) \
{ \
	u32 value; \
	int ret; \
	if (!out) return -EINVAL; \
	ret = cp_fields(CHARGER_PARTITION_INFO_1, \
		offsetof(charger_partition_info_1, member), &value, 1, false); \
	if (!ret) *out = (int)value; \
	return ret; \
} \
EXPORT_SYMBOL(name)

#define CP_INFO1_WRITE(name, member) \
int name(int value) \
{ \
	u32 data = value; \
	return cp_fields(CHARGER_PARTITION_INFO_1, \
		offsetof(charger_partition_info_1, member), &data, 1, true); \
} \
EXPORT_SYMBOL(name)

CP_INFO1_READ(charger_partition_read_double85, double85);
CP_INFO1_WRITE(charger_partition_write_double85, double85);
CP_INFO1_WRITE(charger_partition_write_remove_temp_limit, remove_temp_limit);
CP_INFO1_READ(charger_partition_read_memory_test, memory_test);
CP_INFO1_WRITE(charger_partition_write_memory_test, memory_test);
CP_INFO1_READ(charger_partition_read_soc_limit, soc_limit);
CP_INFO1_WRITE(charger_partition_write_soc_limit, soc_limit);

int charger_partition_get_mishow(bool *out)
{
	u32 value;
	int ret;
	if (!out)
		return -EINVAL;
	ret = cp_fields(CHARGER_PARTITION_INFO_1,
		offsetof(charger_partition_info_1, mishow), &value, 1, false);
	if (!ret)
		*out = !!value;
	return ret;
}
EXPORT_SYMBOL(charger_partition_get_mishow);

int charger_partition_get_eu_model(bool *out)
{
	u32 value;
	int ret;
	if (!out)
		return -EINVAL;
	ret = cp_fields(CHARGER_PARTITION_INFO_2,
		offsetof(charger_partition_info_2, eu_mode), &value, 1, false);
	if (!ret)
		*out = !!value;
	return ret;
}
EXPORT_SYMBOL(charger_partition_get_eu_model);

#define CP_COUNT_READ(name, member) \
int name(u32 *a, u32 *b) \
{ \
	u32 values[2]; \
	int ret; \
	if (!a || !b) return -EINVAL; \
	ret = cp_fields(CHARGER_PARTITION_INFO_2, \
		offsetof(charger_partition_info_2, member), values, 2, false); \
	if (!ret) { *a = values[0]; *b = values[1]; } \
	return ret; \
} \
EXPORT_SYMBOL(name)

#define CP_COUNT_WRITE(name, member) \
int name(u32 a, u32 b) \
{ \
	u32 values[2] = { a, b }; \
	return cp_fields(CHARGER_PARTITION_INFO_2, \
		offsetof(charger_partition_info_2, member), values, 2, true); \
} \
EXPORT_SYMBOL(name)

CP_COUNT_READ(charger_partition_read_ocd_count, ocd_count);
CP_COUNT_WRITE(charger_partition_write_ocd_count, ocd_count);
CP_COUNT_READ(charger_partition_read_cuv_count, cuv_count);
CP_COUNT_WRITE(charger_partition_write_cuv_count, cuv_count);

int charger_partition_read_hscd_count(u32 *out)
{
	return cp_fields(CHARGER_PARTITION_INFO_2,
		offsetof(charger_partition_info_2, hscd_count), out, 1, false);
}
EXPORT_SYMBOL(charger_partition_read_hscd_count);

/* Keep the original exported hcsd spelling; consumers use this ABI. */
int charger_partition_write_hcsd_count(u32 value)
{
	return cp_fields(CHARGER_PARTITION_INFO_2,
		offsetof(charger_partition_info_2, hscd_count), &value, 1, true);
}
EXPORT_SYMBOL(charger_partition_write_hcsd_count);

static int charger_partition_probe(struct platform_device *pdev)
{
	struct block_device *bdev;
	blk_mode_t mode = BLK_OPEN_READ | BLK_OPEN_RESTRICT_WRITES;
	int ret;

	static_assert(sizeof(charger_partition_header) == 20);
	static_assert(sizeof(charger_partition_info_1) == 32);
	static_assert(sizeof(charger_partition_info_2) == 32);
	if (!block_path || !partition_uuid || !*partition_uuid ||
	    format_version == ~0U)
		return -EINVAL;
	if (allow_writes)
		mode |= BLK_OPEN_WRITE;
	mutex_lock(&cp_lock);
	if (cp_file || cp_owner) {
		ret = -EBUSY;
		goto out;
	}
	cp_file = bdev_file_open_by_path(block_path, mode, &cp_lock, NULL);
	if (IS_ERR(cp_file)) {
		ret = PTR_ERR(cp_file);
		cp_file = NULL;
		goto out;
	}
	bdev = file_bdev(cp_file);
	if (!bdev_is_partition(bdev) || !bdev->bd_meta_info ||
	    strcmp(bdev->bd_meta_info->volname, "charger") ||
	    strcasecmp(bdev->bd_meta_info->uuid, partition_uuid) ||
	    bdev_logical_block_size(bdev) != CP_BLOCK ||
	    bdev_nr_bytes(bdev) < CP_MIN_BYTES) {
		ret = -EINVAL;
		goto close;
	}
	cp_poisoned = false;
	ret = cp_check_header();
	if (!ret)
		goto out;
close:
	bdev_fput(cp_file);
	cp_file = NULL;
out:
	mutex_unlock(&cp_lock);
	return ret;
}

static void charger_partition_remove(struct platform_device *pdev)
{
	mutex_lock(&cp_lock);
	if (cp_file) {
		bdev_fput(cp_file);
		cp_file = NULL;
	}
	/* An in-flight owner retains the static buffer and its module ref.
	 * dealloc releases that reference and reports ENODEV; no more disk I/O.
	 */
	mutex_unlock(&cp_lock);
}

static const struct of_device_id match_table[] = {
	{ .compatible = "xiaomi,charger_partition" },
	{},
};
MODULE_DEVICE_TABLE(of, match_table);

static struct platform_driver charger_partition_driver = {
	.driver = {
		.name = "charger_partition",
		.of_match_table = match_table,
		.suppress_bind_attrs = true,
	},
	.probe = charger_partition_probe,
	.remove = charger_partition_remove,
};
module_platform_driver(charger_partition_driver);
MODULE_DESCRIPTION("Myron charger partition storage provider (explicit identity required)");
MODULE_LICENSE("GPL v2");
