#!/usr/bin/env python3
"""Host control-flow checks, with Bazel and kernel compilation simulated."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent


def module_at(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before-runner', type=Path, required=True)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    helper = module_at('r12_early_helper_test', HERE / 'build_new_modules.py')
    installer = module_at('r12_early_installer_test', BUNDLE / 'install_hooks.py')
    before = args.before_runner.read_bytes()
    assert hashlib.sha256(before).hexdigest() == installer.BEFORE
    after = installer.patched(before)
    lock = json.loads((HERE / 'source-lock.json').read_text())
    registry = (HERE / 'payload' / helper.REGISTRY).read_text()
    names = lock['new_r12_modules']
    labels = helper.labels_from_registry(registry, names)
    assert len(labels) == len(set(labels)) == len(names) == 22
    # Includes the three independently observed run15 target names.
    observed = {
        '//vendor/qcom/sm8850:canoe_perf/drivers/power/supply/mca/mca_strategy/strategy_wireless/mca_wireless_revchg',
        '//vendor/qcom/sm8850:canoe_perf/drivers/power/supply/mca/mca_hardware_ic/fuelgauge_ic/bq27z561/bq27z561',
        '//vendor/qcom/sm8850:canoe_perf/drivers/power/supply/mca/mca_common/mca_adsp_glink',
    }
    assert observed <= set(labels)
    checks = [{'case': 'real_registry_22_labels_and_run15_targets', 'result': 'PASS'}]
    negatives = {
        'empty_list': (registry, []),
        'duplicate_list': (registry, names + names[:1]),
        'missing_entry': (registry, names + ['not_registered']),
        'wrong_output_entry': (registry.replace('out = "bq27z561.ko"', 'out = "wrong_bq27z561.ko"'), names),
        'dynamic_registry': (registry + '\nraise Exception("must never execute")\n', names),
        'unsafe_target': (registry.replace('name = "drivers/input/fingerprint/mi_fp"', 'name = "../bad"'), names),
    }
    for case, (text, selected) in negatives.items():
        try:
            helper.labels_from_registry(text, selected)
        except ValueError:
            checks.append({'case': case, 'result': 'PASS'})
        else:
            raise AssertionError('Negative accepted: ' + case)
    with tempfile.TemporaryDirectory(prefix='myron-r12-early-ddk-') as td:
        base = Path(td)
        package = base / 'myron-qcom-platform-r1'
        bundle = base / 'myron-adaptation-r12'
        drivers = bundle / 'drivers'
        package.mkdir()
        drivers.mkdir(parents=True)
        shutil.copy2(HERE / 'build_new_modules.py', drivers / 'build_new_modules.py')
        shutil.copy2(BUNDLE / 'install_hooks.py', bundle / 'install_hooks.py')
        runner_path = package / 'build_platform.py'
        runner_path.write_bytes(before)
        (drivers / 'source-lock.json').write_text(json.dumps(lock))
        # Minimal fixture lock validates every copied payload and uses the real
        # pinned original runner. Do not rewrite the actual release bundle lock.
        files = [{'path': str(p.relative_to(bundle)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                 for p in sorted(bundle.rglob('*')) if p.is_file()]
        (bundle / 'bundle-lock.json').write_text(json.dumps({
            'files': files, 'runner_after_sha256': hashlib.sha256(after).hexdigest()}))
        for expected in ('applied', 'already_applied'):
            subprocess.run([sys.executable, str(bundle / 'install_hooks.py'), '--package', str(package),
                            '--workspace', str(base / 'installer-workspace')], check=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            state = json.loads((base / 'installer-workspace/integration-reports/r12-hooks.json').read_text())
            assert state['status'] == expected
            assert runner_path.read_bytes() == after
        checks.append({'case': 'pinned_runner_install_and_repeat', 'result': 'PASS'})
        for stage, fail in [('soc', None), ('full', None), ('soc', 'early'), ('full', 'early'),
                            ('soc', 'validate'), ('full', 'validate'), ('dtbs', None), ('analyze', None)]:
            root = base / (stage + '-' + str(fail))
            registry_path = root / 'vendor/qcom/sm8850' / helper.REGISTRY
            registry_path.parent.mkdir(parents=True)
            registry_path.write_text(registry)
            runner = module_at('r12_fake_runner_' + stage + str(fail), runner_path)
            calls = []
            def simulated_logged(command, cwd, logpath, echo=True):
                calls.append(('logged', list(command)))
                logpath.write_text('simulated subprocess\n')
                is_build = len(command) > 4 and 'build' in command and Path(command[0]).name == 'bazel'
                if is_build and labels[0] in command and fail == 'early':
                    raise RuntimeError('simulated new module compile error')
                if 'validate' in command and fail == 'validate':
                    raise RuntimeError('simulated required gate failure')
            def simulated_query(command, **kwargs):
                calls.append(('query', list(command)))
                return subprocess.CompletedProcess(command, 0, stdout='', stderr='')
            def simulated_collect(*unused):
                calls.append(('collect', []))
                return 123
            with patch.object(runner, 'logged', side_effect=simulated_logged), \
                    patch.object(runner, 'collect', side_effect=simulated_collect), \
                    patch.object(runner.subprocess, 'run', side_effect=simulated_query), \
                    patch.object(sys, 'argv', ['build_platform.py', '--workspace', str(root), '--stage', stage,
                                               '--jobs', '3', '--ram-mb', '9876']), \
                    contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                result = runner.main()
            state = json.loads((root / 'integration-reports' / (stage + '-status.json')).read_text())
            builds = [c for kind, c in calls if kind == 'logged' and c and Path(c[0]).name == 'bazel']
            if stage in ('soc', 'full'):
                assert builds[0][-len(labels):] == labels
                assert '--jobs=3' in builds[0] and '--local_ram_resources=9876' in builds[0]
                early_state = json.loads((root / 'integration-reports' / (stage + '-r12-new-modules.json')).read_text())
                assert early_state['success'] is (fail != 'early')
                if fail == 'early':
                    assert len(builds) == 1
                    assert not any(k in ('query', 'collect') or 'validate' in c for k, c in calls)
                    assert 'r12_new_modules_compiled' not in state
                else:
                    assert len(builds) == 2
                    full_targets = state['build_targets']
                    assert builds[0][:-len(labels)] == builds[1][:-len(full_targets)], 'Bazel/output/options changed'
                    assert state['r12_new_modules_compiled'] is True
            else:
                assert len(builds) == 1
                assert not (root / 'integration-reports' / (stage + '-r12-new-modules.json')).exists()
                assert 'r12_new_module_targets' not in state
                assert ('--nobuild' in builds[0]) is (stage == 'analyze')
            if fail != 'early' and stage != 'analyze':
                kinds = [k for k, c in calls]
                assert kinds.index('query') < kinds.index('collect')
                assert any('validate' in c for k, c in calls)
            assert result == (1 if fail else 0)
            assert state['success'] is (not fail)
            assert state.get('r12_validation_passed', False) is (not fail and stage != 'analyze')
            checks.append({'case': stage + '_route_' + str(fail), 'result': 'PASS'})
        # Applied registry tampering must fail before a build can be dispatched.
        root = base / 'tamper'
        reports = root / 'integration-reports'
        reports.mkdir(parents=True)
        actual = root / 'vendor/qcom/sm8850' / helper.REGISTRY
        actual.parent.mkdir(parents=True)
        actual.write_text(registry + '\n# tamper\n')
        calls = []
        try:
            helper.build_new_modules(root, bundle, 'full', ['bazel'], ['--keep_going'],
                                     lambda *args: calls.append(args), reports)
        except ValueError as e:
            assert 'source lock' in str(e)
        else:
            raise AssertionError('Tampered registry accepted')
        assert calls == []
        checks.append({'case': 'applied_registry_hash_mismatch_stops_before_bazel', 'result': 'PASS'})
    report = {'success': True, 'checks': checks, 'new_modules': names, 'build_targets': labels,
              'runner_before_sha256': hashlib.sha256(before).hexdigest(),
              'runner_after_sha256': hashlib.sha256(after).hexdigest(),
              'scope': 'Host parser, installer, runner routing; Bazel execution is simulated. No target compilation.'}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'success': True, 'checks': len(checks), 'modules': len(labels),
                      'scope': report['scope']}))


if __name__ == '__main__':
    main()
