#!/usr/bin/env python3
"""Build the locked r12 additions before the broad soc/full target.

This uses real DDK targets, the runner's exact options and output_base, and all
normal dependencies. It reduces unrelated work after a new-driver failure;
it does not avoid the initial kernel preparation/build or prove runtime safety.
"""
import ast
import hashlib
import json
from pathlib import PurePosixPath
import re

REGISTRY = 'drivers/xiaomi/myron/modules.bzl'
TARGET_PREFIX = '//vendor/qcom/sm8850:canoe_perf/'


def labels_from_registry(registry, names):
    if (not isinstance(names, list) or not names or
            not all(isinstance(n, str) and re.fullmatch(r'[A-Za-z0-9_-]+', n) for n in names) or
            len(set(names)) != len(names)):
        raise ValueError('Expected a nonempty unique new_r12_modules list')
    tree = ast.parse(registry)
    if (len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef) or
            tree.body[0].name != 'register_modules'):
        raise ValueError('Expected literal register_modules definition')
    outputs, targets = {}, set()
    for statement in tree.body[0].body:
        call = statement.value if isinstance(statement, ast.Expr) else None
        if (not isinstance(call, ast.Call) or not isinstance(call.func, ast.Attribute) or
                not isinstance(call.func.value, ast.Name) or call.func.value.id != 'registry' or
                call.func.attr != 'register' or call.args or any(k.arg is None for k in call.keywords)):
            raise ValueError('Unsupported dynamic registry statement')
        row = {k.arg: ast.literal_eval(k.value) for k in call.keywords}
        if len(row) != len(call.keywords):
            raise ValueError('Duplicate registry keyword')
        target, out = row.get('name'), row.get('out')
        if (not isinstance(target, str) or not re.fullmatch(r'[A-Za-z0-9_./-]+', target) or
                str(PurePosixPath(target)) != target or target.startswith('/') or
                any(p in ('.', '..') for p in target.split('/')) or
                not isinstance(out, str) or not re.fullmatch(r'[A-Za-z0-9_-]+\.ko', out)):
            raise ValueError('Invalid registry target/output')
        if target in targets or out in outputs:
            raise ValueError('Ambiguous registry target/output: ' + str(out))
        targets.add(target)
        outputs[out] = target
    missing = [n for n in names if n + '.ko' not in outputs]
    if missing:
        raise ValueError('New modules missing from registry: ' + ', '.join(missing))
    # The name field is authoritative; an output basename is not a target path.
    return [TARGET_PREFIX + outputs[n + '.ko'] for n in names]


def build_new_modules(root, bundle, stage, bazel, options, logged, reports):
    if stage not in ('soc', 'full'):
        return None
    report_path = reports / (stage + '-r12-new-modules.json')
    state = {'stage': stage, 'success': False, 'flashable': False,
             'scope': 'Real r12 DDK build only; full collection and gates still required.'}
    try:
        drivers = bundle / 'drivers'
        lock = json.loads((drivers / 'source-lock.json').read_text())
        writes = [r for r in lock['writes'] if r['path'] == REGISTRY]
        if len(writes) != 1:
            raise ValueError('Registry must have exactly one locked write')
        raw = (root / 'vendor/qcom/sm8850' / REGISTRY).read_bytes()
        if hashlib.sha256(raw).hexdigest() != writes[0]['sha256']:
            raise ValueError('Applied registry does not match source lock')
        names = lock['new_r12_modules']
        labels = labels_from_registry(raw.decode(), names)
        if '--keep_going' not in options or '--nobuild' in options:
            raise ValueError('Early DDK pass requires real keep-going build options')
        command = list(bazel) + ['build'] + list(options) + labels
        state.update(modules=names, build_targets=labels, command=command)
        print('r12: build ' + str(len(labels)) + ' new DDK modules before ' + stage, flush=True)
        logged(command, root, reports / (stage + '-r12-new-modules.log'))
        state['success'] = True
        return labels
    except Exception as error:
        state['error'] = str(error)
        raise
    finally:
        report_path.write_text(json.dumps(state, indent=2) + '\n')
