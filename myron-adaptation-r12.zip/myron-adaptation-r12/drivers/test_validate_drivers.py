#!/usr/bin/env python3
"""Negative controls for driver gates, using synthetic AArch64 ELF fixtures.

These tests exercise validation and reporting, not target compilation or hardware.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('driver_gate_under_test', HERE / 'validate_drivers.py')
GATE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GATE)


def module_bytes(name, exports, versions=None, imports=('dep',), aliases=None,
                 parameters=('debug:bool',), dependencies=('provider',)):
    """Write the actual ELF tables consumed by the gate, with no parser mocking."""
    versions = {'module_layout': 0x10, 'dep': 0x20} if versions is None else versions
    aliases = ['i2c:' + name] if aliases is None else aliases
    info = ['name=' + name, 'vermagic=6.12-test SMP modversions aarch64',
            'depends=' + ','.join(dependencies), 'license=GPL']
    info += ['alias=' + x for x in aliases] + ['parmtype=' + x for x in parameters]
    strings = bytearray(b'\0')
    symbols = bytearray(24)
    for symbol, index in [('__ksymtab_' + x, 1) for x in exports] + [(x, 0) for x in imports]:
        offset = len(strings)
        strings.extend(symbol.encode() + b'\0')
        symbols.extend(struct.pack('<IBBHQQ', offset, 0x11, 0, index, 0, 0))
    crcs = b''.join(struct.pack('<Q', crc) + symbol.encode().ljust(56, b'\0')
                    for symbol, crc in versions.items())
    sections = [('', 0, b'', 0, 0),
                ('.modinfo', 1, ('\0'.join(info) + '\0').encode(), 0, 0),
                ('__versions', 1, crcs, 0, 0),
                ('.strtab', 3, bytes(strings), 0, 0),
                ('.symtab', 2, bytes(symbols), 3, 24)]
    section_names = b'\0'
    offsets = [0]
    for section_name, *_ in sections[1:]:
        offsets.append(len(section_names))
        section_names += section_name.encode() + b'\0'
    offsets.append(len(section_names))
    section_names += b'.shstrtab\0'
    sections.append(('.shstrtab', 3, section_names, 0, 0))
    blob = bytearray(64)
    blob[:6] = b'\x7fELF\x02\x01'
    struct.pack_into('<H', blob, 18, 183)
    headers = []
    for idx, (_, kind, data, link, entsize) in enumerate(sections):
        headers.append(struct.pack('<IIQQQQIIQQ', offsets[idx], kind, 0, 0,
                                   len(blob), len(data), link, 0, 1, entsize))
        blob.extend(data)
    struct.pack_into('<Q', blob, 40, len(blob))
    struct.pack_into('<HHH', blob, 58, 64, len(sections), len(sections) - 1)
    blob.extend(b''.join(headers))
    return bytes(blob)


class DriverGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='myron-driver-gate-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.bundle = self.root / 'drivers'
        self.bundle.mkdir()
        self.workspace = self.root / 'workspace'
        self.artifacts = self.workspace / 'integration-artifacts/full'
        self.artifacts.mkdir(parents=True)
        self.manifest = {'stage': 'full', 'flashable': False, 'files': []}
        self.lock = {'exports': {'alpha': ['alpha_export'], 'beta': ['beta_export']},
                     'module_contracts': {name: {
                         'aliases': ['i2c:' + name], 'parameters': ['debug:bool'],
                         'required_imports': ['dep'], 'required_dependencies': ['provider']}
                         for name in ('alpha', 'beta')}}
        for name in self.lock['exports']:
            self.artifact(name + '.ko', module_bytes(name, self.lock['exports'][name]))
        self.artifact('Module.symvers', b'0x10\tmodule_layout\tvmlinux\n0x20\tdep\tprovider\n')
        self.sync()

    def artifact(self, name, data):
        (self.artifacts / name).write_bytes(data)
        self.manifest['files'] = [x for x in self.manifest['files'] if x['file'] != name]
        self.manifest['files'].append({'file': name, 'sha256': hashlib.sha256(data).hexdigest()})

    def sync(self):
        (self.artifacts / 'artifact-manifest.json').write_text(json.dumps(self.manifest))
        (self.bundle / 'source-lock.json').write_text(json.dumps(self.lock))

    def run_gate(self):
        self.sync()
        with patch.object(GATE, 'HERE', self.bundle):
            return GATE.run(self.workspace, 'full')

    def failures(self):
        with self.assertRaises(GATE.ContractValidationError) as caught:
            self.run_gate()
        report = caught.exception.report
        self.assertFalse(report['passed'])
        self.assertFalse(report['success'])
        return report

    def test_success_preserves_api(self):
        result = self.run_gate()
        self.assertTrue(result['passed'])
        self.assertEqual([x['name'] for x in result['modules']], ['alpha', 'beta'])
        self.assertEqual(sum(x['checked_import_crcs'] for x in result['modules']), 4)

    def test_two_modules_report_all_alias_and_parameter_details(self):
        self.lock['module_contracts']['alpha']['aliases'] = ['i2c:wrong']
        self.lock['module_contracts']['beta']['parameters'] = []
        result = self.failures()
        self.assertEqual(result['error_count'], 2)
        self.assertEqual(result['failed_modules'], ['alpha', 'beta'])
        alias, parameters = result['errors']
        self.assertEqual(alias['expected'], ['i2c:wrong'])
        self.assertEqual(alias['actual'], ['i2c:alpha'])
        self.assertEqual(alias['missing'], ['i2c:wrong'])
        self.assertEqual(alias['unexpected'], ['i2c:alpha'])
        self.assertEqual(parameters['actual'], ['debug:bool'])

    def test_alias_failure_does_not_hide_same_module_crc_failure(self):
        self.lock['module_contracts']['alpha']['aliases'] = []
        self.artifact('alpha.ko', module_bytes('alpha', ['alpha_export'],
                                             versions={'module_layout': 0x10, 'dep': 0xDEAD}))
        result = self.failures()
        self.assertEqual([x['check'] for x in result['errors']], ['aliases', 'import_crcs'])
        self.assertEqual(result['errors'][1]['mismatches'][0]['import_crc'], '0xdead')

    def test_exact_exports_and_required_imports_dependencies_remain_strict(self):
        self.artifact('alpha.ko', module_bytes('alpha', ['wrong_export'], imports=(), dependencies=()))
        self.assertEqual({x['check'] for x in self.failures()['errors']},
                         {'exports', 'required_imports', 'required_dependencies'})

    def test_subset_policy_does_not_allow_missing_required_export(self):
        self.lock['module_contracts']['alpha']['exports_policy'] = 'required_subset_only; final exact set from new ELF'
        self.artifact('alpha.ko', module_bytes('alpha', ['alpha_export', 'extra_export']))
        self.assertTrue(self.run_gate()['passed'])
        self.artifact('alpha.ko', module_bytes('alpha', ['extra_export']))
        self.assertEqual([x['check'] for x in self.failures()['errors']], ['exports'])

    def test_export_duplicate_fails_even_with_identical_symbol_crc(self):
        self.artifact('unmanaged.ko', module_bytes('unmanaged', ['alpha_export']))
        report = self.failures()
        self.assertEqual(report['errors'][0]['check'], 'export_ownership')
        self.assertEqual(report['errors'][0]['collisions'],
                         {'alpha_export': ['alpha.ko', 'unmanaged.ko']})

    def test_import_without_crc_rejected(self):
        self.artifact('beta.ko', module_bytes('beta', ['beta_export'], imports=('dep', 'unversioned')))
        self.assertEqual(self.failures()['errors'][0]['check'], 'missing_import_crcs')

    def test_conflicting_provider_crcs_rejected(self):
        self.artifact('Other.symvers', b'0x30\tdep\tother_provider\n')
        errors = self.failures()['errors']
        self.assertEqual({x['module'] for x in errors}, {'alpha', 'beta'})
        self.assertTrue(all(x['check'] == 'import_crcs' for x in errors))

    def test_module_hash_tamper_still_stops_before_contracts(self):
        self.lock['module_contracts']['alpha']['aliases'] = []
        with (self.artifacts / 'beta.ko').open('ab') as output:
            output.write(b'tamper')
        with self.assertRaisesRegex(ValueError, 'module hash mismatch') as caught:
            self.run_gate()
        self.assertNotIsInstance(caught.exception, GATE.ContractValidationError)

    def test_symvers_hash_tamper_rejected(self):
        (self.artifacts / 'Module.symvers').write_text('tamper')
        with self.assertRaisesRegex(ValueError, 'symvers hash mismatch'):
            self.run_gate()

    def test_malformed_elf_rejected_after_matching_hash(self):
        self.artifact('beta.ko', b'not an ELF')
        with self.assertRaisesRegex(ValueError, 'expected little-endian AArch64 ELF64'):
            self.run_gate()

    def test_traversal_manifest_rejected(self):
        self.manifest['files'].append({'file': '../outside.ko', 'sha256': '0' * 64})
        with self.assertRaisesRegex(ValueError, 'unsafe artifact manifest path'):
            self.run_gate()

    def test_missing_module_does_not_hide_other_module_alias_failure(self):
        self.lock['exports']['missing'] = []
        self.lock['module_contracts']['beta']['aliases'] = []
        self.assertEqual({x['check'] for x in self.failures()['errors']}, {'module_count', 'aliases'})

    def test_unknown_export_policy_rejected(self):
        self.lock['module_contracts']['alpha']['exports_policy'] = 'ignore_everything'
        self.assertEqual(self.failures()['errors'][0]['check'], 'exports_policy')

    def test_hwid_specific_gates_retained(self):
        self.lock['exports']['hwid'] = []
        self.artifact('hwid.ko', module_bytes('hwid', []))
        checks = {x['check'] for x in self.failures()['errors']}
        self.assertEqual(checks, {'hwid_socinfo_import', 'hwid_socinfo_dependency', 'hwid_parameters'})

    def test_cli_writes_complete_failure_report_and_exits_nonzero(self):
        self.lock['module_contracts']['alpha']['aliases'] = []
        self.lock['module_contracts']['beta']['parameters'] = []
        self.sync()
        shutil.copy2(HERE / 'validate_drivers.py', self.bundle / 'validate_drivers.py')
        result = subprocess.run([sys.executable, str(self.bundle / 'validate_drivers.py'),
                                 '--workspace', str(self.workspace), '--stage', 'full'],
                                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.assertEqual(result.returncode, 1)
        report = json.loads((self.workspace / 'integration-reports/full-r12-driver-contracts.json').read_text())
        self.assertFalse(report['success'])
        self.assertEqual(report['error_count'], 2)
        self.assertEqual(report['failed_modules'], ['alpha', 'beta'])
        self.assertIn('driver contracts failed: 2 checks', result.stderr)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(DriverGateTests)
    case_names = [case.id().rsplit('.', 1)[-1] for case in suite]
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'passed': result.wasSuccessful(), 'tests_run': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors),
              'cases': case_names,
              'scope': 'Validator regression tests with synthetic AArch64 ELF files; no target compilation or hardware test.'}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    sys.exit(main())
