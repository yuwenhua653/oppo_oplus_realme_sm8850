#!/usr/bin/env python3
"""Check four IC contracts against literal exported I2C source tables.

This supplements, and does not replace, the exact complete alias comparison
against the compiled ELF. Unsupported/macro-generated tables fail explicitly.
"""
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
IC_MODULES = ('hl7603', 'sc8581', 'bq27z561', 'sc96281_charger')


def strip_comments(source):
    # Keep quoted C strings/chars intact while removing comments.
    token = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*.*?\*/|//[^\n]*', re.S)
    return token.sub(lambda m: ' ' if m.group().startswith(('/*', '//')) else m.group(), source)


def derive_i2c_aliases(source):
    source = strip_comments(source)
    declared = re.findall(r'\bMODULE_DEVICE_TABLE\s*\(\s*i2c\s*,\s*(\w+)\s*\)\s*;', source)
    uses = len(re.findall(r'\bMODULE_DEVICE_TABLE\s*\(\s*i2c\b', source))
    if uses != len(declared):
        raise ValueError('unsupported I2C MODULE_DEVICE_TABLE expression')
    aliases = set()
    evidence = []
    for name in declared:
        pattern = r'\bstruct\s+i2c_device_id\s+' + re.escape(name) + r'\s*\[\s*\]\s*=\s*\{(.*?)\}\s*;'
        tables = list(re.finditer(pattern, source, re.S))
        if len(tables) != 1:
            raise ValueError('expected one simple I2C table: ' + name)
        body = tables[0].group(1)
        entries = re.findall(r'\{([^{}]*)\}', body)
        leftover = re.sub(r'\{[^{}]*\}', '', body)
        if leftover.strip(' \t\r\n,'):
            raise ValueError('unsupported/macro-generated I2C table: ' + name)
        ids = []
        terminated = False
        for entry in entries:
            if not entry.strip():
                if terminated:
                    raise ValueError('multiple I2C sentinels: ' + name)
                terminated = True
                continue
            if terminated:
                raise ValueError('I2C entry after sentinel: ' + name)
            match = re.fullmatch(r'\s*"([A-Za-z0-9_,.+-]+)"\s*,\s*([A-Za-z_]\w*|0[xX][0-9A-Fa-f]+|[0-9]+)\s*,?\s*', entry)
            if not match:
                raise ValueError('unsupported I2C entry in ' + name)
            ids.append(match.group(1))
        if not ids or not terminated or len(ids) != len(set(ids)):
            raise ValueError('invalid simple I2C table: ' + name)
        aliases.update('i2c:' + value for value in ids)
        evidence.append({'table': name, 'device_ids': ids})
    # Literal manual I2C aliases are a separate source declaration, not inferred.
    aliases.update(re.findall(r'\bMODULE_ALIAS\s*\(\s*"(i2c:[^"]+)"\s*\)', source))
    return aliases, evidence


def registry_sources():
    entries = {}
    tree = ast.parse((HERE / 'payload/drivers/xiaomi/myron/modules.bzl').read_text())
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute) or node.func.attr != 'register':
            continue
        values = {key.arg: ast.literal_eval(key.value) for key in node.keywords}
        name = values['out'].removesuffix('.ko').replace('-', '_')
        if name in IC_MODULES:
            if name in entries:
                raise ValueError('duplicate IC registry output: ' + name)
            entries[name] = values['srcs']
    if set(entries) != set(IC_MODULES):
        raise ValueError('missing IC registry output')
    return entries


def inspect(lock):
    writes = {item['path']: item for item in lock['writes']}
    results = []
    for name, sources in sorted(registry_sources().items()):
        required = set()
        evidence = []
        for source_path in sources:
            if not source_path.endswith('.c'):
                continue
            entry = writes[source_path]
            data = (HERE / entry['payload']).read_bytes()
            if hashlib.sha256(data).hexdigest() != entry['sha256']:
                raise ValueError('IC source hash mismatch: ' + source_path)
            aliases, tables = derive_i2c_aliases(data.decode())
            required.update(aliases)
            evidence.append({'file': source_path, 'sha256': entry['sha256'], 'tables': tables})
        contract = lock['module_contracts'][name]
        if 'aliases' not in contract:
            raise ValueError('IC alias contract missing: ' + name)
        expected = {alias for alias in contract['aliases'] if alias.startswith('i2c:')}
        if expected != required:
            raise ValueError('I2C source/contract alias mismatch: ' + name + ': missing=' + repr(sorted(required - expected)) + ' unexpected=' + repr(sorted(expected - required)))
        results.append({'module': name, 'required_i2c_aliases': sorted(required), 'sources': evidence})
    return results


def expect_rejection(lock, mutation):
    changed = copy.deepcopy(lock)
    mutation(changed)
    try:
        inspect(changed)
    except ValueError as exc:
        if not str(exc).startswith('I2C source/contract alias mismatch: bq27z561:'):
            raise
        return True
    raise ValueError('negative alias contract was incorrectly accepted')


def run():
    lock = json.loads((HERE / 'source-lock.json').read_text())
    modules = inspect(lock)
    # Reproduce the delivered r12-fix1 omission using the current real source.
    def legacy_contract(changed):
        aliases = changed['module_contracts']['bq27z561']['aliases']
        changed['module_contracts']['bq27z561']['aliases'] = [value for value in aliases if not value.startswith('i2c:')]
    old_rejected = expect_rejection(lock, legacy_contract)
    def unexpected_alias(changed):
        changed['module_contracts']['bq27z561']['aliases'].append('i2c:unexpected-device')
    extra_rejected = expect_rejection(lock, unexpected_alias)
    unsupported = 'static struct i2c_device_id ids[] = { DEVICE_MACRO(foo), {} }; MODULE_DEVICE_TABLE(i2c, ids);'
    try:
        derive_i2c_aliases(unsupported)
    except ValueError:
        complex_rejected = True
    else:
        raise ValueError('macro-generated I2C table incorrectly accepted')
    return {'schema': 1, 'passed': True, 'modules_checked': len(modules),
            'legacy_contract_rejected': old_rejected,
            'unexpected_alias_rejected': extra_rejected,
            'unsupported_table_rejected': complex_rejected,
            'modules': modules,
            'scope': 'Literal exported I2C source tables vs contract I2C aliases. Full ELF alias exact equality, imports, CRCs and export uniqueness remain separate mandatory gates.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    report = run()
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': True, 'modules_checked': report['modules_checked'],
                      'negative_controls': 3}))


if __name__ == '__main__':
    main()
