#include "kernel_test.h"
#include <mca/protocol/protocol_pd_class.h>
#include <mca/common/mca_event.h>
static int checks;
#define CHECK(x) do { checks++;if(!(x)){fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#x);abort();}}while(0)
static void *expect_ptrs[8]; static long expect_vals[8]; static int seen,expected_data;
static int protocol_regs,protocol_fail_at;
static struct adapter_protocol_class_ops *protocol_ops[ADAPTER_PROTOCOL_MAX]; static void *protocol_data[ADAPTER_PROTOCOL_MAX];
int protocol_class_register_ops(unsigned int p,struct adapter_protocol_class_ops *o,void *d) { protocol_regs++;if(protocol_regs==protocol_fail_at)return -EIO;protocol_ops[p]=o;protocol_data[p]=d;return 0; }
int protocol_class_unregister_ops(unsigned int p,struct adapter_protocol_class_ops *o,void *d) { if(protocol_ops[p]!=o||protocol_data[p]!=d)return -ENOENT;protocol_ops[p]=NULL;protocol_data[p]=NULL;return 0; }
#define match_table pd_match_table
#include MCA_PD_SOURCE
#undef match_table
#define match_table bc12_match_table
#include MCA_BC12_SOURCE
#undef match_table
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_adapter_id)==224,"stock slot protocol_pd_get_adapter_id");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_adapter_svid)==232,"stock slot protocol_pd_get_adapter_svid");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_cap)==216,"stock slot protocol_pd_get_cap");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_cc_short_vbus)==376,"stock slot protocol_pd_get_cc_short_vbus");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_cc_status)==368,"stock slot protocol_pd_get_cc_status");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_cc_toggle)==352,"stock slot protocol_pd_get_cc_toggle");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_cid_status)==328,"stock slot protocol_pd_get_cid_status");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_current_state)==280,"stock slot protocol_pd_get_current_state");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_data_role)==272,"stock slot protocol_pd_get_data_role");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_has_dp)==240,"stock slot protocol_pd_get_has_dp");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_otg_plugin_status)==336,"stock slot protocol_pd_get_otg_plugin_status");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pd_active)==72,"stock slot protocol_pd_get_pd_active");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_in_hard_reset)==176,"stock slot protocol_pd_get_in_hard_reset");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pd_type)==128,"stock slot protocol_pd_get_pd_type");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pd_typec_accessory_mode)==208,"stock slot protocol_pd_get_pd_typec_accessory_mode");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pd_verifed)==320,"stock slot protocol_pd_get_pd_verifed");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pdos)==288,"stock slot protocol_pd_get_pdos");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_power_role)==264,"stock slot protocol_pd_get_power_role");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pps_apdo_max)==120,"stock slot protocol_pd_get_pps_apdo_max");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pps_max_cur)==48,"stock slot protocol_pd_get_pps_max_cur");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_pps_get_max_power)==0,"stock slot protocol_pd_pps_get_max_power");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pps_max_volt)==104,"stock slot protocol_pd_get_pps_max_volt");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pps_min_volt)==88,"stock slot protocol_pd_get_pps_min_volt");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pps_ptf)==16,"stock slot protocol_pd_get_pps_ptf");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_pps_status)==56,"stock slot protocol_pd_get_pps_status");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_snk_src_mode)==360,"stock slot protocol_pd_get_snk_src_mode");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_support_keep_pdo)==400,"stock slot protocol_pd_get_support_keep_pdo");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_suspend_support_status)==384,"stock slot protocol_pd_get_suspend_support_status");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_typec_cc_orientation)==152,"stock slot protocol_pd_get_typec_cc_orientation");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_typec_mode)==144,"stock slot protocol_pd_get_typec_mode");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_usb_suspend_supported)==192,"stock slot protocol_pd_get_usb_suspend_supported");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_vdm_cmd)==256,"stock slot protocol_pd_get_vdm_cmd");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_verify_process)==304,"stock slot protocol_pd_get_verify_process");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_get_zimi_cypress_flag)==392,"stock slot protocol_pd_get_zimi_cypress_flag");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_request_vdm_cmd)==248,"stock slot protocol_pd_request_vdm_cmd");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_cc_toggle)==344,"stock slot protocol_pd_set_cc_toggle");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_fixed_pdo_set_vol)==24,"stock slot protocol_pd_fixed_pdo_set_vol");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_gear_shift)==32,"stock slot protocol_pd_set_gear_shift");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_pd_active)==64,"stock slot protocol_pd_set_pd_active");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_in_hard_reset)==168,"stock slot protocol_pd_set_in_hard_reset");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_pd_typec_accessory_mode)==200,"stock slot protocol_pd_set_pd_typec_accessory_mode");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_pd_verifed)==312,"stock slot protocol_pd_set_pd_verifed");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_pps_apdo_max)==112,"stock slot protocol_pd_set_pps_apdo_max");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_pps_max_cur)==40,"stock slot protocol_pd_set_pps_max_cur");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_pps_max_volt)==96,"stock slot protocol_pd_set_pps_max_volt");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_pps_min_volt)==80,"stock slot protocol_pd_set_pps_min_volt");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_pps_pdo_select)==8,"stock slot protocol_pd_pps_pdo_select");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_typec_cc_orientation)==160,"stock slot protocol_pd_set_typec_cc_orientation");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_typec_mode)==136,"stock slot protocol_pd_set_typec_mode");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_usb_suspend_supported)==184,"stock slot protocol_pd_set_usb_suspend_supported");
_Static_assert(offsetof(struct protocol_class_pd_ops,protocol_pd_set_verify_process)==296,"stock slot protocol_pd_set_verify_process");
_Static_assert(sizeof(struct protocol_class_pd_ops)==408,"51 stock callbacks");
_Static_assert(sizeof(struct pd_pdo)==16,"stock PDO stride");
_Static_assert(offsetof(struct pd_pdo,pdo_type)==12,"stock PDO discriminator");
_Static_assert(offsetof(struct adapter_power_cap,min_voltage)==8,"stock cap min");
_Static_assert(offsetof(struct adapter_power_cap,max_voltage)==12,"stock cap max");
static int cb_0(unsigned int *max_power, void *data) {CHECK(data==&expected_data);seen=1;CHECK((void*)max_power==expect_ptrs[0]);return 17;}
static int cb_1(unsigned int volt, unsigned int curr, void *data) {CHECK(data==&expected_data);seen=2;CHECK((long)volt==expect_vals[0]);CHECK((long)curr==expect_vals[1]);return 18;}
static int cb_2(int *pps_ptf, void *data) {CHECK(data==&expected_data);seen=3;CHECK((void*)pps_ptf==expect_ptrs[0]);return 19;}
static int cb_3(unsigned int volt, void *data) {CHECK(data==&expected_data);seen=4;CHECK((long)volt==expect_vals[0]);return 20;}
static int cb_4(int gear_shift, void *data) {CHECK(data==&expected_data);seen=5;CHECK((long)gear_shift==expect_vals[0]);return 21;}
static int cb_5(unsigned int curr, void *data) {CHECK(data==&expected_data);seen=6;CHECK((long)curr==expect_vals[0]);return 22;}
static int cb_6(unsigned int *curr, void *data) {CHECK(data==&expected_data);seen=7;CHECK((void*)curr==expect_ptrs[0]);return 23;}
static int cb_7(unsigned int *volt, unsigned int *curr, void *data) {CHECK(data==&expected_data);seen=8;CHECK((void*)volt==expect_ptrs[0]);CHECK((void*)curr==expect_ptrs[1]);return 24;}
static int cb_8(int pd_active, void *data) {CHECK(data==&expected_data);seen=9;CHECK((long)pd_active==expect_vals[0]);return 25;}
static int cb_9(int *pd_active, void *data) {CHECK(data==&expected_data);seen=10;CHECK((void*)pd_active==expect_ptrs[0]);return 26;}
static int cb_10(unsigned int volt, void *data) {CHECK(data==&expected_data);seen=11;CHECK((long)volt==expect_vals[0]);return 27;}
static int cb_11(unsigned int *volt, void *data) {CHECK(data==&expected_data);seen=12;CHECK((void*)volt==expect_ptrs[0]);return 28;}
static int cb_12(unsigned int volt, void *data) {CHECK(data==&expected_data);seen=13;CHECK((long)volt==expect_vals[0]);return 29;}
static int cb_13(unsigned int *volt, void *data) {CHECK(data==&expected_data);seen=14;CHECK((void*)volt==expect_ptrs[0]);return 30;}
static int cb_14(unsigned int apdo_max, void *data) {CHECK(data==&expected_data);seen=15;CHECK((long)apdo_max==expect_vals[0]);return 31;}
static int cb_15(unsigned int *apdo_max, void *data) {CHECK(data==&expected_data);seen=16;CHECK((void*)apdo_max==expect_ptrs[0]);return 32;}
static int cb_16(int *type, void *data) {CHECK(data==&expected_data);seen=17;CHECK((void*)type==expect_ptrs[0]);return 33;}
static int cb_17(int typec_mode, void *data) {CHECK(data==&expected_data);seen=18;CHECK((long)typec_mode==expect_vals[0]);return 34;}
static int cb_18(int *typec_mode, void *data) {CHECK(data==&expected_data);seen=19;CHECK((void*)typec_mode==expect_ptrs[0]);return 35;}
static int cb_19(int *cc_orientation, void *data) {CHECK(data==&expected_data);seen=20;CHECK((void*)cc_orientation==expect_ptrs[0]);return 36;}
static int cb_20(int cc_orientation, void *data) {CHECK(data==&expected_data);seen=21;CHECK((long)cc_orientation==expect_vals[0]);return 37;}
static int cb_21(int in_hard_reset, void *data) {CHECK(data==&expected_data);seen=22;CHECK((long)in_hard_reset==expect_vals[0]);return 38;}
static int cb_22(int *in_hard_reset, void *data) {CHECK(data==&expected_data);seen=23;CHECK((void*)in_hard_reset==expect_ptrs[0]);return 39;}
static int cb_23(int supported, void *data) {CHECK(data==&expected_data);seen=24;CHECK((long)supported==expect_vals[0]);return 40;}
static int cb_24(int *supported, void *data) {CHECK(data==&expected_data);seen=25;CHECK((void*)supported==expect_ptrs[0]);return 41;}
static int cb_25(int typec_accessory_mode, void *data) {CHECK(data==&expected_data);seen=26;CHECK((long)typec_accessory_mode==expect_vals[0]);return 42;}
static int cb_26(int *typec_accessory_mode, void *data) {CHECK(data==&expected_data);seen=27;CHECK((void*)typec_accessory_mode==expect_ptrs[0]);return 43;}
static int cb_27(int cap_type, struct adapter_power_cap *tacap, void *data) {CHECK(data==&expected_data);seen=28;CHECK((long)cap_type==expect_vals[0]);CHECK((void*)tacap==expect_ptrs[1]);return 44;}
static int cb_28(unsigned int *adapter_id, void *data) {CHECK(data==&expected_data);seen=29;CHECK((void*)adapter_id==expect_ptrs[0]);return 45;}
static int cb_29(unsigned int *adapter_svid, void *data) {CHECK(data==&expected_data);seen=30;CHECK((void*)adapter_svid==expect_ptrs[0]);return 46;}
static int cb_30(bool *has_dp, void *data) {CHECK(data==&expected_data);seen=31;CHECK((void*)has_dp==expect_ptrs[0]);return 47;}
static int cb_31(enum uvdm_state cmd, unsigned int *data, unsigned int data_len, void *priv) {CHECK(priv==&expected_data);seen=32;CHECK((long)cmd==expect_vals[0]);CHECK((void*)data==expect_ptrs[1]);CHECK((long)data_len==expect_vals[2]);return 48;}
static int cb_32(int *cmd, struct usbpd_vdm_data *vdm_data, void *data) {CHECK(data==&expected_data);seen=33;CHECK((void*)cmd==expect_ptrs[0]);CHECK((void*)vdm_data==expect_ptrs[1]);return 49;}
static int cb_33(unsigned char *pr, void *data) {CHECK(data==&expected_data);seen=34;CHECK((void*)pr==expect_ptrs[0]);return 50;}
static int cb_34(unsigned char *pr, void *data) {CHECK(data==&expected_data);seen=35;CHECK((void*)pr==expect_ptrs[0]);return 51;}
static int cb_35(char *current_state, int len, void *data) {CHECK(data==&expected_data);seen=36;CHECK((void*)current_state==expect_ptrs[0]);CHECK((long)len==expect_vals[1]);return 52;}
static int cb_36(struct pd_pdo *pdos, int count, void *data) {CHECK(data==&expected_data);seen=37;CHECK(pdos!=NULL);CHECK((long)count==expect_vals[1]);return 53;}
static int cb_37(int verify_process, void *data) {CHECK(data==&expected_data);seen=38;CHECK((long)verify_process==expect_vals[0]);return 54;}
static int cb_38(int *verify_process, void *data) {CHECK(data==&expected_data);seen=39;CHECK((void*)verify_process==expect_ptrs[0]);return 55;}
static int cb_39(int pd_verifed, void *data) {CHECK(data==&expected_data);seen=40;CHECK((long)pd_verifed==expect_vals[0]);return 56;}
static int cb_40(int *pd_verifed, void *data) {CHECK(data==&expected_data);seen=41;CHECK((void*)pd_verifed==expect_ptrs[0]);return 57;}
static int cb_41(bool *status, void *data) {CHECK(data==&expected_data);seen=42;CHECK((void*)status==expect_ptrs[0]);return 58;}
static int cb_42(bool *status, void *data) {CHECK(data==&expected_data);seen=43;CHECK((void*)status==expect_ptrs[0]);return 59;}
static int cb_43(bool en, void *data) {CHECK(data==&expected_data);seen=44;CHECK((long)en==expect_vals[0]);return 60;}
static int cb_44(bool *en, void *data) {CHECK(data==&expected_data);seen=45;CHECK((void*)en==expect_ptrs[0]);return 61;}
static int cb_45(int *snk_src_mode, void *data) {CHECK(data==&expected_data);seen=46;CHECK((void*)snk_src_mode==expect_ptrs[0]);return 62;}
static int cb_46(bool *status, void *data) {CHECK(data==&expected_data);seen=47;CHECK((void*)status==expect_ptrs[0]);return 63;}
static int cb_47(int *cc_short_vbus, void *data) {CHECK(data==&expected_data);seen=48;CHECK((void*)cc_short_vbus==expect_ptrs[0]);return 64;}
static int cb_48(bool *pdsuspendsupported, void *data) {CHECK(data==&expected_data);seen=49;CHECK((void*)pdsuspendsupported==expect_ptrs[0]);return 65;}
static int cb_49(int *zimi_cypress_flag, void *data) {CHECK(data==&expected_data);seen=50;CHECK((void*)zimi_cypress_flag==expect_ptrs[0]);return 66;}
static int cb_50(int *support, void *data) {CHECK(data==&expected_data);seen=51;CHECK((void*)support==expect_ptrs[0]);return 67;}
static struct protocol_class_pd_ops full_ops = {.protocol_pd_pps_get_max_power=cb_0,.protocol_pd_pps_pdo_select=cb_1,.protocol_pd_get_pps_ptf=cb_2,.protocol_pd_fixed_pdo_set_vol=cb_3,.protocol_pd_set_gear_shift=cb_4,.protocol_pd_set_pps_max_cur=cb_5,.protocol_pd_get_pps_max_cur=cb_6,.protocol_pd_get_pps_status=cb_7,.protocol_pd_set_pd_active=cb_8,.protocol_pd_get_pd_active=cb_9,.protocol_pd_set_pps_min_volt=cb_10,.protocol_pd_get_pps_min_volt=cb_11,.protocol_pd_set_pps_max_volt=cb_12,.protocol_pd_get_pps_max_volt=cb_13,.protocol_pd_set_pps_apdo_max=cb_14,.protocol_pd_get_pps_apdo_max=cb_15,.protocol_pd_get_pd_type=cb_16,.protocol_pd_set_typec_mode=cb_17,.protocol_pd_get_typec_mode=cb_18,.protocol_pd_get_typec_cc_orientation=cb_19,.protocol_pd_set_typec_cc_orientation=cb_20,.protocol_pd_set_in_hard_reset=cb_21,.protocol_pd_get_in_hard_reset=cb_22,.protocol_pd_set_usb_suspend_supported=cb_23,.protocol_pd_get_usb_suspend_supported=cb_24,.protocol_pd_set_pd_typec_accessory_mode=cb_25,.protocol_pd_get_pd_typec_accessory_mode=cb_26,.protocol_pd_get_cap=cb_27,.protocol_pd_get_adapter_id=cb_28,.protocol_pd_get_adapter_svid=cb_29,.protocol_pd_get_has_dp=cb_30,.protocol_pd_request_vdm_cmd=cb_31,.protocol_pd_get_vdm_cmd=cb_32,.protocol_pd_get_power_role=cb_33,.protocol_pd_get_data_role=cb_34,.protocol_pd_get_current_state=cb_35,.protocol_pd_get_pdos=cb_36,.protocol_pd_set_verify_process=cb_37,.protocol_pd_get_verify_process=cb_38,.protocol_pd_set_pd_verifed=cb_39,.protocol_pd_get_pd_verifed=cb_40,.protocol_pd_get_cid_status=cb_41,.protocol_pd_get_otg_plugin_status=cb_42,.protocol_pd_set_cc_toggle=cb_43,.protocol_pd_get_cc_toggle=cb_44,.protocol_pd_get_snk_src_mode=cb_45,.protocol_pd_get_cc_status=cb_46,.protocol_pd_get_cc_short_vbus=cb_47,.protocol_pd_get_suspend_support_status=cb_48,.protocol_pd_get_zimi_cypress_flag=cb_49,.protocol_pd_get_support_keep_pdo=cb_50,};
static void test_dispatch(void) { struct protocol_class_pd_ops missing=full_ops; CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);
{unsigned int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pps_max_power(0,arg0)==17);CHECK(seen==1);
CHECK(protocol_class_pd_get_pps_max_power(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_pps_get_max_power=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pps_max_power(0,arg0)==-1);missing.protocol_pd_pps_get_max_power=full_ops.protocol_pd_pps_get_max_power;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;expect_vals[1]=3;seen=0;CHECK(protocol_class_pd_set_pps_pdo_select(0,2,3)==18);CHECK(seen==2);
CHECK(protocol_class_pd_set_pps_pdo_select(TYPEC_PORT_MAX,2,3)==-EINVAL);
missing.protocol_pd_pps_pdo_select=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pps_pdo_select(0,2,3)==-1);missing.protocol_pd_pps_pdo_select=full_ops.protocol_pd_pps_pdo_select;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pps_ptf(0,arg0)==19);CHECK(seen==3);
CHECK(protocol_class_pd_get_pps_ptf(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pps_ptf=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pps_ptf(0,arg0)==-1);missing.protocol_pd_get_pps_ptf=full_ops.protocol_pd_get_pps_ptf;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_fixed_volt(0,2)==20);CHECK(seen==4);
CHECK(protocol_class_pd_set_fixed_volt(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_fixed_pdo_set_vol=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_fixed_volt(0,2)==-1);missing.protocol_pd_fixed_pdo_set_vol=full_ops.protocol_pd_fixed_pdo_set_vol;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_gear_shift(0,2)==21);CHECK(seen==5);
CHECK(protocol_class_pd_set_gear_shift(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_gear_shift=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_gear_shift(0,2)==-1);missing.protocol_pd_set_gear_shift=full_ops.protocol_pd_set_gear_shift;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pps_max_cur(0,2)==22);CHECK(seen==6);
CHECK(protocol_class_pd_set_pps_max_cur(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_pps_max_cur=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pps_max_cur(0,2)==-1);missing.protocol_pd_set_pps_max_cur=full_ops.protocol_pd_set_pps_max_cur;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pps_max_cur(0,arg0)==23);CHECK(seen==7);
CHECK(protocol_class_pd_get_pps_max_cur(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pps_max_cur=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pps_max_cur(0,arg0)==-1);missing.protocol_pd_get_pps_max_cur=full_ops.protocol_pd_get_pps_max_cur;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};int arg1[8]={0};expect_ptrs[0]=arg0;expect_ptrs[1]=arg1;seen=0;CHECK(protocol_class_pd_get_pps_status(0,arg0,arg1)==24);CHECK(seen==8);
CHECK(protocol_class_pd_get_pps_status(TYPEC_PORT_MAX,arg0,arg1)==-EINVAL);
missing.protocol_pd_get_pps_status=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pps_status(0,arg0,arg1)==-1);missing.protocol_pd_get_pps_status=full_ops.protocol_pd_get_pps_status;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pd_active(0,2)==25);CHECK(seen==9);
CHECK(protocol_class_pd_set_pd_active(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_pd_active=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pd_active(0,2)==-1);missing.protocol_pd_set_pd_active=full_ops.protocol_pd_set_pd_active;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pd_active(0,arg0)==26);CHECK(seen==10);
CHECK(protocol_class_pd_get_pd_active(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pd_active=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pd_active(0,arg0)==-1);missing.protocol_pd_get_pd_active=full_ops.protocol_pd_get_pd_active;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pps_min_volt(0,2)==27);CHECK(seen==11);
CHECK(protocol_class_pd_set_pps_min_volt(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_pps_min_volt=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pps_min_volt(0,2)==-1);missing.protocol_pd_set_pps_min_volt=full_ops.protocol_pd_set_pps_min_volt;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pps_min_volt(0,arg0)==28);CHECK(seen==12);
CHECK(protocol_class_pd_get_pps_min_volt(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pps_min_volt=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pps_min_volt(0,arg0)==-1);missing.protocol_pd_get_pps_min_volt=full_ops.protocol_pd_get_pps_min_volt;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pps_max_volt(0,2)==29);CHECK(seen==13);
CHECK(protocol_class_pd_set_pps_max_volt(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_pps_max_volt=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pps_max_volt(0,2)==-1);missing.protocol_pd_set_pps_max_volt=full_ops.protocol_pd_set_pps_max_volt;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pps_max_volt(0,arg0)==30);CHECK(seen==14);
CHECK(protocol_class_pd_get_pps_max_volt(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pps_max_volt=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pps_max_volt(0,arg0)==-1);missing.protocol_pd_get_pps_max_volt=full_ops.protocol_pd_get_pps_max_volt;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pps_apdo_max(0,2)==31);CHECK(seen==15);
CHECK(protocol_class_pd_set_pps_apdo_max(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_pps_apdo_max=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pps_apdo_max(0,2)==-1);missing.protocol_pd_set_pps_apdo_max=full_ops.protocol_pd_set_pps_apdo_max;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pps_apdo_max(0,arg0)==32);CHECK(seen==16);
CHECK(protocol_class_pd_get_pps_apdo_max(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pps_apdo_max=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pps_apdo_max(0,arg0)==-1);missing.protocol_pd_get_pps_apdo_max=full_ops.protocol_pd_get_pps_apdo_max;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pd_type(0,arg0)==33);CHECK(seen==17);
CHECK(protocol_class_pd_get_pd_type(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pd_type=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pd_type(0,arg0)==-1);missing.protocol_pd_get_pd_type=full_ops.protocol_pd_get_pd_type;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_typec_mode(0,2)==34);CHECK(seen==18);
CHECK(protocol_class_pd_set_typec_mode(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_typec_mode=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_typec_mode(0,2)==-1);missing.protocol_pd_set_typec_mode=full_ops.protocol_pd_set_typec_mode;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_typec_mode(0,arg0)==35);CHECK(seen==19);
CHECK(protocol_class_pd_get_typec_mode(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_typec_mode=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_typec_mode(0,arg0)==-1);missing.protocol_pd_get_typec_mode=full_ops.protocol_pd_get_typec_mode;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_typec_cc_orientation(0,arg0)==36);CHECK(seen==20);
CHECK(protocol_class_pd_get_typec_cc_orientation(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_typec_cc_orientation=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_typec_cc_orientation(0,arg0)==-1);missing.protocol_pd_get_typec_cc_orientation=full_ops.protocol_pd_get_typec_cc_orientation;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_typec_cc_orientation(0,2)==37);CHECK(seen==21);
CHECK(protocol_class_pd_set_typec_cc_orientation(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_typec_cc_orientation=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_typec_cc_orientation(0,2)==-1);missing.protocol_pd_set_typec_cc_orientation=full_ops.protocol_pd_set_typec_cc_orientation;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pd_in_hard_reset(0,2)==38);CHECK(seen==22);
CHECK(protocol_class_pd_set_pd_in_hard_reset(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_in_hard_reset=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pd_in_hard_reset(0,2)==-1);missing.protocol_pd_set_in_hard_reset=full_ops.protocol_pd_set_in_hard_reset;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pd_in_hard_reset(0,arg0)==39);CHECK(seen==23);
CHECK(protocol_class_pd_get_pd_in_hard_reset(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_in_hard_reset=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pd_in_hard_reset(0,arg0)==-1);missing.protocol_pd_get_in_hard_reset=full_ops.protocol_pd_get_in_hard_reset;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_usb_suspend_supported(0,2)==40);CHECK(seen==24);
CHECK(protocol_class_pd_set_usb_suspend_supported(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_usb_suspend_supported=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_usb_suspend_supported(0,2)==-1);missing.protocol_pd_set_usb_suspend_supported=full_ops.protocol_pd_set_usb_suspend_supported;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_usb_suspend_supported(0,arg0)==41);CHECK(seen==25);
CHECK(protocol_class_pd_get_usb_suspend_supported(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_usb_suspend_supported=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_usb_suspend_supported(0,arg0)==-1);missing.protocol_pd_get_usb_suspend_supported=full_ops.protocol_pd_get_usb_suspend_supported;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pd_typec_accessory_mode(0,2)==42);CHECK(seen==26);
CHECK(protocol_class_pd_set_pd_typec_accessory_mode(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_pd_typec_accessory_mode=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pd_typec_accessory_mode(0,2)==-1);missing.protocol_pd_set_pd_typec_accessory_mode=full_ops.protocol_pd_set_pd_typec_accessory_mode;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pd_typec_accessory_mode(0,arg0)==43);CHECK(seen==27);
CHECK(protocol_class_pd_get_pd_typec_accessory_mode(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pd_typec_accessory_mode=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pd_typec_accessory_mode(0,arg0)==-1);missing.protocol_pd_get_pd_typec_accessory_mode=full_ops.protocol_pd_get_pd_typec_accessory_mode;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{struct adapter_power_cap arg1[8]={0};expect_vals[0]=2;expect_ptrs[1]=arg1;seen=0;CHECK(protocol_class_pd_get_cap(0,2,arg1)==44);CHECK(seen==28);
CHECK(protocol_class_pd_get_cap(TYPEC_PORT_MAX,2,arg1)==-EINVAL);
missing.protocol_pd_get_cap=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_cap(0,2,arg1)==-1);missing.protocol_pd_get_cap=full_ops.protocol_pd_get_cap;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_adapter_id(0,arg0)==45);CHECK(seen==29);
CHECK(protocol_class_pd_get_adapter_id(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_adapter_id=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_adapter_id(0,arg0)==-1);missing.protocol_pd_get_adapter_id=full_ops.protocol_pd_get_adapter_id;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_adapter_svid(0,arg0)==46);CHECK(seen==30);
CHECK(protocol_class_pd_get_adapter_svid(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_adapter_svid=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_adapter_svid(0,arg0)==-1);missing.protocol_pd_get_adapter_svid=full_ops.protocol_pd_get_adapter_svid;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{bool arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_has_dp(0,arg0)==47);CHECK(seen==31);
CHECK(protocol_class_pd_get_has_dp(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_has_dp=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_has_dp(0,arg0)==-1);missing.protocol_pd_get_has_dp=full_ops.protocol_pd_get_has_dp;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned int arg1[8]={0};expect_vals[0]=2;expect_ptrs[1]=arg1;expect_vals[2]=7;seen=0;CHECK(protocol_class_pd_request_vdm_cmd(0,2,arg1,7)==48);CHECK(seen==32);
CHECK(protocol_class_pd_request_vdm_cmd(TYPEC_PORT_MAX,2,arg1,7)==-EINVAL);
missing.protocol_pd_request_vdm_cmd=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_request_vdm_cmd(0,2,arg1,7)==-1);missing.protocol_pd_request_vdm_cmd=full_ops.protocol_pd_request_vdm_cmd;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};struct usbpd_vdm_data arg1[8]={0};expect_ptrs[0]=arg0;expect_ptrs[1]=arg1;seen=0;CHECK(protocol_class_pd_get_vdm_cmd(0,arg0,arg1)==49);CHECK(seen==33);
CHECK(protocol_class_pd_get_vdm_cmd(TYPEC_PORT_MAX,arg0,arg1)==-EINVAL);
missing.protocol_pd_get_vdm_cmd=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_vdm_cmd(0,arg0,arg1)==-1);missing.protocol_pd_get_vdm_cmd=full_ops.protocol_pd_get_vdm_cmd;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned char arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_power_role(0,arg0)==50);CHECK(seen==34);
CHECK(protocol_class_pd_get_power_role(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_power_role=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_power_role(0,arg0)==-1);missing.protocol_pd_get_power_role=full_ops.protocol_pd_get_power_role;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{unsigned char arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_data_role(0,arg0)==51);CHECK(seen==35);
CHECK(protocol_class_pd_get_data_role(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_data_role=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_data_role(0,arg0)==-1);missing.protocol_pd_get_data_role=full_ops.protocol_pd_get_data_role;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{char arg0[8]={0};expect_ptrs[0]=arg0;expect_vals[1]=32;seen=0;CHECK(protocol_class_pd_get_current_state(0,arg0,32)==52);CHECK(seen==36);
CHECK(protocol_class_pd_get_current_state(TYPEC_PORT_MAX,arg0,32)==-EINVAL);
missing.protocol_pd_get_current_state=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_current_state(0,arg0,32)==-1);missing.protocol_pd_get_current_state=full_ops.protocol_pd_get_current_state;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{struct pd_pdo arg0[8]={0};expect_ptrs[0]=arg0;expect_vals[1]=7;seen=0;CHECK(protocol_class_pd_get_pdos(0,arg0,7)==53);CHECK(seen==37);
CHECK(protocol_class_pd_get_pdos(TYPEC_PORT_MAX,arg0,7)==-EINVAL);
missing.protocol_pd_get_pdos=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pdos(0,arg0,7)==-1);missing.protocol_pd_get_pdos=full_ops.protocol_pd_get_pdos;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_verify_process(0,2)==54);CHECK(seen==38);
CHECK(protocol_class_pd_set_verify_process(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_verify_process=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_verify_process(0,2)==-1);missing.protocol_pd_set_verify_process=full_ops.protocol_pd_set_verify_process;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_verify_process(0,arg0)==55);CHECK(seen==39);
CHECK(protocol_class_pd_get_verify_process(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_verify_process=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_verify_process(0,arg0)==-1);missing.protocol_pd_get_verify_process=full_ops.protocol_pd_get_verify_process;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=2;seen=0;CHECK(protocol_class_pd_set_pd_verifed(0,2)==56);CHECK(seen==40);
CHECK(protocol_class_pd_set_pd_verifed(TYPEC_PORT_MAX,2)==-EINVAL);
missing.protocol_pd_set_pd_verifed=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_pd_verifed(0,2)==-1);missing.protocol_pd_set_pd_verifed=full_ops.protocol_pd_set_pd_verifed;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_pd_verifed(0,arg0)==57);CHECK(seen==41);
CHECK(protocol_class_pd_get_pd_verifed(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_pd_verifed=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_pd_verifed(0,arg0)==-1);missing.protocol_pd_get_pd_verifed=full_ops.protocol_pd_get_pd_verifed;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{bool arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_cid_status(0,arg0)==58);CHECK(seen==42);
CHECK(protocol_class_pd_get_cid_status(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_cid_status=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_cid_status(0,arg0)==-1);missing.protocol_pd_get_cid_status=full_ops.protocol_pd_get_cid_status;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{bool arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_otg_plugin_status(0,arg0)==59);CHECK(seen==43);
CHECK(protocol_class_pd_get_otg_plugin_status(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_otg_plugin_status=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_otg_plugin_status(0,arg0)==-1);missing.protocol_pd_get_otg_plugin_status=full_ops.protocol_pd_get_otg_plugin_status;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{expect_vals[0]=1;seen=0;CHECK(protocol_class_pd_set_cc_toggle(0,1)==60);CHECK(seen==44);
CHECK(protocol_class_pd_set_cc_toggle(TYPEC_PORT_MAX,1)==-EINVAL);
missing.protocol_pd_set_cc_toggle=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_set_cc_toggle(0,1)==-1);missing.protocol_pd_set_cc_toggle=full_ops.protocol_pd_set_cc_toggle;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{bool arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_cc_toggle(0,arg0)==61);CHECK(seen==45);
CHECK(protocol_class_pd_get_cc_toggle(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_cc_toggle=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_cc_toggle(0,arg0)==-1);missing.protocol_pd_get_cc_toggle=full_ops.protocol_pd_get_cc_toggle;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_snk_src_mode(0,arg0)==62);CHECK(seen==46);
CHECK(protocol_class_pd_get_snk_src_mode(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_snk_src_mode=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_snk_src_mode(0,arg0)==-1);missing.protocol_pd_get_snk_src_mode=full_ops.protocol_pd_get_snk_src_mode;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{bool arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_cc_status(0,arg0)==63);CHECK(seen==47);
CHECK(protocol_class_pd_get_cc_status(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_cc_status=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_cc_status(0,arg0)==-1);missing.protocol_pd_get_cc_status=full_ops.protocol_pd_get_cc_status;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_cc_short_vbus(0,arg0)==64);CHECK(seen==48);
CHECK(protocol_class_pd_get_cc_short_vbus(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_cc_short_vbus=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_cc_short_vbus(0,arg0)==-1);missing.protocol_pd_get_cc_short_vbus=full_ops.protocol_pd_get_cc_short_vbus;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{bool arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_suspend_support_status(0,arg0)==65);CHECK(seen==49);
CHECK(protocol_class_pd_get_suspend_support_status(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_suspend_support_status=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_suspend_support_status(0,arg0)==-1);missing.protocol_pd_get_suspend_support_status=full_ops.protocol_pd_get_suspend_support_status;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_zimi_cypress_flag(0,arg0)==66);CHECK(seen==50);
CHECK(protocol_class_pd_get_zimi_cypress_flag(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_zimi_cypress_flag=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_zimi_cypress_flag(0,arg0)==-1);missing.protocol_pd_get_zimi_cypress_flag=full_ops.protocol_pd_get_zimi_cypress_flag;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
{int arg0[8]={0};expect_ptrs[0]=arg0;seen=0;CHECK(protocol_class_pd_get_support_keep_pdo(0,arg0)==67);CHECK(seen==51);
CHECK(protocol_class_pd_get_support_keep_pdo(TYPEC_PORT_MAX,arg0)==-EINVAL);
missing.protocol_pd_get_support_keep_pdo=NULL;CHECK(protocol_class_pd_register_ops(0,&missing,&expected_data)==0);CHECK(protocol_class_pd_get_support_keep_pdo(0,arg0)==-1);missing.protocol_pd_get_support_keep_pdo=full_ops.protocol_pd_get_support_keep_pdo;CHECK(protocol_class_pd_register_ops(0,&full_ops,&expected_data)==0);}
CHECK(protocol_class_pd_unregister_ops(0,&full_ops,&expected_data)==0); CHECK(protocol_class_pd_unregister_ops(0,&full_ops,&expected_data)==-ENOENT); }
_Static_assert(__builtin_types_compatible_p(__typeof__(((struct protocol_class_pd_ops*)0)->protocol_pd_fixed_pdo_set_vol),int (*)(unsigned int,void*)),"stock fixed voltage unsigned callback");
#include "pps_unsigned_tests.inc"
#include "semantic_tests.inc"
