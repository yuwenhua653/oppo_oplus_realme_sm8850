#!/usr/bin/env bash
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
payload="${1:-$here/../candidate}"
payload="$(cd -- "$payload" && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf -- "$tmp"' EXIT
"${CC:-cc}" -std=gnu11 -O1 -g -Wall -Wextra -Werror -Wno-unused-parameter -Wno-unused-function -Wno-unused-variable -Wno-sign-compare -Wno-misleading-indentation -pthread -fsanitize=address,undefined -fno-omit-frame-pointer -I"$here/stubs" -I"$payload/drivers/power/supply/mca/include" -DMCA_PD_SOURCE="\"$payload/drivers/power/supply/mca/mca_protocol/protocol_pd/mca_protocol_pd_class.c\"" -DMCA_BC12_SOURCE="\"$payload/drivers/power/supply/mca/mca_platform/mca_platform_bc12_class.c\"" "$here/test_pd_bc12.c" -o "$tmp/test_pd_bc12"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=1 "$tmp/test_pd_bc12"
