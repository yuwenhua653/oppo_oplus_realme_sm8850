#!/usr/bin/env python3
"""Execute actual MCA getter/helper bodies with a fake host provider core.

This checks C error propagation and successful unit mappings, not kernel ABI,
callback concurrency, device probe, or battery hardware behavior.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--payload', type=Path, required=True)
parser.add_argument('--report', type=Path)
args = parser.parse_args()
root = args.payload.resolve()
source = root / 'drivers/power/supply/mca/mca_business/business_battery/mca_battery_psy.c'
s = source.read_text()

def function(name):
    m = re.search(r'^(?:static\s+)?(?:bool|int|void)\s+' + re.escape(name) + r'\s*\([^;]*?\)\s*\{', s, re.M)
    if not m:
        raise ValueError('missing function ' + name)
    start = s.index('{', m.start())
    level = 1
    i = start + 1
    # Functions being extracted contain no unmatched literal braces.
    while level:
        level += (s[i] == '{') - (s[i] == '}')
        i += 1
    return s[m.start():i]

names = ['battery_psy_is_wls_available', 'battery_psy_is_usb_available',
         'get_prop_batt_health', 'get_prop_batt_capacity_level',
         'fake_batt_psy_get_prop', 'batt_psy_get_prop',
         'business_battery_dump_log_context', 'business_battery_psy_deinit']
# The exact implementation functions below are compiled, not a rewritten model.
functions = '\n\n'.join(function(name) for name in names)
published = re.search(r'static enum power_supply_property batt_psy_props\[\]\s*=\s*\{.*?\};', s, re.S)
if not published:
    raise ValueError('missing advertised property array')
functions = published.group(0) + '\n' + functions
properties = sorted(set(re.findall(r'\bPOWER_SUPPLY_PROP_\w+', s)))
constants = sorted(set(re.findall(r'\bPOWER_SUPPLY_(?:STATUS|HEALTH|CAPACITY_LEVEL|TECHNOLOGY)_\w+', s)) | {'POWER_SUPPLY_HEALTH_GOOD'})
prefix = r'''
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#define mca_log_info(...) ((void)0)
#define mca_log_err(...) ((void)0)
#define MAIN_BUCK_CHARGER 0
#define MCA_CHARGE_LOG_ID_BATTERY_INFO 0
#define BATT_SOC_DEFAULT 15
#define BATT_VOLTAGE_DEFAULT 3700000
#define BATT_CURRENT_DEFAULT -500000
#define BATT_TEMP_DEFAULT 250
#define IS_ERR_OR_NULL(p) (!(p))
'''
prefix += 'enum power_supply_property {' + ','.join(properties) + ', PROP_COUNT};\n'
prefix += 'enum {' + ','.join(constants) + '};\n'
prefix += r'''
union power_supply_propval { int intval; const char *strval; };
struct power_supply { int id; void *data; };
struct thermal_zone_device { int unused; };
struct batt_psy_info {
    struct power_supply *batt_psy, *usb_psy, *wls_psy;
    void *input_suppend_voter;
    struct thermal_zone_device *tzd;
    int fake_power;
};
static struct batt_psy_info info;
static struct power_supply battery = {0, &info}, usb = {1, NULL}, wireless = {2, NULL};
static int available[3], refs[3], lookups[3], put_count, thermal_put, log_detach;
static int ready, soc, done, vote, provider_rc, buck_rc;
static int read_rc[3], online[3], gets[3], fg_reads;
static int val_voltage, val_current, val_temp, val_health, val_buck;
static const char *model = "test-real-provider";
static int batt_psy_get_prop(struct power_supply *, enum power_supply_property,
                            union power_supply_propval *);
static struct power_supply *power_supply_get_by_name(const char *name)
{
    int id = strcmp(name, "usb") == 0 ? 1 : 2;
    assert(id == 1 || strcmp(name, "wireless") == 0);
    ++lookups[id];
    if (!available[id]) return NULL;
    ++refs[id];
    return id == 1 ? &usb : &wireless;
}
static void *power_supply_get_drvdata(struct power_supply *psy) { return psy->data; }
static void power_supply_put(struct power_supply *psy)
{
    assert(psy->id > 0 && refs[psy->id] == 1);
    --refs[psy->id]; ++put_count;
}
static void thermal_zone_device_unregister(struct thermal_zone_device *t) { assert(t); ++thermal_put; }
static void mca_log_charge_log_register(int id, void *ops, void *data)
{ assert(id == 0 && !ops && !data); ++log_detach; }
static int power_supply_get_property(struct power_supply *psy, enum power_supply_property p,
                                     union power_supply_propval *v)
{
    ++gets[psy->id];
    if (read_rc[psy->id]) { v->intval = 456789; return read_rc[psy->id]; }
    if (psy == &battery) return batt_psy_get_prop(psy, p, v);
    if (p == POWER_SUPPLY_PROP_ONLINE) v->intval = online[psy->id];
    else if (p == POWER_SUPPLY_PROP_VOLTAGE_MAX) v->intval = 9000000;
    else if (p == POWER_SUPPLY_PROP_CURRENT_MAX) v->intval = 3000000;
    else assert(0);
    return 0;
}
static int strategy_class_fg_ops_is_init_ok(void) { return ready; }
static int strategy_class_fg_ops_get_soc(void) { ++fg_reads; return soc; }
static bool strategy_class_fg_ops_get_charging_done(void) { return done; }
#define GETTER(name, value) static int name(int *v) { ++fg_reads; *v = value; return provider_rc; }
GETTER(strategy_class_fg_get_health, val_health)
GETTER(strategy_class_fg_ops_get_voltage, val_voltage)
GETTER(strategy_class_fg_ops_get_current, val_current)
GETTER(strategy_class_fg_ops_get_temperature, val_temp)
GETTER(strategy_class_fg_get_rm, 2700000)
GETTER(strategy_class_fg_ops_get_cyclecount, 17)
GETTER(strategy_class_fg_get_fcc, 6000000)
GETTER(strategy_class_fg_get_dc, 6200000)
static int strategy_class_fg_get_model_name(const char **v) { ++fg_reads; *v = model; return provider_rc; }
static int platform_class_buckchg_ops_get_chg_type(int role, int *v)
{ assert(role == 0); *v = val_buck; return buck_rc; }
static void *mca_find_votable(const char *name)
{ assert(strcmp(name, "input_suspend") == 0); return vote ? &vote : NULL; }
static int mca_get_client_vote(void *v, const char *name)
{ assert(v == &vote && strcmp(name, "micharge") == 0); return vote; }
static void reset(void)
{
    memset(&info, 0, sizeof(info)); info.batt_psy = &battery; battery.data = &info;
    memset(refs, 0, sizeof(refs)); memset(lookups, 0, sizeof(lookups));
    memset(read_rc, 0, sizeof(read_rc)); memset(online, 0, sizeof(online));
    memset(gets, 0, sizeof(gets));
    available[1] = available[2] = 1;
    ready = 1; soc = 55; done = vote = provider_rc = buck_rc = fg_reads = 0;
    put_count = thermal_put = log_detach = 0;
    val_voltage = 3900; val_current = -1250000; val_temp = -20;
    val_health = POWER_SUPPLY_HEALTH_GOOD; val_buck = 2;
}
'''
suffix = r'''
static int cases;
static void expect(enum power_supply_property prop, int rc, int val)
{
    union power_supply_propval out = { .intval = -77777 };
    assert(batt_psy_get_prop(&battery, prop, &out) == rc);
    assert(out.intval == (rc ? -77777 : val));
    ++cases;
}
int main(void)
{
    reset(); battery.data = NULL; expect(POWER_SUPPLY_PROP_CAPACITY, -ENODEV, 0);
    reset(); info.batt_psy = NULL; expect(POWER_SUPPLY_PROP_CAPACITY, -ENODEV, 0);
    reset(); ready = -1; expect(POWER_SUPPLY_PROP_CAPACITY, -ENODATA, 0); assert(!fg_reads && !lookups[1]);
    reset(); ready = 0; expect(POWER_SUPPLY_PROP_CAPACITY, -ENODATA, 0); assert(!fg_reads && !lookups[1]);
    reset(); available[1] = 0; expect(POWER_SUPPLY_PROP_CAPACITY, -ENODEV, 0); assert(!fg_reads);
    reset(); available[2] = 0; expect(POWER_SUPPLY_PROP_CAPACITY, -ENODEV, 0); assert(!fg_reads && refs[1] == 1);
    business_battery_psy_deinit(&info); assert(refs[1] == 0 && put_count == 1); ++cases;
    reset(); read_rc[1] = -EIO; expect(POWER_SUPPLY_PROP_STATUS, -EIO, 0); assert(gets[2] == 0 && !fg_reads);
    reset(); read_rc[2] = -ETIMEDOUT; expect(POWER_SUPPLY_PROP_STATUS, -ETIMEDOUT, 0); assert(!fg_reads);
    reset(); online[1] = 1; read_rc[2] = -EIO; expect(POWER_SUPPLY_PROP_STATUS, 0, POWER_SUPPLY_STATUS_CHARGING); assert(gets[2] == 0);
    reset(); online[2] = 1; expect(POWER_SUPPLY_PROP_STATUS, 0, POWER_SUPPLY_STATUS_CHARGING);
    reset(); online[1] = 1; soc = 100; done = 1; expect(POWER_SUPPLY_PROP_STATUS, 0, POWER_SUPPLY_STATUS_FULL);
    reset(); online[2] = 1; soc = 100; done = 0; expect(POWER_SUPPLY_PROP_STATUS, 0, POWER_SUPPLY_STATUS_CHARGING);
    reset(); expect(POWER_SUPPLY_PROP_STATUS, 0, POWER_SUPPLY_STATUS_DISCHARGING); assert(!fg_reads);
    reset(); vote = 1; read_rc[1] = -EIO; expect(POWER_SUPPLY_PROP_STATUS, 0, POWER_SUPPLY_STATUS_DISCHARGING); assert(!gets[1]);
    reset(); online[1] = 1; soc = -EAGAIN; expect(POWER_SUPPLY_PROP_STATUS, -EAGAIN, 0);
    reset(); online[2] = 1; soc = 101; expect(POWER_SUPPLY_PROP_STATUS, -ERANGE, 0);
    reset(); soc = -EREMOTEIO; expect(POWER_SUPPLY_PROP_CAPACITY, -EREMOTEIO, 0);
    reset(); soc = 101; expect(POWER_SUPPLY_PROP_CAPACITY, -ERANGE, 0);
    reset(); soc = 0; expect(POWER_SUPPLY_PROP_CAPACITY, 0, 0);
    reset(); soc = 100; expect(POWER_SUPPLY_PROP_CAPACITY, 0, 100);
    reset(); read_rc[0] = -EIO; expect(POWER_SUPPLY_PROP_CAPACITY_LEVEL, -EIO, 0);
    reset(); soc = -ENODATA; expect(POWER_SUPPLY_PROP_CAPACITY_LEVEL, -ENODATA, 0);
    reset(); soc = 101; expect(POWER_SUPPLY_PROP_CAPACITY_LEVEL, -ERANGE, 0);
    int caps[] = {0, 1, 20, 21, 80, 81, 99, 100};
    int levels[] = {POWER_SUPPLY_CAPACITY_LEVEL_CRITICAL, POWER_SUPPLY_CAPACITY_LEVEL_LOW,
        POWER_SUPPLY_CAPACITY_LEVEL_LOW, POWER_SUPPLY_CAPACITY_LEVEL_NORMAL,
        POWER_SUPPLY_CAPACITY_LEVEL_NORMAL, POWER_SUPPLY_CAPACITY_LEVEL_HIGH,
        POWER_SUPPLY_CAPACITY_LEVEL_HIGH, POWER_SUPPLY_CAPACITY_LEVEL_FULL};
    for (unsigned i = 0; i < sizeof(caps)/sizeof(*caps); ++i) {
        reset(); soc = caps[i]; expect(POWER_SUPPLY_PROP_CAPACITY_LEVEL, 0, levels[i]);
    }
    enum power_supply_property fg_props[] = {POWER_SUPPLY_PROP_HEALTH, POWER_SUPPLY_PROP_VOLTAGE_NOW,
        POWER_SUPPLY_PROP_VOLTAGE_OCV, POWER_SUPPLY_PROP_CURRENT_NOW, POWER_SUPPLY_PROP_TEMP,
        POWER_SUPPLY_PROP_CHARGE_COUNTER, POWER_SUPPLY_PROP_CYCLE_COUNT, POWER_SUPPLY_PROP_CHARGE_FULL,
        POWER_SUPPLY_PROP_CHARGE_FULL_DESIGN, POWER_SUPPLY_PROP_MODEL_NAME};
    for (unsigned i = 0; i < sizeof(fg_props)/sizeof(*fg_props); ++i) {
        reset(); provider_rc = -EREMOTEIO; val_voltage = INT_MAX; expect(fg_props[i], -EREMOTEIO, 0);
    }
    reset(); buck_rc = -ETIMEDOUT; expect(POWER_SUPPLY_PROP_CHARGE_TYPE, -ETIMEDOUT, 0);
    reset(); expect(POWER_SUPPLY_PROP_CHARGE_TYPE, 0, 2);
    reset(); expect(POWER_SUPPLY_PROP_HEALTH, 0, POWER_SUPPLY_HEALTH_GOOD);
    reset(); expect(POWER_SUPPLY_PROP_VOLTAGE_NOW, 0, 3900000);
    reset(); expect(POWER_SUPPLY_PROP_VOLTAGE_OCV, 0, 3900000);
    reset(); expect(POWER_SUPPLY_PROP_CURRENT_NOW, 0, -1250000);
    reset(); expect(POWER_SUPPLY_PROP_TEMP, 0, -20);
    reset(); expect(POWER_SUPPLY_PROP_CHARGE_COUNTER, 0, 2700000);
    reset(); expect(POWER_SUPPLY_PROP_CYCLE_COUNT, 0, 17);
    reset(); expect(POWER_SUPPLY_PROP_CHARGE_FULL, 0, 6000000);
    reset(); expect(POWER_SUPPLY_PROP_CHARGE_FULL_DESIGN, 0, 6200000);
    reset(); union power_supply_propval output;
    assert(!batt_psy_get_prop(&battery, POWER_SUPPLY_PROP_MODEL_NAME, &output) && output.strval == model); ++cases;
    reset(); read_rc[1] = -EIO; expect(POWER_SUPPLY_PROP_VOLTAGE_MAX, -EIO, 0);
    reset(); read_rc[1] = -EIO; expect(POWER_SUPPLY_PROP_CONSTANT_CHARGE_CURRENT_MAX, -EIO, 0);
    reset(); expect(POWER_SUPPLY_PROP_VOLTAGE_MAX, 0, 9000000);
    reset(); expect(POWER_SUPPLY_PROP_CONSTANT_CHARGE_CURRENT_MAX, 0, 3000000);
    reset(); expect(POWER_SUPPLY_PROP_PRESENT, 0, 1);
    reset(); expect(POWER_SUPPLY_PROP_TECHNOLOGY, 0, POWER_SUPPLY_TECHNOLOGY_LIPO);
    reset(); expect(POWER_SUPPLY_PROP_CHARGE_CONTROL_LIMIT_MAX, 0, 16);
    enum power_supply_property absent[] = {POWER_SUPPLY_PROP_INPUT_CURRENT_LIMIT,
        POWER_SUPPLY_PROP_CHARGE_CONTROL_LIMIT, POWER_SUPPLY_PROP_CONSTANT_CHARGE_CURRENT,
        POWER_SUPPLY_PROP_CHARGE_TERM_CURRENT, POWER_SUPPLY_PROP_TIME_TO_FULL_NOW,
        POWER_SUPPLY_PROP_TIME_TO_EMPTY_NOW};
    for (unsigned i = 0; i < sizeof(absent)/sizeof(*absent); ++i) {
        reset(); expect(absent[i], -ENODATA, 0);
    }
    reset(); expect(PROP_COUNT, -EINVAL, 0);
    reset(); info.fake_power = 1; ready = -1; expect(POWER_SUPPLY_PROP_CAPACITY, 0, 15);
    reset(); info.fake_power = 1; read_rc[1] = -EIO; expect(POWER_SUPPLY_PROP_STATUS, -EIO, 0);
    reset(); info.fake_power = 1; buck_rc = -EIO; expect(POWER_SUPPLY_PROP_CHARGE_TYPE, -EIO, 0);
    reset(); info.fake_power = 1; expect(POWER_SUPPLY_PROP_TIME_TO_FULL_NOW, -ENODATA, 0);
    /* power_supply_uevent skips only ENODATA/ENODEV; other errors abort it.
     * Traverse the exact advertised source array with normal, factory,
     * unregistered-FG and absent-USB providers, not a hand-picked subset. */
    for (int mode = 0; mode < 4; ++mode) {
        reset();
        if (mode == 1) info.fake_power = 1;
        if (mode == 2) ready = -1;
        if (mode == 3) available[1] = 0;
        unsigned skipped = 0;
        for (unsigned i = 0; i < sizeof(batt_psy_props)/sizeof(*batt_psy_props); ++i) {
            union power_supply_propval value;
            int rc = batt_psy_get_prop(&battery, batt_psy_props[i], &value);
            if (rc == -ENODATA || rc == -ENODEV) ++skipped;
            else assert(rc == 0);
            ++cases;
        }
        if (mode == 0) assert(skipped == 6);
        if (mode == 1) assert(skipped > 6);
        if (mode >= 2) assert(skipped == sizeof(batt_psy_props)/sizeof(*batt_psy_props));
    }
    reset(); char log[200]; int a, b, c, d, e, f;
    ready = -1; business_battery_dump_log_context(&info, log, sizeof(log));
    assert(sscanf(log, "%d%d%d%d%d%d", &a,&b,&c,&d,&e,&f) == 6);
    assert(a == -1 && b == -1 && c == -1 && d == -1 && e == -1 && f == -1); ++cases;
    reset(); business_battery_dump_log_context(&info, log, sizeof(log));
    assert(sscanf(log, "%d%d%d%d%d%d", &a,&b,&c,&d,&e,&f) == 6);
    assert(a == POWER_SUPPLY_STATUS_DISCHARGING && b == 55 && c == -1 && d == 3900 && e == -1250 && f == -20); ++cases;
    reset(); expect(POWER_SUPPLY_PROP_CAPACITY, 0, 55); expect(POWER_SUPPLY_PROP_TEMP, 0, -20);
    assert(refs[1] == 1 && refs[2] == 1 && lookups[1] == 1 && lookups[2] == 1);
    struct thermal_zone_device zone; info.tzd = &zone;
    business_battery_psy_deinit(&info); assert(refs[1] == 0 && refs[2] == 0 && put_count == 2 && thermal_put == 1); ++cases;
    business_battery_psy_deinit(&info); assert(put_count == 2 && thermal_put == 1); ++cases;
    business_battery_psy_deinit(NULL); ++cases;
    printf("{\"passed\":true,\"cases\":%d}\n", cases);
}
'''
with tempfile.TemporaryDirectory(prefix='r13-battery-') as td:
    cfile = Path(td) / 'test.c'
    exe = Path(td) / 'test'
    cfile.write_text(prefix + functions + suffix)
    subprocess.run(['cc', '-std=gnu11', '-Wall', '-Wextra', '-Werror',
                    '-Wno-unused-parameter', '-fsanitize=undefined',
                    '-fno-sanitize-recover=all', str(cfile), '-o', str(exe)], check=True)
    result = subprocess.run([str(exe)], capture_output=True, text=True)
    if result.returncode:
        sys.stderr.write(result.stderr)
        raise SystemExit(1)
    report = json.loads(result.stdout)
    report.update({'source': str(source.relative_to(root)),
                   'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                   'functions_compiled': names, 'ubsan': True,
                   'uevent_enumeration': 'exact advertised source array; normal, factory, unregistered FG, absent USB; only ENODATA/ENODEV skips',
                   'scope': 'actual functions against fake host providers; not whole-kernel or hardware validation'})
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
