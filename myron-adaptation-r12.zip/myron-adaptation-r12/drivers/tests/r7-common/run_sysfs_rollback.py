#!/usr/bin/env python3
"""Failure-inject actual MCA sysfs group/link helper bodies in host mocks."""
import argparse, hashlib, json, os, re, subprocess, tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('payload',type=Path);p.add_argument('--report',type=Path);a=p.parse_args()
src=a.payload/'drivers/power/supply/mca/mca_common/mca_sysfs.c';s=src.read_text()
def function(name):
 m=re.search(r'^(?:void|int)\s+'+name+r'\s*\(',s,re.M);assert m,name
 brace=s.index('{',m.end());depth=1;i=brace+1
 while depth:depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[m.start():i]+'\n'
code=r'''
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#define pr_info(...) ((void)0)
struct kobject { int id; };
struct device { struct kobject kobj; };
struct attribute_group { int id; };
struct mca_sysfs_class_node { void *mca_class; };
static struct device parent={{1}}, target={{2}};
static struct attribute_group attributes={3};
static struct mca_sysfs_class_node node={(void*)1};
static int group_result,link_result,create_group_calls,create_link_calls;
static int remove_group_calls,remove_link_calls,checks;
static bool has_class=true,has_device=true,group_exists,link_exists;
#define CHECK(x) do{checks++;assert(x);}while(0)
static struct mca_sysfs_class_node *mca_sysfs_get_class_node(const char *name){assert(!strcmp(name,"xm_power"));return has_class?&node:NULL;}
static struct device *mca_sysfs_get_device(struct mca_sysfs_class_node *n,const char *name){assert(n==&node);assert(!strcmp(name,"charger"));return has_device?&parent:NULL;}
static int sysfs_create_group(struct kobject *k,const struct attribute_group *g){assert(k==&target.kobj&&g==&attributes);create_group_calls++;if(group_result)return group_result;assert(!group_exists);group_exists=true;return 0;}
static int sysfs_create_link(struct kobject *p,struct kobject *t,const char *name){assert(p==&parent.kobj&&t==&target.kobj&&!strcmp(name,"charge_interface"));create_link_calls++;if(link_result)return link_result;assert(!link_exists);link_exists=true;return 0;}
static void sysfs_remove_group(struct kobject *k,const struct attribute_group *g){assert(k==&target.kobj&&g==&attributes);assert(group_exists);group_exists=false;remove_group_calls++;}
static void sysfs_remove_link(struct kobject *p,const char *name){assert(p==&parent.kobj&&!strcmp(name,"charge_interface"));assert(link_exists);link_exists=false;remove_link_calls++;}
static void reset(void){group_result=link_result=0;create_group_calls=create_link_calls=remove_group_calls=remove_link_calls=0;group_exists=link_exists=false;has_class=has_device=true;node.mca_class=(void*)1;}
'''
code+=function('mca_sysfs_create_link_group')+function('mca_sysfs_remove_link_group')
code+=r'''
static int create(void){return mca_sysfs_create_link_group("charger","charge_interface",&target,&attributes);}
int main(void){
 reset();CHECK(create()==0);CHECK(group_exists&&link_exists);CHECK(create_group_calls==1&&create_link_calls==1);CHECK(remove_group_calls==0&&remove_link_calls==0);
 mca_sysfs_remove_link_group("charger","charge_interface",&target,&attributes);CHECK(!group_exists&&!link_exists);CHECK(remove_group_calls==1&&remove_link_calls==1);
 int errors[]={-ENOMEM,-EEXIST,-EIO,-EINVAL};
 for(unsigned i=0;i<sizeof(errors)/sizeof(errors[0]);i++){
  reset();group_result=errors[i];group_exists=(errors[i]==-EEXIST);
  bool old_group=group_exists;CHECK(create()==-1);CHECK(group_exists==old_group);CHECK(create_group_calls==1&&create_link_calls==0);CHECK(remove_group_calls==0&&remove_link_calls==0);
  reset();link_result=errors[i];link_exists=(errors[i]==-EEXIST);
  bool old_link=link_exists;CHECK(create()==-1);CHECK(!group_exists);CHECK(link_exists==old_link);CHECK(create_group_calls==1&&create_link_calls==1);CHECK(remove_group_calls==1&&remove_link_calls==0);
 }
 reset();has_class=false;CHECK(create()==-1);CHECK(create_group_calls==0&&remove_group_calls==0);
 reset();node.mca_class=NULL;CHECK(create()==-1);CHECK(create_group_calls==0&&remove_group_calls==0);
 reset();has_device=false;CHECK(create()==-1);CHECK(create_group_calls==0&&remove_group_calls==0);
 reset();CHECK(mca_sysfs_create_link_group(NULL,"charge_interface",&target,&attributes)==-1);
 CHECK(mca_sysfs_create_link_group("charger",NULL,&target,&attributes)==-1);
 CHECK(mca_sysfs_create_link_group("charger","charge_interface",NULL,&attributes)==-1);
 CHECK(mca_sysfs_create_link_group("charger","charge_interface",&target,NULL)==-1);
 CHECK(create_group_calls==0&&create_link_calls==0&&remove_group_calls==0&&remove_link_calls==0);
 printf("{\"passed\":true,\"checks\":%d,\"injected_failure_errno_values\":4,\"actual_helper_bodies\":true}\n",checks);
 return 0;
}
'''
with tempfile.TemporaryDirectory() as t:
 d=Path(t);c=d/'test.c';exe=d/'test';c.write_text(code)
 subprocess.run(['cc','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
 env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';r=subprocess.run([str(exe)],capture_output=True,text=True,check=True,env=env);print(r.stdout.strip())
 report=json.loads(r.stdout);report.update(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),sanitizers=['address','undefined'],scope='Host tests actual create/remove helper C bodies. No real sysfs or module lifetime validation.')
 if a.report:a.report.write_text(json.dumps(report,indent=2)+'\n')
