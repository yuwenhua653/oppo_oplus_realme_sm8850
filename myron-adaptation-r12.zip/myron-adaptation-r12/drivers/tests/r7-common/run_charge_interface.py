#!/usr/bin/env python3
"""Compile actual candidate C/header against host kernel-service mocks.
No target kernel, CFI, real sysfs, module lifetime or hardware validation.
"""
import argparse, json, os, subprocess, tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('payload',type=Path);args=p.parse_args()
source=args.payload/'drivers/power/supply/mca/mca_common/mca_charge_interface.c'
header=args.payload/'drivers/power/supply/mca/include/mca/common/mca_charge_interface.h'
def without_includes(s):return '\n'.join(x for x in s.splitlines() if not x.startswith('#include '))+'\n'
prefix=r'''
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <assert.h>
#define CONFIG_SYSFS 1
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define PAGE_SIZE 4096
#define GFP_KERNEL 0
#define THIS_MODULE NULL
#define __init
#define __exit
#define EXPORT_SYMBOL(x)
#define MODULE_DESCRIPTION(x)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#define module_init(x)
#define module_exit(x)
#define mca_log_err(...) ((void)0)
#define mca_log_info(...) ((void)0)
#define SYSFS_DEV_1 "charger"
#define MCA_EVENT_TYPE_BATTERY_INFO 2
#define MCA_EVENT_BATTERY_STS_CHANGE 17
struct device { void *data; };
struct attribute { const char *name; unsigned short mode; };
struct device_attribute { struct attribute attr; };
struct attribute_group { struct attribute **attrs; };
struct mca_sysfs_attr_info { struct device_attribute attr; int sysfs_attr_name; };
#define mca_sysfs_attr_rw(prefix,mode,name,file) { .attr = { .attr = { #file, mode } }, .sysfs_attr_name = name }
struct of_device_id { const char *compatible; };
struct platform_device { struct device dev; };
struct platform_driver {
 struct { void *owner; const char *name; const struct of_device_id *of_match_table; } driver;
 int (*probe)(struct platform_device *);
 void (*remove)(struct platform_device *);
};
static void *devm_kzalloc(struct device *d,size_t n,int flags){(void)d;(void)flags;return calloc(1,n);}
static void platform_set_drvdata(struct platform_device *p,void *v){p->dev.data=v;}
static int platform_driver_register(struct platform_driver *p){(void)p;return 0;}
static void platform_driver_unregister(struct platform_driver *p){(void)p;}
static int scnprintf(char *b,size_t n,const char *f,...){va_list a;va_start(a,f);int r=vsnprintf(b,n,f,a);va_end(a);return n?(r<(int)n?r:(int)n-1):0;}
static int kstrtouint(const char *s,unsigned base,unsigned *out){char *e;unsigned long n;if(!s||!*s||*s=='-')return -EINVAL;errno=0;n=strtoul(s,&e,base);if(e==s)return -EINVAL;if(*e=='\n')e++;if(*e)return -EINVAL;if(errno==ERANGE||n>UINT_MAX)return -ERANGE;*out=n;return 0;}
static struct mca_sysfs_attr_info *mca_sysfs_lookup_attr(const char *n,struct mca_sysfs_attr_info *a,int size){for(int i=0;i<size;i++)if(!strcmp(a[i].attr.attr.name,n))return &a[i];return NULL;}
static void mca_sysfs_init_attrs(struct attribute **a,struct mca_sysfs_attr_info *b,int n){for(int i=0;i<n;i++)a[i]=&b[i].attr.attr;}
static int mca_sysfs_create_link_group(const char *a,const char *b,struct device *d,const struct attribute_group *g){return 0;}
static void mca_sysfs_remove_link_group(const char *a,const char *b,struct device *d,const struct attribute_group *g){}
static int notify_calls,notify_type,notify_event;
static int mca_event_block_notify(int type,unsigned long event,void *d){assert(!d);notify_calls++;notify_type=type;notify_event=event;return 0;}
'''
tests=r'''
#define OFF(field,n) _Static_assert(offsetof(struct mca_charge_if_ops, field)==n,#field " stock offset")
OFF(type_name,0); OFF(data,8); OFF(set_input_suspend,16); OFF(get_input_suspend,24);
OFF(set_charge_enable,32); OFF(get_charge_enable,40); OFF(set_input_current_limit,48);
OFF(get_input_current_limit,56); OFF(set_charge_current_limit,64); OFF(get_charge_current_limit,72);
OFF(set_charge_power_limit,80); OFF(get_charge_power_limit,88); OFF(set_ship_mode_en,96);
OFF(get_ship_mode_status,104); _Static_assert(sizeof(struct mca_charge_if_ops)==112,"stock callback ABI size");
static int call_id,call_count,backend_result,get_fill,checks;
static unsigned int call_value;
static int cookie;
#define CHECK(x) do{checks++;assert(x);}while(0)
static int set_common(int id,const char *u,void *data){assert(data==&cookie);assert(u&&*u);call_id=id;call_count++;return backend_result;}
static int set_s(const char*u,char*v,void*d){assert(v);return set_common(0,u,d);}
static int set_e(const char*u,unsigned v,void*d){call_value=v;return set_common(1,u,d);}
static int set_i(const char*u,char*v,void*d){assert(v);return set_common(2,u,d);}
static int set_c(const char*u,char*v,void*d){assert(v);return set_common(3,u,d);}
static int set_p(const char*u,unsigned v,void*d){call_value=v;return set_common(4,u,d);}
static int set_h(const char*u,unsigned v,void*d){call_value=v;return set_common(6,u,d);}
static int get_common(int id,char *v,void*d){assert(d==&cookie);call_id=id;call_count++;if(get_fill)memset(v,'x',128);else strcpy(v,"1");return backend_result;}
static int get_s(char*v,void*d){return get_common(0,v,d);}
static int get_e(char*v,void*d){return get_common(1,v,d);}
static int get_i(char*v,void*d){return get_common(2,v,d);}
static int get_c(char*v,void*d){return get_common(3,v,d);}
static int get_p(char*v,void*d){return get_common(4,v,d);}
static int get_h(bool*v,void*d){assert(d==&cookie);*v=true;return backend_result;}
static ssize_t store(int attr,const char *b,size_t n){return mca_charge_if_sysfs_store(NULL,&mca_charge_if_sysfs_field_tbl[attr].attr,b,n);}
static ssize_t show(int attr,char *b){return mca_charge_if_sysfs_show(NULL,&mca_charge_if_sysfs_field_tbl[attr].attr,b);}
int main(void){
 char buf[PAGE_SIZE];
 bool value=false;
 struct mca_charge_if_ops ops[19];
 CHECK(mca_charge_if_ops_register(NULL)==-1);
 struct mca_charge_if_ops bad={0};CHECK(mca_charge_if_ops_register(&bad)==-1);
 bad.type_name="missing";CHECK(mca_charge_if_ops_register(&bad)==-1);
 CHECK(mca_charge_if_get_ops(UINT_MAX)==NULL);CHECK(mca_charge_if_get_ops(19)==NULL);
 CHECK(mca_charge_ship_mode_show(&value)==-ENODEV);
 CHECK(show(6,buf)==-ENODEV);
 for(int i=0;i<19;i++){
  ops[i]=(struct mca_charge_if_ops){g_mca_charge_if_op_type_table[i],&cookie,set_s,get_s,set_e,get_e,set_i,get_i,set_c,get_c,set_p,get_p,set_h,get_h};
  CHECK(mca_charge_if_ops_register(&ops[i])==0);
 }
 CHECK(mca_charge_if_common_sysfs_set("u",19,0,"1")==-EINVAL);
 CHECK(mca_charge_if_common_sysfs_set("u",UINT_MAX,0,"1")==-EINVAL);
 for(int t=0;t<18;t++)for(int a=0;a<7;a++)if(a!=5){
  char line[256];int n=snprintf(line,sizeof(line),"u %s 1",g_mca_charge_if_op_type_table[t]);
  call_count=0;
  CHECK(store(a,a==6?"1\n":line,a==6?2:n)==(a==6?2:n));CHECK(call_count==1);CHECK(call_id==a);
 }
 CHECK(notify_calls>0 && notify_type==2 && notify_event==16);
 for(int a=1;a<=6;a++)if(a==1||a==4||a==6){
  const char *vals[]={"bad","-1","4294967296","1junk",""};
  for(int i=0;i<5;i++){char line[300];int n=snprintf(line,sizeof(line),"u buck %s",vals[i]);call_count=0;
   CHECK(store(a,a==6?vals[i]:line,a==6?strlen(vals[i]):n)<0);CHECK(call_count==0);
  }
 }
 backend_result=-EIO;CHECK(store(1,"u buck 1",8)==-EIO);CHECK(show(6,buf)==-EIO);backend_result=0;
 call_count=0;CHECK(store(1,"u all 1",7)==7);CHECK(call_count==18);
 for(int n=0;n<=8192;n++){
  char *s=malloc((size_t)n+1);memset(s,'1',n);s[n]=0;call_count=0;
  ssize_t r=store(6,s,n);
  if(n==1){CHECK(r==1);CHECK(call_count==1);}else if(n==0||n>=254){CHECK(r==-EINVAL);CHECK(call_count==0);}
  else if(n>10){CHECK(r<0);CHECK(call_count==0);}
  free(s);
 }
 for(int fill=0;fill<2;fill++){
  get_fill=fill;
  for(int attr=0;attr<5;attr++){
   memset(buf,0xaa,sizeof(buf));ssize_t n=show(attr,buf);CHECK(n>0&&n<PAGE_SIZE);CHECK(buf[n]==0);CHECK((size_t)n==strlen(buf));
  }
 }
 get_fill=0;CHECK(mca_charge_suspend_state_show(&value)==0);CHECK(value);
 CHECK(mca_charge_ship_mode_show(&value)==0);CHECK(value);
 printf("{\"passed\":true,\"checks\":%d,\"layout_assertions\":15,\"input_lengths_tested\":8193,\"hardware_tested\":false}\n",checks);
 return 0;
}
'''
with tempfile.TemporaryDirectory() as t:
 d=Path(t);c=d/'test.c';exe=d/'test';c.write_text(prefix+without_includes(header.read_text())+without_includes(source.read_text())+tests)
 subprocess.run(['cc','-std=gnu11','-O1','-g','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-Wno-sign-compare','-fno-omit-frame-pointer','-fsanitize=address,undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
 env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';subprocess.run([str(exe)],check=True,env=env)
