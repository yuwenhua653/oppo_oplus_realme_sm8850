#!/bin/bash
set -euo pipefail
test_dir=$(cd -- "$(dirname -- "$0")" && pwd)
payload_dir=${1:-"$test_dir/../../payload"}
test_tmp=$(mktemp -d)
trap 'rm -rf -- "$test_tmp"' EXIT
${CC:-cc} -std=gnu11 -Wall -Wextra -Werror -Wno-unused-parameter -Wno-unused-function -Wno-unused-variable -Wno-sign-compare \
    -fsanitize=undefined -fno-omit-frame-pointer -pthread \
    -I"$test_dir/stubs" -I"$payload_dir" -I"$payload_dir/drivers/power/supply/mca/include" \
    "$test_dir/test_platform.c" -o "$test_tmp/platform-contract"
"$test_tmp/platform-contract"
