#include "kernel_test.h"
#include "drivers/power/supply/mca/mca_protocol/mca_protocol_class.c"
#undef MCA_LOG_TAG
#define match_table qc_match_table
#include "drivers/power/supply/mca/mca_protocol/protocol_qc/mca_protocol_qc_class.c"
#undef match_table
#undef MCA_LOG_TAG
#include "drivers/power/supply/mca/mca_platform/mca_platform_loadsw_class.c"
#define SLOT(t,m,n) _Static_assert(offsetof(struct t,m)==8*(n), #t ": " #m)
SLOT(adapter_protocol_class_ops,adapter_det_en,0);
SLOT(adapter_protocol_class_ops,set_adapter_verified,1);
SLOT(adapter_protocol_class_ops,get_adapter_verified,2);
SLOT(adapter_protocol_class_ops,get_adapter_type,3);
SLOT(adapter_protocol_class_ops,get_adapter_max_power,4);
SLOT(adapter_protocol_class_ops,get_adapter_pwr_cap,5);
SLOT(adapter_protocol_class_ops,set_adapter_volt_and_curr,6);
SLOT(adapter_protocol_class_ops,get_adapter_volt_and_curr,7);
SLOT(adapter_protocol_class_ops,get_adapter_pps_ptf,8);
SLOT(adapter_protocol_class_ops,get_adapter_info,9);
SLOT(adapter_protocol_class_ops,get_adapter_power_curve,10);
SLOT(adapter_protocol_class_ops,get_adapter_pwr_max_power,11);
SLOT(protocol_class_qc_ops,protocol_qc_get_qc_type,0);
SLOT(protocol_class_qc_ops,protocol_qc_set_volt,1);
SLOT(protocol_class_qc_ops,protocol_qc_set_volt_cmd,2);
SLOT(protocol_class_qc_ops,protocol_qc3_check_class_type,3);
SLOT(platform_class_loadsw_ops,loadsw_get_present,0);
SLOT(platform_class_loadsw_ops,loadsw_get_ibat_limit,1);
SLOT(platform_class_loadsw_ops,loadsw_set_ibat_limit,2);
SLOT(platform_class_loadsw_ops,loadsw_set_lowpower_mode,3);
SLOT(platform_class_loadsw_ops,loadsw_get_lowpower_mode,4);
static int assertions;
#define CHECK(x) do {assert(x);__atomic_add_fetch(&assertions,1,__ATOMIC_SEQ_CST);}while(0)
static int marker, last_voltage;
static int type_cb(int *out,void *data) { CHECK(data==&marker);*out=17;return 23; }
static int voltage_cb(void *data,int v) { CHECK(data==&marker);last_voltage=v;return 25; }
static int output_cb(int *out,void *data) { CHECK(data==&marker);*out=5000;return 0; }
static int fail_get(int *out,void *data) { (void)out;(void)data;return -EIO; }
static int fail_set(int v,void *data) { (void)v;(void)data;return -EIO; }
static pthread_mutex_t test_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t test_cond=PTHREAD_COND_INITIALIZER;
static bool callback_entered, release_callback, unregister_entered, unregister_done;
static int unregister_expected;
static int blocking_cb(void *data,int *out) {
 CHECK(data==&marker);pthread_mutex_lock(&test_lock);callback_entered=true;pthread_cond_broadcast(&test_cond);
 while(!release_callback)pthread_cond_wait(&test_cond,&test_lock);
 pthread_mutex_unlock(&test_lock);*out=9;return 0;
}
static struct adapter_protocol_class_ops blocking_ops={.get_adapter_type=blocking_cb};
static void *dispatch_thread(void *unused) { int value; (void)unused; CHECK(protocol_class_get_adapter_type(0,(unsigned int *)&value)==0);CHECK(value==9);return NULL; }
static void *unregister_thread(void *unused) { (void)unused;pthread_mutex_lock(&test_lock);unregister_entered=true;pthread_cond_broadcast(&test_cond);pthread_mutex_unlock(&test_lock);CHECK(protocol_class_unregister_ops(0,&blocking_ops,&marker)==unregister_expected);pthread_mutex_lock(&test_lock);unregister_done=true;pthread_mutex_unlock(&test_lock);return NULL; }
static int replacement_cb(void *data,int *out) { CHECK(data==&marker);*out=33;return 0; }
static struct adapter_protocol_class_ops replacement_ops={.get_adapter_type=replacement_cb};
static void *replacement_thread(void *unused) { (void)unused;CHECK(protocol_class_register_ops(0,&replacement_ops,&marker)==0);return NULL; }
static bool unregister_has_finished(void) { bool done;pthread_mutex_lock(&test_lock);done=unregister_done;pthread_mutex_unlock(&test_lock);return done; }
int main(void) {
 int value=0; struct platform_device pdev={0};
 struct protocol_class_qc_ops ops={.protocol_qc_get_qc_type=type_cb,.protocol_qc_set_volt=voltage_cb};
 CHECK(protocol_class_register_ops(UINT_MAX,&blocking_ops,&marker)==-1);
 CHECK(protocol_class_register_ops(0,NULL,&marker)==-1);
 CHECK(protocol_class_get_adapter_type(UINT_MAX,(unsigned int *)&value)==-1);
 CHECK(protocol_class_qc_register_ops(UINT_MAX,&ops,&marker)==-1);
 CHECK(protocol_class_qc_register_ops(0,NULL,&marker)==-1);
 CHECK(protocol_class_qc_get_qc_type(0,&value)==-1);
 CHECK(protocol_class_qc_register_ops(0,&ops,&marker)==0);
 CHECK(protocol_class_qc_get_qc_type(0,&value)==23);CHECK(value==17);
 CHECK(protocol_class_qc_set_volt(0,9100)==25);CHECK(last_voltage==9100);
 alloc_fail=1;CHECK(protocol_qc_class_probe(&pdev)==-ENOMEM);alloc_fail=0;
 CHECK(protocol_qc_class_probe(&pdev)==0);
 CHECK(protocol_class_get_adapter_type(ADAPTER_PROTOCOL_QC,(unsigned int *)&value)==23);
 CHECK(protocol_class_set_adapter_volt_and_curr(ADAPTER_PROTOCOL_QC,8700,4000)==25);CHECK(last_voltage==8700);
 CHECK(protocol_class_unregister_ops(ADAPTER_PROTOCOL_QC,&blocking_ops,NULL)==-ENOENT);
 protocol_qc_class_remove(&pdev);CHECK(protocol_class_get_adapter_type(ADAPTER_PROTOCOL_QC,(unsigned int *)&value)==-1);
 CHECK(protocol_class_unregister_ops(ADAPTER_PROTOCOL_QC,&g_protocol_qc_ops,NULL)==-ENOENT);
 CHECK(protocol_class_register_ops(0,&blocking_ops,&marker)==0);
 pthread_t dispatch, unreg;CHECK(pthread_create(&dispatch,NULL,dispatch_thread,NULL)==0);
 pthread_mutex_lock(&test_lock);while(!callback_entered)pthread_cond_wait(&test_cond,&test_lock);pthread_mutex_unlock(&test_lock);
 CHECK(pthread_create(&unreg,NULL,unregister_thread,NULL)==0);
 pthread_mutex_lock(&test_lock);while(!unregister_entered)pthread_cond_wait(&test_cond,&test_lock);CHECK(!unregister_done);release_callback=true;pthread_cond_broadcast(&test_cond);pthread_mutex_unlock(&test_lock);
 pthread_join(dispatch,NULL);pthread_join(unreg,NULL);CHECK(unregister_done);CHECK(protocol_class_get_adapter_type(0,(unsigned int *)&value)==-1);
 /* Regression: replaced provider unregister must still wait for its old reader. */
 callback_entered=release_callback=unregister_entered=unregister_done=false;unregister_expected=-ENOENT;
 CHECK(protocol_class_register_ops(0,&blocking_ops,&marker)==0);
 CHECK(pthread_create(&dispatch,NULL,dispatch_thread,NULL)==0);
 pthread_mutex_lock(&test_lock);while(!callback_entered)pthread_cond_wait(&test_cond,&test_lock);pthread_mutex_unlock(&test_lock);
 int sync_before=__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST);pthread_t replacement;
 CHECK(pthread_create(&replacement,NULL,replacement_thread,NULL)==0);
 while(__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST)<sync_before+1)sched_yield();
 CHECK(pthread_create(&unreg,NULL,unregister_thread,NULL)==0);
 while(!unregister_has_finished() && __atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST)<sync_before+2)sched_yield();
 CHECK(!unregister_has_finished());
 pthread_mutex_lock(&test_lock);release_callback=true;pthread_cond_broadcast(&test_cond);pthread_mutex_unlock(&test_lock);
 pthread_join(dispatch,NULL);pthread_join(replacement,NULL);pthread_join(unreg,NULL);CHECK(unregister_done);
 CHECK(protocol_class_get_adapter_type(0,(unsigned int *)&value)==0);CHECK(value==33);
 CHECK(protocol_class_unregister_ops(0,&replacement_ops,&marker)==0);
 struct device_node node={0};struct device dev={.of_node=&node};struct platform_loadsw_dev ls={.dev=&dev};
 for(dt_count=-2;dt_count<=4;dt_count++)for(dt_num=-2;dt_num<=4;dt_num++) {
   int ret=platform_loadsw_dev_parse_dt(&ls);CHECK((ret==0)==(dt_count>=1&&dt_count<=2&&dt_count==dt_num));
 }
 dt_num=dt_count=2;CHECK(platform_loadsw_dev_parse_dt(&ls)==0);
 sysfs_fail_at=2;CHECK(loadsw_sysfs_create_group(&ls)==-ENOMEM);CHECK(sysfs_create_count==2);CHECK(sysfs_remove_count==1);CHECK(!ls.sysfs_dev[0]&&!ls.sysfs_dev[1]);
 sysfs_fail_at=0;sysfs_create_count=sysfs_remove_count=0;CHECK(loadsw_sysfs_create_group(&ls)==0);CHECK(*(int *)dev_get_drvdata(ls.sysfs_dev[0])==0);CHECK(*(int *)dev_get_drvdata(ls.sysfs_dev[1])==1);
 pdev.dev.data=&ls;platform_loadsw_class_remove(&pdev);CHECK(sysfs_remove_count==2);
 ls.loadsw_dir_list[1]="also_master";sysfs_create_count=0;CHECK(loadsw_sysfs_create_group(&ls)==-EINVAL);CHECK(sysfs_create_count==0);
 ls.loadsw_dir_list[1]="master_slave";CHECK(loadsw_sysfs_create_group(&ls)==-EINVAL);
 ls.loadsw_dir_list[1]="unknown";CHECK(loadsw_sysfs_create_group(&ls)==-EINVAL);
 int index=0;dev.data=&index;char buf[PAGE_SIZE]={0};struct platform_class_loadsw_ops lsops={.loadsw_get_ibat_limit=output_cb,.loadsw_set_ibat_limit=fail_set};
 CHECK(platform_class_loadsw_register_ops(2,&lsops,&marker)==-EOPNOTSUPP);CHECK(platform_class_loadsw_register_ops(0,NULL,&marker)==-EOPNOTSUPP);
 CHECK(platform_class_loadsw_register_ops(0,&lsops,&marker)==0);
 CHECK(loadsw_sysfs_show(&dev,&loadsw_sysfs_field_tbl[1].attr,buf)==5);CHECK(!strcmp(buf,"5000\n"));
 CHECK(loadsw_sysfs_store(&dev,&loadsw_sysfs_field_tbl[1].attr,"5000",4)==-EIO);
 lsops.loadsw_get_ibat_limit=fail_get;CHECK(loadsw_sysfs_show(&dev,&loadsw_sysfs_field_tbl[1].attr,buf)==-EIO);
 dev.data=NULL;CHECK(loadsw_sysfs_show(&dev,&loadsw_sysfs_field_tbl[1].attr,buf)==-ENODEV);
 printf("MCA protocol/QC/loadsw actual C: %d assertions; 21 stock callback offsets; unregister wait and sysfs failure paths PASS\n",assertions);
 return 0;
}
