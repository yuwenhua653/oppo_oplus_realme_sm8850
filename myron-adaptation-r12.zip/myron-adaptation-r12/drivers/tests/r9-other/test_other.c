#include "shim.h"
#include MYRON_IR_SOURCE
#include MYRON_ST54_SOURCE
static _Atomic int checks;
#define CHECK(x) do{assert(x);checks++;}while(0)
static long ir_ioctl(struct file*f,u32 n){return ir_spi_chardev_ioctl(f,LIRC_SET_SEND_MODE,(unsigned long)&n);}
static void*ir_writer(void*p){char b[512]={0};for(int i=0;i<10000;i++){long r=ir_spi_chardev_write(p,b,sizeof(b),NULL);CHECK(r==512||r==-EINVAL);}return NULL;}
static void*ir_resizer(void*p){for(int i=0;i<10000;i++)CHECK(ir_ioctl(p,(i&1)?512:200000)==0);return NULL;}
static void test_ir(void){
 struct spi_device spi={0};struct file f={0},g={0};char b[512]={0};
 fail_alloc=1;CHECK(ir_spi_probe(&spi)==-ENOMEM);CHECK(!live_allocs);
 misc_fail=1;CHECK(ir_spi_probe(&spi)==-EBUSY);CHECK(!live_allocs);CHECK(!spi.data);misc_fail=0;
 CHECK(ir_spi_probe(&spi)==0);struct ir_spi_data*s=spi.data;CHECK(live_allocs==2);CHECK(s->buffer_size==150000);
 f.private_data=&s->misc;CHECK(ir_spi_chardev_open(NULL,&f)==0);CHECK(s->nusers==1);CHECK(ir_ioctl(&f,512)==0);
 CHECK(ir_spi_chardev_write(&f,b,511,NULL)==-EINVAL);CHECK(ir_spi_chardev_write(&f,b,512,NULL)==512);
 copy_fail=1;CHECK(ir_spi_chardev_write(&f,b,512,NULL)==-EFAULT);CHECK(ir_ioctl(&f,512)==-EFAULT);copy_fail=0;
 CHECK(ir_spi_chardev_ioctl(&f,0,0)==-EINVAL);CHECK(ir_ioctl(&f,UINT32_MAX)==-EMSGSIZE);
 fail_alloc=1;CHECK(ir_ioctl(&f,200000)==-ENOMEM);CHECK(s->xfer.len==512);CHECK(s->buffer_size==150000);
 CHECK(ir_ioctl(&f,200000)==0);CHECK(s->buffer_size==200000);CHECK(ir_ioctl(&f,512)==0);
 g.private_data=&s->misc;CHECK(ir_spi_chardev_open(NULL,&g)==0);CHECK(ir_ioctl(&f,512)==0);CHECK(ir_ioctl(&f,256)==-EPERM);CHECK(ir_spi_chardev_close(NULL,&g)==0);
 spi_result=-EIO;CHECK(ir_spi_chardev_write(&f,b,512,NULL)==-EIO);spi_result=0;
 CHECK(ir_ioctl(&f,0)==0);CHECK(ir_spi_chardev_write(&f,NULL,0,NULL)==0);CHECK(ir_spi_chardev_write(&f,b,(size_t)INT_MAX+1,NULL)==-EMSGSIZE);
 pthread_t a,c;CHECK(!pthread_create(&a,NULL,ir_writer,&f));CHECK(!pthread_create(&c,NULL,ir_resizer,&f));pthread_join(a,NULL);pthread_join(c,NULL);
 ir_spi_remove(&spi);CHECK(!misc_live);CHECK(!spi.data);CHECK(live_allocs==2);CHECK(ir_ioctl(&f,1)==-ENODEV);CHECK(ir_spi_chardev_write(&f,b,1,NULL)==-ENODEV);
 CHECK(ir_spi_chardev_close(NULL,&f)==0);CHECK(!live_allocs);
 CHECK(ir_spi_probe(&spi)==0);ir_spi_remove(&spi);CHECK(!live_allocs);
}
static void test_st54(void){
 struct platform_device p={.dev={.of_node=(void*)1}};struct file f={0},g={0},h={0};struct inode inode;
 CHECK(st54spi_gpio_dev_fops.compat_ioctl==st54spi_gpio_dev_ioctl);
 gpio_lookup=-EPROBE_DEFER;CHECK(st54spi_gpio_probe(&p)==-EPROBE_DEFER);CHECK(!live_allocs);gpio_lookup=10;
 fail_alloc=1;CHECK(st54spi_gpio_probe(&p)==-ENOMEM);CHECK(!live_allocs);
 gpio_request_fail=1;CHECK(st54spi_gpio_probe(&p)==-EFAULT);CHECK(!live_allocs&&!gpio_live);gpio_request_fail=0;
 gpio_direction_fail=1;CHECK(st54spi_gpio_probe(&p)==-EFAULT);CHECK(!live_allocs&&!gpio_live);gpio_direction_fail=0;
 region_fail=1;CHECK(st54spi_gpio_probe(&p)==-ENOMEM);CHECK(!live_allocs&&!gpio_live);region_fail=0;
 class_fail=1;CHECK(st54spi_gpio_probe(&p)==-ENOMEM);CHECK(!live_allocs&&!region_live&&!gpio_live);class_fail=0;
 name_fail=1;CHECK(st54spi_gpio_probe(&p)==-ENOMEM);CHECK(!live_allocs&&!region_live&&!class_live&&!gpio_live);name_fail=0;
 cdev_fail=1;CHECK(st54spi_gpio_probe(&p)==-ENOMEM);CHECK(!live_allocs&&!region_live&&!class_live&&!gpio_live);cdev_fail=0;
 CHECK(st54spi_gpio_probe(&p)==0);struct st54spi_gpio_device*s=p.data;inode.i_cdev=&s->cdev;
 CHECK(gpio_live==1&&gpio_value==1);CHECK(st54spi_gpio_dev_open(&inode,&f)==0);CHECK(st54spi_gpio_dev_open(&inode,&g)==0);CHECK(gpio_live==1&&gpio_value==1);
 CHECK(st54spi_gpio_dev_ioctl(&f,ST54SPI_GET_GPIO,0)==1);CHECK(st54spi_gpio_dev_ioctl(&f,ST54SPI_SET_GPIO,0)==0);CHECK(gpio_value==1);
 gpio_value=0;CHECK(st54spi_gpio_dev_ioctl(&f,ST54SPI_SET_GPIO,0)==0);CHECK(gpio_value==0);CHECK(st54spi_gpio_dev_ioctl(&g,ST54SPI_SET_GPIO,1)==0);CHECK(gpio_value==1);
 CHECK(st54spi_gpio_dev_ioctl(&f,ST54SPI_SET_GPIO,2)==-ENOIOCTLCMD);CHECK(st54spi_gpio_dev_ioctl(&f,0,0)==-ENOIOCTLCMD);CHECK(st54spi_gpio_llseek(&f,0,0)==-ESPIPE);
 CHECK(st54spi_gpio_dev_release(&inode,&g)==0);CHECK(gpio_live==1&&gpio_value==1);
 /* Simulate the cdev core's temporary parent reference before racing open. */
 get_device(&s->chardev);st54spi_gpio_remove(&p);CHECK(!p.data);CHECK(!gpio_live&&!region_live&&!class_live&&!cdev_live);CHECK(live_allocs==1);
 CHECK(st54spi_gpio_dev_open(&inode,&h)==-ENODEV);put_device(&s->chardev);
 CHECK(st54spi_gpio_dev_ioctl(&f,ST54SPI_GET_GPIO,0)==-ENODEV);CHECK(st54spi_gpio_dev_release(&inode,&f)==0);CHECK(!live_allocs);
 CHECK(st54spi_gpio_probe(&p)==0);st54spi_gpio_remove(&p);CHECK(!live_allocs);
}
int main(void){test_ir();test_st54();printf("PASS: %d runtime assertions; IR concurrent buffer writes/resizes and stock ST54 probe-high/multi-open/SET0-noop/remove lifetime\n",checks);}
