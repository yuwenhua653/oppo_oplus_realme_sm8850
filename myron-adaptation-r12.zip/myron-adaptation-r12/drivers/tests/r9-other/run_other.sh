#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
payload=${1:?payload root is required}
payload=$(CDPATH= cd -- "$payload" && pwd)
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
${CC:-cc} -std=gnu11 -O1 -g -Wall -Wextra -Werror -Wno-unused-parameter -Wno-unused-function -Wno-unused-variable -fsanitize=address,undefined -fno-omit-frame-pointer -pthread -I"$here" -I"$here/stubs" -DMYRON_IR_SOURCE=\""$payload/drivers/ir-spi/ir-spi.c"\" -DMYRON_ST54_SOURCE=\""$payload/drivers/misc/st54se/st54spi_gpio.c"\" "$here/test_other.c" -o "$out/test_other"
ASAN_OPTIONS=detect_leaks=0 "$out/test_other"
