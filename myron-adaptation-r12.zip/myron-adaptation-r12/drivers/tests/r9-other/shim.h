#pragma once
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <asm-generic/ioctl.h>
#include <pthread.h>
#include <stdatomic.h>
#define __user
#define GFP_KERNEL 1
#define GFP_DMA 2
#define THIS_MODULE ((void*)1)
#define EPROBE_DEFER 517
#define ENOIOCTLCMD 515
#define CONFIG_COMPAT 1
#define MODULE_DEVICE_TABLE(a,b)
#define MODULE_AUTHOR(a)
#define MODULE_DESCRIPTION(a)
#define MODULE_LICENSE(a)
#define MODULE_ALIAS(a)
#define module_spi_driver(a)
#define module_platform_driver(a)
#define container_of(p,t,m) ((t*)((char*)(p)-offsetof(t,m)))
typedef uint8_t u8;
typedef uint32_t u32;
typedef uint32_t __u32;
static _Atomic int live_allocs, fail_alloc, copy_fail, spi_result, spi_calls;
static int misc_fail, misc_live, region_fail, region_live, class_fail, class_live;
static int cdev_fail, cdev_live, name_fail, gpio_lookup=10, gpio_request_fail, gpio_direction_fail;
static int gpio_live, gpio_value;
static void *kzalloc(size_t n,int g){(void)g;if(atomic_exchange(&fail_alloc,0))return NULL;void*p=calloc(1,n);if(p)live_allocs++;return p;}
static void *krealloc(void*p,size_t n,int g){(void)g;if(atomic_exchange(&fail_alloc,0))return NULL;void*q=realloc(p,n);if(q&&!p)live_allocs++;return q;}
static void kfree(void*p){if(p){live_allocs--;free(p);}}
struct mutex {pthread_mutex_t value;};
static void mutex_init(struct mutex*m){assert(!pthread_mutex_init(&m->value,NULL));}
static void mutex_lock(struct mutex*m){assert(!pthread_mutex_lock(&m->value));}
static void mutex_unlock(struct mutex*m){assert(!pthread_mutex_unlock(&m->value));}
static void mutex_destroy(struct mutex*m){assert(!pthread_mutex_destroy(&m->value));}
struct kref {atomic_int count;};
static void kref_init(struct kref*r){atomic_init(&r->count,1);}
static void kref_get(struct kref*r){atomic_fetch_add(&r->count,1);}
static void kref_put(struct kref*r,void(*f)(struct kref*)){if(atomic_fetch_sub(&r->count,1)==1)f(r);}
struct cdev;
struct inode {struct cdev*i_cdev;};
struct file {void*private_data;};
static long noop_llseek(struct file*f,long l,int n){(void)f;(void)n;return l;}
struct file_operations {void*owner;ssize_t(*write)(struct file*,const char*,size_t,loff_t*);int(*open)(struct inode*,struct file*);int(*release)(struct inode*,struct file*);long(*llseek)(struct file*,long,int);long(*unlocked_ioctl)(struct file*,unsigned int,unsigned long);long(*compat_ioctl)(struct file*,unsigned int,unsigned long);};
static long compat_ptr_ioctl(struct file*f,unsigned int c,unsigned long a){(void)f;(void)c;(void)a;return 0;}
struct class {int unused;};
struct device {void*of_node;void*data;struct device*parent;struct class*class;dev_t devt;void(*release)(struct device*);atomic_int refs;};
static void device_initialize(struct device*d){atomic_init(&d->refs,1);}
static void get_device(struct device*d){atomic_fetch_add(&d->refs,1);}
static void put_device(struct device*d){if(atomic_fetch_sub(&d->refs,1)==1&&d->release)d->release(d);}
static int dev_set_name(struct device*d,const char*s){(void)d;(void)s;return name_fail?-ENOMEM:0;}
static void dev_set_drvdata(struct device*d,void*p){d->data=p;}
static int alloc_chrdev_region(dev_t*d,int a,int b,const char*s){(void)a;(void)b;(void)s;if(region_fail)return -ENOMEM;*d=123;region_live++;return 0;}
static void unregister_chrdev_region(dev_t d,int n){(void)d;(void)n;assert(region_live==1);region_live--;}
#define ERR_PTR(e) ((void*)(intptr_t)(e))
#define IS_ERR(p) ((uintptr_t)(p)>=(uintptr_t)-4095)
#define PTR_ERR(p) ((int)(intptr_t)(p))
static struct class*class_create(const char*n){(void)n;if(class_fail)return ERR_PTR(-ENOMEM);class_live++;return (void*)2;}
static void class_destroy(struct class*c){(void)c;assert(class_live==1);class_live--;}
struct cdev {const struct file_operations*fops;void*owner;struct device*parent;};
static void cdev_init(struct cdev*c,const struct file_operations*f){c->fops=f;}
static int cdev_device_add(struct cdev*c,struct device*d){if(cdev_fail)return -ENOMEM;c->parent=d;get_device(d);cdev_live++;return 0;}
static void cdev_device_del(struct cdev*c,struct device*d){(void)d;assert(cdev_live==1);cdev_live--;put_device(c->parent);}
struct miscdevice {int minor;const char*name;const char*nodename;int mode;const struct file_operations*fops;struct device*parent;};
#define MISC_DYNAMIC_MINOR 255
static int misc_register(struct miscdevice*m){(void)m;if(misc_fail)return -EBUSY;misc_live++;return 0;}
static void misc_deregister(struct miscdevice*m){(void)m;assert(misc_live==1);misc_live--;}
struct spi_device {struct device dev;void*data;};
struct spi_transfer {unsigned int len,speed_hz;unsigned char bits_per_word;const void*tx_buf;};
static void spi_set_drvdata(struct spi_device*s,void*p){s->data=p;}
static void*spi_get_drvdata(struct spi_device*s){return s->data;}
static int spi_sync_transfer(struct spi_device*s,struct spi_transfer*t,int n){(void)s;assert(n==1);assert(t->speed_hz==1920000);assert(t->bits_per_word==32);assert(t->tx_buf);spi_calls++;return spi_result;}
static int copy_from_user(void*d,const void*s,size_t n){if(copy_fail||!s)return 1;memcpy(d,s,n);return 0;}
#define get_user(v,p) ((!(p)||copy_fail)?-EFAULT:((v)=*(p),0))
struct of_device_id {const char*compatible;};
struct spi_driver {int(*probe)(struct spi_device*);void(*remove)(struct spi_device*);struct {const char*name;const struct of_device_id*of_match_table;}driver;};
struct platform_device {struct device dev;void*data;};
static void platform_set_drvdata(struct platform_device*p,void*d){p->data=d;}
static void*platform_get_drvdata(struct platform_device*p){return p->data;}
struct platform_driver {int(*probe)(struct platform_device*);void(*remove)(struct platform_device*);struct {const char*name;const struct of_device_id*of_match_table;}driver;};
static int of_get_named_gpio(void*n,const char*p,int i){(void)n;assert(!strcmp(p,"gpio-power_nreset"));assert(i==0);return gpio_lookup;}
static int gpio_is_valid(int g){return g>=0&&g<1024;}
static int gpio_request(int g,const char*n){(void)g;(void)n;if(gpio_request_fail)return -EBUSY;assert(!gpio_live);gpio_live++;return 0;}
static void gpio_free(int g){(void)g;assert(gpio_live==1);gpio_live--;}
static int gpio_direction_output(int g,int v){(void)g;if(gpio_direction_fail)return -EIO;gpio_value=v;return 0;}
static int gpio_get_value(int g){(void)g;assert(gpio_live);return gpio_value;}
static void gpio_set_value(int g,int v){(void)g;assert(gpio_live);gpio_value=v;}
#define LIRC_SET_SEND_MODE _IOW('i',0x11,__u32)
