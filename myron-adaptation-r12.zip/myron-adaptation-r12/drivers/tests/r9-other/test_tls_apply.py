#!/usr/bin/env python3
import hashlib,importlib.util,json,tempfile
from pathlib import Path
R=Path(__file__).resolve().parents[3]
s=importlib.util.spec_from_file_location('tls_apply',R/'common/apply_tls.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
rows=json.loads((R/'common/source-lock.json').read_text())['files']
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 for row in rows:
  f=p/row['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((R/'drivers/evidence/r9-other/upstream/ack'/row['path'].removeprefix('common/')).read_bytes())
 assert not m.apply(p,True)['already_applied']
 for row in rows:assert hashlib.sha256((p/row['path']).read_bytes()).hexdigest()==row['before_sha256']
 assert not m.apply(p)['already_applied'];assert m.apply(p)['already_applied']
 for row in rows:assert hashlib.sha256((p/row['path']).read_bytes()).hexdigest()==row['after_sha256']
 # Reset first file, corrupt second file; must reject without changing first.
 first=p/rows[0]['path'];first.write_bytes((R/'drivers/evidence/r9-other/upstream/ack'/rows[0]['path'].removeprefix('common/')).read_bytes())
 second=p/rows[1]['path'];second.write_bytes(second.read_bytes()+b'unknown local edit\n')
 before={x:(p/x).read_bytes() for x in [row['path'] for row in rows]}
 try:m.apply(p);raise AssertionError('accepted unexpected file')
 except ValueError:pass
 assert all((p/x).read_bytes()==b for x,b in before.items())
print('PASS: TLS config+module list preflight/apply/repeat/conflict non-mutation')
