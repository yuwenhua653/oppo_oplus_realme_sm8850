#include "stubs/kernel_test.h"
#include MCA_FG_SOURCE
static unsigned int assertions;
#define CHECK(v) do { __atomic_add_fetch(&assertions,1,__ATOMIC_SEQ_CST);assert(v); } while(0)
static int token, other_token, expected_int = -2147483000;
static void *expected_data = &token, *expected_out;
static int expected_slot, seen;
static bool expected_bool;
static char expected_char = 0x5a;
static u8 expected_byte = 0xff;
static const char sentinel[] = "real-provider-result";
_Static_assert(FG_IC_MAX == 2, "stock role count");
_Static_assert(sizeof(struct fuelguage_ic_ops) == 536, "stock provider table size");
_Static_assert(offsetof(struct fuelguage_ic_ops, reserved_136) == 136, "stock unexposed slot");
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_probe_ok) == 0, "stock slot fg_ic_probe_ok");
static int cb_fg_ic_probe_ok(void *data, bool *value) { CHECK(data == expected_data);CHECK(expected_slot == 0);seen++;CHECK((void *)value == expected_out);*value = expected_bool;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_batt_info) == 8, "stock slot fg_ic_get_batt_info");
static int cb_fg_ic_get_batt_info(void *data, void *value) { CHECK(data == expected_data);CHECK(expected_slot == 8);seen++;CHECK((void *)value == expected_out);((unsigned char *)value)[131] = 0xa5;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_batt_abnormal_info) == 480, "stock slot fg_ic_get_batt_abnormal_info");
static void cb_fg_ic_get_batt_abnormal_info(void *data, void *value) { CHECK(data == expected_data);CHECK(expected_slot == 480);seen++;CHECK((void *)value == expected_out);((unsigned char *)value)[131] = 0xa5;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_soc) == 16, "stock slot fg_ic_get_soc");
static int cb_fg_ic_get_soc(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 16);seen++;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_rsoc) == 24, "stock slot fg_ic_get_rsoc");
static int cb_fg_ic_get_rsoc(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 24);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_curr) == 32, "stock slot fg_ic_get_curr");
static int cb_fg_ic_get_curr(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 32);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_verify_digest) == 208, "stock slot fg_ic_set_verify_digest");
static int cb_fg_ic_set_verify_digest(void *data, char *value) { CHECK(data == expected_data);CHECK(expected_slot == 208);seen++;CHECK((void *)value == expected_out);*value = expected_char;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_verify_digest) == 216, "stock slot fg_ic_get_verify_digest");
static int cb_fg_ic_get_verify_digest(void *data, char *value) { CHECK(data == expected_data);CHECK(expected_slot == 216);seen++;CHECK((void *)value == expected_out);*value = expected_char;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_authentic) == 224, "stock slot fg_ic_set_authentic");
static int cb_fg_ic_set_authentic(void *data, int value) { CHECK(data == expected_data);CHECK(expected_slot == 224);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_authentic) == 232, "stock slot fg_ic_get_authentic");
static int cb_fg_ic_get_authentic(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 232);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_error_state) == 240, "stock slot fg_ic_get_error_state");
static int cb_fg_ic_get_error_state(void *data, bool *value) { CHECK(data == expected_data);CHECK(expected_slot == 240);seen++;CHECK((void *)value == expected_out);*value = expected_bool;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_volt) == 40, "stock slot fg_ic_get_volt");
static int cb_fg_ic_get_volt(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 40);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_temp) == 48, "stock slot fg_ic_set_temp");
static int cb_fg_ic_set_temp(void *data, int value) { CHECK(data == expected_data);CHECK(expected_slot == 48);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_temp) == 56, "stock slot fg_ic_get_temp");
static int cb_fg_ic_get_temp(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 56);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_original_temp) == 64, "stock slot fg_ic_get_original_temp");
static int cb_fg_ic_get_original_temp(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 64);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_iterm) == 72, "stock slot fg_ic_set_iterm");
static int cb_fg_ic_set_iterm(void *data, int value) { CHECK(data == expected_data);CHECK(expected_slot == 72);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_charge_status) == 80, "stock slot fg_ic_get_charge_status");
static int cb_fg_ic_get_charge_status(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 80);seen++;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_rm) == 88, "stock slot fg_ic_get_rm");
static int cb_fg_ic_get_rm(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 88);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_isc_alert_level) == 344, "stock slot fg_ic_get_isc_alert_level");
static int cb_fg_ic_get_isc_alert_level(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 344);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_soa_alert_level) == 352, "stock slot fg_ic_get_soa_alert_level");
static int cb_fg_ic_get_soa_alert_level(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 352);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_fastcharge) == 96, "stock slot fg_ic_get_fastcharge");
static int cb_fg_ic_get_fastcharge(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 96);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_fastcharge) == 104, "stock slot fg_ic_set_fastcharge");
static int cb_fg_ic_set_fastcharge(void *data, bool value) { CHECK(data == expected_data);CHECK(expected_slot == 104);seen++;CHECK(value == expected_bool);return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_chg_vol) == 112, "stock slot fg_ic_get_chg_vol");
static int cb_fg_ic_get_chg_vol(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 112);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_chip_ok) == 120, "stock slot fg_ic_get_chip_ok");
static int cb_fg_ic_get_chip_ok(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 120);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_cyclecount) == 128, "stock slot fg_ic_get_cyclecount");
static int cb_fg_ic_get_cyclecount(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 128);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_tte) == 144, "stock slot fg_ic_get_tte");
static int cb_fg_ic_get_tte(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 144);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_ttf) == 152, "stock slot fg_ic_get_ttf");
static int cb_fg_ic_get_ttf(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 152);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_fcc) == 160, "stock slot fg_ic_get_fcc");
static int cb_fg_ic_get_fcc(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 160);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_full_design) == 168, "stock slot fg_ic_get_full_design");
static int cb_fg_ic_get_full_design(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 168);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_soh) == 176, "stock slot fg_ic_get_soh");
static int cb_fg_ic_get_soh(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 176);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_temp_max) == 184, "stock slot fg_ic_get_temp_max");
static int cb_fg_ic_get_temp_max(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 184);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_time_ot) == 192, "stock slot fg_ic_get_time_ot");
static int cb_fg_ic_get_time_ot(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 192);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_batt_cell_info) == 200, "stock slot fg_ic_get_batt_cell_info");
static int cb_fg_ic_get_batt_cell_info(void *data, const char **value) { CHECK(data == expected_data);CHECK(expected_slot == 200);seen++;CHECK((void *)value == expected_out);*value = sentinel;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_cutoff_voltage) == 248, "stock slot fg_ic_get_cutoff_voltage");
static int cb_fg_ic_get_cutoff_voltage(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 248);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_cutoff_voltage) == 256, "stock slot fg_ic_set_cutoff_voltage");
static int cb_fg_ic_set_cutoff_voltage(void *data, int value) { CHECK(data == expected_data);CHECK(expected_slot == 256);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_dod_count) == 264, "stock slot fg_ic_get_dod_count");
static int cb_fg_ic_get_dod_count(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 264);seen++;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_count_level1) == 272, "stock slot fg_ic_get_count_level1");
static int cb_fg_ic_get_count_level1(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 272);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_count_level2) == 280, "stock slot fg_ic_get_count_level2");
static int cb_fg_ic_get_count_level2(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 280);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_count_level3) == 288, "stock slot fg_ic_get_count_level3");
static int cb_fg_ic_get_count_level3(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 288);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_vsiloss) == 296, "stock slot fg_ic_get_vsiloss");
static int cb_fg_ic_get_vsiloss(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 296);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_iaver) == 304, "stock slot fg_ic_get_iaver");
static int cb_fg_ic_get_iaver(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 304);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_count_lowtemp) == 312, "stock slot fg_ic_get_count_lowtemp");
static int cb_fg_ic_get_count_lowtemp(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 312);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_clear_count_data) == 320, "stock slot fg_ic_set_clear_count_data");
static int cb_fg_ic_set_clear_count_data(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 320);seen++;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_adapt_power) == 328, "stock slot fg_ic_get_adapt_power");
static int cb_fg_ic_get_adapt_power(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 328);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_aged_flag) == 336, "stock slot fg_ic_get_aged_flag");
static int cb_fg_ic_get_aged_flag(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 336);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_raw_soc) == 360, "stock slot fg_ic_get_raw_soc");
static int cb_fg_ic_get_raw_soc(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 360);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_real_supplement_energy) == 424, "stock slot fg_ic_get_real_supplement_energy");
static int cb_fg_ic_get_real_supplement_energy(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 424);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_calibration_ffc_iterm) == 416, "stock slot fg_ic_get_calibration_ffc_iterm");
static int cb_fg_ic_get_calibration_ffc_iterm(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 416);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_calibration_charge_energy) == 432, "stock slot fg_ic_get_calibration_charge_energy");
static int cb_fg_ic_get_calibration_charge_energy(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 432);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_fl4p0_enable_check) == 440, "stock slot fg_ic_fl4p0_enable_check");
static void cb_fg_ic_fl4p0_enable_check(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 440);seen++;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_update_fw) == 368, "stock slot fg_ic_update_fw");
static void cb_fg_ic_update_fw(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 368);seen++;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_device_name) == 376, "stock slot fg_ic_get_device_name");
static int cb_fg_ic_get_device_name(void *data, const char **value) { CHECK(data == expected_data);CHECK(expected_slot == 376);seen++;CHECK((void *)value == expected_out);*value = sentinel;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_temp_min) == 384, "stock slot fg_ic_get_temp_min");
static int cb_fg_ic_get_temp_min(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 384);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_force_report_full) == 392, "stock slot fg_ic_set_force_report_full");
static void cb_fg_ic_set_force_report_full(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 392);seen++;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_fc) == 400, "stock slot fg_ic_get_fc");
static int cb_fg_ic_get_fc(void *data, bool *value) { CHECK(data == expected_data);CHECK(expected_slot == 400);seen++;CHECK((void *)value == expected_out);*value = expected_bool;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_co) == 408, "stock slot fg_ic_set_co");
static int cb_fg_ic_set_co(void *data, bool value) { CHECK(data == expected_data);CHECK(expected_slot == 408);seen++;CHECK(value == expected_bool);return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_ui_soh) == 448, "stock slot fg_ic_get_ui_soh");
static void cb_fg_ic_get_ui_soh(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 448);seen++;CHECK((void *)value == expected_out);*value = expected_int;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_pack_vendor) == 456, "stock slot fg_ic_get_pack_vendor");
static void cb_fg_ic_get_pack_vendor(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 456);seen++;CHECK((void *)value == expected_out);*value = expected_int;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_calc_rvalue) == 464, "stock slot fg_ic_get_calc_rvalue");
static unsigned long cb_fg_ic_get_calc_rvalue(void *data) { CHECK(data == expected_data);CHECK(expected_slot == 464);seen++;return 0x12345678abcdef01UL;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_batt_sn) == 472, "stock slot fg_ic_get_batt_sn");
static int cb_fg_ic_get_batt_sn(void *data, char *value) { CHECK(data == expected_data);CHECK(expected_slot == 472);seen++;CHECK((void *)value == expected_out);*value = expected_char;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_csd_flag) == 488, "stock slot fg_ic_get_csd_flag");
static int cb_fg_ic_get_csd_flag(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 488);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_batt_qmax) == 496, "stock slot fg_ic_get_batt_qmax");
static int cb_fg_ic_get_batt_qmax(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 496);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_fg_vendor) == 504, "stock slot fg_ic_get_fg_vendor");
static int cb_fg_ic_get_fg_vendor(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 504);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_reboot_vol_thr) == 512, "stock slot fg_ic_set_reboot_vol_thr");
static int cb_fg_ic_set_reboot_vol_thr(void *data, u8 value) { CHECK(data == expected_data);CHECK(expected_slot == 512);seen++;CHECK(value == expected_byte);return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_get_fast_mode_times) == 520, "stock slot fg_ic_get_fast_mode_times");
static int cb_fg_ic_get_fast_mode_times(void *data, int *value) { CHECK(data == expected_data);CHECK(expected_slot == 520);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct fuelguage_ic_ops, fg_ic_set_fast_mode_times) == 528, "stock slot fg_ic_set_fast_mode_times");
static int cb_fg_ic_set_fast_mode_times(void *data, int value) { CHECK(data == expected_data);CHECK(expected_slot == 528);seen++;CHECK(value == expected_int);return -77;}
static struct fuelguage_ic_ops all_ops={
.fg_ic_probe_ok=cb_fg_ic_probe_ok,
.fg_ic_get_batt_info=cb_fg_ic_get_batt_info,
.fg_ic_get_batt_abnormal_info=cb_fg_ic_get_batt_abnormal_info,
.fg_ic_get_soc=cb_fg_ic_get_soc,
.fg_ic_get_rsoc=cb_fg_ic_get_rsoc,
.fg_ic_get_curr=cb_fg_ic_get_curr,
.fg_ic_set_verify_digest=cb_fg_ic_set_verify_digest,
.fg_ic_get_verify_digest=cb_fg_ic_get_verify_digest,
.fg_ic_set_authentic=cb_fg_ic_set_authentic,
.fg_ic_get_authentic=cb_fg_ic_get_authentic,
.fg_ic_get_error_state=cb_fg_ic_get_error_state,
.fg_ic_get_volt=cb_fg_ic_get_volt,
.fg_ic_set_temp=cb_fg_ic_set_temp,
.fg_ic_get_temp=cb_fg_ic_get_temp,
.fg_ic_get_original_temp=cb_fg_ic_get_original_temp,
.fg_ic_set_iterm=cb_fg_ic_set_iterm,
.fg_ic_get_charge_status=cb_fg_ic_get_charge_status,
.fg_ic_get_rm=cb_fg_ic_get_rm,
.fg_ic_get_isc_alert_level=cb_fg_ic_get_isc_alert_level,
.fg_ic_get_soa_alert_level=cb_fg_ic_get_soa_alert_level,
.fg_ic_get_fastcharge=cb_fg_ic_get_fastcharge,
.fg_ic_set_fastcharge=cb_fg_ic_set_fastcharge,
.fg_ic_get_chg_vol=cb_fg_ic_get_chg_vol,
.fg_ic_get_chip_ok=cb_fg_ic_get_chip_ok,
.fg_ic_get_cyclecount=cb_fg_ic_get_cyclecount,
.fg_ic_get_tte=cb_fg_ic_get_tte,
.fg_ic_get_ttf=cb_fg_ic_get_ttf,
.fg_ic_get_fcc=cb_fg_ic_get_fcc,
.fg_ic_get_full_design=cb_fg_ic_get_full_design,
.fg_ic_get_soh=cb_fg_ic_get_soh,
.fg_ic_get_temp_max=cb_fg_ic_get_temp_max,
.fg_ic_get_time_ot=cb_fg_ic_get_time_ot,
.fg_ic_get_batt_cell_info=cb_fg_ic_get_batt_cell_info,
.fg_ic_get_cutoff_voltage=cb_fg_ic_get_cutoff_voltage,
.fg_ic_set_cutoff_voltage=cb_fg_ic_set_cutoff_voltage,
.fg_ic_get_dod_count=cb_fg_ic_get_dod_count,
.fg_ic_get_count_level1=cb_fg_ic_get_count_level1,
.fg_ic_get_count_level2=cb_fg_ic_get_count_level2,
.fg_ic_get_count_level3=cb_fg_ic_get_count_level3,
.fg_ic_get_vsiloss=cb_fg_ic_get_vsiloss,
.fg_ic_get_iaver=cb_fg_ic_get_iaver,
.fg_ic_get_count_lowtemp=cb_fg_ic_get_count_lowtemp,
.fg_ic_set_clear_count_data=cb_fg_ic_set_clear_count_data,
.fg_ic_get_adapt_power=cb_fg_ic_get_adapt_power,
.fg_ic_get_aged_flag=cb_fg_ic_get_aged_flag,
.fg_ic_get_raw_soc=cb_fg_ic_get_raw_soc,
.fg_ic_get_real_supplement_energy=cb_fg_ic_get_real_supplement_energy,
.fg_ic_get_calibration_ffc_iterm=cb_fg_ic_get_calibration_ffc_iterm,
.fg_ic_get_calibration_charge_energy=cb_fg_ic_get_calibration_charge_energy,
.fg_ic_fl4p0_enable_check=cb_fg_ic_fl4p0_enable_check,
.fg_ic_update_fw=cb_fg_ic_update_fw,
.fg_ic_get_device_name=cb_fg_ic_get_device_name,
.fg_ic_get_temp_min=cb_fg_ic_get_temp_min,
.fg_ic_set_force_report_full=cb_fg_ic_set_force_report_full,
.fg_ic_get_fc=cb_fg_ic_get_fc,
.fg_ic_set_co=cb_fg_ic_set_co,
.fg_ic_get_ui_soh=cb_fg_ic_get_ui_soh,
.fg_ic_get_pack_vendor=cb_fg_ic_get_pack_vendor,
.fg_ic_get_calc_rvalue=cb_fg_ic_get_calc_rvalue,
.fg_ic_get_batt_sn=cb_fg_ic_get_batt_sn,
.fg_ic_get_csd_flag=cb_fg_ic_get_csd_flag,
.fg_ic_get_batt_qmax=cb_fg_ic_get_batt_qmax,
.fg_ic_get_fg_vendor=cb_fg_ic_get_fg_vendor,
.fg_ic_set_reboot_vol_thr=cb_fg_ic_set_reboot_vol_thr,
.fg_ic_get_fast_mode_times=cb_fg_ic_get_fast_mode_times,
.fg_ic_set_fast_mode_times=cb_fg_ic_set_fast_mode_times,
};
static struct fuelguage_ic_ops no_ops;
static void exercise_all(unsigned int role, unsigned int empty) {
 int out = 0, before;
 bool bout = false;
 char cout = 0;
 unsigned char opaque[140] = {0};
 const char *sout = NULL;
bout=!expected_bool;expected_out=&bout;expected_slot=0;before=seen;CHECK(platform_fg_ops_probe_ok(role, &bout)==-77);CHECK(seen==before+1);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_probe_ok(empty, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_probe_ok(2, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_probe_ok(UINT_MAX, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
opaque[131]=0;expected_out=opaque;expected_slot=8;before=seen;CHECK(platform_fg_ops_get_batt_info(role, opaque)==-77);CHECK(seen==before+1);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
before=seen;CHECK(platform_fg_ops_get_batt_info(empty, opaque)==-EOPNOTSUPP);CHECK(seen==before);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
before=seen;CHECK(platform_fg_ops_get_batt_info(2, opaque)==-EOPNOTSUPP);CHECK(seen==before);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
before=seen;CHECK(platform_fg_ops_get_batt_info(UINT_MAX, opaque)==-EOPNOTSUPP);CHECK(seen==before);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
opaque[131]=0;expected_out=opaque;expected_slot=480;before=seen;platform_fg_ops_get_batt_abnormal_info(role, opaque);CHECK(seen==before+1);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
before=seen;platform_fg_ops_get_batt_abnormal_info(empty, opaque);CHECK(seen==before);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
before=seen;platform_fg_ops_get_batt_abnormal_info(2, opaque);CHECK(seen==before);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
before=seen;platform_fg_ops_get_batt_abnormal_info(UINT_MAX, opaque);CHECK(seen==before);CHECK(opaque[131]==0xa5);CHECK(opaque[132]==0);
expected_slot=16;before=seen;CHECK(platform_fg_ops_get_soc(role)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_get_soc(empty)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_soc(2)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_soc(UINT_MAX)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=24;before=seen;CHECK(platform_fg_ops_get_rsoc(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_rsoc(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_rsoc(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_rsoc(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=32;before=seen;CHECK(platform_fg_ops_get_curr(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_curr(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_curr(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_curr(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
cout=0;expected_out=&cout;expected_slot=208;before=seen;CHECK(platform_fg_ops_set_verify_digest(role, &cout)==-77);CHECK(seen==before+1);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_set_verify_digest(empty, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_set_verify_digest(2, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_set_verify_digest(UINT_MAX, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
cout=0;expected_out=&cout;expected_slot=216;before=seen;CHECK(platform_fg_ops_get_verify_digest(role, &cout)==-77);CHECK(seen==before+1);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_get_verify_digest(empty, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_get_verify_digest(2, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_get_verify_digest(UINT_MAX, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
expected_slot=224;before=seen;CHECK(platform_fg_ops_set_authentic(role, expected_int)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_authentic(empty, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_authentic(2, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_authentic(UINT_MAX, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=232;before=seen;CHECK(platform_fg_ops_get_authentic(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_authentic(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_authentic(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_authentic(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
bout=!expected_bool;expected_out=&bout;expected_slot=240;before=seen;CHECK(platform_fg_ops_get_error_state(role, &bout)==-77);CHECK(seen==before+1);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_get_error_state(empty, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_get_error_state(2, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_get_error_state(UINT_MAX, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
out=0;expected_out=&out;expected_slot=40;before=seen;CHECK(platform_fg_ops_get_volt(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_volt(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_volt(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_volt(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=48;before=seen;CHECK(platform_fg_ops_set_temp(role, expected_int)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_temp(empty, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_temp(2, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_temp(UINT_MAX, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=56;before=seen;CHECK(platform_fg_ops_get_temp(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=64;before=seen;CHECK(platform_fg_ops_get_original_temp(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_original_temp(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_original_temp(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_original_temp(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=72;before=seen;CHECK(platform_fg_ops_set_iterm(role, expected_int)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_iterm(empty, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_iterm(2, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_iterm(UINT_MAX, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
expected_slot=80;before=seen;CHECK(platform_fg_ops_get_charge_status(role)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_get_charge_status(empty)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_charge_status(2)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_charge_status(UINT_MAX)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=88;before=seen;CHECK(platform_fg_ops_get_rm(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_rm(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_rm(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_rm(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=344;before=seen;CHECK(platform_fg_ops_get_isc_alert_level(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_isc_alert_level(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_isc_alert_level(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_isc_alert_level(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=352;before=seen;CHECK(platform_fg_ops_get_soa_alert_level(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_soa_alert_level(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_soa_alert_level(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_soa_alert_level(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=96;before=seen;CHECK(platform_fg_ops_get_fastcharge(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fastcharge(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fastcharge(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fastcharge(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=104;before=seen;CHECK(platform_fg_ops_set_fastcharge(role, expected_bool)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_fastcharge(empty, expected_bool)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_fastcharge(2, expected_bool)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_fastcharge(UINT_MAX, expected_bool)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=112;before=seen;CHECK(platform_fg_ops_get_chg_vol(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_chg_vol(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_chg_vol(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_chg_vol(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=120;before=seen;CHECK(platform_fg_ops_get_chip_ok(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_chip_ok(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_chip_ok(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_chip_ok(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=128;before=seen;CHECK(platform_fg_ops_get_cyclecount(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_cyclecount(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_cyclecount(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_cyclecount(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=144;before=seen;CHECK(platform_fg_ops_get_tte(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_tte(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_tte(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_tte(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=152;before=seen;CHECK(platform_fg_ops_get_ttf(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_ttf(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_ttf(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_ttf(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=160;before=seen;CHECK(platform_fg_ops_get_fcc(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fcc(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fcc(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fcc(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=168;before=seen;CHECK(platform_fg_ops_get_full_design(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_full_design(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_full_design(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_full_design(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=176;before=seen;CHECK(platform_fg_ops_get_soh(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_soh(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_soh(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_soh(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=184;before=seen;CHECK(platform_fg_ops_get_temp_max(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp_max(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp_max(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp_max(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=192;before=seen;CHECK(platform_fg_ops_get_time_ot(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_time_ot(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_time_ot(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_time_ot(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
sout=NULL;expected_out=&sout;expected_slot=200;before=seen;CHECK(platform_fg_ops_get_batt_cell_info(role, &sout)==-77);CHECK(seen==before+1);CHECK(sout==sentinel);
before=seen;CHECK(platform_fg_ops_get_batt_cell_info(empty, &sout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(sout==sentinel);
before=seen;CHECK(platform_fg_ops_get_batt_cell_info(2, &sout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(sout==sentinel);
before=seen;CHECK(platform_fg_ops_get_batt_cell_info(UINT_MAX, &sout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(sout==sentinel);
out=0;expected_out=&out;expected_slot=248;before=seen;CHECK(platform_fg_ops_get_cutoff_voltage(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_cutoff_voltage(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_cutoff_voltage(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_cutoff_voltage(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=256;before=seen;CHECK(platform_fg_ops_set_cutoff_voltage(role, expected_int)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_cutoff_voltage(empty, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_cutoff_voltage(2, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_cutoff_voltage(UINT_MAX, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
expected_slot=264;before=seen;CHECK(platform_fg_ops_get_dod_count(role)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_get_dod_count(empty)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_dod_count(2)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_dod_count(UINT_MAX)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=272;before=seen;CHECK(platform_fg_ops_get_count_level1(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level1(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level1(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level1(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=280;before=seen;CHECK(platform_fg_ops_get_count_level2(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level2(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level2(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level2(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=288;before=seen;CHECK(platform_fg_ops_get_count_level3(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level3(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level3(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_level3(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=296;before=seen;CHECK(platform_fg_ops_get_vsiloss(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_vsiloss(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_vsiloss(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_vsiloss(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=304;before=seen;CHECK(platform_fg_ops_get_iaver(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_iaver(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_iaver(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_iaver(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=312;before=seen;CHECK(platform_fg_ops_get_count_lowtemp(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_lowtemp(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_lowtemp(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_count_lowtemp(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=320;before=seen;CHECK(platform_fg_ops_set_clear_count_data(role)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_clear_count_data(empty)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_clear_count_data(2)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_clear_count_data(UINT_MAX)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=328;before=seen;CHECK(platform_fg_ops_get_adapt_power(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_adapt_power(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_adapt_power(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_adapt_power(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=336;before=seen;CHECK(platform_fg_ops_get_aged_flag(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_aged_flag(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_aged_flag(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_aged_flag(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=360;before=seen;CHECK(platform_fg_ops_get_raw_soc(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_raw_soc(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_raw_soc(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_raw_soc(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=424;before=seen;CHECK(platform_fg_ops_get_real_supplement_energy(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_real_supplement_energy(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_real_supplement_energy(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_real_supplement_energy(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=416;before=seen;CHECK(platform_fg_ops_get_calibration_ffc_iterm(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_calibration_ffc_iterm(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_calibration_ffc_iterm(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_calibration_ffc_iterm(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=432;before=seen;CHECK(platform_fg_ops_get_calibration_charge_energy(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_calibration_charge_energy(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_calibration_charge_energy(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_calibration_charge_energy(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=440;before=seen;platform_fg_ops_fl4p0_enable_check(role);CHECK(seen==before+1);
before=seen;platform_fg_ops_fl4p0_enable_check(empty);CHECK(seen==before);
before=seen;platform_fg_ops_fl4p0_enable_check(2);CHECK(seen==before);
before=seen;platform_fg_ops_fl4p0_enable_check(UINT_MAX);CHECK(seen==before);
expected_slot=368;before=seen;platform_fg_ops_update_fw(role);CHECK(seen==before+1);
before=seen;platform_fg_ops_update_fw(empty);CHECK(seen==before);
before=seen;platform_fg_ops_update_fw(2);CHECK(seen==before);
before=seen;platform_fg_ops_update_fw(UINT_MAX);CHECK(seen==before);
sout=NULL;expected_out=&sout;expected_slot=376;before=seen;CHECK(platform_fg_ops_get_device_name(role, &sout)==-77);CHECK(seen==before+1);CHECK(sout==sentinel);
before=seen;CHECK(platform_fg_ops_get_device_name(empty, &sout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(sout==sentinel);
before=seen;CHECK(platform_fg_ops_get_device_name(2, &sout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(sout==sentinel);
before=seen;CHECK(platform_fg_ops_get_device_name(UINT_MAX, &sout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(sout==sentinel);
out=0;expected_out=&out;expected_slot=384;before=seen;CHECK(platform_fg_ops_get_temp_min(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp_min(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp_min(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_temp_min(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=392;before=seen;platform_fg_ops_set_force_report_full(role);CHECK(seen==before+1);
before=seen;platform_fg_ops_set_force_report_full(empty);CHECK(seen==before);
before=seen;platform_fg_ops_set_force_report_full(2);CHECK(seen==before);
before=seen;platform_fg_ops_set_force_report_full(UINT_MAX);CHECK(seen==before);
bout=!expected_bool;expected_out=&bout;expected_slot=400;before=seen;CHECK(platform_fg_ops_get_fc(role, &bout)==-77);CHECK(seen==before+1);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_get_fc(empty, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_get_fc(2, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
before=seen;CHECK(platform_fg_ops_get_fc(UINT_MAX, &bout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(bout==expected_bool);
expected_slot=408;before=seen;CHECK(platform_fg_ops_set_co(role, expected_bool)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_co(empty, expected_bool)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_co(2, expected_bool)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_co(UINT_MAX, expected_bool)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=448;before=seen;platform_fg_ops_get_ui_soh(role, &out);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;platform_fg_ops_get_ui_soh(empty, &out);CHECK(seen==before);CHECK(out==expected_int);
before=seen;platform_fg_ops_get_ui_soh(2, &out);CHECK(seen==before);CHECK(out==expected_int);
before=seen;platform_fg_ops_get_ui_soh(UINT_MAX, &out);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=456;before=seen;platform_fg_ops_get_pack_vendor(role, &out);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;platform_fg_ops_get_pack_vendor(empty, &out);CHECK(seen==before);CHECK(out==expected_int);
before=seen;platform_fg_ops_get_pack_vendor(2, &out);CHECK(seen==before);CHECK(out==expected_int);
before=seen;platform_fg_ops_get_pack_vendor(UINT_MAX, &out);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=464;before=seen;CHECK(platform_fg_ops_get_calc_rvalue(role)==0x12345678abcdef01UL);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_get_calc_rvalue(empty)==(unsigned long)-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_calc_rvalue(2)==(unsigned long)-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_get_calc_rvalue(UINT_MAX)==(unsigned long)-EOPNOTSUPP);CHECK(seen==before);
cout=0;expected_out=&cout;expected_slot=472;before=seen;CHECK(platform_fg_ops_get_batt_sn(role, &cout)==-77);CHECK(seen==before+1);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_get_batt_sn(empty, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_get_batt_sn(2, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
before=seen;CHECK(platform_fg_ops_get_batt_sn(UINT_MAX, &cout)==-EOPNOTSUPP);CHECK(seen==before);CHECK(cout==expected_char);
out=0;expected_out=&out;expected_slot=488;before=seen;CHECK(platform_fg_ops_get_csd_flag(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_csd_flag(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_csd_flag(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_csd_flag(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=496;before=seen;CHECK(platform_fg_ops_get_batt_qmax(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_batt_qmax(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_batt_qmax(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_batt_qmax(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
out=0;expected_out=&out;expected_slot=504;before=seen;CHECK(platform_fg_ops_get_fg_vendor(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fg_vendor(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fg_vendor(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fg_vendor(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=512;before=seen;CHECK(platform_fg_ops_set_reboot_vol_thr(role, expected_byte)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_reboot_vol_thr(empty, expected_byte)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_reboot_vol_thr(2, expected_byte)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_reboot_vol_thr(UINT_MAX, expected_byte)==-EOPNOTSUPP);CHECK(seen==before);
out=0;expected_out=&out;expected_slot=520;before=seen;CHECK(platform_fg_ops_get_fast_mode_times(role, &out)==-77);CHECK(seen==before+1);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fast_mode_times(empty, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fast_mode_times(2, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
before=seen;CHECK(platform_fg_ops_get_fast_mode_times(UINT_MAX, &out)==-EOPNOTSUPP);CHECK(seen==before);CHECK(out==expected_int);
expected_slot=528;before=seen;CHECK(platform_fg_ops_set_fast_mode_times(role, expected_int)==-77);CHECK(seen==before+1);
before=seen;CHECK(platform_fg_ops_set_fast_mode_times(empty, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_fast_mode_times(2, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
before=seen;CHECK(platform_fg_ops_set_fast_mode_times(UINT_MAX, expected_int)==-EOPNOTSUPP);CHECK(seen==before);
}
static pthread_mutex_t hold_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t hold_cond = PTHREAD_COND_INITIALIZER;
static int entered, released, reader_done, replace_done, unregister_done;
static int hold_cb(void *data,int *value) {
 CHECK(data==&token);CHECK(value!=NULL);
 pthread_mutex_lock(&hold_lock);entered=1;pthread_cond_broadcast(&hold_cond);
 while(!released)pthread_cond_wait(&hold_cond,&hold_lock);
 pthread_mutex_unlock(&hold_lock);*value=42;return -55;
}
static struct fuelguage_ic_ops hold_ops={.fg_ic_get_rsoc=hold_cb};
static void *reader(void *unused) { int out=0;(void)unused;int r=platform_fg_ops_get_rsoc(0,&out);assert(r==-55 && out==42);__atomic_store_n(&reader_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *replace(void *unused) { (void)unused;assert(!platform_fg_ic_ops_register(0,&token,&all_ops));__atomic_store_n(&replace_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *unregister_old(void *unused) { (void)unused;int r=platform_fg_ic_ops_unregister(0,&token,&hold_ops);assert(r==-ENOENT);__atomic_store_n(&unregister_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *unregister_current(void *unused) { (void)unused;assert(!platform_fg_ic_ops_unregister(0,&token,&hold_ops));__atomic_store_n(&unregister_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void wait_sync(int n) { struct timespec start,now;clock_gettime(CLOCK_MONOTONIC,&start);while(__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST)<n){sched_yield();clock_gettime(CLOCK_MONOTONIC,&now);assert(now.tv_sec-start.tv_sec<5);} }
static void concurrency(void) {
 pthread_t a,b,c;CHECK(!platform_fg_ic_ops_register(0,&token,&hold_ops));
 CHECK(!pthread_create(&a,NULL,reader,NULL));
 pthread_mutex_lock(&hold_lock);while(!entered)pthread_cond_wait(&hold_cond,&hold_lock);pthread_mutex_unlock(&hold_lock);
 int baseline=__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST);
 CHECK(!pthread_create(&b,NULL,replace,NULL));wait_sync(baseline+1);
 CHECK(!__atomic_load_n(&replace_done,__ATOMIC_SEQ_CST));
 CHECK(!pthread_create(&c,NULL,unregister_old,NULL));wait_sync(baseline+2);
 CHECK(!__atomic_load_n(&unregister_done,__ATOMIC_SEQ_CST));
 pthread_mutex_lock(&hold_lock);released=1;pthread_cond_broadcast(&hold_cond);pthread_mutex_unlock(&hold_lock);
 CHECK(!pthread_join(a,NULL));CHECK(!pthread_join(b,NULL));CHECK(!pthread_join(c,NULL));
 CHECK(reader_done && replace_done && unregister_done);
 CHECK(!platform_fg_ic_ops_unregister(0,&token,&all_ops));
 entered=released=reader_done=unregister_done=0;
 CHECK(!platform_fg_ic_ops_register(0,&token,&hold_ops));
 CHECK(!pthread_create(&a,NULL,reader,NULL));
 pthread_mutex_lock(&hold_lock);while(!entered)pthread_cond_wait(&hold_cond,&hold_lock);pthread_mutex_unlock(&hold_lock);
 baseline=__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST);
 CHECK(!pthread_create(&c,NULL,unregister_current,NULL));wait_sync(baseline+1);
 CHECK(!__atomic_load_n(&unregister_done,__ATOMIC_SEQ_CST));
 pthread_mutex_lock(&hold_lock);released=1;pthread_cond_broadcast(&hold_cond);pthread_mutex_unlock(&hold_lock);
 CHECK(!pthread_join(a,NULL));CHECK(!pthread_join(c,NULL));CHECK(reader_done && unregister_done);
 int absent=0;CHECK(platform_fg_ops_get_rsoc(0,&absent)==-EOPNOTSUPP);
}
int main(void) {
 register_error=-EIO;CHECK(platform_fg_init()==-EIO);CHECK(!registered_drivers);
 register_error=0;CHECK(!platform_fg_init());CHECK(registered_drivers==1);
 CHECK(platform_fg_ic_ops_register(2,&token,&all_ops)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_register(UINT_MAX,&token,&all_ops)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_register(0,&token,NULL)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_register(0,NULL,&all_ops)==-EOPNOTSUPP);
 CHECK(platform_fg_ic_ops_unregister(2,&token,&all_ops)==-EINVAL);
 CHECK(platform_fg_ic_ops_unregister(0,&token,NULL)==-EINVAL);
 CHECK(platform_fg_ic_ops_unregister(0,NULL,&all_ops)==-EINVAL);
 CHECK(platform_fg_ic_ops_unregister(0,&token,&all_ops)==-ENOENT);
 CHECK(!platform_fg_ic_ops_register(0,&token,&all_ops));
 CHECK(!platform_fg_ic_ops_register(1,&other_token,&no_ops));
 expected_bool=true;exercise_all(0,1);
 expected_bool=false;expected_int=INT_MAX;expected_byte=0x80;exercise_all(0,1);
 alloc_fail=1;CHECK(platform_fg_ic_ops_register(0,&other_token,&no_ops)==-ENOMEM);alloc_fail=0;
 exercise_all(0,1);
 CHECK(platform_fg_ic_ops_unregister(0,&other_token,&all_ops)==-ENOENT);
 expected_byte=0x7f;exercise_all(0,1);
 expected_byte=0x00;exercise_all(0,1);
 CHECK(!platform_fg_ic_ops_unregister(0,&token,&all_ops));
 CHECK(!platform_fg_ic_ops_register(1,&other_token,&all_ops));
 expected_data=&other_token;expected_bool=true;expected_int=INT_MIN;exercise_all(1,0);
 CHECK(!platform_fg_ic_ops_unregister(1,&other_token,&all_ops));
 expected_data=&token;
 concurrency();
 CHECK(!platform_fg_ic_ops_register(0,&token,&all_ops));
 CHECK(!platform_fg_ic_ops_register(1,&token,&all_ops));
 platform_fg_exit();CHECK(!registered_drivers);CHECK(!live_allocations);
 int value=0;CHECK(platform_fg_ops_get_rsoc(0,&value)==-EOPNOTSUPP);
 CHECK(platform_fg_ops_get_rsoc(1,&value)==-EOPNOTSUPP);
 printf("PASS: %u assertions, 66 callback slots, 536-byte ABI and 2 roles, opaque/boolean/signed/64-bit forwarding, NULL/role bounds, allocation failure, SRCU replacement/unregister wait, module cleanup\n",assertions);
 return 0;
}
