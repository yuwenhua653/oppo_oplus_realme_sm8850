#!/bin/bash
set -euo pipefail
test_dir=$(cd -- "$(dirname -- "$0")" && pwd)
payload_dir=${1:-"$test_dir/../../payload"}
stubs_dir=${2:-"$test_dir/../r7-platform/stubs"}
test_tmp=$(mktemp -d)
trap 'rm -rf -- "$test_tmp"' EXIT
${CC:-cc} -std=gnu11 -Wall -Wextra -Werror -Wno-unused-parameter -Wno-unused-function -Wno-unused-variable -Wno-sign-compare \
    -fsanitize=undefined -fno-omit-frame-pointer -pthread \
    -I"$stubs_dir" -I"$payload_dir" -I"$payload_dir/drivers/power/supply/mca/include" \
    "$test_dir/test_adapter_cap.c" -o "$test_tmp/adapter-cap"
"$test_tmp/adapter-cap"
