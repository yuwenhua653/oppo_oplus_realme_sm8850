#include "kernel_test.h"
#include "drivers/power/supply/mca/mca_protocol/mca_protocol_class.c"
#include <stdint.h>

/* These constants are from the stock AArch64 ELF, not the C declaration. */
_Static_assert(sizeof(struct adapter_power_cap) == 20, "stock cap stride");
_Static_assert(offsetof(struct adapter_power_cap, unknown_0) == 0, "reserved");
_Static_assert(offsetof(struct adapter_power_cap, max_current) == 4, "current");
_Static_assert(offsetof(struct adapter_power_cap, min_voltage) == 8, "minimum");
_Static_assert(offsetof(struct adapter_power_cap, max_voltage) == 12, "maximum");
_Static_assert(offsetof(struct adapter_power_cap, max_power) == 16, "power");
_Static_assert(offsetof(struct adapter_power_cap_info, nums) == 0, "count");
_Static_assert(offsetof(struct adapter_power_cap_info, cap) == 4, "array");
_Static_assert(sizeof(struct adapter_power_cap_info) == 144, "stock buffer size");
_Static_assert(offsetof(struct adapter_protocol_class_ops, get_adapter_pwr_cap) == 40, "unchanged callback slot");
static unsigned assertions;
#define CHECK(x) do { assert(x); assertions++; } while (0)

static void put_word(unsigned char *buffer, size_t offset, uint32_t value)
{
    /* Host test runs on little-endian x86_64/AArch64; encode explicitly. */
    for (unsigned i = 0; i < 4; i++) buffer[offset + i] = value >> (i * 8);
}
static uint32_t get_word(const unsigned char *buffer, size_t offset)
{
    uint32_t value = 0;
    for (unsigned i = 0; i < 4; i++) value |= (uint32_t)buffer[offset + i] << (i * 8);
    return value;
}

static unsigned char stock_wire[144];
static struct adapter_power_cap_info *expected_cap;
static int marker;
static int stock_provider(void *data, struct adapter_power_cap_info *cap)
{
    CHECK(data == &marker);
    CHECK(cap == expected_cap);
    memcpy(cap, stock_wire, sizeof(stock_wire));
    return 23;
}

int main(void)
{
    struct adapter_power_cap_info cap;
    struct adapter_protocol_class_ops ops = { .get_adapter_pwr_cap = stock_provider };
    put_word(stock_wire, 0, 7);
    for (unsigned i = 0; i < 7; i++) {
        size_t base = 4 + i * 20;
        put_word(stock_wire, base, 0x13570000 + i);
        put_word(stock_wire, base + 4, 3000 + i);
        put_word(stock_wire, base + 8, 3300 + i * 100);
        put_word(stock_wire, base + 12, 11000 + i * 100);
        put_word(stock_wire, base + 16, 33000 + i);
    }
    expected_cap = &cap;
    CHECK(protocol_class_register_ops(ADAPTER_PROTOCOL_PPS, &ops, &marker) == 0);
    CHECK(protocol_class_get_adapter_power_cap(ADAPTER_PROTOCOL_PPS, &cap) == 23);
    CHECK(cap.nums == 7);
    for (unsigned i = 0; i < 7; i++) {
        CHECK(cap.cap[i].unknown_0 == (int)(0x13570000 + i));
        CHECK(cap.cap[i].max_current == (int)(3000 + i));
        CHECK(cap.cap[i].min_voltage == (int)(3300 + i * 100));
        CHECK(cap.cap[i].max_voltage == (int)(11000 + i * 100));
        CHECK(cap.cap[i].max_power == (int)(33000 + i));
        /* A valid 10V PPS request must be inside the unequal limits. */
        CHECK(cap.cap[i].min_voltage <= 10000 && cap.cap[i].max_voltage >= 10000);
        cap.cap[i].min_voltage = 3600 + i * 50;
        cap.cap[i].max_voltage = 12000 + i * 50;
        CHECK(get_word((unsigned char *)&cap, 4 + i * 20 + 8) == 3600 + i * 50);
        CHECK(get_word((unsigned char *)&cap, 4 + i * 20 + 12) == 12000 + i * 50);
    }
    CHECK(protocol_class_unregister_ops(ADAPTER_PROTOCOL_PPS, &ops, &marker) == 0);
    CHECK(protocol_class_get_adapter_power_cap(ADAPTER_PROTOCOL_PPS, &cap) == -1);
    printf("shared adapter cap: %u runtime checks + 10 layout assertions passed\n", assertions);
    return 0;
}
