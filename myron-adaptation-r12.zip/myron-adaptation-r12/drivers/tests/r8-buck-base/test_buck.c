#include "stubs/kernel_test.h"
#include MCA_BUCK_SOURCE
static unsigned int assertions;
#define CHECK(v) do { assertions++;assert(v); } while(0)
static int token, expected_int = -2147483000;
static void *expected_data = &token;
static void *expected_out;
static int seen;
_Static_assert(offsetof(struct platform_class_buckchg_ops, is_init_ok) == 0, "stock slot is_init_ok");
static int cb_is_init_ok(void *data) { CHECK(data == expected_data);seen++;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, enable_hvdcp) == 8, "stock slot enable_hvdcp");
static int cb_enable_hvdcp(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_online) == 16, "stock slot get_online");
static int cb_get_online(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, is_charge_done) == 24, "stock slot is_charge_done");
static int cb_is_charge_done(void *data, bool *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = true;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_hiz_status) == 32, "stock slot get_hiz_status");
static int cb_get_hiz_status(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_input_volt_lmt) == 40, "stock slot get_input_volt_lmt");
static int cb_get_input_volt_lmt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_input_curr_lmt) == 48, "stock slot get_input_curr_lmt");
static int cb_get_input_curr_lmt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_bus_curr) == 72, "stock slot get_bus_curr");
static int cb_get_bus_curr(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_bus_volt) == 80, "stock slot get_bus_volt");
static int cb_get_bus_volt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_usb_sns_volt) == 88, "stock slot get_usb_sns_volt");
static int cb_get_usb_sns_volt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_ac_volt) == 96, "stock slot get_ac_volt");
static int cb_get_ac_volt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_batt_volt_sns) == 104, "stock slot get_batt_volt_sns");
static int cb_get_batt_volt_sns(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_batt_volt) == 112, "stock slot get_batt_volt");
static int cb_get_batt_volt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_batt_curr) == 120, "stock slot get_batt_curr");
static int cb_get_batt_curr(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_sys_volt) == 128, "stock slot get_sys_volt");
static int cb_get_sys_volt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_bus_tsns) == 136, "stock slot get_bus_tsns");
static int cb_get_bus_tsns(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_batt_tsns) == 144, "stock slot get_batt_tsns");
static int cb_get_batt_tsns(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_die_temp) == 152, "stock slot get_die_temp");
static int cb_get_die_temp(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_batt_id) == 160, "stock slot get_batt_id");
static int cb_get_batt_id(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_chg_status) == 168, "stock slot get_chg_status");
static int cb_get_chg_status(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_chg_type) == 176, "stock slot get_chg_type");
static int cb_get_chg_type(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_term_curr) == 184, "stock slot get_term_curr");
static int cb_get_term_curr(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_term_volt) == 192, "stock slot get_term_volt");
static int cb_get_term_volt(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_wls_curr) == 200, "stock slot get_wls_curr");
static int cb_get_wls_curr(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_hiz) == 208, "stock slot set_hiz");
static int cb_set_hiz(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_wls_hiz) == 216, "stock slot set_wls_hiz");
static int cb_set_wls_hiz(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_input_curr_lmt) == 224, "stock slot set_input_curr_lmt");
static int cb_set_input_curr_lmt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_ovp_vth) == 56, "stock slot set_ovp_vth");
static int cb_set_ovp_vth(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_ovp_vth) == 64, "stock slot get_ovp_vth");
static int cb_get_ovp_vth(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_wls_input_curr_lmt) == 232, "stock slot set_wls_input_curr_lmt");
static int cb_set_wls_input_curr_lmt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_input_volt_lmt) == 240, "stock slot set_input_volt_lmt");
static int cb_set_input_volt_lmt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_ichg) == 248, "stock slot set_ichg");
static int cb_set_ichg(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_chg) == 256, "stock slot set_chg");
static int cb_set_chg(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_buck_fsw) == 264, "stock slot set_buck_fsw");
static int cb_set_buck_fsw(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_otg) == 272, "stock slot set_otg");
static int cb_set_otg(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_otg_curr) == 280, "stock slot set_otg_curr");
static int cb_set_otg_curr(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_otg_volt) == 288, "stock slot set_otg_volt");
static int cb_set_otg_volt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_term) == 296, "stock slot set_term");
static int cb_set_term(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_term_curr) == 304, "stock slot set_term_curr");
static int cb_set_term_curr(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_term_volt) == 312, "stock slot set_term_volt");
static int cb_set_term_volt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, adc_enable) == 320, "stock slot adc_enable");
static int cb_adc_enable(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_prechg_volt) == 328, "stock slot set_prechg_volt");
static int cb_set_prechg_volt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_prechg_curr) == 336, "stock slot set_prechg_curr");
static int cb_set_prechg_curr(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, force_dpdm) == 344, "stock slot force_dpdm");
static int cb_force_dpdm(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, request_dpdm) == 352, "stock slot request_dpdm");
static int cb_request_dpdm(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_wd_timeout) == 360, "stock slot set_wd_timeout");
static int cb_set_wd_timeout(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, kick_wd) == 368, "stock slot kick_wd");
static int cb_kick_wd(void *data) { CHECK(data == expected_data);seen++;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_qc_volt) == 376, "stock slot set_qc_volt");
static int cb_set_qc_volt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_usb_aicl_cont_thd) == 384, "stock slot set_usb_aicl_cont_thd");
static int cb_set_usb_aicl_cont_thd(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_usb_aicl_cont_thd) == 392, "stock slot get_usb_aicl_cont_thd");
static int cb_get_usb_aicl_cont_thd(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_opt_fws) == 400, "stock slot set_opt_fws");
static int cb_set_opt_fws(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, usb_adapter_allow_override) == 408, "stock slot usb_adapter_allow_override");
static int cb_usb_adapter_allow_override(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_qc3_volt) == 416, "stock slot set_qc3_volt");
static int cb_set_qc3_volt(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_otg_boost_src) == 424, "stock slot get_otg_boost_src");
static int cb_get_otg_boost_src(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_otg_boost_enable_status) == 440, "stock slot get_otg_boost_enable_status");
static int cb_get_otg_boost_enable_status(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_otg_gate_enable_status) == 432, "stock slot get_otg_gate_enable_status");
static int cb_get_otg_gate_enable_status(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_boost_enable) == 448, "stock slot set_boost_enable");
static int cb_set_boost_enable(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_boost_voltage) == 456, "stock slot set_boost_voltage");
static int cb_set_boost_voltage(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_aicl_enable) == 464, "stock slot set_aicl_enable");
static int cb_set_aicl_enable(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_rerun_aicl) == 472, "stock slot set_rerun_aicl");
static int cb_set_rerun_aicl(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_restart_aicl) == 480, "stock slot set_restart_aicl");
static int cb_set_restart_aicl(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, is_support_cid) == 488, "stock slot is_support_cid");
static int cb_is_support_cid(void *data, bool *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = true;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_ship_mode) == 496, "stock slot set_ship_mode");
static int cb_set_ship_mode(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_ship_mode) == 504, "stock slot get_ship_mode");
static int cb_get_ship_mode(void *data, bool *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = true;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_wls_vdd_flag) == 512, "stock slot set_wls_vdd_flag");
static int cb_set_wls_vdd_flag(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_enable) == 520, "stock slot get_lpd_enable");
static int cb_get_lpd_enable(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_status) == 528, "stock slot get_lpd_status");
static int cb_get_lpd_status(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_sbu1) == 536, "stock slot get_lpd_sbu1");
static int cb_get_lpd_sbu1(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_sbu2) == 544, "stock slot get_lpd_sbu2");
static int cb_get_lpd_sbu2(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_cc1) == 552, "stock slot get_lpd_cc1");
static int cb_get_lpd_cc1(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_cc2) == 560, "stock slot get_lpd_cc2");
static int cb_get_lpd_cc2(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_dp) == 568, "stock slot get_lpd_dp");
static int cb_get_lpd_dp(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_dm) == 576, "stock slot get_lpd_dm");
static int cb_get_lpd_dm(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_lpd_sbu1) == 584, "stock slot set_lpd_sbu1");
static int cb_set_lpd_sbu1(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_lpd_control) == 592, "stock slot set_lpd_control");
static int cb_set_lpd_control(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_control) == 600, "stock slot get_lpd_control");
static int cb_get_lpd_control(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_lpd_uart_control) == 608, "stock slot set_lpd_uart_control");
static int cb_set_lpd_uart_control(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_lpd_uart_control) == 616, "stock slot get_lpd_uart_control");
static int cb_get_lpd_uart_control(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_pack_vbat) == 624, "stock slot get_pack_vbat");
static int cb_get_pack_vbat(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_pack_ibat) == 632, "stock slot get_pack_ibat");
static int cb_get_pack_ibat(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_pack_tbat) == 664, "stock slot get_pack_tbat");
static int cb_get_pack_tbat(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_eu_model) == 640, "stock slot set_eu_model");
static int cb_set_eu_model(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_icl_status) == 648, "stock slot get_icl_status");
static int cb_get_icl_status(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_too_hot_limit) == 656, "stock slot set_too_hot_limit");
static int cb_set_too_hot_limit(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_usbin_collapse_rt_sts) == 672, "stock slot get_usbin_collapse_rt_sts");
static int cb_get_usbin_collapse_rt_sts(void *data, int *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = expected_int;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_screen_status) == 680, "stock slot set_screen_status");
static int cb_set_screen_status(void *data, bool value) { CHECK(data == expected_data);seen++;CHECK(value == true);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, set_audio_status) == 688, "stock slot set_audio_status");
static int cb_set_audio_status(void *data, int value) { CHECK(data == expected_data);seen++;CHECK(value == expected_int);return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_usb_input_swap) == 696, "stock slot get_usb_input_swap");
static int cb_get_usb_input_swap(void *data, bool *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = true;return -77;}
_Static_assert(offsetof(struct platform_class_buckchg_ops, get_wls_input_swap) == 704, "stock slot get_wls_input_swap");
static int cb_get_wls_input_swap(void *data, bool *value) { CHECK(data == expected_data);seen++;CHECK((void *)value == expected_out);*value = true;return -77;}
_Static_assert(sizeof(struct platform_class_buckchg_ops) == 712, "stock provider object size");
static struct platform_class_buckchg_ops all_ops = {
 .is_init_ok = cb_is_init_ok,
 .enable_hvdcp = cb_enable_hvdcp,
 .get_online = cb_get_online,
 .is_charge_done = cb_is_charge_done,
 .get_hiz_status = cb_get_hiz_status,
 .get_input_volt_lmt = cb_get_input_volt_lmt,
 .get_input_curr_lmt = cb_get_input_curr_lmt,
 .get_bus_curr = cb_get_bus_curr,
 .get_bus_volt = cb_get_bus_volt,
 .get_usb_sns_volt = cb_get_usb_sns_volt,
 .get_ac_volt = cb_get_ac_volt,
 .get_batt_volt_sns = cb_get_batt_volt_sns,
 .get_batt_volt = cb_get_batt_volt,
 .get_batt_curr = cb_get_batt_curr,
 .get_sys_volt = cb_get_sys_volt,
 .get_bus_tsns = cb_get_bus_tsns,
 .get_batt_tsns = cb_get_batt_tsns,
 .get_die_temp = cb_get_die_temp,
 .get_batt_id = cb_get_batt_id,
 .get_chg_status = cb_get_chg_status,
 .get_chg_type = cb_get_chg_type,
 .get_term_curr = cb_get_term_curr,
 .get_term_volt = cb_get_term_volt,
 .get_wls_curr = cb_get_wls_curr,
 .set_hiz = cb_set_hiz,
 .set_wls_hiz = cb_set_wls_hiz,
 .set_input_curr_lmt = cb_set_input_curr_lmt,
 .set_ovp_vth = cb_set_ovp_vth,
 .get_ovp_vth = cb_get_ovp_vth,
 .set_wls_input_curr_lmt = cb_set_wls_input_curr_lmt,
 .set_input_volt_lmt = cb_set_input_volt_lmt,
 .set_ichg = cb_set_ichg,
 .set_chg = cb_set_chg,
 .set_buck_fsw = cb_set_buck_fsw,
 .set_otg = cb_set_otg,
 .set_otg_curr = cb_set_otg_curr,
 .set_otg_volt = cb_set_otg_volt,
 .set_term = cb_set_term,
 .set_term_curr = cb_set_term_curr,
 .set_term_volt = cb_set_term_volt,
 .adc_enable = cb_adc_enable,
 .set_prechg_volt = cb_set_prechg_volt,
 .set_prechg_curr = cb_set_prechg_curr,
 .force_dpdm = cb_force_dpdm,
 .request_dpdm = cb_request_dpdm,
 .set_wd_timeout = cb_set_wd_timeout,
 .kick_wd = cb_kick_wd,
 .set_qc_volt = cb_set_qc_volt,
 .set_usb_aicl_cont_thd = cb_set_usb_aicl_cont_thd,
 .get_usb_aicl_cont_thd = cb_get_usb_aicl_cont_thd,
 .set_opt_fws = cb_set_opt_fws,
 .usb_adapter_allow_override = cb_usb_adapter_allow_override,
 .set_qc3_volt = cb_set_qc3_volt,
 .get_otg_boost_src = cb_get_otg_boost_src,
 .get_otg_boost_enable_status = cb_get_otg_boost_enable_status,
 .get_otg_gate_enable_status = cb_get_otg_gate_enable_status,
 .set_boost_enable = cb_set_boost_enable,
 .set_boost_voltage = cb_set_boost_voltage,
 .set_aicl_enable = cb_set_aicl_enable,
 .set_rerun_aicl = cb_set_rerun_aicl,
 .set_restart_aicl = cb_set_restart_aicl,
 .is_support_cid = cb_is_support_cid,
 .set_ship_mode = cb_set_ship_mode,
 .get_ship_mode = cb_get_ship_mode,
 .set_wls_vdd_flag = cb_set_wls_vdd_flag,
 .get_lpd_enable = cb_get_lpd_enable,
 .get_lpd_status = cb_get_lpd_status,
 .get_lpd_sbu1 = cb_get_lpd_sbu1,
 .get_lpd_sbu2 = cb_get_lpd_sbu2,
 .get_lpd_cc1 = cb_get_lpd_cc1,
 .get_lpd_cc2 = cb_get_lpd_cc2,
 .get_lpd_dp = cb_get_lpd_dp,
 .get_lpd_dm = cb_get_lpd_dm,
 .set_lpd_sbu1 = cb_set_lpd_sbu1,
 .set_lpd_control = cb_set_lpd_control,
 .get_lpd_control = cb_get_lpd_control,
 .set_lpd_uart_control = cb_set_lpd_uart_control,
 .get_lpd_uart_control = cb_get_lpd_uart_control,
 .get_pack_vbat = cb_get_pack_vbat,
 .get_pack_ibat = cb_get_pack_ibat,
 .get_pack_tbat = cb_get_pack_tbat,
 .set_eu_model = cb_set_eu_model,
 .get_icl_status = cb_get_icl_status,
 .set_too_hot_limit = cb_set_too_hot_limit,
 .get_usbin_collapse_rt_sts = cb_get_usbin_collapse_rt_sts,
 .set_screen_status = cb_set_screen_status,
 .set_audio_status = cb_set_audio_status,
 .get_usb_input_swap = cb_get_usb_input_swap,
 .get_wls_input_swap = cb_get_wls_input_swap,
};
static struct platform_class_buckchg_ops no_ops;
static void exercise_all(void) {
 int out = 0;bool bout = false;int before;
before=seen;CHECK(platform_class_buckchg_ops_is_init_ok(0) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_is_init_ok(1) == -1);CHECK(platform_class_buckchg_ops_is_init_ok(2) == -1);CHECK(platform_class_buckchg_ops_is_init_ok(UINT_MAX) == -1);
before=seen;CHECK(platform_class_buckchg_ops_enable_hvdcp(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_enable_hvdcp(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_enable_hvdcp(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_enable_hvdcp(UINT_MAX, expected_int) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_online(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_online(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_online(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_online(UINT_MAX, &out) == -1);
bout=false;expected_out=&bout;before=seen;CHECK(platform_class_buckchg_ops_is_charge_done(0, &bout) == -77);CHECK(seen==before+1);
CHECK(bout);
CHECK(platform_class_buckchg_ops_is_charge_done(1, &bout) == -1);CHECK(platform_class_buckchg_ops_is_charge_done(2, &bout) == -1);CHECK(platform_class_buckchg_ops_is_charge_done(UINT_MAX, &bout) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_hiz_status(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_hiz_status(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_hiz_status(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_hiz_status(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_input_volt_lmt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_input_volt_lmt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_input_volt_lmt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_input_volt_lmt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_input_curr_lmt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_input_curr_lmt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_input_curr_lmt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_input_curr_lmt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_bus_curr(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_bus_curr(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_bus_curr(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_bus_curr(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_bus_volt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_bus_volt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_bus_volt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_bus_volt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_usb_sns_volt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_usb_sns_volt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_usb_sns_volt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_usb_sns_volt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_ac_volt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_ac_volt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_ac_volt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_ac_volt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_batt_volt_sns(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_batt_volt_sns(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_volt_sns(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_volt_sns(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_batt_volt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_batt_volt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_volt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_volt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_batt_curr(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_batt_curr(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_curr(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_curr(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_sys_volt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_sys_volt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_sys_volt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_sys_volt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_bus_tsns(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_bus_tsns(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_bus_tsns(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_bus_tsns(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_batt_tsns(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_batt_tsns(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_tsns(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_tsns(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_die_temp(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_die_temp(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_die_temp(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_die_temp(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_batt_id(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_batt_id(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_id(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_batt_id(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_chg_status(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_chg_status(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_chg_status(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_chg_status(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_chg_type(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_chg_type(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_chg_type(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_chg_type(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_term_curr(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_term_curr(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_term_curr(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_term_curr(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_term_volt(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_term_volt(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_term_volt(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_term_volt(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_wls_curr(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_wls_curr(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_wls_curr(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_wls_curr(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_hiz(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_hiz(1, true) == -1);CHECK(platform_class_buckchg_ops_set_hiz(2, true) == -1);CHECK(platform_class_buckchg_ops_set_hiz(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_wls_hiz(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_wls_hiz(1, true) == -1);CHECK(platform_class_buckchg_ops_set_wls_hiz(2, true) == -1);CHECK(platform_class_buckchg_ops_set_wls_hiz(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_input_curr_lmt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_input_curr_lmt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_input_curr_lmt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_input_curr_lmt(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_ovp_vth(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_ovp_vth(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_ovp_vth(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_ovp_vth(UINT_MAX, expected_int) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_ovp_vth(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_ovp_vth(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_ovp_vth(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_ovp_vth(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_wls_input_curr_lmt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_wls_input_curr_lmt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_wls_input_curr_lmt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_wls_input_curr_lmt(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_input_volt_lmt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_input_volt_lmt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_input_volt_lmt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_input_volt_lmt(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_ichg(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_ichg(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_ichg(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_ichg(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_chg(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_chg(1, true) == -1);CHECK(platform_class_buckchg_ops_set_chg(2, true) == -1);CHECK(platform_class_buckchg_ops_set_chg(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_buck_fsw(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_buck_fsw(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_buck_fsw(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_buck_fsw(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_otg(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_otg(1, true) == -1);CHECK(platform_class_buckchg_ops_set_otg(2, true) == -1);CHECK(platform_class_buckchg_ops_set_otg(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_otg_curr(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_otg_curr(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_otg_curr(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_otg_curr(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_otg_volt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_otg_volt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_otg_volt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_otg_volt(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_term(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_term(1, true) == -1);CHECK(platform_class_buckchg_ops_set_term(2, true) == -1);CHECK(platform_class_buckchg_ops_set_term(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_term_curr(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_term_curr(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_term_curr(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_term_curr(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_term_volt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_term_volt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_term_volt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_term_volt(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_adc_enable(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_adc_enable(1, true) == -1);CHECK(platform_class_buckchg_ops_adc_enable(2, true) == -1);CHECK(platform_class_buckchg_ops_adc_enable(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_prechg_volt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_prechg_volt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_prechg_volt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_prechg_volt(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_prechg_curr(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_prechg_curr(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_prechg_curr(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_prechg_curr(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_force_dpdm(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_force_dpdm(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_force_dpdm(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_force_dpdm(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_request_dpdm(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_request_dpdm(1, true) == -1);CHECK(platform_class_buckchg_ops_request_dpdm(2, true) == -1);CHECK(platform_class_buckchg_ops_request_dpdm(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_wd_timeout(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_wd_timeout(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_wd_timeout(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_wd_timeout(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_kick_wd(0) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_kick_wd(1) == -1);CHECK(platform_class_buckchg_ops_kick_wd(2) == -1);CHECK(platform_class_buckchg_ops_kick_wd(UINT_MAX) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_qc_volt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_qc_volt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_qc_volt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_qc_volt(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_usb_aicl_cont_thd(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_usb_aicl_cont_thd(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_usb_aicl_cont_thd(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_usb_aicl_cont_thd(UINT_MAX, expected_int) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_usb_aicl_cont_thd(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_usb_aicl_cont_thd(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_usb_aicl_cont_thd(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_usb_aicl_cont_thd(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_opt_fws(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_opt_fws(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_opt_fws(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_opt_fws(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_usb_adapter_allow_override(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_usb_adapter_allow_override(1, true) == -1);CHECK(platform_class_buckchg_ops_usb_adapter_allow_override(2, true) == -1);CHECK(platform_class_buckchg_ops_usb_adapter_allow_override(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_qc3_volt(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_qc3_volt(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_qc3_volt(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_qc3_volt(UINT_MAX, expected_int) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_otg_boost_src(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_otg_boost_src(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_otg_boost_src(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_otg_boost_src(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_otg_boost_enable_status(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_otg_boost_enable_status(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_otg_boost_enable_status(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_otg_boost_enable_status(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_otg_gate_enable_status(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_otg_gate_enable_status(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_otg_gate_enable_status(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_otg_gate_enable_status(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_boost_enable(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_boost_enable(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_boost_enable(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_boost_enable(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_boost_voltage(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_boost_voltage(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_boost_voltage(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_boost_voltage(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_aicl_enable(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_aicl_enable(1, true) == -1);CHECK(platform_class_buckchg_ops_set_aicl_enable(2, true) == -1);CHECK(platform_class_buckchg_ops_set_aicl_enable(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_rerun_aicl(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_rerun_aicl(1, true) == -1);CHECK(platform_class_buckchg_ops_set_rerun_aicl(2, true) == -1);CHECK(platform_class_buckchg_ops_set_rerun_aicl(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_restart_aicl(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_restart_aicl(1, true) == -1);CHECK(platform_class_buckchg_ops_set_restart_aicl(2, true) == -1);CHECK(platform_class_buckchg_ops_set_restart_aicl(UINT_MAX, true) == -1);
bout=false;expected_out=&bout;before=seen;CHECK(platform_class_buckchg_ops_is_support_cid(0, &bout) == -77);CHECK(seen==before+1);
CHECK(bout);
CHECK(platform_class_buckchg_ops_is_support_cid(1, &bout) == -1);CHECK(platform_class_buckchg_ops_is_support_cid(2, &bout) == -1);CHECK(platform_class_buckchg_ops_is_support_cid(UINT_MAX, &bout) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_ship_mode(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_ship_mode(1, true) == -1);CHECK(platform_class_buckchg_ops_set_ship_mode(2, true) == -1);CHECK(platform_class_buckchg_ops_set_ship_mode(UINT_MAX, true) == -1);
bout=false;expected_out=&bout;before=seen;CHECK(platform_class_buckchg_ops_get_ship_mode(0, &bout) == -77);CHECK(seen==before+1);
CHECK(bout);
CHECK(platform_class_buckchg_ops_get_ship_mode(1, &bout) == -1);CHECK(platform_class_buckchg_ops_get_ship_mode(2, &bout) == -1);CHECK(platform_class_buckchg_ops_get_ship_mode(UINT_MAX, &bout) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_wls_vdd_flag(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_wls_vdd_flag(1, true) == -1);CHECK(platform_class_buckchg_ops_set_wls_vdd_flag(2, true) == -1);CHECK(platform_class_buckchg_ops_set_wls_vdd_flag(UINT_MAX, true) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_enable(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_enable(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_enable(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_enable(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_status(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_status(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_status(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_status(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_sbu1(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_sbu1(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_sbu1(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_sbu1(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_sbu2(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_sbu2(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_sbu2(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_sbu2(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_cc1(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_cc1(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_cc1(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_cc1(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_cc2(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_cc2(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_cc2(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_cc2(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_dp(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_dp(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_dp(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_dp(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_dm(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_dm(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_dm(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_dm(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_lpd_sbu1(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_lpd_sbu1(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_lpd_sbu1(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_lpd_sbu1(UINT_MAX, expected_int) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_lpd_control(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_lpd_control(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_lpd_control(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_lpd_control(UINT_MAX, expected_int) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_control(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_control(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_control(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_control(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_lpd_uart_control(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_lpd_uart_control(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_lpd_uart_control(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_lpd_uart_control(UINT_MAX, expected_int) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_lpd_uart_control(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_lpd_uart_control(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_uart_control(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_lpd_uart_control(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_pack_vbat(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_pack_vbat(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_pack_vbat(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_pack_vbat(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_pack_ibat(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_pack_ibat(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_pack_ibat(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_pack_ibat(UINT_MAX, &out) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_pack_tbat(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_pack_tbat(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_pack_tbat(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_pack_tbat(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_eu_model(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_eu_model(1, true) == -1);CHECK(platform_class_buckchg_ops_set_eu_model(2, true) == -1);CHECK(platform_class_buckchg_ops_set_eu_model(UINT_MAX, true) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_icl_status(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_icl_status(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_icl_status(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_icl_status(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_too_hot_limit(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_too_hot_limit(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_too_hot_limit(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_too_hot_limit(UINT_MAX, expected_int) == -1);
out=0;expected_out=&out;before=seen;CHECK(platform_class_buckchg_ops_get_usbin_collapse_rt_sts(0, &out) == -77);CHECK(seen==before+1);
CHECK(out==expected_int);
CHECK(platform_class_buckchg_ops_get_usbin_collapse_rt_sts(1, &out) == -1);CHECK(platform_class_buckchg_ops_get_usbin_collapse_rt_sts(2, &out) == -1);CHECK(platform_class_buckchg_ops_get_usbin_collapse_rt_sts(UINT_MAX, &out) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_screen_status(0, true) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_screen_status(1, true) == -1);CHECK(platform_class_buckchg_ops_set_screen_status(2, true) == -1);CHECK(platform_class_buckchg_ops_set_screen_status(UINT_MAX, true) == -1);
before=seen;CHECK(platform_class_buckchg_ops_set_audio_status(0, expected_int) == -77);CHECK(seen==before+1);
CHECK(platform_class_buckchg_ops_set_audio_status(1, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_audio_status(2, expected_int) == -1);CHECK(platform_class_buckchg_ops_set_audio_status(UINT_MAX, expected_int) == -1);
bout=false;expected_out=&bout;before=seen;CHECK(platform_class_buckchg_ops_get_usb_input_swap(0, &bout) == -77);CHECK(seen==before+1);
CHECK(bout);
CHECK(platform_class_buckchg_ops_get_usb_input_swap(1, &bout) == -1);CHECK(platform_class_buckchg_ops_get_usb_input_swap(2, &bout) == -1);CHECK(platform_class_buckchg_ops_get_usb_input_swap(UINT_MAX, &bout) == -1);
bout=false;expected_out=&bout;before=seen;CHECK(platform_class_buckchg_ops_get_wls_input_swap(0, &bout) == -77);CHECK(seen==before+1);
CHECK(bout);
CHECK(platform_class_buckchg_ops_get_wls_input_swap(1, &bout) == -1);CHECK(platform_class_buckchg_ops_get_wls_input_swap(2, &bout) == -1);CHECK(platform_class_buckchg_ops_get_wls_input_swap(UINT_MAX, &bout) == -1);
}
static pthread_mutex_t hold_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t hold_cond = PTHREAD_COND_INITIALIZER;
static int entered, released, reader_done, replace_done, unregister_done;
static int hold_cb(void *data,int *value) {
 CHECK(data==&token);CHECK(value!=NULL);
 pthread_mutex_lock(&hold_lock);entered=1;pthread_cond_broadcast(&hold_cond);
 while(!released)pthread_cond_wait(&hold_cond,&hold_lock);
 pthread_mutex_unlock(&hold_lock);*value=42;return -55;
}
static struct platform_class_buckchg_ops hold_ops={.get_online=hold_cb};
static void *reader(void *unused) { int out=0;(void)unused;int r=platform_class_buckchg_ops_get_online(0,&out);assert(r==-55 && out==42);__atomic_store_n(&reader_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *replace(void *unused) { (void)unused;assert(!platform_class_buckchg_ops_register(0,&token,&all_ops));__atomic_store_n(&replace_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *unregister_old(void *unused) { (void)unused;int r=platform_class_buckchg_ops_unregister(0,&token,&hold_ops);assert(r==-ENOENT);__atomic_store_n(&unregister_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void *unregister_current(void *unused) { (void)unused;assert(!platform_class_buckchg_ops_unregister(0,&token,&hold_ops));__atomic_store_n(&unregister_done,1,__ATOMIC_SEQ_CST);return NULL; }
static void wait_sync(int n) { struct timespec start,now;clock_gettime(CLOCK_MONOTONIC,&start);while(__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST)<n){sched_yield();clock_gettime(CLOCK_MONOTONIC,&now);assert(now.tv_sec-start.tv_sec<5);} }
static void concurrency(void) {
 pthread_t a,b,c;CHECK(!platform_class_buckchg_ops_register(0,&token,&hold_ops));
 CHECK(!pthread_create(&a,NULL,reader,NULL));
 pthread_mutex_lock(&hold_lock);while(!entered)pthread_cond_wait(&hold_cond,&hold_lock);pthread_mutex_unlock(&hold_lock);
 int baseline=__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST);
 CHECK(!pthread_create(&b,NULL,replace,NULL));wait_sync(baseline+1);
 CHECK(!__atomic_load_n(&replace_done,__ATOMIC_SEQ_CST));
 CHECK(!pthread_create(&c,NULL,unregister_old,NULL));wait_sync(baseline+2);
 CHECK(!__atomic_load_n(&unregister_done,__ATOMIC_SEQ_CST));
 pthread_mutex_lock(&hold_lock);released=1;pthread_cond_broadcast(&hold_cond);pthread_mutex_unlock(&hold_lock);
 CHECK(!pthread_join(a,NULL));CHECK(!pthread_join(b,NULL));CHECK(!pthread_join(c,NULL));
 CHECK(reader_done && replace_done && unregister_done);
 CHECK(!platform_class_buckchg_ops_unregister(0,&token,&all_ops));
 entered=released=reader_done=unregister_done=0;
 CHECK(!platform_class_buckchg_ops_register(0,&token,&hold_ops));
 CHECK(!pthread_create(&a,NULL,reader,NULL));
 pthread_mutex_lock(&hold_lock);while(!entered)pthread_cond_wait(&hold_cond,&hold_lock);pthread_mutex_unlock(&hold_lock);
 baseline=__atomic_load_n(&sync_entered_count,__ATOMIC_SEQ_CST);
 CHECK(!pthread_create(&c,NULL,unregister_current,NULL));wait_sync(baseline+1);
 CHECK(!__atomic_load_n(&unregister_done,__ATOMIC_SEQ_CST));
 pthread_mutex_lock(&hold_lock);released=1;pthread_cond_broadcast(&hold_cond);pthread_mutex_unlock(&hold_lock);
 CHECK(!pthread_join(a,NULL));CHECK(!pthread_join(c,NULL));CHECK(reader_done && unregister_done);
 int absent=0;CHECK(platform_class_buckchg_ops_get_online(0,&absent)==-1);
}
int main(void) {
 CHECK(!platform_class_buckchg_init());CHECK(registered_drivers==1);
 CHECK(platform_class_buckchg_ops_register(2,&token,&all_ops)==-1);
 CHECK(platform_class_buckchg_ops_register(0,&token,NULL)==-1);
 CHECK(platform_class_buckchg_ops_unregister(2,&token,&all_ops)==-EINVAL);
 CHECK(platform_class_buckchg_ops_unregister(0,&token,NULL)==-EINVAL);
 CHECK(platform_class_buckchg_ops_unregister(0,&token,&all_ops)==-ENOENT);
 CHECK(!platform_class_buckchg_ops_register(0,&token,&all_ops));
 CHECK(!platform_class_buckchg_ops_register(1,&token,&no_ops));
 exercise_all();
 alloc_fail=1;CHECK(platform_class_buckchg_ops_register(0,NULL,&no_ops)==-ENOMEM);alloc_fail=0;
 exercise_all();
 /* Guard the actual USB-sense callback, independently of get_bus_volt. */
 struct platform_class_buckchg_ops usb={.get_usb_sns_volt=cb_get_usb_sns_volt};
 CHECK(!platform_class_buckchg_ops_register(0,&token,&usb));
 int value=0;expected_out=&value;CHECK(platform_class_buckchg_ops_get_usb_sns_volt(0,&value)==-77);CHECK(value==expected_int);
 usb.get_usb_sns_volt=NULL;usb.get_bus_volt=cb_get_bus_volt;
 CHECK(platform_class_buckchg_ops_get_usb_sns_volt(0,&value)==-1);
 CHECK(platform_class_buckchg_ops_unregister(0,&token,&all_ops)==-ENOENT);
 CHECK(!platform_class_buckchg_ops_unregister(0,&token,&usb));
 CHECK(platform_class_buckchg_ops_get_online(0,&value)==-1);
 concurrency();
 CHECK(!platform_class_buckchg_ops_register(0,&token,&all_ops));
 platform_class_buckchg_exit();CHECK(!registered_drivers);CHECK(!live_allocations);
 CHECK(platform_class_buckchg_ops_get_online(0,&value)==-1);
 printf("PASS: %u assertions, 89 callback slots plus 712-byte ABI, allocation failure, role/NULL bounds, pass-through, replaced-provider unregister wait, exit cleanup\n",assertions);
 return 0;
}
