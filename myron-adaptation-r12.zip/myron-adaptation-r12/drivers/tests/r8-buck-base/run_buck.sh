#!/usr/bin/env bash
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
payload="${1:-$here/../candidate}"
payload="$(cd -- "$payload" && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf -- "$tmp"' EXIT
"${CC:-cc}" -std=gnu11 -O1 -g -Wall -Wextra -Werror -pthread -fsanitize=address,undefined -fno-omit-frame-pointer -I"$here/stubs" -I"$payload/drivers/power/supply/mca/include" -DMCA_BUCK_SOURCE="\"$payload/drivers/power/supply/mca/mca_platform/mca_platform_buckchg_class.c\"" "$here/test_buck.c" -o "$tmp/test_buck"
ASAN_OPTIONS=detect_leaks=0:abort_on_error=1 "$tmp/test_buck"
