#ifndef MYRON_BUCK_TEST_H
#define MYRON_BUCK_TEST_H
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#define __rcu
#define __init
#define __exit
#define GFP_KERNEL 0
#define MODULE_DESCRIPTION(x)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#define EXPORT_SYMBOL(x)
#define module_init(x)
#define module_exit(x)
#define DEFINE_MUTEX(x) pthread_mutex_t x = PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) pthread_mutex_lock(x)
#define mutex_unlock(x) pthread_mutex_unlock(x)
#define lockdep_is_held(x) 1
#define DEFINE_STATIC_SRCU(x) static pthread_rwlock_t x = PTHREAD_RWLOCK_INITIALIZER
static inline int srcu_read_lock(pthread_rwlock_t *p) { assert(!pthread_rwlock_rdlock(p)); return 0; }
static inline void srcu_read_unlock(pthread_rwlock_t *p,int i) { (void)i;assert(!pthread_rwlock_unlock(p)); }
static int sync_entered_count;
static inline void synchronize_srcu(pthread_rwlock_t *p) { __atomic_add_fetch(&sync_entered_count,1,__ATOMIC_SEQ_CST);assert(!pthread_rwlock_wrlock(p));assert(!pthread_rwlock_unlock(p)); }
#define rcu_replace_pointer(p,v,c) __atomic_exchange_n(&(p),(v),__ATOMIC_SEQ_CST)
#define rcu_dereference_protected(p,c) __atomic_load_n(&(p),__ATOMIC_SEQ_CST)
#define srcu_dereference(p,s) __atomic_load_n(&(p),__ATOMIC_SEQ_CST)
#define RCU_INIT_POINTER(p,v) __atomic_store_n(&(p),(v),__ATOMIC_SEQ_CST)
static int alloc_fail, live_allocations;
static inline void *kmalloc(size_t n,int f) { (void)f;if(alloc_fail)return NULL;void *p=malloc(n);if(p)__atomic_add_fetch(&live_allocations,1,__ATOMIC_SEQ_CST);return p; }
static inline void kfree(void *p) { if(p){__atomic_sub_fetch(&live_allocations,1,__ATOMIC_SEQ_CST);free(p);} }
struct platform_driver { struct { const char *name; } driver; };
static int registered_drivers;
static inline int platform_driver_register(struct platform_driver *p) { (void)p;registered_drivers++;return 0; }
static inline void platform_driver_unregister(struct platform_driver *p) { (void)p;registered_drivers--; }
#endif
