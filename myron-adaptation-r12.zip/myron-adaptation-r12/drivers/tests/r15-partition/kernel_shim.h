/* Host test boundary only: production source never includes this file. */
#ifndef CP_HOST_SHIM_H
#define CP_HOST_SHIM_H
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <pthread.h>
typedef uint8_t u8;
typedef uint32_t u32;
typedef unsigned int blk_mode_t;
#define __aligned(n) __attribute__((aligned(n)))
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))
#define static_assert _Static_assert
#define MODULE_PARM_DESC(...)
#define MODULE_DESCRIPTION(...)
#define MODULE_LICENSE(...)
#define module_param(...)
#define MODULE_DEVICE_TABLE(...)
#define EXPORT_SYMBOL(...)
#define module_platform_driver(x) static void *const used_driver __attribute__((used)) = &(x)
#define DEFINE_MUTEX(n) pthread_mutex_t n = PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) assert(!pthread_mutex_lock(x))
#define mutex_unlock(x) assert(!pthread_mutex_unlock(x))
#define BLK_OPEN_READ 1
#define BLK_OPEN_WRITE 2
#define BLK_OPEN_RESTRICT_WRITES 32
#define THIS_MODULE ((void *)1)
#define IS_ERR(x) ((uintptr_t)(x) >= (uintptr_t)-4095)
#define PTR_ERR(x) ((long)(x))
#define ERR_PTR(x) ((void *)(long)(x))
struct task_struct { int refs; };
extern _Thread_local struct task_struct *mock_current;
#define current mock_current
struct partition_meta_info { char volname[64]; char uuid[64]; };
struct block_device { struct partition_meta_info *bd_meta_info; size_t bytes; bool part; unsigned int logical_size; };
struct file { struct block_device *bdev; };
struct platform_device { int unused; };
struct of_device_id { char compatible[64]; };
struct platform_driver {
 struct { const char *name; const struct of_device_id *of_match_table; bool suppress_bind_attrs; } driver;
 int (*probe)(struct platform_device *);
 void (*remove)(struct platform_device *);
};
static inline struct block_device *file_bdev(struct file *f) { return f->bdev; }
static inline loff_t bdev_nr_bytes(struct block_device *b) { return b->bytes; }
static inline bool bdev_is_partition(struct block_device *b) { return b->part; }
static inline unsigned int bdev_logical_block_size(struct block_device *b) { return b->logical_size; }
extern int module_refs;
static inline bool try_module_get(void *m) { (void)m; module_refs++; return true; }
static inline void module_put(void *m) { (void)m; assert(module_refs > 0); module_refs--; }
static inline void get_task_struct(struct task_struct *t) { t->refs++; }
static inline void put_task_struct(struct task_struct *t) { assert(t->refs > 0); t->refs--; }
struct file *bdev_file_open_by_path(const char *, blk_mode_t, void *, const void *);
void bdev_fput(struct file *);
void invalidate_bdev(struct block_device *);
ssize_t kernel_read(struct file *, void *, size_t, loff_t *);
ssize_t kernel_write(struct file *, const void *, size_t, loff_t *);
int vfs_fsync(struct file *, int);
#endif
