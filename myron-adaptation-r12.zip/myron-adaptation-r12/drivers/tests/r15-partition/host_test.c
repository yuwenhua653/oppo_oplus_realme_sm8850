/* Compile the complete production translation unit against host I/O boundaries. */
#include "kernel_shim.h"
#include "charger_partition_under_test.c"

static unsigned char disk[16 * 4096], before[sizeof(disk)];
static struct task_struct task_a, task_b;
_Thread_local struct task_struct *mock_current;
int module_refs;
static struct partition_meta_info metadata;
static struct block_device block;
static struct file backing;
static struct platform_device device;
static int read_calls, write_calls, fsync_calls, invalidate_calls, open_calls, close_calls;
static int fail_read_at, short_read_at, fail_write_at, short_write_at, fail_sync_at, open_error;
static blk_mode_t opened_mode;

struct file *bdev_file_open_by_path(const char *p, blk_mode_t mode, void *h, const void *ops)
{
 assert(p && h && !ops);
 opened_mode = mode; open_calls++;
 return open_error ? ERR_PTR(open_error) : &backing;
}
void bdev_fput(struct file *f) { assert(f == &backing); close_calls++; }
void invalidate_bdev(struct block_device *b) { assert(b == &block); invalidate_calls++; }
ssize_t kernel_read(struct file *f, void *out, size_t size, loff_t *pos)
{
 assert(f == &backing && size == 4096 && *pos >= 0 && *pos + size <= sizeof(disk));
 read_calls++;
 if (read_calls == fail_read_at) return -EIO;
 if (read_calls == short_read_at) return size - 1;
 memcpy(out, disk + *pos, size); *pos += size; return size;
}
ssize_t kernel_write(struct file *f, const void *in, size_t size, loff_t *pos)
{
 assert(f == &backing && size == 4096 && *pos >= 0 && *pos + size <= sizeof(disk));
 assert(opened_mode & BLK_OPEN_WRITE);
 write_calls++;
 if (write_calls == fail_write_at) return -EIO;
 if (write_calls == short_write_at) size--;
 memcpy(disk + *pos, in, size); *pos += size; return size;
}
int vfs_fsync(struct file *f, int datasync)
{
 assert(f == &backing && !datasync); fsync_calls++;
 return fsync_calls == fail_sync_at ? -EIO : 0;
}

static charger_partition_header *header(void) { return (void *)disk; }
static charger_partition_info_1 *info1(void) { return (void *)(disk + 4096); }
static charger_partition_info_2 *info2(void) { return (void *)(disk + 8192); }
static void reset(bool writable)
{
 assert(!cp_owner && !module_refs && !task_a.refs && !task_b.refs);
 if (cp_file) charger_partition_remove(&device);
 memset(disk, 0xa5, sizeof(disk));
 *header() = (charger_partition_header){ CHARGER_PARTITION_MAGIC, 7, 1, 1, 0xabcd };
 *info1() = (charger_partition_info_1){ 2, 3, 1, 85, 0, 80, 17, 0x9876 };
 *info2() = (charger_partition_info_2){ 1, {2, 3}, {4, 5}, 6, 7, 8 };
 strcpy(metadata.volname, "charger"); strcpy(metadata.uuid, "01234567-89ab-cdef-0123-456789abcdef");
 block = (struct block_device){ &metadata, sizeof(disk), true, 4096 }; backing.bdev = &block;
 block_path = "/explicit/test/partition"; partition_uuid = metadata.uuid; format_version = 7; allow_writes = writable;
 mock_current = &task_a; cp_poisoned = false;
 read_calls = write_calls = fsync_calls = invalidate_calls = open_calls = close_calls = 0;
 fail_read_at = short_read_at = fail_write_at = short_write_at = fail_sync_at = open_error = 0;
}
#define ALLOC() charger_partition_alloc(CHARGER_PARTITION_HOST_KERNEL, CHARGER_PARTITION_INFO_1, sizeof(charger_partition_info_1))
#define FREE() charger_partition_dealloc(CHARGER_PARTITION_HOST_KERNEL, CHARGER_PARTITION_INFO_1, sizeof(charger_partition_info_1))
#define READ() charger_partition_read(CHARGER_PARTITION_HOST_KERNEL, CHARGER_PARTITION_INFO_1, sizeof(charger_partition_info_1))
static void ready(bool rw) { reset(rw); assert(!charger_partition_probe(&device)); }
static unsigned int passed;
#define PASS(label) do { passed++; puts(label); } while (0)

static void *contender(void *ignored)
{
 (void)ignored; mock_current = &task_b;
 assert(ALLOC() == -EBUSY); assert(!READ()); assert(FREE() == -EPERM);
 return NULL;
}

int main(void)
{
 int out = 123;
 bool flag = false;
 u32 a, b;
 pthread_t t;
 charger_partition_info_1 *record;
 reset(false); block_path = NULL; assert(charger_partition_probe(&device) == -EINVAL && !open_calls); PASS("missing path rejected before open");
 reset(false); partition_uuid = NULL; assert(charger_partition_probe(&device) == -EINVAL && !open_calls); PASS("missing UUID rejected before open");
 reset(false); format_version = ~0U; assert(charger_partition_probe(&device) == -EINVAL && !open_calls); PASS("unknown format rejected before open");
 reset(false); open_error = -ENOENT; assert(charger_partition_probe(&device) == -ENOENT && !cp_file); PASS("open error propagated");
 reset(false); block.part = false; assert(charger_partition_probe(&device) == -EINVAL && close_calls == 1); PASS("whole disk rejected");
 reset(false); strcpy(metadata.volname,"wrong"); assert(charger_partition_probe(&device) == -EINVAL); PASS("wrong label rejected");
 reset(false); partition_uuid = "other"; assert(charger_partition_probe(&device) == -EINVAL); PASS("wrong UUID rejected");
 reset(false); block.logical_size = 512; assert(charger_partition_probe(&device) == -EINVAL); PASS("wrong block size rejected");
 reset(false); block.bytes = CP_MIN_BYTES-1; assert(charger_partition_probe(&device) == -EINVAL); PASS("short partition rejected");
 reset(false); header()->magic++; memcpy(before,disk,sizeof(disk)); assert(charger_partition_probe(&device) == -EUCLEAN && !memcmp(before,disk,sizeof(disk))); PASS("bad magic never formatted");
 reset(false); header()->version++; assert(charger_partition_probe(&device) == -EUCLEAN); PASS("wrong version rejected");
 reset(false); header()->initialized = 0; assert(charger_partition_probe(&device) == -EUCLEAN); PASS("uninitialized data rejected");
 reset(false); header()->avaliable = 0; assert(charger_partition_probe(&device) == -EBUSY); PASS("busy partition never reset");
 reset(false); short_read_at = 1; assert(charger_partition_probe(&device) == -EIO); PASS("short header read fails probe");
 ready(false); memcpy(before,disk,sizeof(disk));
 assert(!charger_partition_read_double85(&out) && out == 85);
 assert(!charger_partition_read_memory_test(&out) && out == 17);
 assert(!charger_partition_read_soc_limit(&out) && out == 80);
 assert(!charger_partition_get_mishow(&flag) && flag);
 assert(!charger_partition_get_eu_model(&flag) && flag);
 assert(!charger_partition_read_ocd_count(&a,&b) && a == 2 && b == 3);
 assert(!charger_partition_read_cuv_count(&a,&b) && a == 4 && b == 5);
 assert(!charger_partition_read_hscd_count(&a) && a == 6);
 assert(!memcmp(before,disk,sizeof(disk)) && !write_calls && !fsync_calls);
 assert(read_calls == invalidate_calls); PASS("all read APIs return real fields without writes and invalidate cache");
 assert(charger_partition_write_double85(0) == -EROFS);
 assert(charger_partition_write_remove_temp_limit(1) == -EROFS);
 assert(charger_partition_write_memory_test(1) == -EROFS);
 assert(charger_partition_write_soc_limit(1) == -EROFS);
 assert(charger_partition_write_ocd_count(1,2) == -EROFS);
 assert(charger_partition_write_cuv_count(1,2) == -EROFS);
 assert(charger_partition_write_hcsd_count(1) == -EROFS);
 assert(!ALLOC()); assert(charger_partition_write(4,1,before,32) == -EROFS); assert(!FREE());
 assert(!write_calls); PASS("all write APIs refuse read-only mode");
 out = 123; fail_read_at = read_calls+2; assert(charger_partition_read_double85(&out) == -EIO && out == 123 && !cp_owner && !module_refs); PASS("read failure preserves output and releases owner");
 assert(charger_partition_read_double85(NULL) == -EINVAL);
 assert(charger_partition_get_eu_model(NULL) == -EINVAL);
 assert(charger_partition_get_mishow(NULL) == -EINVAL);
 assert(charger_partition_read_ocd_count(NULL,&b) == -EINVAL);
 assert(charger_partition_read_cuv_count(&a,NULL) == -EINVAL);
 assert(charger_partition_read_hscd_count(NULL) == -EINVAL); PASS("null output pointers rejected");
 ready(false); assert(charger_partition_alloc(0,1,32) == -EINVAL); assert(charger_partition_alloc(4,0,32) == -EINVAL); assert(charger_partition_alloc(4,11,32) == -EINVAL); assert(charger_partition_alloc(4,1,4096) == -EINVAL); assert(charger_partition_alloc(4,1,0) == -EINVAL); PASS("host record and length bounds enforced");
 assert(!ALLOC() && module_refs == 1 && task_a.refs == 1);
 assert(!pthread_create(&t,NULL,contender,NULL)); assert(!pthread_join(t,NULL));
 assert(charger_partition_dealloc(4,2,32) == -EINVAL && cp_owner); assert(!FREE()); PASS("concurrent task cannot borrow buffer or release transaction");
 ready(true); memcpy(before,disk,sizeof(disk)); assert(!charger_partition_write_soc_limit(90));
 ((charger_partition_info_1 *)(before+4096))->soc_limit = 90;
 assert(!memcmp(before,disk,sizeof(disk)) && write_calls == 3 && fsync_calls == 3); PASS("RMW preserves every unrelated byte and fsyncs claim data release");
 assert(!charger_partition_write_double85(33) && info1()->double85 == 33);
 assert(!charger_partition_write_remove_temp_limit(0) && !info1()->remove_temp_limit);
 assert(!charger_partition_write_memory_test(42) && info1()->memory_test == 42);
 assert(!charger_partition_write_ocd_count(11,12) && info2()->ocd_count[1] == 12);
 assert(!charger_partition_write_cuv_count(21,22) && info2()->cuv_count[0] == 21);
 assert(!charger_partition_write_hcsd_count(99) && info2()->hscd_count == 99); PASS("all field write APIs persist requested data");
 assert(!ALLOC()); record = READ(); assert(record); record->soc_limit=66; assert(!charger_partition_write(4,1,record,32)); assert(!FREE() && info1()->soc_limit==66); PASS("public read buffer can be passed to write");
 ready(true); short_write_at=2; assert(charger_partition_write_soc_limit(9)==-EIO); assert(cp_poisoned && !cp_owner && !module_refs && header()->avaliable==0); assert(ALLOC()==-EIO); PASS("short data write poisons backend and does not clear busy");
 ready(true); fail_sync_at=2; assert(charger_partition_write_soc_limit(9)==-EIO); assert(cp_poisoned && !cp_owner && header()->avaliable==0); PASS("data flush error never reported as success");
 ready(true); fail_write_at=1; assert(ALLOC()==-EIO && !cp_owner && !module_refs && cp_poisoned); PASS("failed claim releases module ref and poisons backend");
 ready(true); assert(!ALLOC()); fail_write_at=write_calls+1; assert(FREE()==-EIO && !cp_owner && !module_refs && cp_poisoned); PASS("failed release propagates error and closes transaction");
 ready(true); assert(!ALLOC()); header()->magic++; assert(FREE()==-EUCLEAN && cp_poisoned && !module_refs); PASS("metadata mutation during transaction is rejected");
 ready(false); assert(!ALLOC()); record=READ(); assert(record && module_refs==1); charger_partition_remove(&device); assert(record->soc_limit==80); assert(!READ()); assert(FREE()==-ENODEV && !module_refs && !cp_owner); PASS("device removal leaves borrowed memory valid until release");
 assert(charger_partition_read_soc_limit(&out)==-ENODEV); PASS("unbound provider returns failure not fake data");
 reset(false); assert(!module_refs && !task_a.refs && !task_b.refs); printf("PASS %u host behavior groups\n",passed);
 return 0;
}
