#!/usr/bin/env python3
"""Host execution of complete production C; explicitly not a target .ko build."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
SOURCE = 'drivers/power/supply/mca/mca_shared_memory/charger_partition.c'
HEADER = 'drivers/power/supply/mca/include/mca/shared_memory/charger_partition_class.h'

def run(payload):
    source = (payload / SOURCE).read_text()
    with tempfile.TemporaryDirectory(prefix='myron-partition-host-') as tmp:
        root = Path(tmp)
        for include in re.findall(r'^#include <([^>]+)>', source, re.M):
            target = root/include
            target.parent.mkdir(parents=True, exist_ok=True)
            if include.startswith('linux/'):
                target.write_text('#include "kernel_shim.h"\n')
            else:
                shutil.copyfile(payload/HEADER, target)
        for name in ('kernel_shim.h', 'host_test.c'):
            shutil.copyfile(HERE/name, root/name)
        (root/'charger_partition_under_test.c').write_text(source)
        cmd = ['cc', '-std=gnu11', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter',
               '-fsanitize=undefined', '-fno-sanitize-recover=all', '-pthread', '-I'+str(root),
               str(root/'host_test.c'), '-o', str(root/'test')]
        built = subprocess.run(cmd, text=True, capture_output=True)
        if built.returncode:
            raise RuntimeError(built.stdout+built.stderr)
        result = subprocess.run([str(root/'test')], text=True, capture_output=True)
        print(result.stdout, end='')
        if result.returncode:
            raise RuntimeError(result.stdout+result.stderr)
        groups = result.stdout.strip().splitlines()
    return {'passed':True, 'target_compiled':False, 'hardware_tested':False,
            'scope':'Entire production C against host kernel I/O boundaries; undefined-behavior sanitizer enabled',
            'source_sha256':hashlib.sha256(source.encode()).hexdigest(), 'checks':groups[:-1],
            'check_groups':len(groups)-1}

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('payload',type=Path)
    p.add_argument('--report',type=Path)
    a=p.parse_args()
    report=run(a.payload)
    if a.report:
        a.report.parent.mkdir(parents=True,exist_ok=True)
        a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':True,'host_check_groups':report['check_groups'],'target_compiled':False}))
