/* Host ASan/UBSan tests of actual formatter; not a kernel/device runtime test. */
#include "../payload/drivers/misc/miev/mievent.c"
#include <limits.h>

static char captured[4097];
static int write_error;
int write_kbuf(char *buffer, int size)
{
 assert(size >= 0 && size <= 4096);
 if (write_error) return write_error;
 memcpy(captured,buffer,size); captured[size]=0;
 return size;
}
int main(void)
{
 struct misight_mievent *a, *b;
 char long_text[4098];
 a=cdev_tevent_alloc(1);assert(a);
 assert(cdev_tevent_write(a)==0);
 assert(!strcmp(captured,"EventId 1 -t 1234 -paraList {}"));
 cdev_tevent_destroy(a);
 a=cdev_tevent_alloc(2);assert(a);
 assert(cdev_tevent_add_int(a,"integer",LONG_MIN)==0);
 b=cdev_tevent_alloc(3);assert(b);
 assert(cdev_tevent_add_str(b,"key\"", "line\nslash\\")==0);
 assert(cdev_tevent_write(a)==0);
 assert(strstr(captured,"\"integer\":-9223372036854775808"));
 assert(cdev_tevent_write(b)==0);
 assert(!strcmp(captured,"EventId 3 -t 1234 -paraList {\"key\\\"\":\"line\\u000aslash\\\\\"}"));
 assert(cdev_tevent_write(b)==0);assert(strstr(captured,"{}"));
 cdev_tevent_destroy(a);cdev_tevent_destroy(b);
 a=cdev_tevent_alloc(UINT_MAX);assert(a);
 memset(long_text,'a',sizeof(long_text));long_text[4097]=0;
 assert(cdev_tevent_add_str(a,"key",long_text)==-E2BIG);
 long_text[4096]=0;
 assert(cdev_tevent_add_str(a,"key",long_text)==0);
 assert(cdev_tevent_write(a)==-E2BIG);
 assert(a->head->next);cdev_tevent_destroy(a);
 a=cdev_tevent_alloc(4);assert(a);assert(cdev_tevent_add_int(a,"value",42)==0);
 write_error=-EIO;assert(cdev_tevent_write(a)==-EIO);assert(a->head->next);
 write_error=0;assert(cdev_tevent_write(a)==0);assert(!a->head->next);
 allocation_fail_after=0;assert(cdev_tevent_add_int(a,"oom",1)==-ENOMEM);
 assert(cdev_tevent_write(a)==-ENOMEM);allocation_fail_after=-1;cdev_tevent_destroy(a);
 allocation_fail_after=0;assert(!cdev_tevent_alloc(5));
 allocation_fail_after=1;assert(!cdev_tevent_alloc(5));allocation_fail_after=-1;
 assert(cdev_tevent_add_str(NULL,"k","v")==-EINVAL);
 assert(cdev_tevent_add_int(NULL,"k",1)==-EINVAL);
 assert(cdev_tevent_write(NULL)==-EINVAL);cdev_tevent_destroy(NULL);
 assert(allocation_balance == 0);
 puts("PASS: formatter empty/interleaved/escaped/size/error/allocation cases; ASan+UBSan");
 return 0;
}
