#!/bin/bash
set -euo pipefail
test_dir=$(cd -- "$(dirname -- "$0")" && pwd)
payload_dir="$test_dir/../../payload/drivers/misc/hwid"
test_tmp=$(mktemp -d)
trap 'rm -rf -- "$test_tmp"' EXIT
${CC:-cc} -std=c11 -Wall -Wextra -Werror -fsanitize=undefined \
    -fno-omit-frame-pointer -I"$test_dir/stubs" -I"$payload_dir" \
    "$test_dir/test_hwid_contract.c" -o "$test_tmp/hwid-contract"
"$test_tmp/hwid-contract"
