#ifndef TEST_SOCINFO_H
#define TEST_SOCINFO_H
#include <linux/types.h>
uint32_t socinfo_get_id(void);
#endif
