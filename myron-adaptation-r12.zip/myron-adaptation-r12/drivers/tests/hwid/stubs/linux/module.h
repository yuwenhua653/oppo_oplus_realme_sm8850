#ifndef TEST_LINUX_MODULE_H
#define TEST_LINUX_MODULE_H
#include <linux/types.h>
struct test_param { const char *name; const char *type; unsigned mode; unsigned *value; };
#define module_param(n, t, p) static const struct test_param test_param_##n = { #n, #t, p, &n }
#define MODULE_PARM_DESC(n, d)
#define EXPORT_SYMBOL(n)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#endif
