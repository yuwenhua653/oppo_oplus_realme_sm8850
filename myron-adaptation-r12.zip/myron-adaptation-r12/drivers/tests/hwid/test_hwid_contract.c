/* Host contract test: compiles the actual candidate hwid.c with minimal stubs.
 * This checks pure mapping/getter behavior, not a kernel build or module load.
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

static uint32_t test_soc_id;
static unsigned socinfo_calls;
uint32_t socinfo_get_id(void)
{
	socinfo_calls++;
	return test_soc_id;
}
#include "hwid.c"

static unsigned assertions;
#define CHECK(c) do { assertions++; if (!(c)) { \
	fprintf(stderr, "%s:%d: failed: %s\n", __FILE__, __LINE__, #c); exit(1); \
} } while (0)

static void expect_name(uint32_t soc, unsigned proj, const char *expected)
{
	unsigned calls_before = socinfo_calls;
	test_soc_id = soc;
	project = proj;
	CHECK(strcmp(product_name_get(), expected) == 0);
	CHECK(socinfo_calls == calls_before + 1);
}

static void expect_getters(uint32_t value)
{
	hwid_value = value;
	CHECK(get_hw_id_value() == value);
	CHECK(get_hw_country_version() == value / 1048576U);
	CHECK(get_hw_version_major() == value / 65536U);
	CHECK(get_hw_version_minor() == value % 65536U);
	CHECK(get_hw_version_build() == (value / 65536U) % 16U);
}

int main(void)
{
	static const struct test_param *params[] = {
		&test_param_project, &test_param_hwid_value,
		&test_param_build_adc, &test_param_project_adc,
	};
	static const char *names[] = { "project", "hwid_value", "build_adc", "project_adc" };
	static const char *devices[] = { "popsicle", "pudding", "pandora", "myron", "nezha", "pecan", "pixiu" };
	static const unsigned invalid_projects[] = { 0U, 8U, 9U, UINT_MAX };
	static const uint32_t other_socs[] = { 0U, 457U, 519U, 557U, 614U, 618U, 661U, 16777876U, UINT32_MAX };
	static const uint32_t boundaries[] = { 0U, 1U, 0xffffU, 0x10000U, 0xf0000U, 0xfffffU, 0x100000U, 0x7fffffffU, 0x80000000U, UINT32_MAX };
	uint32_t seed = 0x8850;
	unsigned i;

	CHECK(sizeof(uint) == sizeof(uint32_t));
	for (i = 0; i < sizeof(params) / sizeof(params[0]); i++) {
		CHECK(strcmp(params[i]->name, names[i]) == 0);
		CHECK(strcmp(params[i]->type, "uint") == 0);
		CHECK(params[i]->mode == 0444);
		CHECK(*params[i]->value == 0U);
	}
	/* Zero-filled defaults must never identify an actual device. */
	test_soc_id = 660;
	CHECK(strcmp(product_name_get(), "unknown") == 0);

	for (i = 0; i < sizeof(devices) / sizeof(devices[0]); i++)
		expect_name(660, i + 1U, devices[i]);
	for (i = 0; i < sizeof(invalid_projects) / sizeof(invalid_projects[0]); i++)
		expect_name(660, invalid_projects[i], "unknown");
	for (i = 0; i < sizeof(other_socs) / sizeof(other_socs[0]); i++)
		expect_name(other_socs[i], 4U, "unknown");

	/* Device-captured boot arguments: observed values, not driver defaults. */
	project = 4;
	hwid_value = 589830;
	build_adc = 51310;
	project_adc = 16691;
	test_soc_id = 660;
	CHECK(strcmp(product_name_get(), "myron") == 0);
	CHECK(get_hw_version_platform() == 4U);
	CHECK(get_hw_id_value() == 0x90006U);
	CHECK(get_hw_country_version() == 0U);
	CHECK(get_hw_version_major() == 9U);
	CHECK(get_hw_version_minor() == 6U);
	CHECK(get_hw_version_build() == 9U);
	CHECK(get_hw_build_adc() == 51310U);
	CHECK(get_hw_project_adc() == 16691U);
	/* Inputs remain authoritative when changed; no phone-value hardcoding. */
	project = UINT_MAX;
	build_adc = 0;
	project_adc = UINT_MAX;
	CHECK(get_hw_version_platform() == UINT_MAX);
	CHECK(get_hw_build_adc() == 0U);
	CHECK(get_hw_project_adc() == UINT_MAX);
	build_adc = UINT_MAX;
	project_adc = 0;
	CHECK(get_hw_build_adc() == UINT_MAX);
	CHECK(get_hw_project_adc() == 0U);

	for (i = 0; i < sizeof(boundaries) / sizeof(boundaries[0]); i++)
		expect_getters(boundaries[i]);
	for (i = 0; i < 4096; i++) {
		seed = seed * 1664525U + 1013904223U;
		expect_getters(seed);
	}
	printf("PASS: %u host contract assertions; actual candidate C compiled; kernel runtime untested\n", assertions);
	return 0;
}
