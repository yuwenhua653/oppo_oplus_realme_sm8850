static void reset(void){
 assert(!resource_count && !active_irq && !active_wake && !active_gpio && !active_notifier && !active_mutex && !active_work && !wakeup_enabled);
 inject_stage=0;inject_nth=1;stage_count=0;alloc_nth=0;alloc_count=0;action_nth=0;action_count=0;ops_registered=0;sysfs_count=0;handle_called=0;g_info=NULL;support_hall=1;
}
static void sc_case(int stage,int nth,int allocation,int action,int hall,int expected){
 reset();inject_stage=stage;inject_nth=nth;alloc_nth=allocation;action_nth=action;support_hall=hall;
 struct device_node node={0};struct i2c_client client={.dev.of_node=&node};
 int ret=sc96281_charger_probe(&client);
 if(ret!=expected){fprintf(stderr,"sc stage %d nth %d alloc %d action %d hall %d: got %d expected %d\n",stage,nth,allocation,action,hall,ret,expected);abort();}
 assert(ops_registered==(expected==0));
 if(!expected){assert(active_irq==(hall?3:2));assert(active_wake==active_irq);assert(active_notifier==1);}
 unwind();assert(!active_irq && !active_wake && !active_gpio && !active_notifier && !active_mutex && !active_work && !wakeup_enabled);++cases;
}
static void path_case(int stage,int allocation,int expected){
 reset();inject_stage=stage;alloc_nth=allocation;
 struct platform_device dev={0};
 int ret=mca_path_control_probe(&dev);assert(ret==expected);
 if(expected){assert(!g_info && !active_work && !active_mutex);}
 else{
  assert(g_info && active_work==1 && active_mutex==1);
  for(int i=0;i<MAX_ROLE;i++)assert(g_info->gate_sts[i]==0);
  assert(mca_path_control_enable_gate((CONTROL_SRC)123,true)==-EINVAL);assert(!handle_called);
  assert(mca_path_control_enable_gate(PATH_CONTROL_USB,true)==0);assert(handle_called==1);
  cancel_delayed_work_sync(&g_info->update_condition_work);mutex_destroy(&g_info->enable_handling_lock);g_info=NULL;
 }
 unwind();++cases;
}
int main(void){
 reset();assert(mca_path_control_enable_gate(PATH_CONTROL_USB,true)==-ENODEV);++cases;
 path_case(0,1,-ENOMEM);path_case(0,2,-ENOMEM);path_case(15,0,-EPROBE_DEFER);path_case(16,0,-ENOMEM);path_case(0,0,0);
 sc_case(0,1,1,0,1,-ENOMEM);sc_case(0,1,2,0,1,-ENOMEM);
 for(int a=1;a<=7;a++)sc_case(0,1,0,a,1,-ENOMEM);
 sc_case(1,1,0,0,1,-EIO);sc_case(2,1,0,0,1,-ENODEV);sc_case(3,1,0,0,1,-EINVAL);sc_case(4,1,0,0,1,-EPROBE_DEFER);
 for(int n=1;n<=2;n++){sc_case(5,n,0,0,1,-EPROBE_DEFER);sc_case(6,n,0,0,1,-EIO);}
 for(int n=1;n<=4;n++)sc_case(7,n,0,0,1,-EPROBE_DEFER);
 sc_case(8,1,0,0,1,-EBUSY);
 for(int n=1;n<=3;n++){sc_case(9,n,0,0,1,-EPROBE_DEFER);sc_case(10,n,0,0,1,-EINVAL);sc_case(11,n,0,0,1,-EBUSY);sc_case(12,n,0,0,1,-EIO);}
 sc_case(13,1,0,0,1,-EBUSY);sc_case(14,1,0,0,1,-EOPNOTSUPP);
 sc_case(0,1,0,0,1,0);sc_case(0,1,0,0,0,0);
 reset();printf("PASS: %d scenarios; actual production probe/IRQ/DT/cleanup bodies, simulated immediate IRQ, ASan + UBSan.\n",cases);return 0;
}
