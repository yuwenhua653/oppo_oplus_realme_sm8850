#!/usr/bin/env python3
"""Extract changed production C functions and fault-inject their kernel APIs.
This is a host lifecycle test, not a kernel build or hardware test.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, tempfile
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT.parents[1]/'payload'
parser=argparse.ArgumentParser()
parser.add_argument('--payload',type=Path,default=DEFAULT)
parser.add_argument('--report',type=Path)
parser.add_argument('--out',type=Path,help='Optional directory retaining generated host C/executable')
a=parser.parse_args()
temporary=tempfile.TemporaryDirectory(prefix='myron-r13-runtime-') if a.out is None else None
a.out=a.out or Path(temporary.name)
a.out.mkdir(parents=True,exist_ok=True)
base=a.payload/'drivers/power/supply/mca'
pathfile=base/'mca_hardware_monitor/mca_path_control.c'
scfile=base/'mca_hardware_ic/wireless_ic/sc96281/sc96281_core.c'
def function(text,name):
    # Kernel >= 6.6.9 probe signature; body bytes remain unchanged.
    text=re.sub(r'#if \(LINUX_VERSION_CODE >= KERNEL_VERSION\(6, 6, 9\)\)\n(.*?)\n#else\n.*?\n#endif',r'\1',text,flags=re.S)
    pat=r'(?m)^(?:static )?(?:int|void|irqreturn_t) '+name+r'\s*\('
    m=re.search(pat,text); assert m,name
    start=m.start(); b=text.index('{',m.end()); depth=1; i=b+1; quote=None; line=False; block=False
    while depth:
        c=text[i]; nxt=text[i:i+2]
        if line:
            if c=='\n': line=False
        elif block:
            if nxt=='*/': block=False;i+=1
        elif quote:
            if c=='\\':i+=1
            elif c==quote:quote=None
        elif nxt=='//':line=True;i+=1
        elif nxt=='/*':block=True;i+=1
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
        i+=1
    return text[start:i]
path_names=['mca_path_control_enable_gate','mca_path_control_probe']
sc_names=['sc96281_parse_dt','sc96281_cancel_works','sc96281_destroy_mutexes','sc96281_disable_wakeup','sc96281_disable_irq_wake','sc96281_unregister_reboot_notifier','sc96281_request_irq','sc96281_irq_init','sc96281_charger_probe']
sc_handlers=['sc96281_interrupt_handler','sc96281_power_good_handler','sc96281_hall_interrupt_handler']
functions='\n\n'.join(function(pathfile.read_text(),n) for n in path_names)+'\n'+ '\n\n'.join(function(scfile.read_text(),n) for n in sc_handlers+sc_names)
stubs=(ROOT/'runtime_stubs.c').read_text()
main=(ROOT/'runtime_cases.c').read_text()
translation=a.out/'runtime-functions.c';translation.write_text(stubs+'\n'+functions+'\n'+main)
cmd=['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(translation),'-o',str(a.out/'runtime-functions')]
subprocess.run(cmd,check=True)
env=dict(os.environ, ASAN_OPTIONS='detect_leaks=0')
r=subprocess.run([str(a.out/'runtime-functions')],check=True,text=True,capture_output=True,env=env)
print(r.stdout,end='')
report={'passed':True,'test_kind':'host actual-function fault injection with ASan/UBSan','leak_sanitizer':False,'leak_sanitizer_reason':'ptrace environment; devres counters and ASan/UBSan remain checked','kernel_compile':False,'hardware_test':False,'functions':path_names+sc_handlers+sc_names,'command':cmd,'result':r.stdout,'source_sha256':{str(p.relative_to(a.payload)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [pathfile,scfile]}}
if a.report:
    a.report.parent.mkdir(parents=True,exist_ok=True)
    a.report.write_text(json.dumps(report,indent=2)+'\n')
if temporary:
    temporary.cleanup()
