#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define EPROBE_DEFER 517
#define GFP_KERNEL 0
#define MAX_ROLE 5
#define IRQF_ONESHOT 1
#define IRQF_TRIGGER_FALLING 2
#define IRQF_TRIGGER_RISING 4
#define IRQ_HANDLED 1
#define GPIOF_OUT_INIT_LOW 0
#define SC96281_DRV_VERSION "test"
#define IS_ERR(p) ((intptr_t)(p)<0 && (intptr_t)(p)>-4096)
#define IS_ERR_OR_NULL(p) (!(p) || IS_ERR(p))
#define PTR_ERR(p) ((int)(intptr_t)(p))
#define ERR_PTR(n) ((void *)(intptr_t)(n))
#define mca_log_err(...) do { if (0) fprintf(stderr,__VA_ARGS__); } while(0)
#define mca_log_info(...) do { if (0) fprintf(stderr,__VA_ARGS__); } while(0)
#define msecs_to_jiffies(n) (n)
typedef int irqreturn_t;
typedef irqreturn_t (*irq_handler_t)(int,void *);
struct device_node {int unused;};
struct device {struct device_node *of_node;void *data;};
struct platform_device {struct device dev;};
struct i2c_client {struct device dev;};
struct mutex {int initialized;int held;};
struct delayed_work {int initialized;int pending;};
struct notifier_block {int (*notifier_call)(struct notifier_block *,unsigned long,void *);int priority;};
struct sc96281 {
 struct device *dev;struct i2c_client *client;int *wls_fw_data;void *regmap;
 unsigned int project_vendor,support_hall,rx_role,fw_version_index;
 void *sc96281_pinctrl,*pinctrl_stat,*pinctrl_stat_hall;
 int enable_gpio,irq_gpio,power_good_gpio,hall_int_gpio;
 int irq,power_good_irq,hall_int_irq;
 struct mutex i2c_rw_lock,data_transfer_lock,wireless_chg_int_lock;
 struct delayed_work interrupt_work,pg_detect_work,init_detect_work,hall_interrupt_work;
 struct notifier_block shutdown_notifier;
};
typedef enum {PATH_CONTROL_USB=1,PATH_CONTROL_WLS=2,PATH_CONTROL_WLS_REV=4,PATH_CONTROL_OTG=8,PATH_CONTROL_VDD=16} CONTROL_SRC;
struct mca_path_control {
 struct {void *control_enable_func;} control_scheme[MAX_ROLE];
 int *gate_sts;struct device *dev;struct mutex enable_handling_lock;
 struct delayed_work update_condition_work;
};
static struct mca_path_control *g_info;
static int sc96281_regmap_config,sc96281_wls_ops;
static int inject_stage,inject_nth,stage_count,alloc_nth,alloc_count,action_nth,action_count;
static int active_irq,active_wake,active_gpio,active_notifier,active_mutex,active_work,wakeup_enabled;
static int support_hall=1,cases,handle_called,ops_registered,sysfs_count;
static struct {void (*fn)(void *);void *data;} resources[128];
static int resource_count;
static int fault(int stage) {return inject_stage==stage && ++stage_count==inject_nth;}
static void push(void (*fn)(void *),void *data){assert(resource_count<128);resources[resource_count].fn=fn;resources[resource_count++].data=data;}
static void unwind(void){while(resource_count){--resource_count;resources[resource_count].fn(resources[resource_count].data);}}
static void *devm_kzalloc(struct device *dev,size_t n,int flags){if (++alloc_count==alloc_nth)return NULL;void *p=calloc(1,n);assert(p);push(free,p);return p;}
static void *devm_kcalloc(struct device *dev,size_t n,size_t size,int flags){return devm_kzalloc(dev,n*size,flags);}
static int devm_add_action_or_reset(struct device *dev,void (*fn)(void *),void *data){if (++action_count==action_nth){fn(data);return -ENOMEM;}push(fn,data);return 0;}
static void mutex_init(struct mutex *m){assert(!m->initialized);m->initialized=1;++active_mutex;}
static void mutex_destroy(struct mutex *m){assert(m->initialized && !m->held && !active_work);m->initialized=0;--active_mutex;}
static void mutex_lock(struct mutex *m){assert(m && m->initialized && !m->held);m->held=1;}
static void mutex_unlock(struct mutex *m){assert(m->held);m->held=0;}
#define INIT_DELAYED_WORK(w,fn) do {(w)->initialized=1;(w)->pending=0;} while(0)
static void schedule_delayed_work(struct delayed_work *w,int delay){assert(w->initialized);if(!w->pending){w->pending=1;++active_work;}}
static void cancel_delayed_work_sync(struct delayed_work *w){assert(!active_irq);assert(w->initialized);if(w->pending){w->pending=0;--active_work;}}
static void platform_set_drvdata(struct platform_device *p,void *d){p->dev.data=d;}
static void i2c_set_clientdata(struct i2c_client *c,void *d){c->dev.data=d;}
static int device_init_wakeup(struct device *d,bool on){if(on && fault(1))return -EIO;wakeup_enabled=on;return 0;}
static void *devm_regmap_init_i2c(struct i2c_client *c,void *cfg){return fault(2)?ERR_PTR(-ENODEV):(void *)&sc96281_regmap_config;}
static int sc96281_parse_fw_fod_data(struct sc96281 *chip){return fault(3)?-EINVAL:0;}
static int mca_parse_dts_u32(struct device_node *n,const char *name,unsigned int *v,unsigned int dflt){*v=!strcmp(name,"support-hall")?support_hall:0;return 0;}
static void *devm_pinctrl_get(struct device *d){return fault(4)?ERR_PTR(-EPROBE_DEFER):(void *)1;}
static void *pinctrl_lookup_state(void *p,const char *s){return fault(5)?ERR_PTR(-EPROBE_DEFER):(void *)2;}
static int pinctrl_select_state(void *p,void *s){return fault(6)?-EIO:0;}
static int of_get_named_gpio(struct device_node *n,const char *name,int idx){if(fault(7))return -EPROBE_DEFER;if(!strcmp(name,"sleep-rx-gpio"))return 10;if(!strcmp(name,"rx-int"))return 11;if(!strcmp(name,"hall-int2"))return 13;return 12;}
static int gpio_is_valid(int gpio){return gpio>=0 && gpio<100;}
static void release_gpio(void *p){assert(active_gpio);--active_gpio;}
static int devm_gpio_request_one(struct device *d,int gpio,unsigned long flags,const char *name){if(fault(8))return -EBUSY;assert(gpio==10);assert(flags==GPIOF_OUT_INIT_LOW);++active_gpio;push(release_gpio,NULL);return 0;}
static int gpio_to_irq(int gpio){if(fault(9))return -EPROBE_DEFER;if(fault(10))return 0;return gpio+100;}
static void release_irq(void *p){assert(active_irq);--active_irq;}
static int devm_request_threaded_irq(struct device *d,int irq,irq_handler_t hard,irq_handler_t thread,unsigned long flags,const char *name,void *chip){if(fault(11))return -EBUSY;assert(irq>0);++active_irq;push(release_irq,NULL);assert(thread(irq,chip)==IRQ_HANDLED);return 0;}
static int enable_irq_wake(int irq){assert(active_irq);if(fault(12))return -EIO;++active_wake;return 0;}
static int disable_irq_wake(int irq){assert(active_wake);--active_wake;return 0;}
static int register_reboot_notifier(struct notifier_block *n){if(fault(13))return -EBUSY;++active_notifier;return 0;}
static int unregister_reboot_notifier(struct notifier_block *n){assert(active_notifier);--active_notifier;return 0;}
static int sc96281_shutdown_cb(struct notifier_block *n,unsigned long c,void *d){return 0;}
static int platform_class_wireless_register_ops(unsigned int role,void *data,void *ops){if(fault(14))return -EOPNOTSUPP;++ops_registered;return 0;}
static int mca_path_control_parse_dt(struct mca_path_control *i){return fault(15)?-EPROBE_DEFER:0;}
static int mca_path_control_sysfs_create_group(struct device *d){++sysfs_count;return fault(16)?-ENOMEM:0;}
static int mca_path_control_usb_in(struct mca_path_control *i,bool on,int *v){*v=1;return 0;}
static int mca_path_control_wireless_in(struct mca_path_control *i,bool on,int *v){*v=2;return 0;}
static int mca_path_control_wireless_rev(struct mca_path_control *i,bool on,int *v){*v=4;return 0;}
static int mca_path_control_otg_in(struct mca_path_control *i,bool on,int *v){*v=8;return 0;}
static int mca_path_control_wireless_vdd(struct mca_path_control *i,bool on,int *v){*v=16;return 0;}
static int mca_path_control_handle_func(struct mca_path_control *i,int v){assert(v==1||v==2||v==4||v==8||v==16);++handle_called;return 0;}
