#include "kernel_test.h"
#include "drivers/power/supply/mca/mca_common/mca_qcom_smem.c"
#include "drivers/power/supply/mca/mca_common/mca_charge_mievent.c"
static unsigned checks;
#define CHECK(x) do { checks++;assert(x); } while(0)
static void smem_tests(void) {
 struct mca_smem_battery_info b={0};
 CHECK(sizeof(b)==36);CHECK(offsetof(struct mca_smem_battery_info,zero_speed_start_mode)==32);
 CHECK(mca_qcom_smem_is_zero_speed()==-ENODEV);
 alloc_result=-ENOMEM;CHECK(mca_qcom_smem_init()==-EPROBE_DEFER);CHECK(smem_get_calls==0);CHECK(allocated_size==36);
 alloc_result=-EEXIST;smem_pointer=ERR_PTR(-EPROBE_DEFER);CHECK(mca_qcom_smem_init()==-EPROBE_DEFER);
 smem_pointer=NULL;CHECK(mca_qcom_smem_init()==-EPROBE_DEFER);
 smem_pointer=&b;smem_size=35;CHECK(mca_qcom_smem_init()==-EINVAL);
 smem_size=36;CHECK(mca_qcom_smem_init()==0);CHECK(mca_qcom_smem_is_zero_speed()==0);
 b.zero_speed_start_mode=1;CHECK(mca_qcom_smem_is_zero_speed()==1);
 b.zero_speed_start_mode=0x1020304;CHECK(mca_qcom_smem_is_zero_speed()==0x1020304);
 mca_qcom_smem_exit();CHECK(mca_qcom_smem_is_zero_speed()==-ENODEV);CHECK(b.zero_speed_start_mode==0x1020304);
 alloc_result=0;CHECK(mca_qcom_smem_init()==0);mca_qcom_smem_exit();
}
static const struct charge_mievent_info expected[] = {
 { 909001004, "chgErrInfo", "PdAuthFail", 0, 0, 0, 1, { "adapterId" } },
 { 909001005, "chgErrInfo", "CpEnFail", 0, 1, 0, 1, { "cpId" } },
 { 909002001, "chgErrInfo", "NoneStandartChg", 0, 2, 2, 0, {  } },
 { 909002002, "chgErrInfo", "CorrosionDischarge", 0, 3, 2, 0, {  } },
 { 909002003, "chgErrInfo", "LpdDetected", 0, 4, 0, 1, { "lpdFlag" } },
 { 909002004, "chgErrInfo", "CpVbusOvp", 0, 5, 2, 0, {  } },
 { 909002005, "chgErrInfo", "CpIbusOcp", 0, 6, 2, 0, {  } },
 { 909002006, "chgErrInfo", "CpVbatOvp", 0, 7, 0, 2, { "vbat", "vbatMax" } },
 { 909002007, "chgErrInfo", "CpIbatOcp", 0, 8, 2, 0, {  } },
 { 909002008, "chgErrInfo", "CpVacOvp", 0, 9, 2, 0, {  } },
 { 909002012, "chgStatInfo", "AntiBurnTirg", 0, 10, 0, 1, { "tconn" } },
 { 909002013, "chgErrInfo", "ChgBroken", 0, 11, 2, 0, {  } },
 { 909003002, "chgErrInfo", "SocNotFull", 0, 12, 0, 3, { "vbat", "soc", "rsoc" } },
 { 909003004, "chgStatInfo", "SmartEnduraTrig", 0, 13, 0, 1, { "soc" } },
 { 909003006, "chgStatInfo", "SmartNaviTrig", 0, 14, 0, 1, { "soc" } },
 { 909003007, "chgStatInfo", "IspLevelOne", 0, 15, 0, 1, { "ispLevel" } },
 { 909003008, "chgStatInfo", "IspLevelTwo", 0, 16, 0, 1, { "ispLevel" } },
 { 909003009, "chgErrInfo", "IspLevelThree", 0, 17, 0, 1, { "ispLevel" } },
 { 909003010, "chgErrInfo", "csdFlag", 0, 18, 0, 1, { "csdFlag" } },
 { 909003011, "chgStatInfo", "VbatOvSecureCurr", 0, 19, 2, 1, { "cycleCount" } },
 { 909004001, "chgErrInfo", "socJump", 0, 20, 0, 10, { "preUIsoc", "preRsoc", "uisoc", "rsoc", "temp", "vbat", "online", "current", "fcc", "qmax" } },
 { 909004002, "chgStatInfo", "vbatMeanShutdown", 0, 21, 0, 3, { "vbat_mean", "current", "temp" } },
 { 909005003, "chgErrInfo", "BattLinkerAbsent", 0, 22, 2, 0, {  } },
 { 909005004, "chgStatInfo", "CpTdieHot", 0, 23, 0, 2, { "masterTdie", "slaveTdie" } },
 { 909005005, "chgErrInfo", "VbusUvlo", 0, 24, 0, 3, { "vbat", "vbus", "aicl" } },
 { 909005007, "chgErrInfo", "NotChgInLowTemp", 0, 25, 0, 1, { "tbat" } },
 { 909005008, "chgErrInfo", "NotChgInHighTemp", 0, 26, 0, 1, { "tbat" } },
 { 909005009, "chgErrInfo", "DualBattLinkerAbsent", 0, 27, 0, 1, { "status" } },
 { 909006010, "chgErrInfo", "SmartEnduraSocErr", 0, 28, 0, 1, { "soc" } },
 { 909006011, "chgErrInfo", "SmartNaviSocErr", 0, 29, 0, 1, { "soc" } },
 { 909007001, "chgErrInfo", "BattAuthFail", 0, 30, 2, 0, {  } },
 { 909007002, "chgErrInfo", "ChgBattAuthFail", 0, 31, 0, 1, { "status" } },
 { 909009003, "chgErrInfo", "AntiFail", 0, 32, 2, 0, {  } },
 { 909010001, "chgStatInfo", "SoftCidTrigger", 0, 33, 2, 0, {  } },
 { 909011001, "chgErrInfo", "WlsFastChgFail", 0, 34, 2, 0, {  } },
 { 909011002, "chgErrInfo", "WlsQLow", 0, 35, 0, 2, { "chgQbase", "chgQreal" } },
 { 909012001, "chgErrInfo", "WlsRxOTP", 0, 36, 0, 1, { "chgRxtemp" } },
 { 909012002, "chgErrInfo", "WlsRxOVP", 0, 37, 2, 0, {  } },
 { 909012003, "chgErrInfo", "WlsRxOCP", 0, 38, 2, 0, {  } },
 { 909012004, "chgErrInfo", "WlsTrxFod", 0, 39, 2, 0, {  } },
 { 909012005, "chgErrInfo", "WlsTrxOCP", 0, 40, 2, 0, {  } },
 { 909012006, "chgErrInfo", "WlsTrxUVLO", 0, 41, 2, 0, {  } },
 { 909013001, "chgErrInfo", "WlsTrxI2cErr", 0, 42, 2, 0, {  } },
 { 909013004, "chgErrInfo", "WlsRxI2cErr", 0, 43, 2, 0, {  } },
 { 909007003, "chgErrInfo", "LoadSwitchI2cErr", 0, 44, 2, 0, {  } },
 { 909013002, "chgErrInfo", "WlsFwUpgradeErr", 0, 45, 1, 1, { "errReason" } },
 { 909001006, "chgStatInfo", "ChargeSlowly", 0, 46, 0, 5, { "maxPower", "initialRm", "endRm", "initialSoc", "endSoc" } },
 { 909001007, "chgStatInfo", "NonStandardCharger", 0, 47, 0, 1, { "chgType" } },
 { 909014003, "chgErrInfo", "BatteryOcd", 0, 48, 0, 13, { "ocdCount", "ocdLastCycle", "hocdCount", "hocdLastCycle", "uiSoc", "voltage", "temp", "LastOcdVoltage", "LastOcdCurrent", "LastOcdTemp", "LastHocdVoltage", "LastHocdCurrent", "LastHocdTemp" } },
 { 909014004, "chgErrInfo", "BatteryCuv", 0, 49, 0, 13, { "cuvCount", "cuvLastCycle", "hcuvCount", "hcuvLastCycle", "uiSoc", "voltage", "temp", "LastCuvVoltage", "LastCuvCurrent", "LastCuvTemp", "LastHcuvVoltage", "LastHcuvCurrent", "LastHcuvTemp" } },
 { 909014005, "chgErrInfo", "BatteryScd", 0, 50, 0, 5, { "hscdCount", "hscdLastCycle", "LastHscdVoltage", "LastHscdCurrent", "LastHscdTemp" } },
 { 909014006, "chgErrInfo", "BatteryCov", 0, 51, 0, 8, { "covCount", "covLastCycle", "hcovCount", "hcovLastCycle", "uiSoc", "voltage", "current", "temp" } },
 { 909014007, "chgErrInfo", "BatteryOcc", 0, 52, 0, 8, { "occCount", "occLastCycle", "hoccCount", "hoccLastCycle", "uiSoc", "voltage", "current", "temp" } },
 { 909003001, "chgStatInfo", "chgBattCycle", 1, 0, 0, 1, { "cycleCnt" } },
 { 909005001, "chgErrInfo", "FgI2cErr", 1, 1, 0, 1, { "soc" } },
 { 909005002, "chgErrInfo", "CpI2cErr", 1, 2, 0, 2, { "masterOk", "slaveOk" } },
 { 909006001, "chgErrInfo", "VbatSocNotMatch", 1, 3, 0, 3, { "vbat", "soc", "cycleCnt" } },
 { 909009001, "chgStatInfo", "TbatHot", 1, 4, 0, 4, { "tbat", "tbatMax", "isCharging", "tboard" } },
 { 909009002, "chgStatInfo", "TbatCold", 1, 5, 0, 4, { "tbat", "tbatMin", "isCharging", "tboard" } },
 { 909014002, "chgErrInfo", "DualVbatDiff", 1, 6, 0, 2, { "chgBaseBattVol", "chgFlipBattVol" } },
 { 909011003, "chgStatInfo", "WlsMagCaseAttach", 1, 7, 2, 0, {  } },
};

static void mievent_tests(void) {
 int values[16];char *strings[16];char text[]="firmware failure";
 for(int i=0;i<16;i++){values[i]=i*17-60;strings[i]=text;}
 CHECK(sizeof(struct charge_mievent_info)==560);
 CHECK(sizeof(expected)==sizeof(g_charge_mievent_info));
 CHECK(!memcmp(expected,g_charge_mievent_info,sizeof(expected)));
 CHECK(CHARGE_DFX_MAX_NUM==61);CHECK(PLUG_TYPE_MAX_NUM==53);CHECK(TIME_TYPE_MAX_NUM==8);
 CHECK(CHARGE_DFX_SOC_NOT_FULL==12);CHECK(CHARGE_DFX_WLS_FW_UPGRADE_FAIL==45);
 CHECK(CHARGE_DFX_BATTERY_OCD==48);CHECK(CHARGE_DFX_BATTERY_CYCLECOUNT==53);
 for(int i=0;i<61;i++) {
  const struct charge_mievent_info *r=&expected[i];
  void *data=r->data_type==MIEVENT_DATA_TYPE_STRING ? (void *)strings : (void *)values;
  mca_charge_mievent_set_state(MIEVENT_STATE_END,i);int before=write_count;
  mca_charge_mievent_report(i,data,r->data_count);
  CHECK(write_count==before+1);CHECK(last_event.id==(unsigned)r->event_code);
  CHECK(!strcmp(last_event.field[0].key,r->event_type));CHECK(!strcmp(last_event.field[0].text,r->event_describe));
  int n=r->data_type==MIEVENT_DATA_TYPE_NULL?0:r->data_count;
  CHECK(last_event.fields==n+1);
  for(int k=0;k<n;k++) {
   CHECK(!strcmp(last_event.field[k+1].key,r->para_name[k]));
   if(r->data_type==MIEVENT_DATA_TYPE_INT)CHECK(last_event.field[k+1].number==values[k]);
   else CHECK(!strcmp(last_event.field[k+1].text,text));
  }
 }
 int before=write_count;
 mca_charge_mievent_report(-1,values,1);mca_charge_mievent_report(61,values,1);
 mca_charge_mievent_report(0,values,-1);mca_charge_mievent_report(0,values,2);mca_charge_mievent_report(0,NULL,1);
 strings[0]=NULL;mca_charge_mievent_report(45,strings,1);
 char longbuf[129];memset(longbuf,'x',128);longbuf[128]=0;strings[0]=longbuf;mca_charge_mievent_report(45,strings,1);
 CHECK(write_count==before);strings[0]=text;
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);mca_charge_mievent_report(0,values,1);
 CHECK(write_count==before+1);mca_charge_mievent_report(0,values,1);CHECK(write_count==before+1);
 mca_charge_mievent_set_state(MIEVENT_STATE_PLUG,1);mca_charge_mievent_report(0,values,1);CHECK(write_count==before+1);
 mca_charge_mievent_set_state(MIEVENT_STATE_PLUG,0);mca_charge_mievent_report(0,values,1);CHECK(write_count==before+2);
 // The stock 3-report CP limit and 5-report slow-charge limit.
 mca_charge_mievent_set_state(MIEVENT_STATE_END,1);before=write_count;
 for(int i=0;i<10;i++)mca_charge_mievent_report(1,values,1);CHECK(write_count==before+3);
 mca_charge_mievent_set_state(MIEVENT_STATE_END,46);before=write_count;
 for(int i=0;i<10;i++)mca_charge_mievent_report(46,values,5);CHECK(write_count==before+5);
 // Timer index 7 must be one week, not Onyx's uninitialized zero interval.
 mca_charge_mievent_set_state(MIEVENT_STATE_END,60);test_now=1;before=write_count;
 mca_charge_mievent_report(60,NULL,0);mca_charge_mievent_report(60,NULL,0);CHECK(write_count==before+1);
 test_now=604800;mca_charge_mievent_report(60,NULL,0);CHECK(write_count==before+1);
 test_now=604801;mca_charge_mievent_report(60,NULL,0);CHECK(write_count==before+2);
 // Allocation/append failures release every successfully allocated object.
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);before=destroy_count;event_alloc_fail=1;
 mca_charge_mievent_report(0,values,1);CHECK(destroy_count==before);event_alloc_fail=0;
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);before=write_count;int d=destroy_count;add_fail_at=1;
 mca_charge_mievent_report(0,values,1);CHECK(write_count==before);CHECK(destroy_count==d+1);add_fail_at=0;
 mca_charge_mievent_set_state(MIEVENT_STATE_END,0);d=destroy_count;add_fail_at=2;
 mca_charge_mievent_report(0,values,1);CHECK(write_count==before);CHECK(destroy_count==d+1);add_fail_at=0;
}
static void *race_report(void *p) { int v=1;(void)p;for(int i=0;i<10000;i++)mca_charge_mievent_report(1,&v,1);return NULL; }
static void race_test(void) {
 pthread_t threads[8];mca_charge_mievent_set_state(MIEVENT_STATE_END,1);int before=write_count;
 for(int i=0;i<8;i++)CHECK(!pthread_create(&threads[i],NULL,race_report,NULL));
 for(int i=0;i<8;i++)CHECK(!pthread_join(threads[i],NULL));
 CHECK(write_count==before+3);CHECK(g_upload_type_plug_info[1].count==3);
}
int main(int argc,char **argv) {
 if(argc==2 && !strcmp(argv[1],"--table")) { fwrite(g_charge_mievent_info,sizeof(g_charge_mievent_info),1,stdout);return 0; }
 smem_tests();mievent_tests();race_test();printf("helpers: %u checks passed; 61 stock records, 80000 concurrent requests\n",checks);return 0;
}
