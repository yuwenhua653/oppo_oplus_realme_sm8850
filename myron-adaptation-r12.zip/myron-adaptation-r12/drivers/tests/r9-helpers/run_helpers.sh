#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
payload=${1:?payload directory required}
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
cc -std=gnu11 -Wall -Wextra -Werror -Wno-unused-function -Wno-unused-variable -Wno-sign-compare -Wno-misleading-indentation -pthread -fsanitize=undefined -fno-sanitize-recover=all -I"$here/stubs" -I"$payload" -I"$payload/drivers/power/supply/mca/include" "$here/test_helpers.c" -o "$tmp/test_helpers"
"$tmp/test_helpers"
