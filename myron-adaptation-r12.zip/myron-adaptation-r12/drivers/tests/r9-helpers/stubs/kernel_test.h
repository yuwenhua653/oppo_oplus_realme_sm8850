#ifndef HELPERS_KERNEL_TEST_H
#define HELPERS_KERNEL_TEST_H
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
typedef uint32_t u32;typedef unsigned char u8;typedef int64_t time64_t;
#define __init
#define __exit
#define EXPORT_SYMBOL(x)
#define EXPORT_SYMBOL_GPL(x)
#define MODULE_DESCRIPTION(x)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#define module_init(x)
#define module_exit(x)
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define DEFINE_MUTEX(x) pthread_mutex_t x=PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) pthread_mutex_lock(x)
#define mutex_unlock(x) pthread_mutex_unlock(x)
#define READ_ONCE(x) __atomic_load_n(&(x),__ATOMIC_ACQUIRE)
#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v),__ATOMIC_RELEASE)
#define IS_ERR_OR_NULL(x) (!(x) || (uintptr_t)(x)>(uintptr_t)-4096)
#define ERR_PTR(x) ((void *)(intptr_t)(x))
#define EPROBE_DEFER 517
#define mca_log_err(...) do {} while(0)
#define mca_log_info(...) do {} while(0)
#define mca_log_jirabot(...) do {} while(0)
#define QCOM_SMEM_HOST_ANY 0xffffffff
static int alloc_result,smem_alloc_calls,smem_get_calls;
static size_t smem_size,allocated_size;
static void *smem_pointer;
static int qcom_smem_alloc(unsigned h,unsigned id,size_t n) {
 assert(h==QCOM_SMEM_HOST_ANY && id==0x51);smem_alloc_calls++;allocated_size=n;return alloc_result;
}
static void *qcom_smem_get(unsigned h,unsigned id,size_t *n) {
 assert(h==QCOM_SMEM_HOST_ANY && id==0x51 && n);smem_get_calls++;*n=smem_size;return smem_pointer;
}
static time64_t test_now;
static time64_t ktime_get_boottime_seconds(void) { return test_now; }
struct mca_event_notify_data { const char *event;int event_len; };
static atomic_int uevent_count,alloc_count,destroy_count,write_count;
static int event_alloc_fail,add_fail_at;
static void mca_event_report_uevent(const struct mca_event_notify_data *n) {
 assert(!strcmp(n->event,"MCA_LOG_FULL_EVENT") && n->event_len==18);uevent_count++;
}
struct test_field { char key[64];char text[160];long number;int type; };
struct misight_mievent { unsigned id;int fields;struct test_field field[17]; };
static struct misight_mievent last_event;
static pthread_mutex_t capture_lock=PTHREAD_MUTEX_INITIALIZER;
static struct misight_mievent *cdev_tevent_alloc(unsigned id) {
 alloc_count++;if(event_alloc_fail)return NULL;
 struct misight_mievent *e=calloc(1,sizeof(*e));assert(e);e->id=id;return e;
}
static int cdev_tevent_add_str(struct misight_mievent *e,const char *key,const char *val) {
 assert(e && key && val && e->fields<17);
 if(add_fail_at && e->fields+1==add_fail_at)return -ENOMEM;
 struct test_field *f=&e->field[e->fields++];snprintf(f->key,sizeof(f->key),"%s",key);snprintf(f->text,sizeof(f->text),"%s",val);f->type=1;return 0;
}
static int cdev_tevent_add_int(struct misight_mievent *e,const char *key,long val) {
 assert(e && key && e->fields<17);
 if(add_fail_at && e->fields+1==add_fail_at)return -ENOMEM;
 struct test_field *f=&e->field[e->fields++];snprintf(f->key,sizeof(f->key),"%s",key);f->number=val;f->type=0;return 0;
}
static int cdev_tevent_write(struct misight_mievent *e) {
 pthread_mutex_lock(&capture_lock);last_event=*e;write_count++;pthread_mutex_unlock(&capture_lock);return 0;
}
static void cdev_tevent_destroy(struct misight_mievent *e) { destroy_count++;free(e); }
#endif
