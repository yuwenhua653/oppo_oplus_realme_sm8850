#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
binary=$(mktemp)
trap 'rm -f "$binary"' EXIT HUP INT TERM
gcc -std=gnu11 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer \
    -I "$here/include" -I "$here/../upstream/include" "$here/test_mievent.c" -o "$binary"
# LSan is disabled for constrained /proc environments; the test counts live allocations.
ASAN_OPTIONS=detect_leaks=0 "$binary"
