#!/usr/bin/env python3
"""Compile and execute the real selected SC8581 parser and setter bodies."""
from pathlib import Path
import argparse,re,subprocess,tempfile,json,hashlib
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'candidate'
REL=Path('drivers/payload/drivers/power/supply/mca/mca_hardware_ic/charge_pump_ic/sc8581')
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,default=DEFAULT);p.add_argument('--output',type=Path,default=ROOT/'pmid2-host-tests.json');args=p.parse_args()
s=(args.bundle/REL/'sc8581.c').read_text();h=(args.bundle/REL/'inc/sc8581.h').read_text()
reg=(args.bundle/REL/'inc/sc8581_reg.h').read_text()

def function(name):
 m=re.search(r'^static int '+name+r'\([^;]*?\)\n\{',s,re.M);assert m,name
 end=m.end();depth=1
 while depth:
  if s[end]=='{':depth+=1
  elif s[end]=='}':depth-=1
  end+=1
 return s[m.start():end]

names=('sc8581_parse_pmid2out_uvp','sc8581_set_pmid2outuvp_th','ops_cp_set_pmid2outuvp_th')
funcs='\n\n'.join(function(n) for n in names)
enum=re.search(r'enum sc8581_pmid2out_uvp_index \{.*?\};',h,re.S).group()
assert 'unsigned int pmid2out_uvp_th[SC8581_PMID2OUT_UVP_COUNT];' in h
assert 'sc8581_set_pmid2outuvp_th(cp, cp->operation_mode)' in s
assert 'ret = sc8581_parse_pmid2out_uvp(bq, np);\n\tif (ret)\n\t\treturn ret;' in s
assert 'sc8581_set_pmid2outuvp_th(bq, operation_mode)' in s
macros='\n'.join(line for line in reg.splitlines() if re.match(r'#define SC8581_(?:PMID2OUT_UVP_(?:BASE|LSB|MASK|SHIFT)|REVERSE_1_[24]_CONVERTER_MODE|REG_09) ',line))
pre=r'''
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
typedef uint8_t u8;
#define mca_log_err(...) ((void)0)
'''+enum+'\n'+macros+r'''
struct device_node { int count, read_error; unsigned int data[8]; };
struct sc8581_cfg { unsigned int pmid2out_uvp_th[SC8581_PMID2OUT_UVP_COUNT]; };
struct sc8581_device { void *client; struct sc8581_cfg cfg; };
static int updates, update_error, reg_seen, mask_seen, value_seen, reads;
static int of_property_count_u32_elems(struct device_node *np, const char *name) {
 assert(strcmp(name,"pmid2-uvp-threshold")==0); return np->count;
}
static int mca_parse_dts_u32_array(struct device_node *np,const char *name,unsigned int *data,unsigned int count) {
 reads++;assert(strcmp(name,"pmid2-uvp-threshold")==0);assert(count==3);
 if(np->read_error)return np->read_error;
 memcpy(data,np->data,count*sizeof(*data));return 0;
}
static int cp_update_bits(void *client,int reg,int mask,int value) {
 assert(client==(void*)0x1234);updates++;reg_seen=reg;mask_seen=mask;value_seen=value;
 return update_error;
}
'''
main=r'''
int main(void) {
 struct sc8581_device b={.client=(void*)0x1234};
 struct device_node n={.count=3,.data={350,350,100}};
 int mode,i,count,checks=0;
 assert(sc8581_parse_pmid2out_uvp(&b,&n)==0);checks++;
 assert(b.cfg.pmid2out_uvp_th[0]==350&&b.cfg.pmid2out_uvp_th[1]==350&&b.cfg.pmid2out_uvp_th[2]==100);checks++;
 for(mode=-1;mode<=8;mode++) {
  updates=0;assert(ops_cp_set_pmid2outuvp_th(mode,&b)==0);
  assert(updates==1&&reg_seen==9&&mask_seen==7);
  assert(value_seen==((mode==4||mode==5)?6:1));checks++;
 }
 /* Distinct cells expose swapped indices even when Myron cells 0 and 1 equal. */
 n.data[0]=350;n.data[1]=250;n.data[2]=100;assert(sc8581_parse_pmid2out_uvp(&b,&n)==0);
 for(mode=0;mode<8;mode++) {
  assert(ops_cp_set_pmid2outuvp_th(mode,&b)==0);
  assert(value_seen==(mode==4?6:mode==5?4:1));checks++;
 }
 for(count=-2;count<=5;count++)if(count!=3) {
  n.count=count;reads=0;updates=0;assert(sc8581_parse_pmid2out_uvp(&b,&n)==(count<0?count:-EINVAL));assert(!reads&&!updates);checks++;
 }
 n.count=3;n.read_error=-EIO;reads=0;assert(sc8581_parse_pmid2out_uvp(&b,&n)==-EIO);assert(reads==1);checks++;
 n.read_error=0;
 for(i=0;i<3;i++) {
  unsigned int invalid[]={0,49,51,399,401,450,UINT32_MAX};
  for(unsigned int j=0;j<sizeof(invalid)/sizeof(invalid[0]);j++) {
   n.data[0]=n.data[1]=n.data[2]=100;n.data[i]=invalid[j];updates=0;
   assert(sc8581_parse_pmid2out_uvp(&b,&n)==-EINVAL);assert(!updates);checks++;
  }
 }
 for(i=50;i<=400;i+=50) {
  n.data[0]=n.data[1]=n.data[2]=(unsigned int)i;assert(sc8581_parse_pmid2out_uvp(&b,&n)==0);
  assert(ops_cp_set_pmid2outuvp_th(0,&b)==0);assert(value_seen==(i-50)/50);checks++;
 }
 update_error=-EIO;assert(ops_cp_set_pmid2outuvp_th(4,&b)==-EIO);checks++;
 printf("%d scenarios passed\n",checks);return 0;
}
'''
with tempfile.TemporaryDirectory(prefix='myron-pmid2-') as td:
 src=Path(td)/'test.c';exe=Path(td)/'test';src.write_text(pre+'\n'+funcs+'\n'+main)
 subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-O2','-fsanitize=undefined',str(src),'-o',str(exe)],check=True)
 r=subprocess.run([str(exe)],capture_output=True,text=True,check=True)
report={'passed':True,'test_kind':'compile and execute extracted real C functions with host OF/I2C mocks, UBSan','functions':list(names),'result':r.stdout.strip(),'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'header_sha256':hashlib.sha256(h.encode()).hexdigest(),'coverage':['captured DT three values preserved','distinct values expose index permutations','stock operation-mode selection 4,5,other incl 3/7 and unknown','exact property cardinality','negative OF count and read errors','register representability 50..400 by 50 per source macros','I2C error propagation','init protection passes operation_mode','parse failure propagated before init GPIO/I2C']}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
