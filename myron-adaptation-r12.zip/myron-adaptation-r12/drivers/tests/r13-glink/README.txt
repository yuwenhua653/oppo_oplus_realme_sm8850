R13 MCA ADSP GLINK request/receive host regression tests

Run from any directory:
  python3 test_glink.py --payload /path/to/drivers/payload --report /path/to/report.json

Without --payload, the test uses ../../payload relative to this script.
Optional --output DIR also saves the generated C translation unit and logs.
Host GCC or Clang with AddressSanitizer and UndefinedBehaviorSanitizer is required.

The test extracts the actual wire structures, private device state and all
request/receive functions from mca_adsp_glink.c. It also uses the actual public
header. The source is not rewritten for the positive test. Host-only primitive
substitutes implement locks, completions, linked lists and transport delivery.

Coverage: every short fixed response and notification size, oversized frames,
null/unaligned buffers, owner/type/opcode/property/sequence mismatches, error
responses, duplicate and stale replies, normal notifications for both owners,
all four read/write APIs, failed transport/timeout/down-state cleanup, and a
concurrent response versus cancellation exercise. ASan and UBSan stay enabled;
LeakSanitizer is disabled because the execution sandbox can prohibit /proc
thread inspection.

This is not a kernel build, a firmware interoperability test, lockdep/KCSAN,
or evidence that QBG transport subscription or hboost events are implemented.
Notifications keep the original opcode behavior because the source defines
no notification opcode contract. Request/response opcode matching is strict.
