static unsigned cases;
static unsigned notifications[2];
static int transport_mode, sends;
static struct mca_adsp_glink_dev test_mca;
static struct mca_adsp_glink_req_msg sent_request;

static void notification(u32 prop, void *value, u32 size, void *priv)
{
	assert(prop == 77);
	assert(size == MCA_ADSP_PROP_DATA_LEN);
	assert(((u8 *)value)[0] == 0x63);
	assert(((u8 *)value)[255] == 0x64);
	notifications[(size_t)priv]++;
}

static void arm(u32 owner, u32 opcode, u32 property, u32 seq)
{
	struct mca_adsp_glink_req_msg request = {
		.hdr = {owner, MCA_ADSP_GLINK_MSG_REQ, opcode},
		.property_id = property, .seq = seq,
	};
	test_mca.seq = seq;
	memset(test_mca.read_buf, 0xaa, sizeof(test_mca.read_buf));
	mca_adsp_glink_begin_request(&test_mca, &request);
}

static struct mca_adsp_glink_resp_msg response(u32 owner, u32 opcode, u32 property, u32 seq)
{
	struct mca_adsp_glink_resp_msg result = {
		.hdr = {owner, MCA_ADSP_GLINK_MSG_REQ, opcode},
		.property_id = property, .seq = seq,
	};
	memset(result.data, 0x5b, sizeof(result.data));
	return result;
}

static void expect_ignored(void *packet, size_t len)
{
	unsigned notify_before = notifications[0] + notifications[1];
	assert(mca_adsp_glink_callback(&test_mca, packet, len) == 0);
	assert(test_mca.pending);
	assert(atomic_load(&test_mca.ack.done) == 0);
	assert(test_mca.retcode == 0);
	assert(test_mca.read_buf[0] == 0xaa && test_mca.read_buf[255] == 0xaa);
	assert(notifications[0] + notifications[1] == notify_before);
	cases++;
}

static void test_lengths(void)
{
	struct mca_adsp_glink_resp_msg reply = response(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
	struct mca_adsp_glink_notify_msg note = {
		.hdr = {MCA_ADSP_GLINK_OWNER, MCA_ADSP_GLINK_MSG_NOTIFY, 93}, .property_id = 77,
	};
	_Static_assert(sizeof(reply) == 280, "response wire size changed");
	_Static_assert(sizeof(note) == 272, "notification wire size changed");
	_Static_assert(sizeof(struct mca_adsp_glink_req_msg) == 276, "request wire size changed");
	for (size_t len = 0; len < sizeof(reply) + 20; len++) {
		if (len == sizeof(reply)) continue;
		void *packet = malloc(len ? len : 1);
		memset(packet, 0, len);
		memcpy(packet, &reply, len < sizeof(reply) ? len : sizeof(reply));
		arm(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
		expect_ignored(packet, len);
		free(packet);
	}
	for (size_t len = 0; len < sizeof(note) + 20; len++) {
		if (len == sizeof(note)) continue;
		void *packet = malloc(len ? len : 1);
		memset(packet, 0, len);
		memcpy(packet, &note, len < sizeof(note) ? len : sizeof(note));
		arm(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
		expect_ignored(packet, len);
		free(packet);
	}
	arm(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
	expect_ignored(NULL, sizeof(reply));
	assert(mca_adsp_glink_callback(NULL, &reply, sizeof(reply)) == 0);
	cases++;
	/* The response handler also rejects truncated frames before field reads. */
	for (size_t len = 0; len < sizeof(reply); len++) {
		void *packet = malloc(len ? len : 1);
		memcpy(packet, &reply, len);
		assert(mca_adsp_glink_handle_message(&test_mca, packet, len) == 0);
		assert(test_mca.pending && !atomic_load(&test_mca.ack.done));
		free(packet);
		cases++;
	}
}

static void test_match_fields(void)
{
	for (unsigned error = 0; error < 2; error++) {
		for (unsigned field = 0; field < 9; field++) {
			struct mca_adsp_glink_resp_msg reply = response(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
			reply.retcode = error ? 17 : 0;
			switch (field) {
			case 0: reply.seq--; break;
			case 1: reply.seq++; break;
			case 2: reply.property_id++; break;
			case 3: reply.hdr.owner = MCA_ADSP_GLINK_QBG_OWNER; break;
			case 4: reply.hdr.owner = 0xdead; break;
			case 5: reply.hdr.opcode = MCA_ADSP_GLINK_OPCODE_WRITE; break;
			case 6: reply.hdr.opcode = 0x123; break;
			case 7: reply.hdr.type = 0x456; break;
			case 8: reply.hdr.type = MCA_ADSP_GLINK_MSG_NOTIFY; break;
			}
			arm(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
			expect_ignored(&reply, sizeof(reply));
		}
	}
	for (unsigned owner = 0; owner < 2; owner++) {
		for (u32 opcode = 1; opcode <= 2; opcode++) {
			for (unsigned error = 0; error < 3; error++) {
				u32 expected_owner = owner ? MCA_ADSP_GLINK_QBG_OWNER : MCA_ADSP_GLINK_OWNER;
				struct mca_adsp_glink_resp_msg reply = response(expected_owner, opcode, 41, 7);
				reply.retcode = error == 1 ? 17 : (error == 2 ? UINT32_MAX : 0);
				arm(expected_owner, opcode, 41, 7);
				assert(mca_adsp_glink_callback(&test_mca, &reply, sizeof(reply)) == 0);
				assert(!test_mca.pending && atomic_load(&test_mca.ack.done) == 1);
				assert(test_mca.retcode == (int)reply.retcode);
				assert(test_mca.read_buf[0] == (!error && opcode == 1 ? 0x5b : 0xaa));
				/* A duplicate must neither complete again nor replace the result. */
				reply.retcode = 99;
				assert(mca_adsp_glink_callback(&test_mca, &reply, sizeof(reply)) == 0);
				assert(atomic_load(&test_mca.ack.done) == 1 && test_mca.retcode != 99);
				cases += 2;
			}
		}
	}
	arm(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
	mca_adsp_glink_end_request(&test_mca);
	struct mca_adsp_glink_resp_msg late = response(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
	assert(mca_adsp_glink_callback(&test_mca, &late, sizeof(late)) == 0);
	assert(!test_mca.pending && !atomic_load(&test_mca.ack.done));
	arm(MCA_ADSP_GLINK_OWNER, 1, 41, 8);
	expect_ignored(&late, sizeof(late));
	cases++;
}

static void test_notifications(void)
{
	struct mca_adsp_glink_notify_msg note = {
		.hdr = {MCA_ADSP_GLINK_OWNER, MCA_ADSP_GLINK_MSG_NOTIFY, 93}, .property_id = 77,
	};
	note.data[0] = 0x63; note.data[255] = 0x64;
	for (unsigned owner = 0; owner < 2; owner++) {
		note.hdr.owner = owner ? MCA_ADSP_GLINK_QBG_OWNER : MCA_ADSP_GLINK_OWNER;
		arm(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
		unsigned before = notifications[owner];
		assert(mca_adsp_glink_callback(&test_mca, &note, sizeof(note)) == 0);
		assert(notifications[owner] == before + 1);
		assert(test_mca.pending && !atomic_load(&test_mca.ack.done));
		cases++;
	}
	note.hdr.owner = 0xdead;
	expect_ignored(&note, sizeof(note));
}

static void test_unaligned_frames(void)
{
	struct mca_adsp_glink_resp_msg reply = response(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
	struct mca_adsp_glink_notify_msg note = {
		.hdr = {MCA_ADSP_GLINK_OWNER, MCA_ADSP_GLINK_MSG_NOTIFY, 93}, .property_id = 77,
	};
	u8 *packet = malloc(sizeof(reply) + 1);
	assert(packet);
	arm(MCA_ADSP_GLINK_OWNER, 1, 41, 7);
	memcpy(packet + 1, &reply, sizeof(reply));
	assert(mca_adsp_glink_callback(&test_mca, packet + 1, sizeof(reply)) == 0);
	assert(!test_mca.pending && atomic_load(&test_mca.ack.done) == 1);
	note.data[0] = 0x63; note.data[255] = 0x64;
	unsigned before = notifications[0];
	memcpy(packet + 1, &note, sizeof(note));
	assert(mca_adsp_glink_callback(&test_mca, packet + 1, sizeof(note)) == 0);
	assert(notifications[0] == before + 1);
	free(packet);
	cases += 2;
}

static int pmic_glink_write(struct pmic_glink_client *client, void *data, size_t len)
{
	(void)client;
	assert(len == sizeof(sent_request));
	memcpy(&sent_request, data, len);
	sends++;
	assert(test_mca.pending);
	if (transport_mode == 1) return -EIO;
	if (transport_mode == 2) return 0;
	struct mca_adsp_glink_resp_msg reply = response(sent_request.hdr.owner,
		sent_request.hdr.opcode, sent_request.property_id, sent_request.seq);
	reply.retcode = transport_mode == 3 ? 17 : 0;
	assert(mca_adsp_glink_callback(&test_mca, &reply, sizeof(reply)) == 0);
	return 0;
}

static void test_public_apis(void)
{
	int (*apis[])(int, void *, size_t) = {
		mca_adsp_glink_read_prop, mca_adsp_glink_write_prop,
		mca_adsp_glink_qbg_read_prop, mca_adsp_glink_qbg_write_prop,
	};
	for (unsigned api = 0; api < 4; api++) {
		for (int mode = 0; mode < 5; mode++) {
			u8 value[64]; memset(value, 0x7c, sizeof(value));
			int before = sends;
			transport_mode = mode;
			test_mca.glink_state = mode == 4 ? 0 : 1;
			int ret = apis[api](41, value, sizeof(value));
			int expected = mode == 1 ? -EIO : mode == 2 ? -ETIMEDOUT : mode == 3 ? 17 : mode == 4 ? -ENOTCONN : 0;
			assert(ret == expected);
			assert(!test_mca.pending && test_mca.cur_property_id == UINT32_MAX);
			assert(sends == before + (mode != 4));
			if (mode != 4) {
				assert(sent_request.hdr.owner == (api >= 2 ? MCA_ADSP_GLINK_QBG_OWNER : MCA_ADSP_GLINK_OWNER));
				assert(sent_request.hdr.opcode == (api % 2 ? 2 : 1));
				if (api % 2) assert(sent_request.data[0] == 0x7c);
			}
			assert(value[0] == (!mode && !(api % 2) ? 0x5b : 0x7c));
			if (mode == 1 || mode == 2) {
				struct mca_adsp_glink_resp_msg late = response(sent_request.hdr.owner,
					sent_request.hdr.opcode, sent_request.property_id, sent_request.seq);
				unsigned done = atomic_load(&test_mca.ack.done);
				assert(mca_adsp_glink_callback(&test_mca, &late, sizeof(late)) == 0);
				assert(atomic_load(&test_mca.ack.done) == done && !test_mca.pending);
			}
			cases++;
		}
		u8 value[256] = {0};
		assert(apis[api](41, NULL, 1) == -1);
		assert(apis[api](41, value, sizeof(value)) == -1);
		cases += 2;
	}
}

static void *deliver_response(void *packet)
{
	mca_adsp_glink_callback(&test_mca, packet, sizeof(struct mca_adsp_glink_resp_msg));
	return NULL;
}

static void test_cancel_race(void)
{
	for (unsigned i = 0; i < 200; i++) {
		pthread_t worker;
		struct mca_adsp_glink_resp_msg reply = response(MCA_ADSP_GLINK_OWNER, 1, 41, i);
		arm(MCA_ADSP_GLINK_OWNER, 1, 41, i);
		assert(!pthread_create(&worker, NULL, deliver_response, &reply));
		mca_adsp_glink_end_request(&test_mca);
		assert(!pthread_join(worker, NULL));
		assert(!test_mca.pending);
		assert(atomic_load(&test_mca.ack.done) <= 1);
		assert(test_mca.cur_property_id == UINT32_MAX);
		cases++;
	}
}

int main(void)
{
	assert(!pthread_mutex_init(&test_mca.pending_lock, NULL));
	assert(!pthread_mutex_init(&test_mca.rw_lock.lock, NULL));
	g_mca_adsp_glink = &test_mca;
	struct mca_adsp_glink_ops ops = {.notification = notification};
	struct mca_adsp_ops_node normal = {.ops = &ops, .priv = (void *)0};
	struct mca_adsp_ops_node qbg = {.ops = &ops, .priv = (void *)1};
	list_add(&normal.node, &g_mca_adsp_glink_ops_head);
	list_add(&qbg.node, &g_mca_adsp_glink_qbg_ops_head);
	test_lengths(); test_match_fields(); test_notifications(); test_unaligned_frames(); test_public_apis(); test_cancel_race();
	assert(!pthread_mutex_destroy(&test_mca.pending_lock));
	assert(!pthread_mutex_destroy(&test_mca.rw_lock.lock));
	printf("{\"status\":\"passed\",\"cases\":%u,\"wire_sizes\":[276,280,272],\"notifications\":[%u,%u]}\n", cases, notifications[0], notifications[1]);
	return 0;
}
