#!/usr/bin/env python3
"""Execute actual GLINK request/RX code with host ASan/UBSan primitives.

The wire structures and every function from begin_request through callback are
extracted verbatim. Kernel locks/completions/transport are host substitutes;
this is not a kernel compile or remote ADSP interoperability test.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path)
    parser.add_argument('--payload', type=Path, default=here.parents[1] / 'payload')
    parser.add_argument('--report', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.source is None:
        args.source = args.payload / 'drivers/power/supply/mca/mca_common/mca_adsp_glink.c'
    compiler = shutil.which('clang') or shutil.which('gcc')
    if not compiler:
        raise SystemExit('A host clang or gcc is required')
    source = args.source.read_text()
    start = source.index('#define MCA_ADSP_GLINK_OWNER ')
    end = source.index('static void mca_adsp_glink_sync_work(')
    actual = source[start:end]
    # Spinlock initialization is outside the tested range, in probe.
    assert 'spin_lock_init(&mca->pending_lock);' in source
    public_header = (args.source.parent.parent / 'include/mca/common/mca_adsp_glink.h').read_text().replace('#include <linux/types.h>', '')
    generated = here.joinpath('host_shim.h').read_text() + '\n' + public_header + '\n' + actual + '\n' + here.joinpath('host_cases.c').read_text()
    with tempfile.TemporaryDirectory(prefix='myron-glink-test-') as tmp:
        tmp = Path(tmp)
        cfile, binary = tmp / 'actual-glink.c', tmp / 'glink-test'
        cfile.write_text(generated)
        flags = ['-std=gnu11', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-pthread']
        compile_result = subprocess.run([compiler, *flags, str(cfile), '-o', str(binary)], text=True, capture_output=True)
        if compile_result.returncode:
            raise SystemExit(compile_result.stdout + compile_result.stderr)
        env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        run = subprocess.run([str(binary)], env=env, text=True, capture_output=True)
        if run.returncode:
            raise SystemExit(f'GLINK host test failed ({run.returncode})\n{run.stdout}{run.stderr}')
        result = json.loads(run.stdout)
        result.update({
            'source_sha256': hashlib.sha256(args.source.read_bytes()).hexdigest(),
            'actual_function_extraction': True,
            'sanitizers': ['address', 'undefined'],
            'compiler': subprocess.check_output([compiler, '--version'], text=True).splitlines()[0],
            'compiler_flags': flags,
            'limits': ['host kernel primitives, not a kernel build', 'no remote ADSP wire trace', 'notification opcode left compatible because none is defined in source', 'registered callback lifetime not changed', 'LeakSanitizer disabled for sandbox process restrictions'],
        })
        if args.output:
            args.output.mkdir(parents=True, exist_ok=True)
            (args.output / 'actual-glink.c').write_text(generated)
            (args.output / 'host-tests.json').write_text(json.dumps(result, indent=2) + '\n')
            (args.output / 'compiler.log').write_text(compile_result.stdout + compile_result.stderr)
            (args.output / 'runtime.log').write_text(run.stdout + run.stderr)
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
