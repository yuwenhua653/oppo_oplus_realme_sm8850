/* Host-only primitives for executing the extracted, unmodified GLINK functions. */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <stdatomic.h>
typedef uint32_t u32;
typedef uint8_t u8;
#define __packed __attribute__((packed))
#define EXPORT_SYMBOL(x)
#define GFP_KERNEL 0
#define mca_log_err(...) ((void)0)
#define mca_log_info(...) ((void)0)
struct device { int unused; };
struct work_struct { int unused; };
struct pmic_glink_client { int unused; };
struct pmic_glink_hdr { u32 owner; u32 type; u32 opcode; };
struct mutex { pthread_mutex_t lock; };
struct completion { _Atomic unsigned done; };
typedef pthread_mutex_t spinlock_t;
#define spin_lock_irqsave(lock, flags) do { (flags) = 0; assert(!pthread_mutex_lock(lock)); } while (0)
#define spin_unlock_irqrestore(lock, flags) do { (void)(flags); assert(!pthread_mutex_unlock(lock)); } while (0)
static void mutex_lock(struct mutex *m) { assert(!pthread_mutex_lock(&m->lock)); }
static void mutex_unlock(struct mutex *m) { assert(!pthread_mutex_unlock(&m->lock)); }
static void reinit_completion(struct completion *c) { atomic_store(&c->done, 0); }
static void complete(struct completion *c) { atomic_fetch_add(&c->done, 1); }
static unsigned wait_for_completion_timeout(struct completion *c, unsigned timeout)
{
	(void)timeout;
	return atomic_load(&c->done) != 0;
}
#define msecs_to_jiffies(x) (x)
static void *kzalloc(size_t size, int flags) { (void)flags; return calloc(1, size); }
struct list_head { struct list_head *next, *prev; };
#define LIST_HEAD(name) struct list_head name = { &(name), &(name) }
static void list_add(struct list_head *node, struct list_head *head)
{
	node->next = head->next; node->prev = head;
	head->next->prev = node; head->next = node;
}
#define list_for_each_entry(pos, head, member) \
	for (struct list_head *cursor = (head)->next; \
	     cursor != (head) && ((pos) = (__typeof__(pos))((char *)cursor - offsetof(__typeof__(*(pos)), member)), 1); \
	     cursor = cursor->next)
static int pmic_glink_write(struct pmic_glink_client *client, void *data, size_t len);
