#!/usr/bin/env python3
"""Compile the actual patched getter with a tiny fake power-supply core.

These tests exercise ownership/reference/error branches, not kernel ABI or devices.
"""
from pathlib import Path
import json
import subprocess
import tempfile
import hashlib
import sys

HERE = Path(__file__).resolve().parent
SOURCE = Path(sys.argv[1]) / 'drivers/power/supply/qti_battery_charger.c'

PREFIX = r'''
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

enum battery_charger_prop { BATTERY_RESISTANCE, BATTERY_CHARGER_PROP_MAX };
enum power_supply_property { POWER_SUPPLY_PROP_PRESENT };
union power_supply_propval { int intval; };
struct power_supply;
typedef int (*get_prop_t)(struct power_supply *, enum power_supply_property,
                          union power_supply_propval *);
struct power_supply_desc { get_prop_t get_property; };
struct power_supply { const struct power_supply_desc *desc; void *drvdata; };
enum { PSY_TYPE_BATTERY, BATT_RESISTANCE = 0 };
struct psy_state { unsigned int prop[1]; };
struct battery_chg_dev { struct psy_state psy_list[1]; };
static struct battery_chg_dev owned_device = { .psy_list = {{ .prop = {24680} }} };
static struct power_supply_desc desc;
static struct power_supply supply;
static int lookups, put_calls, gets, reads, references, read_rc, missing;
static struct power_supply *power_supply_get_by_name(const char *name)
{
    assert(name);
    ++lookups;
    if (missing) return NULL;
    ++references;
    return &supply;
}
static void *power_supply_get_drvdata(struct power_supply *psy)
{
    assert(psy == &supply && references == 1);
    ++gets;
    return psy->drvdata;
}
static void power_supply_put(struct power_supply *psy)
{
    assert(psy == &supply && references == 1);
    --references;
    ++put_calls;
}
static int read_property_id(struct battery_chg_dev *dev,
                            struct psy_state *pst, int property)
{
    assert(references == 1);
    assert(dev == &owned_device && pst == &owned_device.psy_list[0]);
    assert(property == BATT_RESISTANCE);
    ++reads;
    return read_rc;
}
#define CB(name, result) \
static int name(struct power_supply *p, enum power_supply_property prop, \
                union power_supply_propval *val) \
{ (void)p; (void)prop; (void)val; return result; }
CB(battery_psy_get_prop, 1)
CB(usb_psy_get_prop, 2)
CB(wls_psy_get_prop, 3)
CB(foreign_mca_get_prop, 4)
static void reset(get_prop_t callback)
{
    lookups = put_calls = gets = reads = references = read_rc = missing = 0;
    desc.get_property = callback;
    supply.desc = &desc;
    supply.drvdata = &owned_device;
}
'''

SUFFIX = r'''
int main(void)
{
    int val, rc, cases = 0;
    const char *names[] = { "battery", "usb", "usb-2", "wireless" };
    get_prop_t callbacks[] = { battery_psy_get_prop, usb_psy_get_prop,
                              usb_psy_get_prop, wls_psy_get_prop };

    /* MCA uses a valid but incompatible private layout; do not even retrieve it. */
    reset(foreign_mca_get_prop); supply.drvdata = (void *)1; val = -123;
    assert(qti_battery_charger_get_prop("battery", BATTERY_RESISTANCE, &val) == -ENODEV);
    assert(val == -123 && gets == 0 && reads == 0 && put_calls == 1 && references == 0); ++cases;

    reset(NULL); supply.drvdata = (void *)1;
    assert(qti_battery_charger_get_prop("battery", BATTERY_RESISTANCE, &val) == -ENODEV);
    assert(gets == 0 && put_calls == 1 && references == 0); ++cases;

    reset(battery_psy_get_prop); supply.desc = NULL;
    assert(qti_battery_charger_get_prop("battery", BATTERY_RESISTANCE, &val) == -ENODEV);
    assert(gets == 0 && put_calls == 1 && references == 0); ++cases;

    reset(battery_psy_get_prop); supply.drvdata = NULL;
    assert(qti_battery_charger_get_prop("battery", BATTERY_RESISTANCE, &val) == -ENODEV);
    assert(gets == 1 && reads == 0 && put_calls == 1 && references == 0); ++cases;

    for (unsigned int i = 0; i < sizeof(names) / sizeof(names[0]); ++i) {
        reset(callbacks[i]); val = -123;
        rc = qti_battery_charger_get_prop(names[i], BATTERY_RESISTANCE, &val);
        assert(rc == 0 && val == 24680 && reads == 1 && gets == 1 && put_calls == 1 && references == 0); ++cases;
    }

    reset(battery_psy_get_prop); read_rc = -EIO; val = -123;
    assert(qti_battery_charger_get_prop("battery", BATTERY_RESISTANCE, &val) == -EIO);
    assert(val == -123 && reads == 1 && put_calls == 1 && references == 0); ++cases;

    reset(battery_psy_get_prop); missing = 1;
    assert(qti_battery_charger_get_prop("battery", BATTERY_RESISTANCE, &val) == -ENODEV);
    assert(lookups == 1 && put_calls == 0 && reads == 0); ++cases;

    reset(battery_psy_get_prop);
    assert(qti_battery_charger_get_prop(NULL, BATTERY_RESISTANCE, &val) == -EINVAL);
    assert(qti_battery_charger_get_prop("battery", BATTERY_RESISTANCE, NULL) == -EINVAL);
    assert(qti_battery_charger_get_prop("battery", BATTERY_CHARGER_PROP_MAX, &val) == -EINVAL);
    assert(qti_battery_charger_get_prop("battery", (enum battery_charger_prop)-1, &val) == -EINVAL);
    assert(qti_battery_charger_get_prop("unrelated", BATTERY_RESISTANCE, &val) == -EINVAL);
    assert(lookups == 0 && put_calls == 0 && reads == 0); cases += 5;

    printf("PASS %d ownership/reference/error cases\n", cases);
    return 0;
}
'''

def main():
    source = SOURCE.read_text()
    start = source.index('int qti_battery_charger_get_prop(const char *name,')
    end = source.index('EXPORT_SYMBOL(qti_battery_charger_get_prop);', start)
    getter = source[start:end]
    with tempfile.TemporaryDirectory(prefix='myron-qti-psy-guard-') as td:
        td = Path(td)
        test = td/'guard-test.c'; output = td/'guard-test'
        test.write_text(PREFIX + '\n' + getter + '\n' + SUFFIX)
        command = ['cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                   '-fsanitize=undefined', str(test), '-o', str(output)]
        subprocess.run(command, check=True)
        completed = subprocess.run([str(output)], check=True, capture_output=True, text=True)
    print(completed.stdout, end='')
    report = {'schema': 'myron-r12-qti-psy-guard-test-v1', 'result': 'PASS',
              'cases': 15, 'actual_source_function_extracted': True,
              'test_type': 'Host compiled C function with fake power-supply core',
              'undefined_behavior_sanitizer': True,
              'compiler_flags': '-std=c11 -O2 -Wall -Wextra -Werror -fsanitize=undefined',
              'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              'test_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'target_compile': False, 'kernel_abi_test': False, 'device_test': False}
    print(json.dumps(report, sort_keys=True))

if __name__ == '__main__': main()
