#!/usr/bin/env python3
"""Failure-inject the actual candidate sysfs transaction and cleanup bodies."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

p = argparse.ArgumentParser()
p.add_argument('payload', type=Path)
p.add_argument('--report', type=Path)
a = p.parse_args()
source = a.payload / 'drivers/power/supply/mca/mca_common/mca_sysfs.c'
text = source.read_text()

def body(name):
    m = re.search(r'^(?:int|void)\s+' + name + r'\s*\(', text, re.M)
    assert m, name
    start = text.index('{', m.end())
    depth, end = 1, start + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[m.start():end] + '\n'

code = r'''
#include <assert.h>
#include <stdbool.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#define pr_err(...) ((void)0)
struct attribute { const char *name; int id; };
struct device_attribute { struct attribute attr; };
struct mca_sysfs_attr_info { struct device_attribute attr; int sysfs_attr_name; };
struct kobject { int id; };
struct device { struct kobject kobj; };
struct mca_sysfs_class_node { void *mca_class; };
static struct mca_sysfs_class_node node={(void*)1};
static struct device dev={{1}};
static struct mca_sysfs_attr_info attrs[4]={
 {{{"a",0}},0}, {{{"b",1}},1}, {{{"c",2}},2}, {{{"d",3}},3}
};
static int g_mca_sysfs_class_lock, refs, creates, removes, fail_at, error, checks;
static bool has_class,has_device,locked,exists[4];
#define CHECK(x) do{checks++;assert(x);}while(0)
static void mutex_lock(int *lock){assert(lock==&g_mca_sysfs_class_lock&&!locked);locked=true;}
static void mutex_unlock(int *lock){assert(lock==&g_mca_sysfs_class_lock&&locked);locked=false;}
static struct mca_sysfs_class_node *mca_sysfs_get_class_node(const char *name){assert(locked&&!strcmp(name,"xm_power"));return has_class?&node:NULL;}
static struct device *mca_sysfs_get_device(struct mca_sysfs_class_node *n,const char *name){assert(locked&&n==&node&&!strcmp(name,"typec"));return has_device?&dev:NULL;}
static struct device *get_device(struct device *d){assert(locked);if(d){assert(d==&dev);refs++;}return d;}
static void put_device(struct device *d){assert(!locked&&d==&dev&&refs>0);refs--;}
static int sysfs_create_file(struct kobject *k,const struct attribute *a){
 assert(!locked&&refs==1&&k==&dev.kobj&&a->id>=0&&a->id<4);
 creates++;
 if(exists[a->id])return -EEXIST;
 if(a->id==fail_at)return error;
 exists[a->id]=true;return 0;
}
static void sysfs_remove_file(struct kobject *k,const struct attribute *a){
 assert(!locked&&refs==1&&k==&dev.kobj&&a->id>=0&&a->id<4);
 assert(exists[a->id]);exists[a->id]=false;removes++;
}
static void reset(void){
 assert(!locked&&refs==0);creates=removes=0;fail_at=-1;error=-EIO;
 has_class=has_device=true;node.mca_class=(void*)1;
 memset(exists,0,sizeof(exists));
}
'''
code += body('mca_sysfs_create_files') + body('mca_sysfs_remove_files')
code += r'''
int main(void){
 reset();CHECK(mca_sysfs_create_files("typec",attrs,4)==0);
 CHECK(creates==4&&removes==0&&refs==0&&!locked);
 for(int i=0;i<4;i++)CHECK(exists[i]);
 mca_sysfs_remove_files("typec",attrs,4);
 CHECK(removes==4&&refs==0&&!locked);
 for(int i=0;i<4;i++)CHECK(!exists[i]);
 int errors[]={-ENOMEM,-EIO,-EINVAL,-EEXIST};
 for(int at=0;at<4;at++)for(int e=0;e<4;e++){
  reset();fail_at=at;error=errors[e];if(error==-EEXIST)exists[at]=true;
  CHECK(mca_sysfs_create_files("typec",attrs,4)==error);
  CHECK(creates==at+1&&removes==at&&refs==0&&!locked);
  for(int i=0;i<4;i++)CHECK(exists[i]==(i==at&&error==-EEXIST));
 }
 reset();CHECK(mca_sysfs_create_files(NULL,attrs,4)==-EINVAL);
 CHECK(mca_sysfs_create_files("typec",NULL,4)==-EINVAL);
 CHECK(mca_sysfs_create_files("typec",attrs,0)==-EINVAL);
 CHECK(mca_sysfs_create_files("typec",attrs,-1)==-EINVAL);
 const char *old=attrs[3].attr.attr.name;attrs[3].attr.attr.name=NULL;
 CHECK(mca_sysfs_create_files("typec",attrs,4)==-EINVAL);
 mca_sysfs_remove_files("typec",attrs,4);
 attrs[3].attr.attr.name="";CHECK(mca_sysfs_create_files("typec",attrs,4)==-EINVAL);
 attrs[3].attr.attr.name=old;
 mca_sysfs_remove_files(NULL,attrs,4);mca_sysfs_remove_files("typec",NULL,4);
 mca_sysfs_remove_files("typec",attrs,0);mca_sysfs_remove_files("typec",attrs,-1);
 CHECK(creates==0&&removes==0&&refs==0&&!locked);
 for(int state=0;state<3;state++){
  reset();if(state==0)has_class=false;if(state==1)has_device=false;if(state==2)node.mca_class=NULL;
  CHECK(mca_sysfs_create_files("typec",attrs,4)==-ENODEV);
  mca_sysfs_remove_files("typec",attrs,4);
  CHECK(creates==0&&removes==0&&refs==0&&!locked);
 }
 printf("{\"passed\":true,\"checks\":%d,\"actual_function_bodies\":true}\n",checks);
 return 0;
}
'''
with tempfile.TemporaryDirectory() as t:
    root = Path(t)
    c, exe = root / 'files.c', root / 'files'
    c.write_text(code)
    subprocess.run(['cc', '-std=gnu11', '-Wall', '-Wextra', '-Werror', '-O1', '-g',
                    '-fsanitize=address,undefined', '-fno-sanitize-recover=all',
                    str(c), '-o', str(exe)], check=True)
    result = subprocess.run([str(exe)], capture_output=True, text=True, check=True,
                            env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=0:abort_on_error=1'})
    report = json.loads(result.stdout)
    report.update(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  scope='Mocked kernel services, real candidate bodies; no sysfs runtime or hardware test.')
    print(json.dumps(report))
    if a.report:
        a.report.write_text(json.dumps(report, indent=2) + '\n')
