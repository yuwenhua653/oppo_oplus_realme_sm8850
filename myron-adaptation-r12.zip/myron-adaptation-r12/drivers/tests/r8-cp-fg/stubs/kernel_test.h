#ifndef MCA_PLATFORM_KERNEL_TEST_H
#define MCA_PLATFORM_KERNEL_TEST_H
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdarg.h>
#include <sched.h>
#include <sys/types.h>
typedef uint32_t u32;
typedef unsigned char u8;
#define __rcu
#define __init
#define __exit
#define GFP_KERNEL 0
#define THIS_MODULE NULL
#define MODULE_DESCRIPTION(x)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#define EXPORT_SYMBOL(x)
#define module_platform_driver(x)
#define module_init(x)
#define module_exit(x)
#define PAGE_SIZE 4096
#define scnprintf snprintf
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define DEFINE_MUTEX(x) pthread_mutex_t x = PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(x) pthread_mutex_lock(x)
#define mutex_unlock(x) pthread_mutex_unlock(x)
#define lockdep_is_held(x) 1
#define DEFINE_STATIC_SRCU(x) static pthread_rwlock_t x = PTHREAD_RWLOCK_INITIALIZER
static inline int srcu_read_lock(pthread_rwlock_t *p) { pthread_rwlock_rdlock(p); return 0; }
static inline void srcu_read_unlock(pthread_rwlock_t *p, int i) { (void)i; pthread_rwlock_unlock(p); }
static int sync_entered_count;
static inline void synchronize_srcu(pthread_rwlock_t *p) { __atomic_add_fetch(&sync_entered_count,1,__ATOMIC_SEQ_CST);pthread_rwlock_wrlock(p);pthread_rwlock_unlock(p); }
#define rcu_replace_pointer(p,v,c) __atomic_exchange_n(&(p),(v),__ATOMIC_SEQ_CST)
#define rcu_dereference_protected(p,c) __atomic_load_n(&(p),__ATOMIC_SEQ_CST)
#define srcu_dereference(p,s) __atomic_load_n(&(p),__ATOMIC_SEQ_CST)
#define RCU_INIT_POINTER(p,v) __atomic_store_n(&(p),(v),__ATOMIC_SEQ_CST)
static int alloc_fail;
static inline void *kmalloc(size_t n,int f) { (void)f; return alloc_fail ? NULL : malloc(n); }
#define kfree(x) free(x)
struct device_node { int dummy; };
struct device { void *data; struct device_node *of_node; };
struct platform_device { struct device dev; };
struct of_device_id { const char *compatible; };
struct platform_driver { struct { const char *name; const struct of_device_id *of_match_table; void *owner; } driver; int (*probe)(struct platform_device *); void (*remove)(struct platform_device *); void (*shutdown)(struct platform_device *); };
static inline int platform_driver_register(struct platform_driver *p) { (void)p; return 0; }
static inline void platform_driver_unregister(struct platform_driver *p) { (void)p; }
static inline void *dev_get_drvdata(struct device *d) { return d->data; }
static inline void dev_set_drvdata(struct device *d,void *v) { d->data=v; }
static inline void platform_set_drvdata(struct platform_device *d,void *v) { d->dev.data=v; }
static inline void *platform_get_drvdata(struct platform_device *d) { return d->dev.data; }
static inline void *devm_kzalloc(struct device *d,size_t n,int f) { (void)d;(void)f;return calloc(1,n); }
#define IS_ERR_OR_NULL(p) (!(p) || (uintptr_t)(p) > (uintptr_t)-4096)
#define PTR_ERR(p) ((long)(p))
#define mca_log_err(...) do {} while (0)
#define mca_log_info(...) do {} while (0)
struct attribute { const char *name; };
struct device_attribute { struct attribute attr; };
struct attribute_group { struct attribute **attrs; };
struct mca_sysfs_attr_info { struct device_attribute attr; int sysfs_attr_name; };
#define mca_sysfs_attr_ro(p,m,n,f) { .attr.attr.name=#f, .sysfs_attr_name=n }
#define mca_sysfs_attr_rw(p,m,n,f) { .attr.attr.name=#f, .sysfs_attr_name=n }
static int sysfs_create_count, sysfs_remove_count, sysfs_fail_at;
static int link_create_count, link_remove_count, link_fail;
static inline int mca_sysfs_create_link_group(const char *d,const char *l,struct device *v,const struct attribute_group *g) { (void)d;(void)l;(void)v;(void)g;link_create_count++;return link_fail ? -ENOMEM : 0; }
static inline void mca_sysfs_remove_link_group(const char *d,const char *l,struct device *v,const struct attribute_group *g) { (void)d;(void)l;(void)v;(void)g;link_remove_count++; }
static inline struct device *mca_sysfs_create_group(const char *c,const char *n,const struct attribute_group *g) { (void)c;(void)n;(void)g;sysfs_create_count++;return sysfs_create_count==sysfs_fail_at ? NULL : calloc(1,sizeof(struct device)); }
static inline void mca_sysfs_remove_group(const char *c,struct device *d,const struct attribute_group *g) { (void)c;(void)g;sysfs_remove_count++;free(d); }
static inline void mca_sysfs_init_attrs(struct attribute **a,struct mca_sysfs_attr_info *i,int n) { (void)a;(void)i;(void)n; }
static inline struct mca_sysfs_attr_info *mca_sysfs_lookup_attr(const char *n,struct mca_sysfs_attr_info *a,int len) { for(int i=0;i<len;i++)if(!strcmp(n,a[i].attr.attr.name))return &a[i];return NULL; }
static inline ssize_t sysfs_emit(char *b,const char *f,...) { va_list a;va_start(a,f);int n=vsnprintf(b,PAGE_SIZE,f,a);va_end(a);return n; }
static inline int kstrtoint(const char *s,int base,int *out) { char *end;errno=0;long n=strtol(s,&end,base);if(errno||end==s||(*end&&*end!='\n')||n<INT_MIN||n>INT_MAX)return -EINVAL;*out=(int)n;return 0; }
static int dt_num=1,dt_count=1,dt_index_fail=-1;
static const char *dt_names[3]={"cp_master","cp_slave","cp_third"};
static inline int mca_parse_dts_u32(const struct device_node *d,const char *s,u32 *v,u32 def) { (void)d;(void)s;(void)def;*v=(u32)dt_num;return 0; }
static inline int mca_parse_dts_count_strings(const struct device_node *d,const char *s,u32 a,u32 b) { (void)d;(void)s;(void)a;(void)b;return dt_count; }
static inline int mca_parse_dts_string_index(const struct device_node *d,const char *s,int i,const char **out) { (void)d;(void)s;if(i==dt_index_fail)return -EINVAL;*out=dt_names[i];return 0; }
#endif
