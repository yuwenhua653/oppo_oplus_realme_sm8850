#!/usr/bin/env bash
set -euo pipefail
self="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
payload="$(cd -- "${1:?usage: run_cp.sh PAYLOAD}" && pwd)"
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
cc -std=gnu11 -Wall -Wextra -Werror=implicit-function-declaration -Werror=incompatible-pointer-types -Wno-unused-function -Wno-unused-variable -Wno-unused-parameter -Wno-pointer-sign -Wno-sign-compare -g -fsanitize=undefined -fno-sanitize-recover=all -pthread \
 -I"$self/stubs" -I"$payload/drivers/power/supply/mca/include" \
 -DCP_SOURCE_FILE="\"$payload/drivers/power/supply/mca/mca_platform/mca_platform_cp_class.c\"" \
 "$self/test_cp.c" -o "$work/test_cp"
"$work/test_cp"
