#include "kernel_test.h"
#include CP_SOURCE_FILE
static int checks;
#define CHECK(x) do { checks++; assert(x); } while (0)
static int iv, channel = -7, sentinel; static bool bv; static int calls, cbret=-EIO;
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_enable) == 0, "stock slot 0: cp_set_enable");
static int cb_cp_set_enable(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_enabled) == 8, "stock slot 8: cp_get_enabled");
static int cb_cp_get_enabled(bool * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&bv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_present) == 16, "stock slot 16: cp_set_present");
static int cb_cp_set_present(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_vbus_present) == 32, "stock slot 32: cp_get_vbus_present");
static int cb_cp_get_vbus_present(bool * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&bv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_present) == 24, "stock slot 24: cp_get_present");
static int cb_cp_get_present(bool * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&bv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_battery_present) == 64, "stock slot 64: cp_get_battery_present");
static int cb_cp_get_battery_present(bool * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&bv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_battery_voltage) == 40, "stock slot 40: cp_get_battery_voltage");
static int cb_cp_get_battery_voltage(u32 * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_battery_current) == 48, "stock slot 48: cp_get_battery_current");
static int cb_cp_get_battery_current(u32 * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_battery_temperature) == 56, "stock slot 56: cp_get_battery_temperature");
static int cb_cp_get_battery_temperature(u32 * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_bus_voltage) == 72, "stock slot 72: cp_get_bus_voltage");
static int cb_cp_get_bus_voltage(u32 * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_bus_current) == 80, "stock slot 80: cp_get_bus_current");
static int cb_cp_get_bus_current(u32 * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_bus_temperature) == 88, "stock slot 88: cp_get_bus_temperature");
static int cb_cp_get_bus_temperature(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_die_temperature) == 96, "stock slot 96: cp_get_die_temperature");
static int cb_cp_get_die_temperature(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_alarm_status) == 104, "stock slot 104: cp_get_alarm_status");
static int cb_cp_get_alarm_status(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_fault_status) == 112, "stock slot 112: cp_get_fault_status");
static int cb_cp_get_fault_status(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_bus_error_status) == 120, "stock slot 120: cp_get_bus_error_status");
static int cb_cp_get_bus_error_status(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_reg_status) == 128, "stock slot 128: cp_get_reg_status");
static int cb_cp_get_reg_status(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_mode) == 176, "stock slot 176: cp_set_mode");
static int cb_cp_set_mode(int a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == channel); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_mode) == 184, "stock slot 184: cp_get_mode");
static int cb_cp_get_mode(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_device_init) == 192, "stock slot 192: cp_device_init");
static int cb_cp_device_init(int a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == channel); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_enable_adc) == 200, "stock slot 200: cp_enable_adc");
static int cb_cp_enable_adc(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_bypass_support) == 208, "stock slot 208: cp_get_bypass_support");
static int cb_cp_get_bypass_support(bool * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&bv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_dump_register) == 216, "stock slot 216: cp_dump_register");
static int cb_cp_dump_register(void *data) { CHECK(data == &sentinel); calls++; return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_chip_vendor) == 224, "stock slot 224: cp_get_chip_vendor");
static int cb_cp_get_chip_vendor(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_int_stat) == 248, "stock slot 248: cp_get_int_stat");
static int cb_cp_get_int_stat(int a0, bool * a1, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == channel); CHECK((void *)a1 == (void *)&bv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_enable_acdrv_manual) == 232, "stock slot 232: cp_enable_acdrv_manual");
static int cb_cp_enable_acdrv_manual(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_adjustadble_timeout) == 240, "stock slot 240: cp_set_adjustadble_timeout");
static int cb_cp_set_adjustadble_timeout(int a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == channel); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_enable_wpcgate) == 136, "stock slot 136: cp_enable_wpcgate");
static int cb_cp_enable_wpcgate(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_enable_ovpgate) == 144, "stock slot 144: cp_enable_ovpgate");
static int cb_cp_enable_ovpgate(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_enable_ovpgate_with_check) == 152, "stock slot 152: cp_enable_ovpgate_with_check");
static int cb_cp_enable_ovpgate_with_check(int a0, bool a1, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == channel); CHECK(a1 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_ovpgate_status) == 160, "stock slot 160: cp_get_ovpgate_status");
static int cb_cp_get_ovpgate_status(bool * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&bv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_probe_ok) == 352, "stock slot 352: cp_get_probe_ok");
static int cb_cp_get_probe_ok(void *data) { CHECK(data == &sentinel); calls++; return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_usb_voltage) == 168, "stock slot 168: cp_get_usb_voltage");
static int cb_cp_get_usb_voltage(u32 * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_errorhl_stat) == 256, "stock slot 256: cp_get_errorhl_stat");
static int cb_cp_get_errorhl_stat(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_enable_busucp) == 264, "stock slot 264: cp_enable_busucp");
static int cb_cp_enable_busucp(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_default_fsw) == 280, "stock slot 280: cp_set_default_fsw");
static int cb_cp_set_default_fsw(void *data) { CHECK(data == &sentinel); calls++; return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_fsw) == 288, "stock slot 288: cp_get_fsw");
static int cb_cp_get_fsw(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_fsw_step) == 296, "stock slot 296: cp_get_fsw_step");
static int cb_cp_get_fsw_step(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_get_tdie) == 304, "stock slot 304: cp_get_tdie");
static int cb_cp_get_tdie(int * a0, void *data) { CHECK(data == &sentinel); calls++; CHECK((void *)a0 == (void *)&iv); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_qb) == 312, "stock slot 312: cp_set_qb");
static int cb_cp_set_qb(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_rcp) == 336, "stock slot 336: cp_set_rcp");
static int cb_cp_set_rcp(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_pmid2outuvp_th) == 320, "stock slot 320: cp_set_pmid2outuvp_th");
static int cb_cp_set_pmid2outuvp_th(int a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == channel); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_vout2out_uvp) == 328, "stock slot 328: cp_set_vout2out_uvp");
static int cb_cp_set_vout2out_uvp(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_revchg) == 344, "stock slot 344: cp_set_revchg");
static int cb_cp_set_revchg(bool a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == true); return cbret; }
_Static_assert(offsetof(struct platform_class_cp_ops, cp_set_fsw) == 272, "stock slot 272: cp_set_fsw");
static int cb_cp_set_fsw(int a0, void *data) { CHECK(data == &sentinel); calls++; CHECK(a0 == channel); return cbret; }
static int read_current(u32 *out, void *data) { *out = data == &sentinel ? 1300 : 700; return 0; }
static int read_present(bool *out, void *data) { (void)data; *out = true; return 0; }
static int enable_adc(bool en, void *data) { (void)en;(void)data; return cbret; }
static int uvp_false(bool en, void *data) { CHECK(!en); CHECK(data == &sentinel); return -ERANGE; }
int main(void) {
struct platform_class_cp_ops ops={0}, empty={0};
struct device_node node={0}; struct platform_device pdev={ .dev.of_node=&node };
struct platform_cp_dev cp={ .dev=&pdev.dev };
struct device dev={0}; char buf[4096]; int idx=0;
CHECK(CP_ROLE_MAX==3);
CHECK(platform_class_cp_register_ops(3,&ops,&sentinel)==-EOPNOTSUPP);
CHECK(platform_class_cp_register_ops(0,NULL,&sentinel)==-EOPNOTSUPP);
CHECK(platform_class_cp_register_ops(0,&ops,NULL)==-EOPNOTSUPP);
ops.cp_set_enable=cb_cp_set_enable;
ops.cp_get_enabled=cb_cp_get_enabled;
ops.cp_set_present=cb_cp_set_present;
ops.cp_get_vbus_present=cb_cp_get_vbus_present;
ops.cp_get_present=cb_cp_get_present;
ops.cp_get_battery_present=cb_cp_get_battery_present;
ops.cp_get_battery_voltage=cb_cp_get_battery_voltage;
ops.cp_get_battery_current=cb_cp_get_battery_current;
ops.cp_get_battery_temperature=cb_cp_get_battery_temperature;
ops.cp_get_bus_voltage=cb_cp_get_bus_voltage;
ops.cp_get_bus_current=cb_cp_get_bus_current;
ops.cp_get_bus_temperature=cb_cp_get_bus_temperature;
ops.cp_get_die_temperature=cb_cp_get_die_temperature;
ops.cp_get_alarm_status=cb_cp_get_alarm_status;
ops.cp_get_fault_status=cb_cp_get_fault_status;
ops.cp_get_bus_error_status=cb_cp_get_bus_error_status;
ops.cp_get_reg_status=cb_cp_get_reg_status;
ops.cp_set_mode=cb_cp_set_mode;
ops.cp_get_mode=cb_cp_get_mode;
ops.cp_device_init=cb_cp_device_init;
ops.cp_enable_adc=cb_cp_enable_adc;
ops.cp_get_bypass_support=cb_cp_get_bypass_support;
ops.cp_dump_register=cb_cp_dump_register;
ops.cp_get_chip_vendor=cb_cp_get_chip_vendor;
ops.cp_get_int_stat=cb_cp_get_int_stat;
ops.cp_enable_acdrv_manual=cb_cp_enable_acdrv_manual;
ops.cp_set_adjustadble_timeout=cb_cp_set_adjustadble_timeout;
ops.cp_enable_wpcgate=cb_cp_enable_wpcgate;
ops.cp_enable_ovpgate=cb_cp_enable_ovpgate;
ops.cp_enable_ovpgate_with_check=cb_cp_enable_ovpgate_with_check;
ops.cp_get_ovpgate_status=cb_cp_get_ovpgate_status;
ops.cp_get_probe_ok=cb_cp_get_probe_ok;
ops.cp_get_usb_voltage=cb_cp_get_usb_voltage;
ops.cp_get_errorhl_stat=cb_cp_get_errorhl_stat;
ops.cp_enable_busucp=cb_cp_enable_busucp;
ops.cp_set_default_fsw=cb_cp_set_default_fsw;
ops.cp_get_fsw=cb_cp_get_fsw;
ops.cp_get_fsw_step=cb_cp_get_fsw_step;
ops.cp_get_tdie=cb_cp_get_tdie;
ops.cp_set_qb=cb_cp_set_qb;
ops.cp_set_rcp=cb_cp_set_rcp;
ops.cp_set_pmid2outuvp_th=cb_cp_set_pmid2outuvp_th;
ops.cp_set_vout2out_uvp=cb_cp_set_vout2out_uvp;
ops.cp_set_revchg=cb_cp_set_revchg;
ops.cp_set_fsw=cb_cp_set_fsw;
CHECK(platform_class_cp_register_ops(0,&ops,&sentinel)==0);
calls=0; CHECK(platform_class_cp_set_charging_enable(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_charging_enable(3, true)==-1);
calls=0; CHECK(platform_class_cp_get_charging_enabled(0, &bv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_charging_enabled(3, &bv)==-1);
calls=0; CHECK(platform_class_cp_set_present(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_present(3, true)==-1);
calls=0; CHECK(platform_class_cp_get_vbus_present(0, &bv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_vbus_present(3, &bv)==-1);
calls=0; CHECK(platform_class_cp_get_present(0, &bv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_present(3, &bv)==-1);
calls=0; CHECK(platform_class_cp_get_battery_present(0, &bv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_battery_present(3, &bv)==-1);
calls=0; CHECK(platform_class_cp_get_battery_voltage(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_battery_voltage(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_battery_current(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_battery_current(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_battery_temperature(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_battery_temperature(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_bus_voltage(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_bus_voltage(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_bus_current(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_bus_current(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_bus_temperature(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_bus_temperature(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_die_temperature(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_die_temperature(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_alarm_status(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_alarm_status(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_fault_status(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_fault_status(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_bus_error_status(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_bus_error_status(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_reg_status(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_reg_status(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_set_mode(0, channel)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_mode(3, channel)==-1);
calls=0; CHECK(platform_class_cp_get_mode(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_mode(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_device_init(0, channel)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_device_init(3, channel)==-1);
calls=0; CHECK(platform_class_cp_enable_adc(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_enable_adc(3, true)==-1);
calls=0; CHECK(platform_class_cp_get_bypass_support(0, &bv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_bypass_support(3, &bv)==-1);
calls=0; CHECK(platform_class_cp_dump_register(0)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_dump_register(3)==-1);
calls=0; CHECK(platform_class_cp_get_chip_vendor(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_chip_vendor(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_int_stat(0, channel, &bv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_int_stat(3, channel, &bv)==-1);
calls=0; CHECK(platform_class_cp_enable_acdrv_manual(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_enable_acdrv_manual(3, true)==-1);
calls=0; CHECK(platform_class_cp_set_adjustadble_timeout(0, channel)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_adjustadble_timeout(3, channel)==-1);
calls=0; CHECK(platform_class_cp_enable_wpcgate(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_enable_wpcgate(3, true)==-1);
calls=0; CHECK(platform_class_cp_enable_ovpgate(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_enable_ovpgate(3, true)==-1);
calls=0; CHECK(platform_class_cp_enable_ovpgate_with_check(0, channel, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_enable_ovpgate_with_check(3, channel, true)==-1);
calls=0; CHECK(platform_class_cp_get_ovpgate_status(0, &bv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_ovpgate_status(3, &bv)==-1);
calls=0; CHECK(platform_class_cp_get_probe_ok(0)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_probe_ok(3)==-1);
calls=0; CHECK(platform_class_cp_get_usb_voltage(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_usb_voltage(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_errorhl_stat(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_errorhl_stat(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_enable_busucp(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_enable_busucp(3, true)==-1);
calls=0; CHECK(platform_class_cp_set_default_fsw(0)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_default_fsw(3)==-1);
calls=0; CHECK(platform_class_cp_get_fsw(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_fsw(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_fsw_step(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_fsw_step(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_get_tdie(0, &iv)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_get_tdie(3, &iv)==-1);
calls=0; CHECK(platform_class_cp_set_qb(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_qb(3, true)==-1);
calls=0; CHECK(platform_class_cp_set_rcp(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_rcp(3, true)==-1);
calls=0; CHECK(platform_class_cp_set_pmid2outuvp_th(0, channel)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_pmid2outuvp_th(3, channel)==-1);
calls=0; CHECK(platform_class_cp_set_vout2out_uvp(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_vout2out_uvp(3, true)==-1);
calls=0; CHECK(platform_class_cp_set_revchg(0, true)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_revchg(3, true)==-1);
calls=0; CHECK(platform_class_cp_set_fsw(0, channel)==cbret); CHECK(calls==1);
CHECK(platform_class_cp_set_fsw(3, channel)==-1);
CHECK(platform_class_cp_register_ops(0,&empty,&sentinel)==0);
CHECK(platform_class_cp_set_vout2out_uvp(0,true)==-1);
CHECK(platform_class_cp_register_ops(0,&ops,&sentinel)==0);
ops.cp_set_vout2out_uvp=uvp_false;
CHECK(platform_class_cp_register_ops(2,&ops,&sentinel)==0);
CHECK(platform_class_cp_set_vout2out_uvp(2,false)==-ERANGE);
ops.cp_set_vout2out_uvp=cb_cp_set_vout2out_uvp;
/* DT input must not escape three fixed role slots. */
dt_num=4;dt_count=4;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);
dt_num=0;dt_count=0;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);
dt_num=2;dt_count=1;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);
dt_num=3;dt_count=3;dt_index_fail=2;CHECK(platform_cp_dev_parse_dt(&cp)==-EINVAL);
dt_index_fail=-1;CHECK(platform_cp_dev_parse_dt(&cp)==0);
cp.cp_dir_list[0]="unknown";CHECK(cp_sysfs_create_group(&cp)==-EINVAL); CHECK(sysfs_create_count==0);
cp.cp_dir_list[0]="master_slave";CHECK(cp_sysfs_create_group(&cp)==-EINVAL);
cp.cp_dir_list[0]="cp_master";cp.cp_dir_list[1]="other_master";CHECK(cp_sysfs_create_group(&cp)==-EINVAL);
cp.cp_dir_list[1]="cp_slave";sysfs_fail_at=2;CHECK(cp_sysfs_create_group(&cp)==-ENOMEM);CHECK(sysfs_remove_count==1);
sysfs_create_count=0;sysfs_remove_count=0;sysfs_fail_at=0;CHECK(cp_sysfs_create_group(&cp)==0);CHECK(sysfs_create_count==3);
for(int i=0;i<3;i++)CHECK(*(int*)dev_get_drvdata(cp.sysfs_dev[i])==i);
cp_sysfs_remove_groups(&cp);CHECK(sysfs_remove_count==3);
/* Sysfs must never publish data when the hardware callback failed. */
dev.data=&idx;
struct device_attribute batt={.attr.name="batt_present"},bus={.attr.name="vbus"},fsw={.attr.name="fsw"},ovp={.attr.name="ovpgate"};
memset(buf,0x5a,sizeof(buf));
ops.cp_get_battery_present=read_present;CHECK(cp_sysfs_show(&dev,&batt,buf)==2);CHECK(!strcmp(buf,"1\n"));
ops.cp_enable_adc=enable_adc;cbret=-EIO;memset(buf,0x5a,sizeof(buf));CHECK(cp_sysfs_show(&dev,&bus,buf)==-EIO);CHECK(buf[0]==0x5a);
CHECK(cp_sysfs_store(&dev,&ovp,"bad",3)==-EINVAL);CHECK(cp_sysfs_store(&dev,&fsw,"-1",2)==-EINVAL);
CHECK(cp_sysfs_store(&dev,&fsw,"500",3)==-ENODEV);
/* Late link failure rolls back all role devices and singleton publication. */
sysfs_create_count=0;sysfs_remove_count=0;link_fail=1;CHECK(platform_cp_class_probe(&pdev)==-ENOMEM);CHECK(sysfs_remove_count==3);CHECK(g_platform_cp_dev==NULL);free(platform_get_drvdata(&pdev));
link_fail=0;sysfs_create_count=0;sysfs_remove_count=0;CHECK(platform_cp_class_probe(&pdev)==0);CHECK(g_platform_cp_dev!=NULL);
/* A failed forced-frequency operation cannot latch an unexecuted override. */
channel=500;cbret=-EIO;CHECK(cp_sysfs_store(&dev,&fsw,"500",3)==-EIO);CHECK(g_platform_cp_dev->force_fsw==0);
cbret=0;CHECK(cp_sysfs_store(&dev,&fsw,"500",3)==3);CHECK(g_platform_cp_dev->force_fsw==500);
calls=0;CHECK(platform_class_cp_set_fsw(0,700)==0);CHECK(calls==0);
channel=0;CHECK(cp_sysfs_store(&dev,&fsw,"0",1)==1);CHECK(g_platform_cp_dev->force_fsw==0);
platform_cp_class_remove(&pdev);CHECK(sysfs_remove_count==3);CHECK(link_remove_count==1);CHECK(g_platform_cp_dev==NULL);free(platform_get_drvdata(&pdev));
/* Preserve the stock two-role current aggregation. */
ops.cp_get_bus_current=read_current;CHECK(platform_class_cp_register_ops(1,&ops,&iv)==0);
CHECK(platform_class_cp_get_ibus_total(&iv)==0);CHECK(iv==2000);
CHECK(platform_class_cp_get_ibus_delta(&iv)==0);CHECK(iv==600);
printf("PASS: %d actual CP assertions; 45 compile-time stock callback offsets\n", checks); return 0; }
