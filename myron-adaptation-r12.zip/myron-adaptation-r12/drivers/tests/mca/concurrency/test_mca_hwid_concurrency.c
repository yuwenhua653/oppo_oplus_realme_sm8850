/* Exercise the actual candidate C; kernel mutex/slab are host mocks. */
#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <linux/slab.h>

static void record_lock_attempt(void);
#define MCA_TEST_LOCK_ATTEMPT() record_lock_attempt()
#include "mca_hwid.c"

_Static_assert(sizeof(void *) == 8, "test requires a 64-bit host");
_Static_assert(sizeof(struct mca_hwid) == 40, "stock record size");
_Static_assert(offsetof(struct mca_hwid, build_adc) == 20, "build ADC");
_Static_assert(offsetof(struct mca_hwid, product_adc) == 24, "project ADC");
_Static_assert(offsetof(struct mca_hwid, hwid_value) == 28, "raw hwid");
_Static_assert(offsetof(struct mca_hwid, product_name) == 32, "name pointer");

enum { THREADS = 16, CALLS_PER_THREAD = 64, ROUNDS = 32 };
static pthread_mutex_t state_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t state_changed = PTHREAD_COND_INITIALIZER;
static unsigned int lock_attempts, completed;
static int gate_enabled, getter_blocked, release_getter;
static atomic_uint allocations, getter_calls, invalid_records, null_returns;
static atomic_int fail_remaining;
static uint32_t values[8];
static const char product[] = "myron";
static const struct mca_hwid *results[THREADS];

static void record_lock_attempt(void)
{
    assert(pthread_mutex_lock(&state_lock) == 0);
    ++lock_attempts;
    assert(pthread_cond_broadcast(&state_changed) == 0);
    assert(pthread_mutex_unlock(&state_lock) == 0);
}

void *test_kzalloc(size_t size, int flags)
{
    (void)flags;
    assert(size == sizeof(struct mca_hwid));
    atomic_fetch_add(&allocations, 1);
    int failures = atomic_load(&fail_remaining);
    while (failures > 0) {
        if (atomic_compare_exchange_weak(&fail_remaining, &failures, failures - 1))
            return NULL;
    }
    return calloc(1, size);
}

void test_mca_log(const char *format, ...) { (void)format; }

uint32_t get_hw_version_platform(void)
{
    atomic_fetch_add(&getter_calls, 1);
    assert(pthread_mutex_lock(&state_lock) == 0);
    if (gate_enabled) {
        getter_blocked = 1;
        assert(pthread_cond_broadcast(&state_changed) == 0);
        while (!release_getter)
            assert(pthread_cond_wait(&state_changed, &state_lock) == 0);
    }
    assert(pthread_mutex_unlock(&state_lock) == 0);
    return values[0];
}
#define GETTER(name, index) uint32_t name(void) { \
    atomic_fetch_add(&getter_calls, 1); return values[index]; }
GETTER(get_hw_country_version, 1)
GETTER(get_hw_version_major, 2)
GETTER(get_hw_version_minor, 3)
GETTER(get_hw_version_build, 4)
GETTER(get_hw_build_adc, 5)
GETTER(get_hw_project_adc, 6)
GETTER(get_hw_id_value, 7)
const char *product_name_get(void)
{
    atomic_fetch_add(&getter_calls, 1);
    return product;
}

static void check_record(const struct mca_hwid *info)
{
    if (memcmp(info, values, sizeof(values)) || info->product_name != product)
        atomic_fetch_add(&invalid_records, 1);
}

static void *worker(void *arg)
{
    size_t index = (size_t)arg;
    for (unsigned int i = 0; i < CALLS_PER_THREAD; ++i) {
        const struct mca_hwid *info = mca_get_hwid_info();
        if (i == 0)
            results[index] = info;
        if (info)
            check_record(info);
        else
            atomic_fetch_add(&null_returns, 1);
    }
    assert(pthread_mutex_lock(&state_lock) == 0);
    ++completed;
    assert(pthread_cond_broadcast(&state_changed) == 0);
    assert(pthread_mutex_unlock(&state_lock) == 0);
    return NULL;
}

/* Called only with all worker threads joined and no API use in flight. */
static void reset(unsigned int round)
{
    free(phwid);
    phwid = NULL;
    lock_attempts = completed = 0;
    gate_enabled = getter_blocked = release_getter = 0;
    atomic_store(&allocations, 0);
    atomic_store(&getter_calls, 0);
    atomic_store(&invalid_records, 0);
    atomic_store(&null_returns, 0);
    atomic_store(&fail_remaining, 0);
    const uint32_t seed[8] = { 660, 4, 3, 6, 9, 51310, 16691, 589830 };
    memcpy(values, seed, sizeof(values));
    values[0] += round;
    memset(results, 0, sizeof(results));
}

static struct timespec deadline(void)
{
    struct timespec result;
    assert(clock_gettime(CLOCK_REALTIME, &result) == 0);
    result.tv_sec += 5;
    return result;
}

static void concurrent_initialization(unsigned int round)
{
    pthread_t threads[THREADS];
    reset(round);
    gate_enabled = 1;
    assert(pthread_create(&threads[0], NULL, worker, (void *)0) == 0);
    struct timespec until = deadline();
    assert(pthread_mutex_lock(&state_lock) == 0);
    while (!getter_blocked)
        assert(pthread_cond_timedwait(&state_changed, &state_lock, &until) == 0);
    assert(pthread_mutex_unlock(&state_lock) == 0);
    /* First getter is paused before any fields have been assigned. */
    for (size_t i = 1; i < THREADS; ++i)
        assert(pthread_create(&threads[i], NULL, worker, (void *)i) == 0);
    until = deadline();
    assert(pthread_mutex_lock(&state_lock) == 0);
    while (lock_attempts < THREADS && !completed)
        assert(pthread_cond_timedwait(&state_changed, &state_lock, &until) == 0);
    assert(completed == 0);
    assert(atomic_load(&invalid_records) == 0);
    assert(atomic_load(&allocations) == 1);
    release_getter = 1;
    assert(pthread_cond_broadcast(&state_changed) == 0);
    assert(pthread_mutex_unlock(&state_lock) == 0);
    for (size_t i = 0; i < THREADS; ++i)
        assert(pthread_join(threads[i], NULL) == 0);
    assert(phwid != NULL);
    for (size_t i = 0; i < THREADS; ++i)
        assert(results[i] == phwid);
    assert(atomic_load(&invalid_records) == 0);
    assert(atomic_load(&null_returns) == 0);
    assert(atomic_load(&allocations) == 1);
    assert(atomic_load(&getter_calls) == 9);
    assert(lock_attempts == THREADS * CALLS_PER_THREAD);
}

static void allocation_failures(void)
{
    reset(0);
    atomic_store(&fail_remaining, 2);
    assert(mca_get_hwid_info() == NULL);
    assert(phwid == NULL);
    assert(mca_get_hwid_info() == NULL);
    assert(phwid == NULL);
    assert(atomic_load(&allocations) == 2);
    assert(atomic_load(&getter_calls) == 0);
    const struct mca_hwid *info = mca_get_hwid_info();
    assert(info && info == phwid);
    check_record(info);
    assert(atomic_load(&allocations) == 3);
    assert(atomic_load(&getter_calls) == 9);
    /* Cached access must not allocate or consume a pending failure. */
    atomic_store(&fail_remaining, 1);
    assert(mca_get_hwid_info() == info);
    assert(atomic_load(&allocations) == 3);
    assert(atomic_load(&fail_remaining) == 1);
    assert(atomic_load(&invalid_records) == 0);

    reset(0);
    atomic_store(&fail_remaining, 7);
    pthread_t threads[THREADS];
    for (size_t i = 0; i < THREADS; ++i)
        assert(pthread_create(&threads[i], NULL, worker, (void *)i) == 0);
    for (size_t i = 0; i < THREADS; ++i)
        assert(pthread_join(threads[i], NULL) == 0);
    assert(atomic_load(&null_returns) == 7);
    assert(atomic_load(&allocations) == 8);
    assert(atomic_load(&getter_calls) == 9);
    assert(atomic_load(&invalid_records) == 0);
    assert(phwid != NULL);
}

int main(void)
{
    for (unsigned int round = 0; round < ROUNDS; ++round)
        concurrent_initialization(round);
    allocation_failures();
    reset(0);
    printf("MCA hwid concurrency PASS: %u gated initializations, %u threads, "
           "%u successful concurrent reads; allocation failure and retry PASS\n",
           ROUNDS, THREADS, ROUNDS * THREADS * CALLS_PER_THREAD);
    return 0;
}
