#ifndef MYRON_HWID_CONCURRENCY_SLAB_H
#define MYRON_HWID_CONCURRENCY_SLAB_H
#include <stddef.h>
#define GFP_KERNEL 0
void *test_kzalloc(size_t size, int flags);
#define kzalloc test_kzalloc
#endif
