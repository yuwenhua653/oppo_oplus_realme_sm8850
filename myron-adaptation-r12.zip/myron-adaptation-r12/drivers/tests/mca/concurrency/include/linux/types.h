#ifndef MYRON_HWID_CONCURRENCY_TYPES_H
#define MYRON_HWID_CONCURRENCY_TYPES_H
#include <stdint.h>
typedef uint32_t u32;
#endif
