#ifndef MYRON_HWID_CONCURRENCY_MUTEX_H
#define MYRON_HWID_CONCURRENCY_MUTEX_H
#include <pthread.h>
#include <assert.h>
#define DEFINE_MUTEX(name) pthread_mutex_t name = PTHREAD_MUTEX_INITIALIZER
#ifndef MCA_TEST_LOCK_ATTEMPT
#define MCA_TEST_LOCK_ATTEMPT() ((void)0)
#endif
static inline void mutex_lock(pthread_mutex_t *lock)
{
    MCA_TEST_LOCK_ATTEMPT();
    assert(pthread_mutex_lock(lock) == 0);
}
static inline void mutex_unlock(pthread_mutex_t *lock)
{
    assert(pthread_mutex_unlock(lock) == 0);
}
#endif
