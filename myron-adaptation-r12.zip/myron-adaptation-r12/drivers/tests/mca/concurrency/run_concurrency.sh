#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PAYLOAD=${1:?pass the driver payload root containing drivers/}
HWID_HEADERS=${2:-$PAYLOAD/drivers/misc/hwid}
MCA="$PAYLOAD/drivers/power/supply/mca"
BUILD=$(mktemp -d)
trap 'rm -rf -- "$BUILD"' EXIT
"${CC:-gcc}" -std=c11 -O1 -g -Wall -Wextra -Werror -pthread \
  -fsanitize="${MCA_TEST_SANITIZERS:-undefined}" \
  -I"$HERE/include" -I"$MCA/include" -I"$MCA/mca_common" -I"$HWID_HEADERS" \
  "$HERE/test_mca_hwid_concurrency.c" -o "$BUILD/test-mca-hwid-concurrency"
"$BUILD/test-mca-hwid-concurrency"
