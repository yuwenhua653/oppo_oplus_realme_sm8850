#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PAYLOAD=${1:?pass the driver payload root containing drivers/}
HWID_HEADERS=${2:-$PAYLOAD/drivers/misc/hwid}
MCA="$PAYLOAD/drivers/power/supply/mca"
BUILD=$(mktemp -d)
trap 'rm -rf -- "$BUILD"' EXIT
"${CC:-gcc}" -std=c11 -O1 -Wall -Wextra -Werror -pthread -fsanitize=undefined \
  -I"$HERE/include" -I"$MCA/include" -I"$MCA/mca_common" -I"$HWID_HEADERS" \
  "$HERE/test_mca_hwid.c" -o "$BUILD/test-mca-hwid"
"$BUILD/test-mca-hwid"
