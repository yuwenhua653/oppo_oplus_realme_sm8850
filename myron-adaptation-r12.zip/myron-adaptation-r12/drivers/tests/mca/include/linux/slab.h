/* kzalloc/GFP_KERNEL supplied by this host test suite's module.h. */
