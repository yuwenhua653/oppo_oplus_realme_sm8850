#ifndef MYRON_MCA_TEST_MODULE_H
#define MYRON_MCA_TEST_MODULE_H
#include <stddef.h>
#include <stdlib.h>
#define EXPORT_SYMBOL(x)
#define MODULE_DESCRIPTION(x)
#define MODULE_AUTHOR(x)
#define MODULE_LICENSE(x)
#define GFP_KERNEL 0
extern int fail_allocation;
static inline void *kzalloc(size_t size, int flags) {
    (void)flags;
    return fail_allocation ? NULL : calloc(1, size);
}
#endif
