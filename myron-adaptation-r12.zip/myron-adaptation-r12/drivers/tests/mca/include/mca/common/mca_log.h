#ifndef MYRON_MCA_TEST_LOG_H
#define MYRON_MCA_TEST_LOG_H
void test_mca_log(const char *format, ...);
#define mca_log_err(...) test_mca_log(__VA_ARGS__)
#define mca_log_info(...) test_mca_log(__VA_ARGS__)
#endif
