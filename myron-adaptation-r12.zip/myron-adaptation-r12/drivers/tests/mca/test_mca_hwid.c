/* Compile the candidate's actual C and header; no hardware or kernel execution. */
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "mca_hwid.c"
_Static_assert(sizeof(void *) == 8, "layout test requires a 64-bit host");
_Static_assert(sizeof(struct mca_hwid) == 40, "stock record is 40 bytes");
_Static_assert(offsetof(struct mca_hwid, platform_version) == 0, "platform");
_Static_assert(offsetof(struct mca_hwid, country_version) == 4, "country");
_Static_assert(offsetof(struct mca_hwid, major_version) == 8, "major");
_Static_assert(offsetof(struct mca_hwid, minor_version) == 12, "minor");
_Static_assert(offsetof(struct mca_hwid, build_version) == 16, "build");
_Static_assert(offsetof(struct mca_hwid, build_adc) == 20, "stock build ADC");
_Static_assert(offsetof(struct mca_hwid, product_adc) == 24, "stock project ADC");
_Static_assert(offsetof(struct mca_hwid, hwid_value) == 28, "raw hwid");
_Static_assert(offsetof(struct mca_hwid, product_name) == 32, "name pointer");
int fail_allocation;
static uint32_t value[8];
static const char *name_value;
void test_mca_log(const char *format, ...) { (void)format; }
uint32_t get_hw_version_platform(void) { return value[0]; }
uint32_t get_hw_country_version(void) { return value[1]; }
uint32_t get_hw_version_major(void) { return value[2]; }
uint32_t get_hw_version_minor(void) { return value[3]; }
uint32_t get_hw_version_build(void) { return value[4]; }
uint32_t get_hw_build_adc(void) { return value[5]; }
uint32_t get_hw_project_adc(void) { return value[6]; }
uint32_t get_hw_id_value(void) { return value[7]; }
const char *product_name_get(void) { return name_value; }
int main(void) {
    uint32_t raw[8];
    fail_allocation = 1;
    assert(mca_get_hwid_info() == NULL);
    assert(phwid == NULL);
    fail_allocation = 0;
    for (uint32_t project = 0; project < 32; ++project) {
        for (uint32_t country = 0; country < 5; ++country) {
            value[0] = project; value[1] = country;
            value[2] = 3; value[3] = 6; value[4] = 9;
            value[5] = 51310; value[6] = 16691; value[7] = 589830;
            name_value = "myron";
            const struct mca_hwid *info = mca_get_hwid_info();
            assert(info);
            memcpy(raw, info, sizeof(raw));
            assert(memcmp(raw, value, sizeof(raw)) == 0);
            assert(info->product_name == name_value);
            assert(mca_get_hwid_info() == info);
            free(phwid); phwid = NULL;
        }
    }
    puts("MCA hwid stock layout and 160 identity/country cases PASS");
    return 0;
}
