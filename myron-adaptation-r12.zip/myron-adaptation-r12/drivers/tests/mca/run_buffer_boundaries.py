#!/usr/bin/env python3
"""Compile actual candidate log/event function bodies in a bounded host harness."""
import argparse, hashlib, json, os, re, subprocess, tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('payload',type=Path);p.add_argument('--cc',default='gcc');p.add_argument('--report',type=Path);a=p.parse_args()
common=a.payload/'drivers/power/supply/mca/mca_common'
log=(common/'mca_log.c').read_text();event=(common/'mca_event.c').read_text()
def function(s,name):
 m=re.search(r'^(?:static )?(?:void|int)\s+'+re.escape(name)+r'\s*\(',s,re.M);assert m,name
 start=m.start();brace=s.index('{',m.end());depth=1;i=brace+1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[start:i]+'\n'
def record(s,name):
 m=re.search(r'^struct '+name+r'\s*\{.*?^};',s,re.M|re.S);assert m,name;return m[0]+'\n'
harness=r'''
#include <assert.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MCA_EVENT_NOTIFY_SIZE 128
#define MCA_LOG_SINGLE_LOG_MAX_LEN 256
#define MCA_LOG_BUFF_COUNT 20
#define MCA_LOG_BUFF_DEFAULT_COUNT 4
#define PAGE_SIZE 4096
#define GFP_KERNEL 0
#define GFP_ATOMIC 0
#define KOBJ_CHANGE 1
#define pr_err(...) ((void)0)
#define pr_info(...) ((void)0)
#define spin_lock_irqsave(lock, flags) ((void)(lock), (flags)=0)
#define spin_unlock_irqrestore(lock, flags) ((void)(lock), (void)(flags))
#define MCA_LOG_LEVEL_INFO 1
#define MCA_LOG_LEVEL_DEBUG 2
static int g_mca_log_lock;
static unsigned charge_boot_mode;
static int in_interrupt(void) { return 0; }
static void *kzalloc(size_t n, int f) { (void)f; return calloc(1,n); }
static void *kcalloc(size_t n,size_t s,int f) { (void)f; return calloc(n,s); }
#define kfree free
struct device;
struct rtc_time { int tm_hour, tm_min, tm_sec; };
struct mca_event_notify_data { const char *event; int event_len; };
struct mca_event_dev { void *sysfs_ne; };
static struct mca_event_dev event_device = { (void *)(uintptr_t)1 };
static struct mca_event_dev *g_mca_event_dev = &event_device;
static int sent_events;
static unsigned expected_count;
static size_t expected_lengths[2];
static int kobject_uevent_env(void *node,int kind,char **envp) {
 assert(node); assert(kind==KOBJ_CHANGE);
 unsigned n=0;
 for (;envp[n];n++) {
  assert(n<expected_count);
  assert(strlen(envp[n])==expected_lengths[n]);
  for(size_t i=0;i<expected_lengths[n];i++) assert(envp[n][i]=='X');
 }
 assert(n==expected_count);sent_events++;return 0;
}
static int vscnprintf(char *s,size_t n,const char *f,va_list ap) {
 int r=vsnprintf(s,n,f,ap);if(r<0)return 0;
 return n ? (r<(int)n?r:(int)n-1) : 0;
}
static int scnprintf(char *s,size_t n,const char *f,...) {
 va_list ap;va_start(ap,f);int r=vscnprintf(s,n,f,ap);va_end(ap);return r;
}
'''
harness+=record(log,'mca_log_buf_info')+record(log,'mca_cur_time')
harness+='static struct mca_log_buf_info g_mca_log_info;\n'
harness+='static void mca_log_get_cur_time(struct mca_cur_time *tm) { memset(tm,0,sizeof(*tm)); }\n'
for name in ['mca_event_report_uevent','mca_event_report_multiple_uevent']:harness+=function(event,name)
for name in ['mca_log_proc_log_info','__mca_log_err','__mca_log_info','__mca_log_debug']:harness+=function(log,name)
harness+=r'''
static void reset_log(void) {
 free(g_mca_log_info.log_buff);
 for(int i=0;i<MCA_LOG_BUFF_COUNT;i++) free(g_mca_log_info.log_buff_cache[i]);
 memset(&g_mca_log_info,0,sizeof(g_mca_log_info));
 g_mca_log_info.init_flag=1;g_mca_log_info.info_level_flag=1;
 g_mca_log_info.log_level=2;g_mca_log_info.console_level=0;
 g_mca_log_info.max_cache_num=4;
}
int main(void) {
 int log_cases=0,event_cases=0;
 size_t sizes[]={0,1,230,231,232,254,255,256,257,1024,8192};
 for(unsigned i=0;i<sizeof(sizes)/sizeof(sizes[0]);i++) {
  char *s=malloc(sizes[i]+1);assert(s);memset(s,'X',sizes[i]);s[sizes[i]]=0;
  for(int f=0;f<3;f++) {
   reset_log();
   if(f==0)__mca_log_err("[write_log] %s",s);
   if(f==1)__mca_log_info("[write_log] %s",s);
   if(f==2)__mca_log_debug("[write_log] %s",s);
   assert(g_mca_log_info.count>0 && g_mca_log_info.count<256);
   assert(g_mca_log_info.log_buff);log_cases++;
  }
  free(s);
 }
 reset_log();
 char empty[256]={0};
 for(int i=-1;i<=256;i+=(i<0?1:(i==0?256:1))) {
  mca_log_proc_log_info(empty,i,&g_mca_log_info);
  assert(g_mca_log_info.count==0);log_cases++;
 }
 reset_log();
 char buffer[128];memset(buffer,'X',sizeof(buffer));
 int lengths[]={-1,0,1,126,127,128,10000};
 for(unsigned i=0;i<sizeof(lengths)/sizeof(lengths[0]);i++) {
  int len=lengths[i];bool valid=len>=0&&len<128;
  struct mca_event_notify_data data={buffer,len};
  expected_count=1;expected_lengths[0]=(size_t)(len<0?0:len);
  for(int multi=0;multi<2;multi++) {
   int before=sent_events;
   if(multi)mca_event_report_multiple_uevent(&data,1);
   else mca_event_report_uevent(&data);
   assert(sent_events-before==(valid?1:0));event_cases++;
  }
 }
 struct mca_event_notify_data pair[2]={{buffer,3},{buffer,127}};
 expected_count=2;expected_lengths[0]=3;expected_lengths[1]=127;
 int before=sent_events;mca_event_report_multiple_uevent(pair,2);
 assert(sent_events==before+1);event_cases++;
 before=sent_events;mca_event_report_multiple_uevent(pair,0);
 mca_event_report_multiple_uevent(pair,UINT32_MAX);
 assert(sent_events==before);event_cases+=2;
 printf("actual MCA log/event boundary bodies PASS: %d log cases, %d event cases\n",log_cases,event_cases);
 return 0;
}
'''
with tempfile.TemporaryDirectory() as td:
 c=Path(td)/'boundaries.c';exe=Path(td)/'boundaries';c.write_text(harness)
 subprocess.run([a.cc,'-std=c11','-Wall','-Wextra','-Werror','-O1','-g','-fsanitize=address,undefined',str(c),'-o',str(exe)],check=True)
 env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';result=subprocess.run([str(exe)],env=env,check=True,text=True,capture_output=True);print(result.stdout.strip())
 report={'passed':True,'actual_function_bodies':True,'sanitizers':['address','undefined'],'log_cases':36,'event_cases':17,'scope':'Host kernel-service mocks exercise the actual candidate function bodies; no kernel runtime or hardware equivalence claim.','source_sha256':{n:hashlib.sha256((common/n).read_bytes()).hexdigest() for n in ['mca_log.c','mca_event.c']},'stdout':result.stdout.strip()}
 if a.report:a.report.write_text(json.dumps(report,indent=2)+'\n')
