#pragma once
#include <linux/kernel.h>
#define EXPORT_SYMBOL_GPL(symbol)
