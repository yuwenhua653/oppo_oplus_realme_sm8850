#pragma once
#include <linux/kernel.h>
#define GFP_KERNEL 0
static int allocation_fail_after=-1;
static int allocation_balance;
static void *test_allocate(size_t n, bool zero) {
 if (allocation_fail_after == 0) return NULL;
 if (allocation_fail_after > 0) allocation_fail_after--;
 void *result=zero ? calloc(1,n) : malloc(n);
 if (result) allocation_balance++;
 return result;
}
#define kmalloc(n,flags) test_allocate(n,false)
#define kzalloc(n,flags) test_allocate(n,true)
static void test_free(void *ptr) { if (ptr) allocation_balance--; free(ptr); }
#define kfree(ptr) test_free(ptr)
