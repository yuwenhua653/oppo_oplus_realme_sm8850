#pragma once
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#define __kernel
static inline int scnprintf(char *out, size_t n, const char *format, ...) {
 va_list args; va_start(args,format); int result=vsnprintf(out,n,format,args); va_end(args);
 return result >= (int)n ? (int)n-1 : result;
}
