#pragma once
#define EINVAL 22
#define ENOMEM 12
#define E2BIG 7
#define EIO 5
