#pragma once
static inline long long ktime_get_real_seconds(void) { return 1234; }
