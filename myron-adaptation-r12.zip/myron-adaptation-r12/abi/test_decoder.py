#!/usr/bin/env python3
"""Decoder negative controls, independent of optional ELF Python packages."""
import importlib.util,json,struct
from pathlib import Path
here=Path(__file__).resolve().parent
gate=here/'verify_callback_contracts.py'
if not gate.exists():gate=here/'verify_callback_abi.py'
spec=importlib.util.spec_from_file_location('gate',gate);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def code(reg,slot,kcfi):
 return [0xf9400000|(slot//8<<10)|(reg<<5)|reg,0xb85fc010|(reg<<5),0x72800011|((kcfi&0xffff)<<5),0x72a00011|((kcfi>>16)<<5),0x6b11021f,0x54000040,0xd4200000|((0x8220|reg)<<5),0xd63f0000|(reg<<5)]
def parse(words):return g.indirect_calls({'bytes':struct.pack('<'+'I'*len(words),*words),'offset':100})
checks=0
for reg in (8,9,10):
 for slot in (0,8,56,288,528):
  for h in (0,0xffffffff,0xa7f8f8a9,0x33cf4cf6):
   result=parse(code(reg,slot,h));assert len(result)==1 and result[0]['slot']==slot and result[0]['kcfi']==hex(h);checks+=1
base=code(9,56,0x33cf4cf6)
for index,value in [(0,0xd503201f),(1,0xb85fc110),(2,0xd503201f),(3,base[2]),(4,0x6b10021f),(5,0x54000060),(6,0xd4200020)]:
 test=base[:];test[index]=value
 try:parse(test)
 except ValueError:checks+=1
 else:raise AssertionError('accepted malformed guard '+str(index))
# Wrong callback slot / hash remain parseable but compare unequal to pinned contract.
assert parse(code(9,64,0x33cf4cf6))[0]['slot']!=56;checks+=1
assert parse(code(9,56,0x3b959bc7))[0]['kcfi']!='0x33cf4cf6';checks+=1
print(json.dumps({'success':True,'decoder_checks':checks,'scope':'synthetic instruction pattern controls; no compiled-kernel certification'}))
