#!/usr/bin/env python3
"""Fail closed on stock-pinned MCA public and indirect callback KCFI contracts.
Standard library only; bounded ELF64 and AArch64 pattern decoder. This is not a
whole-program disassembler, CRC validator or certification of stock module mixing.
"""
import argparse,hashlib,json,struct,sys
from pathlib import Path

def read_elf(path):
 d=Path(path).read_bytes()
 if d[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',d,18)[0]!=183:raise ValueError('expected AArch64 ELF64')
 off=struct.unpack_from('<Q',d,40)[0];size,count,si=struct.unpack_from('<HHH',d,58)
 if size!=64 or not count or si>=count or off+size*count>len(d):raise ValueError('bad section table')
 sh=[struct.unpack_from('<IIQQQQIIQQ',d,off+i*64) for i in range(count)]
 def data(h):
  a,b=h[4:6]
  if a+b>len(d):raise ValueError('section overflow')
  return d[a:a+b]
 def string(b,i):
  if i>=len(b):raise ValueError('string overflow')
  return b[i:b.index(b'\0',i)].decode()
 names=data(sh[si]);sections={string(names,h[0]):h for h in sh};symbols=[]
 for h in sh:
  if h[1]!=2:continue
  if h[9]!=24 or h[6]>=count:raise ValueError('bad symbols')
  b=data(h);st=data(sh[h[6]])
  if len(b)%24:raise ValueError('bad symbol length')
  for i in range(0,len(b),24):
   n,info,other,index,value,length=struct.unpack_from('<IBBHQQ',b,i)
   symbols.append((string(st,n),info,index,value,length))
 exports={n[10:] for n,inf,ix,v,l in symbols if ix and inf&15!=3 and n.startswith('__ksymtab_')}
 funcs={}
 for n,inf,ix,v,l in symbols:
  if inf&15!=2 or not 0<ix<count:continue
  b=data(sh[ix])
  if v+l>len(b) or v<4:raise ValueError('invalid function bounds '+n)
  funcs[n]={'offset':v,'bytes':b[v:v+l],'kcfi':hex(struct.unpack_from('<I',b,v-4)[0])}
 info={}
 for item in data(sections['.modinfo']).split(b'\0'):
  if b'=' in item:
   k,v=item.decode().split('=',1);info.setdefault(k,[]).append(v)
 return {'sha256':hashlib.sha256(d).hexdigest(),'exports':exports,'functions':funcs,'info':info}

def indirect_calls(func):
 """Read BLR sites guarded by canonical -4 prefix checks; reject unknown forms."""
 b=func['bytes']
 if len(b)%4:raise ValueError('unaligned function')
 words=struct.unpack('<'+'I'*(len(b)//4),b);calls=[]
 for i,w in enumerate(words):
  if w&0xfffffc1f!=0xd63f0000:continue
  reg=(w>>5)&31
  # Clang KCFI: ldur w16,[xN,#-4];movk w17,lo;movk w17,hi,lsl16;
  # cmp w16,w17;b.eq; brk #0x822N;blr xN. Require this exact guard.
  if i<7:raise ValueError('unguarded indirect call')
  guard=words[i-6:i]
  if guard[0]!=(0xb85fc010|(reg<<5)):raise ValueError('unknown KCFI prefix load')
  parts={}
  for m in guard[1:3]:
   if m&0xff80001f!=0x72800011:raise ValueError('unknown KCFI immediate')
   shift=((m>>21)&3)*16
   if shift not in (0,16) or shift in parts:raise ValueError('duplicate KCFI halfword')
   parts[shift]=(m>>5)&0xffff
  if set(parts)!={0,16}:raise ValueError('incomplete KCFI hash')
  if guard[3]!=0x6b11021f or guard[4]!=0x54000040 or guard[5]!=(0xd4200000|((0x8220|reg)<<5)):raise ValueError('unknown KCFI comparison/trap')
  # Nearest LDR into BLR register is the concrete callback-table slot.
  load=None
  for j in range(i-7,-1,-1):
   q=words[j]
   if q&0xffc0001f==(0xf9400000|reg):
    load={'slot':((q>>10)&0xfff)*8,'base_register':(q>>5)&31};break
  if load is None:raise ValueError('callback pointer load not found')
  calls.append({'slot':load['slot'],'kcfi':hex(parts[0]|(parts[16]<<16)),'call_offset':func['offset']+i*4})
 return calls

def audit(objects,contract,stage="full"):
 rows=[];errors=[]
 for module in contract['modules']:
  if stage not in module.get('stages',['soc','full']):continue
  paths=[p for p in Path(objects).rglob('*.ko') if p.stem.replace('-','_')==module['name']]
  if len(paths)!=1:errors.append(module['name']+': expected exactly one module');continue
  e=read_elf(paths[0]);bad=[];pub=[];callbacks=[]
  if e['info'].get('name')!=[module['name']]:bad.append('module name')
  for name,expected in module['public_function_kcfi'].items():
   got=e['functions'].get(name,{}).get('kcfi');ok=got==expected and name in e['exports']
   pub.append({'function':name,'expected':expected,'actual':got,'match':ok})
   if not ok:bad.append('public KCFI '+name)
  for name,expected in module['callbacks'].items():
   if name not in e['functions']:bad.append('missing callback wrapper '+name);continue
   try:actual=[{k:v for k,v in x.items() if k!='call_offset'} for x in indirect_calls(e['functions'][name])]
   except ValueError as exc:bad.append(name+': '+str(exc));continue
   ok=actual==expected;callbacks.append({'function':name,'expected':expected,'actual':actual,'match':ok})
   if not ok:bad.append('callback slot/KCFI '+name)
  errors.extend(module['name']+': '+x for x in bad)
  rows.append({'name':module['name'],'path':str(paths[0]),'sha256':e['sha256'],'public_functions_checked':len(pub),'callback_sites_checked':sum(len(x['actual']) for x in callbacks),'public_functions':pub,'callbacks':callbacks,'errors':bad,'scope':module['scope']})
 return {'schema':1,'success':not errors,'errors':errors,'modules':rows,'contract_stock_sha256':{m['name']:m['stock_sha256'] for m in contract['modules']},'limits':['Type-hash equality does not prove implementation or hardware semantics.','Same-build module CRC/provider checks remain separately required.','IR, ST54SE and ACK TLS have no enforced stock public callback ABI here; presence only.','No claim that stock binary modules can load into this kernel.']}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--objects',type=Path);ap.add_argument('--artifacts',type=Path);ap.add_argument('--stage',choices=['soc','full'],default='full');ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('stock-callback-contract.json'));ap.add_argument('--output','--report',dest='output',type=Path,required=True);a=ap.parse_args()
 if (a.objects is None)==(a.artifacts is None):ap.error('choose exactly one of --objects or --artifacts')
 objects=a.objects if a.objects is not None else a.artifacts/'objects'
 try:
  contract=json.loads(a.contract.read_text());r=audit(objects,contract,a.stage)
 except (OSError,ValueError,KeyError,TypeError,IndexError,struct.error) as exc:
  r={'schema':1,'success':False,'errors':[type(exc).__name__+': '+str(exc)],'modules':[]}
 r['stage']=a.stage
 r['contract_sha256']=hashlib.sha256(a.contract.read_bytes()).hexdigest() if a.contract.is_file() else None
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'success':r['success'],'errors':r['errors'],'public_functions':sum(m['public_functions_checked'] for m in r['modules']),'callback_sites':sum(m['callback_sites_checked'] for m in r['modules'])}));return 0 if r['success'] else 1
if __name__=='__main__':sys.exit(main())
