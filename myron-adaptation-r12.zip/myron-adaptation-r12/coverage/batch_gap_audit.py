#!/usr/bin/env python3
"""Compare sanitized stock module names/contracts with a new selected build.

No phone access or source/ELF execution. --build reuses the existing coverage
analyzer's manifest, selection and ELF checks; --build-json is metadata-only.
Same-name coverage is never an ABI, boot, hardware or partition certificate.
"""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

NAME = re.compile(r'[A-Za-z0-9_]+\Z')

def normalize(s):
    if not isinstance(s, str): raise ValueError('Module name must be a string')
    s = s.replace('-', '_')
    if not NAME.fullmatch(s): raise ValueError('Invalid module name')
    return s

def group(n):
    if n in {'hwid','miev'}: return 'foundation_identity_and_events'
    if n.startswith('mca_') or n in {'bq27z561','hl7603','nuvolta_1671','sc7601','sc8531','sc8581','sc96281_charger','charger_partition','qcom_adsp_pd_protocol','mi_thermal_interface'}: return 'charge_battery_thermal'
    for category, names in {
        'touch': {'xiaomi_touch','focaltech_touch_3683'},
        'external_audio_amplifier': {'cs35l43_dlkm','tas25xx_dlkm','tfa98xx_dlkm'},
        'camera_oem_extensions': {'mi_cam','cameralog','cameramsger'},
        'nfc_secure_element': {'stm_nfc_i2c','stm_st54se_gpio'},
        'tee_oem_extension': {'mitee_dlkm'},
        'infrared_and_auxiliary_gpio': {'ir_spi','gpio_mi_t1'},
        'generic_kernel_config_candidates': {'tls','mtdoops'},
        'probable_module_packaging_difference': {'qcom_tzmem'},
    }.items():
        if n in names: return category
    return 'other_oem_services_performance_debug_or_unclassified'

def compare(stock, build, input_evidence):
    if stock.get('schema_version') != 1: raise ValueError('Unsupported stock schema')
    loaded = {normalize(n) for n in stock['loaded_names']}
    originals = {normalize(m['name']): m for m in stock['modules']}
    if len(originals) != len(stock['modules']): raise ValueError('Duplicate stock names')
    candidates = {}
    for m in build['selected_modules']:
        name = normalize(m['name'])
        if name in candidates: raise ValueError('Unresolved duplicate selected module: ' + name)
        for key in ('depends','aliases','softdeps'):
            if not isinstance(m.get(key),list): raise ValueError('Missing/list metadata: ' + key)
        candidates[name] = m
    builtins = {normalize(n) for n in build.get('builtin_name_hints', [])}
    wanted = set(originals) | loaded
    rows, groups = [], collections.defaultdict(list)
    for name in sorted(wanted):
        orig, cand = originals.get(name), candidates.get(name)
        status = ('same_name_built_candidate' if cand else
                  'builtin_name_hint_requires_review' if name in builtins else 'no_same_name_candidate')
        deps = sorted({normalize(dep) for v in orig['variants'] for dep in v['depends']}) if orig else None
        alias = sorted({a for v in orig['variants'] for a in v['aliases']}) if orig else None
        row = {'name':name,'loaded_in_reference':name in loaded,'original_file_available':bool(orig and orig['variants']),
               'coverage_state':status,'group':group(name),'stock_dependency_names_union':deps,
               'stock_depends_without_same_name_candidate':sorted(set(deps or [])-set(candidates)-builtins),
               'candidate_depends':cand['depends'] if cand else None,
               'stock_aliases_union':alias,'candidate_aliases':cand['aliases'] if cand else None,
               'alias_sets_equal':set(alias or [])==set(cand['aliases']) if cand and orig else None,
               'stock_equivalence_verified':False}
        rows.append(row)
        if status == 'no_same_name_candidate': groups[group(name)].append(name)
    stages = {}
    for stage, names in stock['load_sets'].items():
        s = {normalize(n) for n in names}
        stages[stage] = {'stock_explicit_names':len(s),'same_name_candidates':len(s & set(candidates)),
                        'builtin_hints':sorted((s-set(candidates)) & builtins),
                        'no_same_name_candidates':sorted(s-set(candidates)-builtins),
                        'source_partition_assignment_verified':False,'actual_execution_order_known':False}
    absent = [{'requester':n,'dependency':normalize(dep)} for n,m in sorted(candidates.items())
              for dep in m['depends'] if normalize(dep) not in candidates and normalize(dep) not in builtins]
    return {'schema_version':1,'scope':'Static names and metadata coverage; not source availability, ABI, partition, boot, driver binding or hardware equivalence.',
            'input_evidence':input_evidence,'stock_inventory_sha256':input_evidence['stock_sha256'],
            'build_kernel_release':build.get('kernel_release'),'selection_policy':build.get('selection_policy'),
            'counts':{'stock_names':len(wanted),'loaded_reference_names':len(loaded),'selected_candidate_names':len(candidates),
                      'same_name_candidate_names':sum(x['coverage_state']=='same_name_built_candidate' for x in rows),
                      'missing_same_name_candidates':sum(x['coverage_state']=='no_same_name_candidate' for x in rows),
                      'loaded_missing_same_name_candidates':sum(x['loaded_in_reference'] and x['coverage_state']=='no_same_name_candidate' for x in rows),
                      'loaded_without_original_file':sum(n not in originals or not originals[n]['variants'] for n in loaded),
                      'selected_candidate_hard_dependencies_absent_by_name':len(absent)},
            'remaining_group_counts':{k:len(v) for k,v in sorted(groups.items())},'remaining_groups':dict(sorted(groups.items())),
            'load_stages':stages,'candidate_hard_dependencies_absent_by_name':absent,'modules':rows,
            'loading_order_resolved':False,'source_partition_dependency_closure_verified':False,
            'stock_equivalence_verified':False,'hardware_tested':False,'flashable':False,
            'caveats':['Missing module name may represent a built-in or merged provider; inspect config and exported contracts.',
                       'Dependencies from stock variants are unioned for review, not prescribed as new source dependencies.',
                       'Runtime loaded names do not identify original file provider or actual loading/probe order.',
                       'All previous missing original files were recovered from vendor_boot; an original file gap is reported separately.',
                       'The stock generic loader uses parallel modprobe and system find scanning; old lists are reference inputs, not a new autoload policy.']}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stock',type=Path,required=True)
    src=p.add_mutually_exclusive_group(required=True)
    src.add_argument('--build',type=Path,help='Build ZIP/directory with artifact-manifest.json and module-selection.json')
    src.add_argument('--build-json',type=Path,help='Existing coverage JSON (build field) or normalized build_inventory JSON; metadata-only')
    p.add_argument('--coverage-tool',type=Path,help='Existing compare-myron-coverage.py for --build; its module_selection_policy.py must be alongside it')
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(); raw=a.stock.read_bytes(); stock=json.loads(raw)
    evidence={'stock_sha256':hashlib.sha256(raw).hexdigest(),'build_input_kind':'metadata_only','build_manifest_verified_in_this_invocation':False}
    if a.build:
        if not a.coverage_tool: p.error('--build requires --coverage-tool')
        sys.path.insert(0,str(a.coverage_tool.resolve().parent))
        spec=importlib.util.spec_from_file_location('myron_existing_coverage',a.coverage_tool)
        mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        view=mod.Input(a.build)
        try: build=mod.build_inventory(view)
        finally:
            if view.archive: view.archive.close()
        evidence.update(build_input_kind='manifest_and_binary_validation',build_manifest_verified_in_this_invocation=True,
                        manifest_verified_files=build['manifest_verified_files'])
    else:
        raw=a.build_json.read_bytes();build=json.loads(raw);build=build.get('build',build)
        evidence['build_metadata_sha256']=hashlib.sha256(raw).hexdigest()
    result=compare(stock,build,evidence)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'counts':result['counts'],'remaining_group_counts':result['remaining_group_counts'],'out':str(a.out)},indent=2))
if __name__=='__main__':main()
