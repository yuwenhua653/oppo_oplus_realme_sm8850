#!/usr/bin/env python3
"""Select diagnostic QCOM module candidates, retaining all built originals.

The pinned QCOM build excludes its zram/zsmalloc GKI counterparts from the
runtime distribution. This policy is deliberately limited to the two verified
output pairs. It is not an autoload list or a flashable partition manifest.
"""
import collections
import json
from pathlib import PurePosixPath
import re

POLICY = "myron-qcom-zram-v1"
BASE = "bazel-out/aarch64-fastbuild/bin/"
OVERRIDES = {
    "zram": {
        "reference": BASE + "common/kernel_aarch64/drivers/block/zram/zram.ko",
        "selected": BASE + "vendor/qcom/sm8850/canoe_perf/drivers/block/zram/zram/zram.ko",
    },
    "zsmalloc": {
        "reference": BASE + "common/kernel_aarch64/mm/zsmalloc.ko",
        "selected": BASE + "vendor/qcom/sm8850/canoe_perf/mm/zsmalloc/zsmalloc.ko",
    },
}
NOTE = ("Diagnostic candidate selection only: all originals remain in objects/. "
        "Not a module autoload list, partition layout, flash package, or hardware validation.")


def build_selection(modules):
    """Return a selection bound to every input file's path, name, hash and vermagic."""
    modules = sorted(modules, key=lambda item: item["file"])
    if not modules:
        raise ValueError("No modules to select")
    by_name = collections.defaultdict(list)
    files = set()
    for module in modules:
        filename = module["file"]
        path = PurePosixPath(filename)
        if path.is_absolute() or ".." in path.parts or str(path) != filename or path.suffix != ".ko":
            raise ValueError("Unsafe or noncanonical module path: " + filename)
        if filename in files:
            raise ValueError("Repeated module path: " + filename)
        if not re.fullmatch(r"[0-9a-f]{64}", module["sha256"]):
            raise ValueError("Invalid module SHA256: " + filename)
        if not module["vermagic"].strip():
            raise ValueError("Missing module vermagic: " + filename)
        files.add(filename)
        by_name[module["name"]].append(module)
    excluded = []
    for name, expected in OVERRIDES.items():
        pair = by_name.get(name, [])
        if len(pair) != 2 or {item["file"] for item in pair} != set(expected.values()):
            raise ValueError("Expected exactly the pinned common/QCOM pair for " + name)
        if len({item["vermagic"] for item in pair}) != 1:
            raise ValueError("Common/QCOM vermagic differs for " + name)
        excluded.append({
            "file": expected["reference"], "name": name,
            "selected_instead": expected["selected"],
            "reason": "Pinned QCOM module override; retain the GKI original for reference only.",
        })
    # Never turn this policy into a blanket duplicate exception.
    for name, group in by_name.items():
        if name not in OVERRIDES and len({item["sha256"] for item in group}) > 1:
            raise ValueError("Unapproved conflicting duplicate module: " + name)
    excluded_files = {item["file"] for item in excluded}
    return {
        "schema_version": 1, "policy": POLICY,
        "flashable": False, "hardware_tested": False, "note": NOTE,
        "all_built": [{key: item[key] for key in ("file", "name", "sha256", "vermagic")}
                      for item in modules],
        "selected": [item["file"] for item in modules if item["file"] not in excluded_files],
        "excluded": sorted(excluded, key=lambda item: item["file"]),
    }


def validate_selection(modules, selection):
    """Reject stale hashes, extra exclusions, path substitutions or missing inputs."""
    expected = build_selection(modules)
    if selection != expected:
        raise ValueError("Selection manifest differs from the explicit pinned policy or current module files")
    wanted = set(expected["selected"])
    return [module for module in modules if module["file"] in wanted]


