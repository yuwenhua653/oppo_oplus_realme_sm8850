#!/usr/bin/env python3
"""Offline module coverage inventory, not ABI or device compatibility certification.

Python 3 standard library only. Inputs are read as data and never extracted or
executed. --build is optional; omit it to inventory a newly collected baseline.
"""
import argparse
import collections
import csv
import gzip
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import sys
import tarfile
import zipfile
import zlib

from module_selection_policy import validate_selection

MAX_FILES = 30000
MAX_FILE = 256 * 1024 * 1024
MAX_TOTAL = 3 * 1024 * 1024 * 1024
MAX_MODULE = 128 * 1024 * 1024
MAX_TEXT = 32 * 1024 * 1024
MODULE_SUFFIXES = ('.ko', '.ko.gz', '.ko.xz', '.ko.zst')
HEX = re.compile(r'[0-9a-f]{64}\Z')
NAME = re.compile(r'[A-Za-z0-9_]+\Z')
SCOPE = ('Same-name coverage candidates only. No symbol CRC, signature trust, firmware, '
         'device-tree, partition layout, or hardware compatibility certification. '
         'Never copy old OEM modules into the newly built kernel module set.')


def safe_name(value):
    if not isinstance(value, str) or not value or '\\' in value or '\x00' in value:
        raise ValueError('Unsafe input path: ' + repr(value))
    if value.startswith('/') or '..' in value.split('/') or re.match(r'^[A-Za-z]:', value):
        raise ValueError('Unsafe input path: ' + repr(value))
    normalized = str(PurePosixPath(value))
    if normalized in ('', '.'):
        raise ValueError('Empty input path')
    return normalized


class Input:
    """Bounded read-only archive/directory view. No archive extraction."""
    def __init__(self, path):
        self.path = Path(path)
        self.files = {}
        self.archive = None
        self.total = 0
        if self.path.is_symlink():
            raise ValueError('Input root must not be a symlink')
        if self.path.is_dir():
            entry_count = 0
            for base, dirs, files in os.walk(self.path, followlinks=False):
                entry_count += len(dirs) + len(files)
                if entry_count > MAX_FILES:
                    raise ValueError("Directory entry count exceeds limit")
                for child in dirs + files:
                    p = Path(base) / child
                    mode = p.lstat().st_mode
                    if stat.S_ISLNK(mode) or not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                        raise ValueError('Symlink or special file rejected: ' + str(p))
                    if stat.S_ISREG(mode):
                        if p.stat().st_nlink > 1:
                            raise ValueError('Hardlinked input file rejected: ' + str(p))
                        self._add(str(p.relative_to(self.path)).replace(os.sep, '/'), p.stat().st_size, p)
        elif zipfile.is_zipfile(self.path):
            self.archive = zipfile.ZipFile(self.path)
            if len(self.archive.infolist()) > MAX_FILES:
                raise ValueError('Archive member count exceeds limit')
            seen = set()
            for member in self.archive.infolist():
                if member.filename.rstrip('/') in ('', '.'):
                    continue
                name = safe_name(member.filename)
                if name in seen:
                    raise ValueError('Repeated archive member: ' + name)
                seen.add(name)
                mode = member.external_attr >> 16
                kind = stat.S_IFMT(mode)
                if kind not in (0, stat.S_IFREG, stat.S_IFDIR) or member.flag_bits & 1:
                    raise ValueError('Symlink, special, or encrypted ZIP entry rejected: ' + name)
                if not member.is_dir():
                    self._add(name, member.file_size, member)
        elif tarfile.is_tarfile(self.path):
            self.archive = tarfile.open(self.path, 'r:*')
            seen = set()
            for index, member in enumerate(self.archive):
                if index >= MAX_FILES:
                    raise ValueError('Archive member count exceeds limit')
                if member.name.rstrip('/') in ('', '.'):
                    continue
                name = safe_name(member.name)
                if name in seen:
                    raise ValueError('Repeated archive member: ' + name)
                seen.add(name)
                if member.isdir():
                    continue
                if not member.isfile() or getattr(member, 'sparse', None):
                    raise ValueError('Link or special TAR entry rejected: ' + name)
                self._add(name, member.size, member)
        else:
            raise ValueError('Input must be a directory, ZIP, or TAR archive: ' + str(path))
        if not self.files:
            raise ValueError('Input contains no regular files')

    def _add(self, name, size, handle):
        name = safe_name(name)
        if name in self.files:
            raise ValueError('Repeated file: ' + name)
        self.total += size
        if size < 0 or size > MAX_FILE or self.total > MAX_TOTAL or len(self.files) >= MAX_FILES:
            raise ValueError('Input exceeds file/count/total size limits')
        self.files[name] = (size, handle)

    def open(self, name):
        if name not in self.files:
            raise ValueError('Required file missing: ' + name)
        handle = self.files[name][1]
        if self.archive is None:
            if handle.is_symlink() or not handle.is_file():
                raise ValueError('Input file changed type: ' + name)
            return handle.open('rb')
        if isinstance(self.archive, zipfile.ZipFile):
            return self.archive.open(handle)
        return self.archive.extractfile(handle)

    def read(self, name, limit=MAX_FILE):
        if name not in self.files:
            raise ValueError('Required file missing: ' + name)
        if self.files[name][0] > limit:
            raise ValueError('File exceeds read limit: ' + name)
        with self.open(name) as stream:
            data = stream.read(limit + 1)
        if len(data) > limit or len(data) != self.files[name][0]:
            raise ValueError('File size changed or exceeds read limit: ' + name)
        return data

    def sha(self, name):
        digest = hashlib.sha256()
        count = 0
        with self.open(name) as stream:
            while True:
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                if count > self.files[name][0] or count > MAX_FILE:
                    raise ValueError('Input changed or exceeds limit: ' + name)
                digest.update(chunk)
        if count != self.files[name][0]:
            raise ValueError('Unexpected input size: ' + name)
        return digest.hexdigest()

    def text(self, name):
        return self.read(name, MAX_TEXT).decode('utf-8')

    def unique(self, basename):
        found = [p for p in self.files if PurePosixPath(p).name == basename]
        if len(found) != 1:
            raise ValueError('Expected exactly one ' + basename + ', found ' + str(len(found)))
        return found[0]

    def __del__(self):
        archive = getattr(self, 'archive', None)
        if archive is not None:
            archive.close()

    def close(self):
        if self.archive is not None:
            self.archive.close()


def normalize(name):
    name = name.replace('-', '_')
    if not NAME.fullmatch(name):
        raise ValueError('Invalid module name: ' + repr(name))
    return name


def module_name_from_path(value):
    value = PurePosixPath(value).name
    for suffix in ('.gz', '.xz', '.zst'):
        if value.endswith(suffix):
            value = value[:-len(suffix)]
    if value.endswith('.ko'):
        value = value[:-3]
    return normalize(value)


def module_info(data, path):
    stored_sha = hashlib.sha256(data).hexdigest()
    if path.endswith('.zst'):
        raise ValueError('unsupported_compression: .ko.zst needs a separate trusted zstd decompression step')
    if path.endswith(('.gz', '.xz')):
        opener = gzip.open if path.endswith('.gz') else lzma.open
        with opener(io.BytesIO(data), 'rb') as stream:
            data = stream.read(MAX_MODULE + 1)
    if len(data) > MAX_MODULE:
        raise ValueError('Decompressed module exceeds limit')
    if len(data) < 64 or data[:7] != b'\x7fELF\x02\x01\x01':
        raise ValueError('Expected ELF64 little-endian module')
    if struct.unpack_from('<HH', data, 16) != (1, 183):
        raise ValueError('Expected AArch64 ET_REL module')
    offset = struct.unpack_from('<Q', data, 40)[0]
    size, count, names_index = struct.unpack_from('<HHH', data, 58)
    if size != 64 or offset + 64 > len(data):
        raise ValueError('Invalid ELF section table')
    first = struct.unpack_from('<IIQQQQIIQQ', data, offset)
    count = count or first[5]
    names_index = first[6] if names_index == 0xffff else names_index
    if not count or count > 65536 or offset + count * size > len(data) or names_index >= count:
        raise ValueError('Invalid ELF section count/string table')
    sections = [struct.unpack_from('<IIQQQQIIQQ', data, offset + i * size) for i in range(count)]

    def contents(section):
        start, length = section[4:6]
        if start + length > len(data):
            raise ValueError('ELF section extends past end of file')
        return data[start:start + length]

    names = contents(sections[names_index])
    metadata = []
    for section in sections:
        start = section[0]
        end = names.find(b'\0', start)
        if start >= len(names) or end < 0:
            raise ValueError('Invalid ELF section name')
        if names[start:end] == b'.modinfo':
            metadata.append(contents(section))
    if len(metadata) != 1:
        raise ValueError('Expected exactly one .modinfo section')
    fields = collections.defaultdict(list)
    for entry in metadata[0].split(b'\0'):
        if b'=' in entry:
            key, value = entry.decode('utf-8').split('=', 1)
            fields[key].append(value)
    for field in ('name', 'vermagic'):
        if len(fields[field]) != 1 or not fields[field][0].strip():
            raise ValueError('Missing or ambiguous .modinfo ' + field)
    return {'name': normalize(fields['name'][0]), 'sha256': hashlib.sha256(data).hexdigest(),
            'stored_sha256': stored_sha, 'vermagic': ' '.join(fields['vermagic'][0].split()),
            'depends': sorted({normalize(d.strip()) for value in fields.get('depends', [])
                               for d in value.split(',') if d.strip()}),
            'aliases': fields.get('alias', []), 'softdeps': fields.get('softdep', []),
            'compression': 'gzip' if path.endswith('.gz') else 'xz' if path.endswith('.xz') else 'none'}


def tsv(value):
    return list(csv.DictReader(io.StringIO(value), delimiter='\t'))


def partition(path):
    root = path.lstrip('/').split('/')[0]
    if root in ('vendor_dlkm', 'system_dlkm', 'odm_dlkm', 'vendor', 'odm', 'system'):
        return root
    if root in ('lib', 'first_stage_ramdisk'):
        return 'ramdisk_or_rootfs'
    return root or 'unknown'


def kmi(release):
    match = re.search(r'^(\d+\.\d+)\.\d+-android(\d+)-(\d+)(?:-|$)', release)
    return {'kernel_family': match[1], 'android': int(match[2]), 'generation': int(match[3])} if match else None


def baseline_inventory(view):
    manifest_name = view.unique('manifest.tsv')
    root = str(PurePosixPath(manifest_name).parent)
    root = '' if root == '.' else root + '/'
    required = ['SHA256SUMS', 'metadata/kernel-release.txt', 'metadata/proc-modules.txt',
                'metadata/status.txt', 'metadata/root-map.tsv', 'metadata/availability.tsv']
    for rel in required:
        if root + rel not in view.files:
            raise ValueError('Required baseline metadata missing: ' + rel)
    sums = {}
    for line in view.text(root + 'SHA256SUMS').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64}) [ *](.+)', line)
        if not match:
            raise ValueError('Invalid SHA256SUMS line')
        rel = safe_name(match[2])
        if rel in sums or rel == 'SHA256SUMS':
            raise ValueError('Duplicate or self-referential baseline checksum')
        sums[rel] = match[1]
    all_files = {p[len(root):] for p in view.files if p.startswith(root)} - {'SHA256SUMS'}
    if set(sums) != all_files:
        raise ValueError('Baseline SHA256SUMS does not cover every regular file exactly')
    for rel, expected in sums.items():
        if view.sha(root + rel) != expected:
            raise ValueError('Baseline checksum mismatch: ' + rel)
    rows = tsv(view.text(manifest_name))
    by_archive = {}
    special_sources = {'/sys/firmware/fdt': 'metadata/live-fdt.dtb',
                       '/proc/device-tree/compatible': 'metadata/device-tree-compatible.bin',
                       '/proc/device-tree/model': 'metadata/device-tree-model.bin'}
    for row in rows:
        if not {'source_path', 'archive_path', 'bytes', 'sha256'} <= set(row):
            raise ValueError('Invalid baseline manifest columns')
        rel = safe_name(row['archive_path'])
        source = row['source_path']
        if not source.startswith('/') or safe_name(source[1:]) != source[1:] or rel != special_sources.get(source, 'files/' + source[1:]):
            raise ValueError('Invalid baseline source mapping: ' + source)
        if rel in by_archive or not HEX.fullmatch(row['sha256']):
            raise ValueError('Repeated manifest file or invalid hash')
        if root + rel not in view.files or int(row['bytes']) != view.files[root + rel][0] or sums.get(rel) != row['sha256']:
            raise ValueError('Baseline manifest mismatch: ' + rel)
        by_archive[rel] = row
    source_files = {p[len(root):] for p in view.files if p.startswith(root + 'files/')}
    if {p for p in by_archive if p.startswith('files/')} != source_files:
        raise ValueError('Baseline manifest does not cover every files/ object exactly')
    status = dict(line.split('=', 1) for line in view.text(root + 'metadata/status.txt').splitlines() if '=' in line)
    if status.get('status') not in ('COMPLETE', 'INCOMPLETE'):
        raise ValueError('Missing or invalid collection status')
    release = view.text(root + 'metadata/kernel-release.txt').strip()
    if not release or len(release.split()) != 1:
        raise ValueError('Invalid baseline kernel release')
    availability = tsv(view.text(root + 'metadata/availability.tsv'))
    proc_status = [row for row in availability if row.get('source') in ('proc-modules.txt', '/proc/modules', 'metadata/proc-modules.txt')]
    loaded_snapshot_available = len(proc_status) == 1 and proc_status[0].get('status') == 'OK' and proc_status[0].get('exit_code') == '0'
    loaded = {}
    for line in view.text(root + 'metadata/proc-modules.txt').splitlines():
        parts = line.split()
        if len(parts) < 6 or not parts[1].isdigit() or not parts[2].isdigit():
            raise ValueError('Malformed /proc/modules row: ' + line)
        name = normalize(parts[0])
        if name in loaded:
            raise ValueError('Duplicate /proc/modules name: ' + name)
        loaded[name] = {'bytes': int(parts[1]), 'use_count': int(parts[2]), 'state': parts[4]}
    mappings = tsv(view.text(root + 'metadata/root-map.tsv'))
    def real_source(source):
        applicable = [m for m in mappings if m.get('status') in ('OK', 'ok', 'RESOLVED') and
                      (source == m.get('logical_root') or source.startswith(m.get('logical_root', '\0') + '/'))]
        if not applicable:
            return source
        m = max(applicable, key=lambda item: len(item['logical_root']))
        return m['resolved_root'].rstrip('/') + source[len(m['logical_root']):]
    modules, errors = [], []
    if not loaded_snapshot_available:
        errors.append({'kind': 'loaded_snapshot_unavailable', 'availability': proc_status})
    for rel, row in sorted(by_archive.items()):
        if rel.endswith(MODULE_SUFFIXES):
            try:
                info = module_info(view.read(root + rel), rel)
                modules.append(dict(file=rel, source_path=row['source_path'], resolved_path=real_source(row['source_path']),
                                    partition=partition(row['source_path']), loaded=(info['name'] in loaded) if loaded_snapshot_available else None, **info))
            except (ValueError, OSError, EOFError, lzma.LZMAError, zlib.error, struct.error) as exc:
                errors.append({'file': rel, 'kind': 'unsupported_module' if 'unsupported_compression' in str(exc) else 'invalid_module', 'error': str(exc)})
    if not modules:
        errors.append({'kind': 'no_parseable_modules'})
    identities = collections.defaultdict(list)
    by_name = collections.defaultdict(list)
    for module in modules:
        identities[module['resolved_path']].append(module)
        by_name[module['name']].append(module)
    for source, group in identities.items():
        if len({m['sha256'] for m in group}) != 1:
            errors.append({'kind': 'physical_path_hash_conflict', 'resolved_path': source})
    load_lists, unresolved, builtin_names = [], [], set()
    metadata_files = []
    for rel in sorted(source_files):
        basename = PurePosixPath(rel).name
        if not basename.startswith('modules.'):
            continue
        metadata_files.append(rel)
        if not (basename.startswith('modules.load') or basename == 'modules.order' or basename == 'modules.builtin'):
            continue
        entries = []
        for line_number, line in enumerate(view.text(root + rel).splitlines(), 1):
            value = line.split('#', 1)[0].strip()
            if not value:
                continue
            try:
                if len(value.split()) != 1:
                    raise ValueError('expected one module per line')
                name = module_name_from_path(value)
            except ValueError as exc:
                unresolved.append({'file': rel, 'line': line_number, 'entry': value, 'reason': str(exc)})
                continue
            if basename == 'modules.builtin':
                builtin_names.add(name)
                entries.append({'line': line_number, 'entry': value, 'name_hint': name, 'builtin': True})
                continue
            # Preserve paths and order. A basename/name match is only a lookup hint;
            # a duplicate identity must never be silently resolved by filename.
            candidates = [m for m in modules if (m['source_path'] == value or
                          m['source_path'] == '/' + str(PurePosixPath(rel[6:]).parent / value))]
            method = 'path'
            if not candidates:
                candidates = by_name.get(name, [])
                method = 'name_hint'
            identities_found = sorted({m['resolved_path'] for m in candidates})
            entry = {'line': line_number, 'entry': value, 'name_hint': name,
                     'resolution': method, 'resolved_paths': identities_found}
            if len(identities_found) != 1:
                unresolved.append(dict(file=rel, **entry, reason='missing' if not candidates else 'ambiguous_identity'))
            entries.append(entry)
        load_lists.append({'file': rel, 'kind': basename, 'entries': entries})
    if not any(PurePosixPath(p).name.startswith('modules.load') for p in source_files):
        errors.append({'kind': 'no_modules_load_metadata'})
    if status['status'] != 'COMPLETE':
        errors.append({'kind': 'collection_incomplete', 'status': status})
    unresolved_runtime_load = [entry for entry in unresolved
                               if PurePosixPath(entry['file']).name.startswith('modules.load')]
    if unresolved_runtime_load:
        errors.append({'kind': 'unresolved_runtime_load_entries', 'count': len(unresolved_runtime_load)})
    missing_loaded = sorted(set(loaded) - set(by_name))
    if missing_loaded:
        errors.append({'kind': 'loaded_module_files_not_parsed', 'names': missing_loaded})
    return {'kernel_release': release, 'kmi': kmi(release), 'collection_status': status,
            'hash_verification': 'all_regular_files', 'modules': modules, 'loaded': loaded,
            'loaded_snapshot_available': loaded_snapshot_available,
            'loaded_not_collected_or_unparseable': missing_loaded, 'root_map': mappings,
            'availability': availability,
            'module_metadata_files': metadata_files, 'load_and_order': load_lists,
            'unresolved_load_or_order': unresolved, 'load_resolution_complete': not unresolved_runtime_load, 'required_missing': tsv(view.text(root + 'metadata/required-missing.tsv')) if root + 'metadata/required-missing.tsv' in view.files else [], 'builtin_name_hints': sorted(builtin_names),
            'duplicate_names': [{'name': name, 'paths': [m['source_path'] for m in group],
                                 'resolved_identities': sorted({m['resolved_path'] for m in group}),
                                 'distinct_module_hashes': len({m['sha256'] for m in group})}
                                for name, group in sorted(by_name.items()) if len(group) > 1],
            'errors': errors}


def build_inventory(view):
    manifest_file = view.unique('artifact-manifest.json')
    root = str(PurePosixPath(manifest_file).parent)
    root = '' if root == '.' else root + '/'
    manifest = json.loads(view.text(manifest_file))
    if manifest.get('stage') not in ('full', 'soc') or manifest.get('missing_required_outputs') != []:
        raise ValueError('Build artifact stage is unsupported or required outputs are missing')
    items, seen = manifest.get('files', []), set()
    if not items:
        raise ValueError('Empty build artifact manifest')
    modules = []
    releases, builtins = [], set()
    for item in items:
        rel = safe_name(item['file'])
        source = safe_name(item['source'])
        if rel != 'objects/' + source or rel in seen or not HEX.fullmatch(item['sha256']):
            raise ValueError('Invalid artifact manifest path/hash: ' + rel)
        seen.add(rel)
        key = root + rel
        if key not in view.files or view.files[key][0] != item['bytes'] or view.sha(key) != item['sha256']:
            raise ValueError('Artifact manifest size/hash mismatch: ' + rel)
        if rel.endswith(MODULE_SUFFIXES):
            info = module_info(view.read(key), rel)
            modules.append(dict(file=source, **info))
        if '/common/kernel_aarch64/' in source:
            if PurePosixPath(source).name == 'kernel.release':
                releases.append(view.text(key).strip())
            if PurePosixPath(source).name == 'modules.builtin':
                for line in view.text(key).splitlines():
                    if line.strip():
                        builtins.add(module_name_from_path(line.strip()))
    actual_objects = {p[len(root):] for p in view.files if p.startswith(root + 'objects/')}
    if seen != actual_objects:
        raise ValueError('Artifact manifest does not cover all objects exactly')
    actual_modules = {p for p in view.files if p.endswith(MODULE_SUFFIXES)}
    expected_modules = {root + 'objects/' + m['file'] for m in modules}
    if actual_modules != expected_modules:
        raise ValueError('Extra module outside declared artifact objects')
    selection = json.loads(view.text(root + 'module-selection.json'))
    selected = validate_selection(modules, selection)
    if len(releases) != 1 or not releases[0] or len(releases[0].split()) != 1:
        raise ValueError('Expected exactly one valid common kernel.release')
    if any(m['vermagic'].split()[0] != releases[0] for m in modules):
        raise ValueError('Build module vermagic release does not match common kernel.release')
    if len({m['vermagic'] for m in modules}) != 1:
        raise ValueError('Build modules have mixed vermagic')
    return {'kernel_release': releases[0], 'kmi': kmi(releases[0]), 'manifest_verified_files': len(items),
            'selection_policy': selection['policy'], 'all_built_count': len(modules),
            'selected_count': len(selected), 'reference_only': selection['excluded'],
            'selected_modules': selected, 'builtin_name_hints': sorted(builtins),
            'integrity_note': 'Hashes bind local files to the included manifest; publisher authenticity is not independently authenticated.'}


def compare(baseline, build=None):
    base_by_name = collections.defaultdict(list)
    for module in baseline['modules']:
        base_by_name[module['name']].append(module)
    candidates = collections.defaultdict(list)
    if build:
        for module in build['selected_modules']:
            candidates[module['name']].append(module)
    rows = []
    required_by_loadlist = collections.defaultdict(list)
    for listing in baseline['load_and_order']:
        if not listing['kind'].startswith('modules.load'):
            continue
        for entry in listing['entries']:
            resolved = [module['name'] for module in baseline['modules']
                        if module['resolved_path'] in entry.get('resolved_paths', [])]
            for name in set(resolved or [entry['name_hint']]):
                required_by_loadlist[name].append({'file': listing['file'], 'line': entry['line'], 'entry': entry['entry']})
    baseline_names = set(base_by_name) | set(baseline['loaded']) | set(required_by_loadlist)
    for name in sorted(baseline_names):
        modules = base_by_name.get(name, [])
        matches = candidates.get(name, [])
        status = 'inventory_only' if build is None else 'same_name_candidate' if len(matches) == 1 else 'multiple_candidates' if matches else 'no_module_candidate'
        if build and not matches and name in build['builtin_name_hints']:
            status = 'build_builtin_name_hint'
        rows.append({'name': name, 'loaded': (name in baseline['loaded']) if baseline['loaded_snapshot_available'] else None, 'status': status,
                     'required_by_loadlist': required_by_loadlist[name],
                     'baseline_paths': [m['source_path'] for m in modules],
                     'baseline_resolved_identities': sorted({m['resolved_path'] for m in modules}),
                     'baseline_partitions': sorted({m['partition'] for m in modules}),
                     'baseline_sha256': sorted({m['sha256'] for m in modules}),
                     'baseline_vermagic': sorted({m['vermagic'] for m in modules}),
                     'candidate_paths': [m['file'] for m in matches],
                     'candidate_sha256': [m['sha256'] for m in matches],
                     'candidate_vermagic': sorted({m['vermagic'] for m in matches}),
                     'candidate_depends': sorted({d for m in matches for d in m['depends']}),
                     'alias_sets_equal': ({a for m in modules for a in m['aliases']} ==
                                          {a for m in matches for a in m['aliases']}) if matches and modules else None,
                     'compatibility_proven': False})
    cross = None if build is None else baseline['kernel_release'] != build['kernel_release'] or baseline['kmi'] != build['kmi']
    status_counts = dict(collections.Counter(row['status'] for row in rows))
    return {'schema_version': 1, 'analysis_complete': not baseline['errors'], 'flashable': False,
            'hardware_tested': False, 'scope': SCOPE, 'baseline': baseline, 'build': build,
            'cross_kernel_baseline': cross,
            'cross_kernel_note': ('Baseline and build releases/KMI differ. OEM binaries are reference inputs only and must not be mixed into the new kernel.'
                                  if cross else 'Build artifact not supplied; inventory only.' if build is None else 'Equal release labels do not prove ABI, signature, or hardware compatibility.'),
            'summary': {'baseline_module_files': len(baseline['modules']), 'baseline_unique_names': len(base_by_name),
                        'baseline_resolved_identities': len({m['resolved_path'] for m in baseline['modules']}),
                        'baseline_names_including_loaded_and_loadlist': len(baseline_names),
                        'load_resolution_complete': baseline['load_resolution_complete'],
                        'loaded_unique_names': len(baseline['loaded']) if baseline['loaded_snapshot_available'] else None,
                        'loaded_snapshot_available': baseline['loaded_snapshot_available'], 'coverage_status_counts': status_counts,
                        'loaded_status_counts': dict(collections.Counter(r['status'] for r in rows if r['loaded'])) if baseline['loaded_snapshot_available'] else None,
                        'unresolved_load_or_order_entries': len(baseline['unresolved_load_or_order'])},
            'coverage': rows,
            'extra_build_candidates_not_autoload': [m for name in sorted(set(candidates) - baseline_names) for m in candidates[name]]}


def verify_build_archive(path, reference):
    """CLI pins the downloaded ZIP; directory mode can only check object manifests."""
    if path.is_dir():
        return {'archive_identity_verified': False,
                'reason': 'Directory input: original ZIP identity cannot be verified.'}
    expected = reference['build_archive_sha256']
    size = reference['build_archive_bytes']
    if not HEX.fullmatch(expected) or not isinstance(size, int) or size < 1:
        raise ValueError('Invalid BUILD-REFERENCE.json artifact hash/size')
    if path.stat().st_size != size:
        raise ValueError('Build ZIP size differs from pinned run ' + str(reference['run_id']))
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(chunk)
    if sha.hexdigest() != expected:
        raise ValueError('Build ZIP SHA256 differs from pinned run ' + str(reference['run_id']))
    return {'archive_identity_verified': True, 'archive_sha256': expected,
            'archive_bytes': size, 'run_id': reference['run_id'], 'commit': reference['commit']}


def write_reports(result, out):
    out.mkdir(parents=True, exist_ok=True)
    (out / 'coverage.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    fields = ['name', 'loaded', 'status', 'required_by_loadlist', 'baseline_partitions', 'baseline_paths', 'baseline_resolved_identities',
              'baseline_sha256', 'baseline_vermagic', 'candidate_paths', 'candidate_sha256',
              'candidate_vermagic', 'candidate_depends', 'alias_sets_equal', 'compatibility_proven']
    with (out / 'coverage.csv').open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in result['coverage']:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, list) else v for k, v in row.items()})
    summary = result['summary']
    lines = ['MYRON MODULE COVERAGE — DIAGNOSTIC ONLY',
             'Analysis complete: ' + str(result['analysis_complete']),
             'Baseline kernel: ' + result['baseline']['kernel_release'],
             'Build kernel: ' + (result['build']['kernel_release'] if result['build'] else '(not supplied; inventory only)'),
             'Cross-kernel baseline: ' + str(result['cross_kernel_baseline']),
             'Baseline unique names: ' + str(summary['baseline_unique_names']),
             'Loaded unique names: ' + (str(summary['loaded_unique_names']) if summary['loaded_snapshot_available'] else 'UNKNOWN (snapshot unavailable)'),
             'Runtime modules.load resolution complete: ' + str(summary['load_resolution_complete']),
             'Coverage counts: ' + json.dumps(summary['coverage_status_counts']),
             'Loaded coverage counts: ' + json.dumps(summary['loaded_status_counts']),
             'Unresolved load/order entries: ' + str(summary['unresolved_load_or_order_entries']),
             'Extra build candidates (NOT an autoload list): ' + str(len(result['extra_build_candidates_not_autoload'])),
             'Errors: ' + json.dumps(result['baseline']['errors'], ensure_ascii=False),
             'flashable=false; hardware_tested=false', result['cross_kernel_note'], SCOPE]
    (out / 'brief.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', required=True, type=Path, help='collector tar.gz or extracted directory')
    parser.add_argument('--build', type=Path, help='full/soc source-build artifact ZIP or directory; optional')
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args(argv)
    views = []
    output_safe = False
    try:
        for source in (args.baseline, args.build):
            if source is not None and source.is_dir() and (args.out.resolve() == source.resolve() or source.resolve() in args.out.resolve().parents):
                raise ValueError('--out must not be inside an input directory')
        if args.out.is_symlink() or args.out.exists() and not args.out.is_dir():
            raise ValueError("--out must be a real directory")
        output_safe = True
        base_view = Input(args.baseline)
        views.append(base_view)
        baseline = baseline_inventory(base_view)
        build = None
        if args.build:
            reference_path = Path(__file__).resolve().with_name('BUILD-REFERENCE.json')
            reference = json.loads(reference_path.read_text(encoding='utf-8'))
            archive_identity = verify_build_archive(args.build, reference)
            build_view = Input(args.build)
            views.append(build_view)
            build = build_inventory(build_view)
            build.update(archive_identity)
        result = compare(baseline, build)
        write_reports(result, args.out)
        previous_error = args.out / 'analysis-error.json'
        if previous_error.is_file() and not previous_error.is_symlink():
            previous_error.unlink()
        print((args.out / 'brief.txt').read_text(encoding='utf-8'))
        return 0 if result['analysis_complete'] else 2
    except (ValueError, OSError, EOFError, KeyError, TypeError, struct.error, lzma.LZMAError, zlib.error, zipfile.BadZipFile, tarfile.TarError) as exc:
        if output_safe:
            args.out.mkdir(parents=True, exist_ok=True)
        failure = {'analysis_complete': False, 'flashable': False, 'hardware_tested': False, 'error': str(exc)}
        if output_safe:
            (args.out / 'analysis-error.json').write_text(json.dumps(failure, indent=2) + '\n', encoding='utf-8')
            (args.out / 'coverage.json').write_text(json.dumps(failure, indent=2) + '\n', encoding='utf-8')
            (args.out / 'coverage.csv').write_text('name,loaded,status\n', encoding='utf-8-sig')
            (args.out / 'brief.txt').write_text('ANALYSIS FAILED: ' + str(exc) + '\nflashable=false; hardware_tested=false\n', encoding='utf-8')
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 2
    finally:
        for view in views:
            view.close()


if __name__ == '__main__':
    sys.exit(main())
