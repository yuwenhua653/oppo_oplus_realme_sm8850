Myron r13：复用 run16 的模块装配规划

这部分无需重新编译。它读取已经核验的 run16 真正 ELF 和同次构建
Module.symvers，再生成可以复现的目录草案。未使用 r11 旧 KO。

本轮推进
- 保留 msm_video，排除互斥的 video，实际核对并消除五个重复导出。
- 在 605 个无冲突候选中验证 33,713 条 import CRC，并要求每一条都由
  已选择的唯一模块或 vmlinux 提供；未选择模块的相同 CRC 不能掩盖问题。
- 四阶段最终并集 521 个模块，比 r11 增加 22 个。normal 114、recovery 352、
  system 80、vendor 387。最终并集 30,869 条 import CRC 全通过。
- vendor_boot 352、system_dlkm 80、vendor_dlkm 387，共 819 份自包含副本。
  同一模块跨分区副本字节相同，避免假定 switch_root 后还能读取早期 /lib/modules。
  已实际生成本地目录并核对全部 819 份 SHA；没有生成镜像或 modules.load。

还未放行的内容
- 原 normal 缺名项仍 34，recovery 67，vendor 52。qcom_tzmem 的实现迁移另列，
  不混入缺名计数；这里的数量不是“还必须写多少个驱动”。
- vendor 原 74 项缺名减少为 52；按历史原厂 DT/配置证据：19 个匹配 enabled
  节点、1 个只有 disabled 匹配、5 个 OF 表未匹配选中 DT、5 个配置接口引用、
  22 个其它未决。充电/电池/温控链尚有 15 个缺名项。
- 新增 22 个“已编译并可装配”不等于硬件功能已验证。不能据此删除原厂缺失项。
- 原厂收集的 system 加载脚本递归扫描 KO，不遵从 modules.load 内容；
  vendor 后台加载也未汇总失败。仅替换模块名单不能解决加载器问题。
- ipam / msm_video 的 subsys-pil-tz、qcom-arm-smmu-mod 旧 softdep 名称仍保留。
  r11 有当前实现源码与先后约束，但未给 modprobe 添加假 alias。
- 仍有 8 条 USB 网卡精确 alias 重叠，显式顺序不能替代热插拔策略。
- vendor 模块未压缩 121,429,938 字节，参考逻辑分区 53,805,056 字节。
  尚未构造目标 EROFS，不能说压缩后装得下或一定超限。

证据边界
stock-inventory 记录的是分区成员和名单集合；未保留各 KO 精确原路径或
原 modules.load 行顺序。报告明确将 stock_exact_original_paths 设为 null。
这里的顺序使用 r11 依赖排序草案作种子，并用 run16 实际 hard/import/soft
依赖重新排序，不能冒充实机观察到的加载顺序。提议目标文件统一为规范化
模块名，绝不沿用旧 modules.dep 绝对路径索引。

复现方法（Python 3，仅本地文件）
  python plan_module_layout.py --artifacts <run16的full目录> --bundle <当前适配目录> --out <报告目录>
  python test_layout.py
  python materialize_plan.py --plan <报告目录>/module-layout.json --artifacts <run16的full目录> --out <全新目录>

plan_module_layout.py 的 --artifacts 是内含 artifact-manifest.json 与 objects
的 full 目录。--bundle 内应存在 coverage/stock-inventory.json 和
drivers/validate_drivers.py。reference-inputs 只保存 r11 小型规划证据，不含旧 KO。
输出已存在时 materialize_plan.py 拒绝覆盖；源文件 SHA/大小不符也拒绝生成。

主要报告
reports/module-layout.json：每个源 ELF、分区证据、目标草案、依赖顺序、缺口。
reports/selected-import-providers.json：每条选中导入的唯一提供者和 CRC。
reports/phase-plan.draft.tsv：带源文件 SHA 的阶段顺序；全部运行策略仍 unresolved。
reports/physical-copies.draft.tsv：819 份物理副本的源路径/目标草案/校验信息。
reports/remaining-vendor-gaps.json：更新后的 52 项逐条历史证据与未决处置。
reports/materialization-verification.json：819 份实际生成并验证的结果。

flashable=false，boot_ready=false；本目录不连接手机、不刷机、不触发 CI。
