#!/usr/bin/env python3
"""Focused regressions for assembly trust, graph order and provider choice."""
import unittest
from plan_module_layout import relative_path, softdeps, stable_order, unique_owners, validate_imports


class LayoutTests(unittest.TestCase):
    def test_pre_and_post_order(self):
        self.assertEqual(softdeps(['pre: usb-core post: service']),
                         [('pre','usb_core','usb-core'),('post','service','service')])
        self.assertEqual(stable_order({'usb','consumer','after'},
                         {('usb','consumer'),('consumer','after')},['after','consumer','usb']),
                         ['usb','consumer','after'])

    def test_cycles_and_unknown_edge(self):
        for edges in ({('a','b'),('b','a')},{('a','absent')},{('a','a')}):
            with self.assertRaises(ValueError):stable_order({'a','b'},edges,['a','b'])

    def test_paths_cannot_escape(self):
        for path in ('../x.ko','/x.ko','a/../x.ko','a\\x.ko','a//x.ko'):
            with self.assertRaises(ValueError):relative_path(path)

    def test_duplicate_export_provider_rejected_even_same_crc(self):
        modules={'a':{'exports':{'api'},'imports':set(),'versions':{}},
                 'b':{'exports':{'api'},'imports':set(),'versions':{}},
                 'c':{'exports':set(),'imports':{'api'},'versions':{'api':123}}}
        owners=unique_owners(modules,set())
        errors,_,_=validate_imports(modules,owners,{('a','api'):{123},('b','api'):{123}})
        self.assertEqual(errors[0]['error'],'provider_not_unique')

    def test_unselected_matching_crc_cannot_mask_wrong_selected_provider(self):
        modules={'c':{'exports':set(),'imports':{'api'},'versions':{'api':123}}}
        errors,_,_=validate_imports(modules,{'api':{'actual'}},
                   {('actual','api'):{456},('excluded','api'):{123}})
        self.assertEqual(errors[0]['error'],'provider_crc_mismatch')

    def test_missing_crc_and_missing_provider(self):
        modules={'c':{'exports':set(),'imports':{'unversioned','absent'},'versions':{'absent':123}}}
        errors,_,_=validate_imports(modules,{}, {})
        self.assertEqual({e['error'] for e in errors},{'missing_import_crc','provider_not_unique'})

    def test_current_provider_success(self):
        modules={'c':{'exports':set(),'imports':{'api'},'versions':{'api':123}}}
        errors,rows,checked=validate_imports(modules,{'api':{'vmlinux'}},{('vmlinux','api'):{123}})
        self.assertEqual(errors,[])
        self.assertEqual(checked,1)
        self.assertEqual(rows['c'],[{'symbol':'api','provider':'vmlinux','crc':'0x7b'}])


if __name__=='__main__':unittest.main()
