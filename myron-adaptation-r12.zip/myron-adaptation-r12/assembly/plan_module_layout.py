#!/usr/bin/env python3
"""Build an offline, byte-bound module assembly proposal; never loads modules.

Inputs: a current build's actual artifact directory, current adaptation bundle,
and the small historical r11 proposal evidence shipped beside this tool.
Only Python's standard library is used. No old binary or old CRC is selected.
"""
import argparse
import collections
import hashlib
import heapq
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import sys

HERE = Path(__file__).resolve().parent
PHASE_PARTITION = {'normal':'vendor_boot', 'recovery':'vendor_boot',
                   'system':'system_dlkm', 'vendor':'vendor_dlkm'}
EXPECTED_COLLISIONS = {'msm_vidc_enable_bugon', 'msm_vidc_fw_dump',
                       'msm_vidc_fw_unload', 'msm_vidc_lossless_encode',
                       'msm_vidc_syscache_disable'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def module_name(value):
    if not re.fullmatch(r'[A-Za-z0-9_-]+', value):
        raise ValueError('Unsafe module name: ' + repr(value))
    return value.replace('-', '_')


def relative_path(value):
    path = PurePosixPath(value)
    if path.is_absolute() or '..' in path.parts or str(path) != value or '\\' in value:
        raise ValueError('Unsafe artifact path: ' + repr(value))
    return path


def softdeps(values):
    result = []
    for value in values:
        kind = None
        for token in value.split():
            if token in ('pre:', 'post:'):
                kind = token[:-1]
            elif kind:
                result.append((kind, module_name(token), token))
            else:
                raise ValueError('Invalid softdep: ' + value)
    return result


def stable_order(names, edges, seed):
    names = set(names)
    rank = {n:i for i,n in enumerate(dict.fromkeys(seed))}
    pred, succ = {n:set() for n in names}, {n:set() for n in names}
    for a,b in edges:
        if a == b or a not in names or b not in names:
            raise ValueError('Invalid dependency edge: ' + repr((a,b)))
        pred[b].add(a)
        succ[a].add(b)
    ready = [(rank.get(n,len(rank)),n) for n in names if not pred[n]]
    heapq.heapify(ready)
    result = []
    while ready:
        _,n = heapq.heappop(ready)
        result.append(n)
        for m in sorted(succ[n]):
            pred[m].remove(n)
            if not pred[m]:
                heapq.heappush(ready,(rank.get(m,len(rank)),m))
    if len(result) != len(names):
        raise ValueError('Dependency cycle: ' + ', '.join(sorted(n for n in names if pred[n])))
    return result


def unique_owners(modules, builtin_exports):
    owners = collections.defaultdict(set)
    for sym in builtin_exports:
        owners[sym].add('vmlinux')
    for name, module in modules.items():
        for sym in module['exports']:
            owners[sym].add(name)
    return owners


def validate_imports(modules, owners, crc_by_owner):
    """Require a unique selected provider, then that provider's own CRC."""
    errors, imports, checked = [], {}, 0
    for name,m in sorted(modules.items()):
        imports[name] = []
        for sym in sorted(m['imports'] - m['versions'].keys()):
            errors.append({'module':name,'symbol':sym,'error':'missing_import_crc'})
        for sym,crc in sorted(m['versions'].items()):
            checked += 1
            ps = owners.get(sym,set())
            if len(ps) != 1:
                errors.append({'module':name,'symbol':sym,'error':'provider_not_unique',
                               'providers':sorted(ps)})
                continue
            provider = next(iter(ps))
            actual = crc_by_owner.get((provider,sym),set())
            if actual != {crc}:
                errors.append({'module':name,'symbol':sym,'error':'provider_crc_mismatch',
                               'provider':provider,'import_crc':hex(crc),
                               'provider_crcs':sorted(map(hex,actual))})
            imports[name].append({'symbol':sym,'provider':provider,'crc':hex(crc)})
    return errors,imports,checked


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts',type=Path,required=True)
    parser.add_argument('--bundle',type=Path,required=True)
    parser.add_argument('--reference',type=Path,default=HERE/'reference-inputs/r11-proposal-evidence.json')
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    art,bundle=args.artifacts.resolve(),args.bundle.resolve()
    manifest_path=art/'artifact-manifest.json'
    manifest,selection,reference,stock = (read(p) for p in
        (manifest_path,art/'module-selection.json',args.reference,bundle/'coverage/stock-inventory.json'))
    if manifest['stage']!='full' or manifest.get('flashable') is not False:
        raise ValueError('Expected a full diagnostic artifact set')
    spec=importlib.util.spec_from_file_location('myron_layout_elf',bundle/'drivers/validate_drivers.py')
    validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
    sys.path.insert(0,str(bundle/'coverage'))
    from module_selection_policy import validate_selection
    validate_selection(selection['all_built'],selection)

    records,raw_modules,crc_by_owner={}, {},collections.defaultdict(set)
    builtin_exports=set(); symvers_count=0; builtin=set()
    for row in manifest['files']:
        rel=relative_path(row['file']);path=art/rel
        if row['file'] in records or path.is_symlink() or not path.resolve().is_relative_to(art):
            raise ValueError('Repeated/unsafe artifact: '+row['file'])
        data=path.read_bytes()
        if len(data)!=row['bytes'] or sha(data)!=row['sha256']:
            raise ValueError('Artifact hash/size mismatch: '+row['file'])
        records[row['file']]=row
        if path.suffix=='.ko':
            raw_modules[row['file']]=validator.elf(data)
        elif path.name=='modules.builtin':
            builtin.update(module_name(Path(line).stem) for line in data.decode().splitlines())
        elif path.suffix=='.symvers' and '/canoe_perf_dtb_build/' not in path.as_posix():
            symvers_count+=1
            for line in data.decode().splitlines():
                fields=line.split()
                if len(fields)<3:
                    raise ValueError('Malformed symvers record')
                crc,symbol,provider=fields[:3]
                provider=module_name(PurePosixPath(provider).name.removesuffix('.ko'))
                crc_by_owner[(provider,symbol)].add(int(crc,16))
                if provider=='vmlinux':builtin_exports.add(symbol)

    selected={}
    by_path={r['file']:r for r in selection['all_built']}
    for filename in selection['selected']:
        row=by_path[filename];source='objects/'+filename
        m=raw_modules[source]
        if row['sha256']!=records[source]['sha256'] or m['info'].get('name')!=[row['name']]:
            raise ValueError('Selection/ELF mismatch: '+filename)
        if m['info'].get('vermagic')!=[row['vermagic']]:
            raise ValueError('Selection vermagic mismatch')
        if row['name'] in selected:
            raise ValueError('Duplicate module name')
        selected[row['name']]={**m,'source':source,'sha256':row['sha256'],
            'bytes':records[source]['bytes'],'vermagic':row['vermagic'],
            'depends':sorted({module_name(n) for value in m['info'].get('depends',[]) for n in value.split(',') if n}),
            'softdeps':m['info'].get('softdep',[]),'aliases':m['info'].get('alias',[])}
    if set(raw_modules)!=set('objects/'+r['file'] for r in selection['all_built']):
        raise ValueError('Unrecorded built module in actual manifest')
    all_owners=unique_owners(selected,builtin_exports)
    collisions={s:sorted(p) for s,p in all_owners.items() if len(p)>1}
    if set(collisions)!=EXPECTED_COLLISIONS or any(ps!=['msm_video','video'] for ps in collisions.values()):
        raise ValueError('Unexpected provider conflict; policy review required')
    if reference['selected_video_module']!='msm_video' or reference['excluded_conflicting_module']!='video':
        raise ValueError('Changed historical video policy')
    rejected_video=selected.pop('video')
    owners=unique_owners(selected,builtin_exports)
    if any(len(p)!=1 for p in owners.values()):raise ValueError('Duplicate selected exports')
    if set(selected)&builtin:raise ValueError('Selected/builtin module name collision')
    errors,imports,checked=validate_imports(selected,owners,crc_by_owner)
    missing_dep=[]
    for name,m in selected.items():
        for dep in m['depends']:
            if dep not in selected and dep not in builtin:
                missing_dep.append({'module':name,'dependency':dep})
    if missing_dep:errors.extend({'error':'missing_hard_dependency',**r} for r in missing_dep)
    if errors:
        args.out.mkdir(parents=True,exist_ok=True)
        (args.out/'failed-import-audit.json').write_text(json.dumps(errors,indent=2)+'\n')
        raise ValueError('Import audit failed; see failed-import-audit.json')
    depmap={name:set(m['depends'])|{r['provider'] for r in imports[name] if r['provider']!='vmlinux'}
            for name,m in selected.items()}
    stock_by_name={m['name']:m for m in stock['modules']}
    phases={}; phase_sets={}
    for phase,old in reference['phases'].items():
        newly_available=sorted(set(old['missing_roots_unreviewed'])&selected.keys())
        seed=old['order']+newly_available
        absent_previous=set(old['order'])-selected.keys()
        if absent_previous:raise ValueError('Previously staged modules now missing: '+repr(sorted(absent_previous)))
        ns=set(seed);queue=list(seed)
        extra=old.get('source_backed_order_constraints',[])
        while queue:
            n=queue.pop()
            needed=depmap[n]|{d for _,d,_ in softdeps(selected[n]['softdeps']) if d in selected}
            needed|={e['before'] for e in extra if e['after']==n}
            for d in needed-builtin-ns:
                if d not in selected:raise ValueError('Missing dependency in phase '+phase+':'+d)
                ns.add(d);queue.append(d)
        edges=set();unresolved=[]
        for n in ns:
            edges.update((d,n) for d in depmap[n] if d in selected)
            for kind,d,original in softdeps(selected[n]['softdeps']):
                if d in ns:edges.add((d,n) if kind=='pre' else (n,d))
                elif d not in builtin:unresolved.append({'consumer':n,'kind':kind,'declared_name':original})
        edges.update((e['before'],e['after']) for e in extra if e['after'] in ns)
        order=stable_order(ns,edges,seed)
        phase_sets[phase]=ns
        phases[phase]={'partition':PHASE_PARTITION[phase],
            'source_of_seed':'r11 prior proposed closure plus newly built historical missing roots; not observed load order',
            'old_closure_count':len(old['order']),'newly_available_original_roots':newly_available,
            'closure_count':len(ns),'order':order,'dependency_edge_count':len(edges),
            'missing_original_roots':sorted(set(old['missing_roots_unreviewed'])-selected.keys()),
            'implementation_migrations_still_not_equivalence_proven':[{**item, 'provider_sha256_scope':'historical r11 evidence', 'current_provider_sha256':selected.get(item.get('provider'),{}).get('sha256')} for item in old.get('implementation_migrations',[])],
            'unresolved_legacy_softdeps':sorted(unresolved,key=lambda x:(x['consumer'],x['declared_name'])),
            'source_backed_order_constraints':extra,'runtime_policy':'unresolved','runtime_order_approved':False}
    union=set.union(*phase_sets.values())
    partition_sets={'vendor_boot':phase_sets['normal']|phase_sets['recovery'],
                    'system_dlkm':phase_sets['system'],'vendor_dlkm':phase_sets['vendor']}
    rows=[]
    for name in sorted(union):
        m=selected[name];stockrow=stock_by_name.get(name,{'variants':[]})
        rows.append({'name':name,'source':m['source'],'original_build_basename':Path(m['source']).name,
            'sha256':m['sha256'],'bytes':m['bytes'],'vermagic':m['vermagic'],
            'hard_depends':m['depends'],'softdeps':m['softdeps'],
            'stock_partition_evidence':sorted({p for v in stockrow['variants'] for p in v['partitions']}),
            'stock_exact_original_paths':None,'stock_load_list_membership':[k for k,v in stock['load_sets'].items() if name in v],
            'required_by_phases':[p for p,s in phase_sets.items() if name in s],
            'module_code_unchanged':True})
    copies=[]; capacity={}
    for partition,ns in partition_sets.items():
        for name in sorted(ns):
            prefix='/lib/modules' if partition=='vendor_boot' else '/'+partition+'/lib/modules'
            copies.append({'name':name,'partition':partition,'relative_path':'lib/modules/'+name+'.ko',
                'proposed_runtime_path':prefix+'/'+name+'.ko','sha256':selected[name]['sha256'],
                'bytes':selected[name]['bytes'],'source':selected[name]['source']})
        capacity[partition]={'module_count':len(ns),'uncompressed_module_bytes':sum(selected[n]['bytes'] for n in ns),
            **reference['capacity_reference'][partition],'filesystem_image_created':False,'partition_fit_proven':False}
    aliases=collections.defaultdict(set)
    for n in union:
        for alias in selected[n]['aliases']:aliases[alias].add(n)
    exact_alias={a:sorted(ns) for a,ns in aliases.items() if len(ns)>1}
    selected_imports={n:imports[n] for n in sorted(union)}
    report={'schema':1,'scope':'Offline current-build module layout proposal; no module loading, boot policy or partition image',
        'inputs':{'artifact_manifest_sha256':sha(manifest_path.read_bytes()),
                  'module_selection_sha256':sha((art/'module-selection.json').read_bytes()),
                  'stock_inventory_sha256':sha((bundle/'coverage/stock-inventory.json').read_bytes()),
                  'r11_reference_sha256':sha(args.reference.read_bytes())},
        'checks':{'manifest_files_verified':len(records),'built_module_count':len(raw_modules),
            'diagnostic_selected_count':len(selected)+1,'collision_free_candidate_count':len(selected),
            'same_build_symvers_files':symvers_count,'candidate_import_crcs_verified':checked,
            'assembly_import_crcs_verified':sum(len(v) for v in selected_imports.values()),
            'selected_provider_unique':True,'crc_matches_selected_provider':True,'hard_dependency_closed':True,
            'original_collision_symbols':collisions,'selected_collision_symbols':{},
            'errors':[]},
        'excluded_conflicting_provider':{'name':'video','source':rejected_video['source'],
            'sha256':rejected_video['sha256'],'kept_provider':'msm_video','reason':'r11 explicit mutually-exclusive provider policy; exact five actual exports verified'},
        'unique_assembly_modules':len(union),'physical_copy_count':len(copies),
        'modules':rows,'copies':copies,'phases':phases,'capacities':capacity,
        'exact_alias_collisions':exact_alias,'alias_pattern_overlap_checked':False,
        'not_in_assembly_candidates':sorted(selected.keys()-union),
        'new_module_count_since_r11':len(union)-reference['original_r11_unique_count'],
        'stock_original_load_order_available':False,'original_module_paths_recovered':False,
        'loader_findings':reference['loader_findings'],
        'limits':['Partition membership is recorded evidence, proposed destination paths are new normalized paths.',
                  'No stock original .ko path or actual per-boot insertion order is reconstructed from sorted names.',
                  'Dependency closure and CRC do not prove driver probe, firmware, DT compatibility or side effects.',
                  'Missing roots remain unresolved, not approved to delete. r11 ipclite_test omission remains a diagnostic policy review.',
                  'Same-name modules can occur in several partitions. Same-hash copies avoid assuming switch_root preserves the early directory.',
                  'Legacy softdep metadata remains unchanged; source-backed order does not teach modprobe the absent aliases.',
                  'No modules.load, depmod index, init patch, device operation, filesystem image or flash ZIP generated.'],
        'boot_ready':False,'flashable':False,'hardware_tested':False}
    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/'module-layout.json').write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    (args.out/'selected-import-providers.json').write_text(json.dumps(selected_imports,indent=2)+'\n')
    historical_vendor_path=args.reference.parent/'r11-vendor-disposition.json'
    if historical_vendor_path.exists():
        historical_vendor=read(historical_vendor_path)
        missing=set(phases['vendor']['missing_original_roots'])
        matrix=[x for x in historical_vendor['matrix'] if x['name'] in missing]
        if {x['name'] for x in matrix}!=missing:
            raise ValueError('Vendor missing set lacks historical per-module review')
        gap_report={'scope':'Remaining same-name gaps after current ELF compilation; stock DT/config classifications are historical r11 evidence, not new probe results',
            'historical_source_sha256':sha(historical_vendor_path.read_bytes()),
            'historical_source_run':historical_vendor['run_id'],
            'current_newly_available':phases['vendor']['newly_available_original_roots'],
            'remaining_count':len(matrix),
            'remaining_groups':dict(collections.Counter(x['disposition'] for x in matrix)),
            'charging_thermal_members_remaining':sorted(set(historical_vendor['charging_thermal_members'])&missing),
            'matrix':matrix,'missing_approved_for_removal':False,'runtime_probe_verified':False,'flashable':False}
        (args.out/'remaining-vendor-gaps.json').write_text(json.dumps(gap_report,ensure_ascii=False,indent=2)+'\n')
    header='phase\torder\tname\tproposed_runtime_path\tsha256\tsource\tpolicy\n'
    lines=[]
    for phase,p in phases.items():
        part=p['partition'];prefix='/lib/modules' if part=='vendor_boot' else '/'+part+'/lib/modules'
        for i,n in enumerate(p['order']):
            lines.append('\t'.join(map(str,(phase,i,n,prefix+'/'+n+'.ko',selected[n]['sha256'],selected[n]['source'],'unresolved')))+'\n')
    (args.out/'phase-plan.draft.tsv').write_text(header+''.join(lines))
    (args.out/'physical-copies.draft.tsv').write_text('partition\tname\tproposed_runtime_path\tsha256\tbytes\tsource\n'+''.join('\t'.join(str(c[k]) for k in ('partition','name','proposed_runtime_path','sha256','bytes','source'))+'\n' for c in copies))
    print(json.dumps({'unique_modules':len(union),'physical_copies':len(copies),
        'phases':{p:{'count':r['closure_count'],'new':len(r['newly_available_original_roots']),'missing':len(r['missing_original_roots'])} for p,r in phases.items()},
        'checks':report['checks'],'flashable':False},indent=2))


if __name__=='__main__':
    main()
