#!/usr/bin/env python3
"""Create a new local directory from a locked draft plan; never access devices."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_path(value):
    p=PurePosixPath(value)
    if p.is_absolute() or '..' in p.parts or str(p)!=value or '\\' in value:
        raise ValueError('Unsafe relative path')
    return p


def materialize(plan_path, artifacts, output):
    plan=json.loads(plan_path.read_text())
    if plan.get('flashable') is not False or plan.get('boot_ready') is not False:
        raise ValueError('Only a non-flashable draft plan is accepted')
    artifacts=artifacts.resolve()
    if sha(artifacts/'artifact-manifest.json')!=plan['inputs']['artifact_manifest_sha256']:
        raise ValueError('Plan belongs to another build')
    if output.exists() or output.is_symlink():
        raise ValueError('Output must be a new directory')
    modules={m['name']:m for m in plan['modules']}
    if len(modules)!=len(plan['modules']):raise ValueError('Repeated module')
    for name,m in modules.items():
        source=artifacts/safe_path(m['source'])
        if source.is_symlink() or not source.resolve().is_relative_to(artifacts):
            raise ValueError('Unsafe source')
        if source.stat().st_size!=m['bytes'] or sha(source)!=m['sha256']:
            raise ValueError('Changed source: '+name)
    destinations=set()
    for row in plan['copies']:
        if row['partition'] not in ('vendor_boot','vendor_dlkm','system_dlkm'):
            raise ValueError('Unknown partition')
        m=modules[row['name']]
        if any(row[k]!=m[k] for k in ('sha256','bytes','source')):
            raise ValueError('Copy does not match selected module')
        rel=Path(row['partition'])/safe_path(row['relative_path'])
        if rel in destinations:raise ValueError('Duplicate copy destination')
        destinations.add(rel)
    output.mkdir(parents=True)
    for row in plan['copies']:
        target=output/row['partition']/row['relative_path']
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(artifacts/row['source'],target)
        if target.stat().st_size!=row['bytes'] or sha(target)!=row['sha256']:
            raise ValueError('Copy verification failed')
    result={'plan_sha256':sha(plan_path),'unique_source_modules':len(modules),
            'physical_copies_verified':len(destinations),'module_bytes_changed':False,
            'images_created':False,'flashable':False,'boot_ready':False}
    (output/'NOT-A-FLASH-PACKAGE.txt').write_text('Offline draft directories only. No modules.load or init integration. Do not copy into a device. Missing roots and runtime policies remain unresolved.\n')
    (output/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,required=True)
    p.add_argument('--artifacts',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    print(json.dumps(materialize(a.plan,a.artifacts,a.out),indent=2))


if __name__=='__main__':main()
