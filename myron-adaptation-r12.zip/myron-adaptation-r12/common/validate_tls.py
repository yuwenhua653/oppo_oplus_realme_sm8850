#!/usr/bin/env python3
"""Require the actual built GKI TLS module and its selected configuration."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

def validate(root):
    configs=list(root.rglob('kernel_aarch64_dot_config'))
    modules=[p for p in root.rglob('tls.ko') if '/common/kernel_aarch64/' in str(p)]
    if len(configs)!=1 or len(modules)!=1:
        raise ValueError('Expected exactly one collected GKI config and TLS module')
    config=set(configs[0].read_text().splitlines())
    required=['CONFIG_TLS=m','CONFIG_STREAM_PARSER=y','CONFIG_NET_SOCK_MSG=y',
              'CONFIG_CRYPTO=y','CONFIG_CRYPTO_AES=y','CONFIG_CRYPTO_GCM=y']
    for line in required:
        if line not in config:raise ValueError('Missing required TLS config: '+line)
    b=modules[0].read_bytes()
    if b[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',b,18)[0]!=183:
        raise ValueError('TLS module is not AArch64 ELF64 little endian')
    shoff=struct.unpack_from('<Q',b,40)[0];sz,num,stridx=struct.unpack_from('<HHH',b,58)
    sections=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*sz) for i in range(num)]
    ss=sections[stridx];names=b[ss[4]:ss[4]+ss[5]];info=[]
    for sec in sections:
        name=names[sec[0]:].split(b'\0',1)[0]
        if name==b'.modinfo':info=b[sec[4]:sec[4]+sec[5]].split(b'\0')
    if b'name=tls' not in info or b'alias=tcp-ulp-tls' not in info:
        raise ValueError('TLS identity/ULP alias missing')
    if not b.endswith(b'~Module signature appended~\n'):
        raise ValueError('Built GKI TLS module signature trailer missing')
    return {'success':True,'module':str(modules[0]),'sha256':hashlib.sha256(b).hexdigest(),
            'required_config':required,'scope':'Build-output contract, not hardware/network runtime testing'}
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--artifact-dir',required=True,type=Path)
    parser.add_argument('--report',type=Path);args=parser.parse_args();result=validate(args.artifact_dir)
    if args.report:args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
