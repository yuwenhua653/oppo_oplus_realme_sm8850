#!/usr/bin/env python3
"""Hash-locked, conflict-checked ACK TLS enablement after the r1 prepare step."""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

def apply(workspace, check_only=False):
    lock = json.loads((HERE / 'source-lock.json').read_text())
    plans = []
    for row in lock['files']:
        target = workspace / row['path']
        payload = (HERE / row['payload']).read_bytes()
        if hashlib.sha256(payload).hexdigest() != row['after_sha256']:
            raise ValueError('Corrupt TLS payload: ' + row['payload'])
        current = hashlib.sha256(target.read_bytes()).hexdigest()
        if current not in (row['before_sha256'], row['after_sha256']):
            raise ValueError('Unexpected TLS preimage; no files changed: ' + str(target))
        plans.append((target, payload, current == row['after_sha256']))
    # Validate every preimage before mutating any file.
    for target, payload, already in plans:
        if not check_only and not already:
            target.write_bytes(payload)
    return {'success': True, 'check_only': check_only,
            'already_applied': all(row[2] for row in plans),
            'files': [str(row[0]) for row in plans]}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    print(json.dumps(apply(args.workspace.resolve(), args.check), indent=2))
