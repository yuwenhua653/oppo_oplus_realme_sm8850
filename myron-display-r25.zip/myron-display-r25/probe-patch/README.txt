MYRON R25 DSI mode enumeration source probes

Purpose
R23 ends after ROI alignment without a timing index. R24 drm.debug=1 CORE logs
reach three timings (60/120/90 Hz): the first two include partial-update and
transfer-threshold output; the last captured third-timing message is ROI
alignment. This bundle adds targeted pr_info boundaries
to determine whether execution returns from ROI validation and panel parsing,
then follows transfer calculation, display mode array population, DRM modes,
connector properties, default layer mixers and connector hardware fences.
It is diagnostic source instrumentation, not a confirmed boot fix.

Source boundary
LineageOS/android_kernel_qcom_sm8850-modules
f2ecb6a09ea56bd8ec9a0bfd2e97f45e200ab322

Eight pinned targets. sde_rm.c, sde_hw_dspp.c, sde_kms.c and sde_fence.c retain
their exact R23 after bytes (including removal of the old debug-only IOVA read).
The four additional pinned targets are dsi_panel.c, dsi_display.c, dsi_drm.c
and sde_connector.c. Removing the 76 R25 pr_info calls recovers their original
token sequences without changes to calls, branches, return values, defaults,
device tree, module parameters, waits or hardware accesses.

Probe arguments
Print initialized local index/count/return values, explicit-width integer
casts, and scalar fields in existing normal-RAM panel/mode allocations.
Do not read MMIO, IOVA, hardware queue pointers, log pointer addresses, or call
new accessors. Extra ordinary RAM reads and printk can change timing; a missing
return marker does not independently prove where the CPU stopped if transport
was lost. fill_allowed_modes enter/return brackets the existing optional-callback
region; those markers do not imply the callback exists or ran.

Binary collection
59 required format strings = original 39 R21/R23 plus 20 non-loop R25
function/call boundaries. All 244 unique source markers are listed separately;
loop/error/optional path markers are not a blanket mandatory binary gate.
expected_markers omit decoded newline. Exact ELF literal checks append LF+NUL.
Mandatory ELF presence does not mean that execution reaches that path.

Apply only
python3 apply_probe.py --modules-root /absolute/modules-checkout --report /outside/report.json
The script preflights every one of the eight source and payload hash pairs
before the first source replacement. Unknown content, links and bad manifest
or patch hashes are refused. Existing exact after bytes are idempotent. Each
file replacement is atomic; this is not a multi-file transaction.

Verification
python3 verify_structure.py --report /outside/structure.json
python3 -m unittest discover -s tests -v
Host C compilation checks only string escape/suffix representation. It does
not compile the Qualcomm driver or establish target compatibility. Full CI
compilation and a later reviewed real-device test are still required.

No images, prebuilt modules, flash commands or device operations are included.
