"""Temporary-fixture tests; never modify the actual kernel checkout or bundle."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch


SOURCE = Path(__file__).resolve().parents[1] / "apply_probe.py"
SPEC = importlib.util.spec_from_file_location("r25_apply_test", SOURCE)
app = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(app)


class ApplyProbeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.bundle = self.root / "bundle"
        self.modules = self.root / "modules"
        self.report = self.root / "report.json"
        (self.bundle / "before").mkdir(parents=True)
        (self.bundle / "after").mkdir()
        (self.modules / "src").mkdir(parents=True)
        self.entries = []
        for i in range(8):
            name = "source" + str(i) + ".c"
            before = ("int value" + str(i) + ";\n").encode()
            after = before + b"/* probe */\n"
            (self.modules / "src" / name).write_bytes(before)
            (self.modules / "src" / name).chmod(0o640 + i)
            (self.bundle / "before" / name).write_bytes(before)
            (self.bundle / "after" / name).write_bytes(after)
            self.entries.append(dict(path="src/" + name, before_file="before/" + name,
                                     after_file="after/" + name,
                                     before_sha256=app.digest(before), after_sha256=app.digest(after)))
        (self.bundle / "probe.patch").write_bytes(b"reviewed fixture patch\n")
        self.manifest = dict(schema=1, patch_id="fixture", files=self.entries,
                             patch=dict(path="probe.patch", sha256=app.digest(b"reviewed fixture patch\n")))
        self.pin_manifest()

    def pin_manifest(self):
        data = (json.dumps(self.manifest) + "\n").encode()
        (self.bundle / "manifest.json").write_bytes(data)
        self.pin = hashlib.sha256(data).hexdigest()

    def invoke(self):
        with patch.object(app, "MANIFEST_SHA256", self.pin):
            return app.apply(self.modules, self.report, self.bundle)

    def snapshot(self):
        return {p: (p.read_bytes(), stat.S_IMODE(p.stat().st_mode), p.stat().st_mtime_ns,
                    p.stat().st_ino) for p in sorted((self.modules / "src").iterdir())}

    def test_pristine_apply_preserves_permissions_then_idempotent_without_replace(self):
        modes = {p: values[1] for p, values in self.snapshot().items()}
        self.assertEqual(self.invoke(), 0)
        for entry in self.entries:
            target = self.modules / entry["path"]
            self.assertEqual(app.digest(target.read_bytes()), entry["after_sha256"])
            self.assertEqual(stat.S_IMODE(target.stat().st_mode), modes[target])
        report = json.loads(self.report.read_text())
        self.assertEqual(len(report["source_files_replaced"]), 8)
        self.assertFalse(report["compiled"])
        before_second = self.snapshot()
        self.assertEqual(self.invoke(), 0)
        self.assertEqual(self.snapshot(), before_second)
        report = json.loads(self.report.read_text())
        self.assertEqual(report["status"], "already_applied")
        self.assertEqual(report["source_files_replaced"], [])

    def test_unknown_eighth_source_refuses_without_any_source_write(self):
        (self.modules / self.entries[7]["path"]).write_bytes(b"unreviewed change\n")
        before = self.snapshot()
        self.assertEqual(self.invoke(), 1)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(json.loads(self.report.read_text())["source_files_replaced"], [])

    def test_corrupt_before_after_or_patch_refuses_without_source_writes(self):
        for relative in [self.entries[7]["before_file"], self.entries[7]["after_file"], "probe.patch"]:
            with self.subTest(payload=relative):
                payload = self.bundle / relative
                original = payload.read_bytes()
                payload.write_bytes(original + b"corrupt")
                before = self.snapshot()
                self.assertEqual(self.invoke(), 1)
                self.assertEqual(self.snapshot(), before)
                payload.write_bytes(original)

    def test_manifest_pin_is_checked_before_parsing(self):
        (self.bundle / "manifest.json").write_bytes(b"not json")
        before = self.snapshot()
        self.assertEqual(self.invoke(), 1)
        self.assertEqual(self.snapshot(), before)
        self.assertIn("Manifest SHA256 mismatch", json.loads(self.report.read_text())["error"])

    def test_symlink_target_parent_and_payload_are_refused(self):
        target = self.modules / self.entries[7]["path"]
        external = self.root / "external.c"
        external.write_bytes(target.read_bytes())
        target.unlink()
        try:
            target.symlink_to(external)
        except (OSError, NotImplementedError):
            self.skipTest("Symlinks unavailable")
        before = self.snapshot()
        self.assertEqual(self.invoke(), 1)
        self.assertEqual(self.snapshot(), before)
        target.unlink()
        target.write_bytes(external.read_bytes())
        real_src = self.root / "external-src"
        (self.modules / "src").rename(real_src)
        (self.modules / "src").symlink_to(real_src, target_is_directory=True)
        self.assertEqual(self.invoke(), 1)
        (self.modules / "src").unlink()
        real_src.rename(self.modules / "src")
        payload = self.bundle / self.entries[1]["after_file"]
        external.write_bytes(payload.read_bytes())
        payload.unlink()
        payload.symlink_to(external)
        before = self.snapshot()
        self.assertEqual(self.invoke(), 1)
        self.assertEqual(self.snapshot(), before)

    def test_manifest_path_escape_and_source_report_clobber_are_refused(self):
        self.entries[7]["path"] = "../outside.c"
        self.pin_manifest()
        before = self.snapshot()
        self.assertEqual(self.invoke(), 1)
        self.assertEqual(self.snapshot(), before)
        self.report = self.modules / self.entries[0]["path"]
        self.assertEqual(self.invoke(), 1)
        self.assertEqual(self.snapshot(), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
