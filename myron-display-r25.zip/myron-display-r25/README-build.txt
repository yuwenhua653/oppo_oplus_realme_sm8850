R25 DSI 模式创建边界源码构建包
构建身份：R25-DSI-MODE-BOUNDARIES-20261012-01

本包用于编译新的 msm_drm.ko 诊断候选模块。在 R23 的全部已验证源码改动上，
为 DSI 面板模式解析、模式枚举与连接器初始化的关键边界补充成对日志。
这是定位下一处故障所需的源码诊断；尚未证明修复卡屏，也不能直接当刷机包。

沿用的构建条件
  - baseline/myron-boot-r18.zip 原封不动，SHA-256：
    a3c7e97e4a28f6574a619bcc10dab8962911ed5fcef8617aeb7fc835bdbe7d13
  - 全部源码锁定版本、R13 准备流程、R18 SOCCP 修复与内核配置保持原样。
  - 仅把 msm_drm 和必要的核心元数据列为顶层构建目标：
    //vendor/qcom/sm8850-modules/qcom/opensource/display-drivers:canoe_perf_msm_drm
    //common:kernel_aarch64
    //myron_artifact_metadata:kernel_release
  - 冷启动 CI 仍会编译所需内核和依赖。上次 R23 完整工作流约 33 分钟，
    不能据此保证本轮耗时，也不意味着仅编译一个 KO。

Fix1 收集逻辑保留
  build / cquery / aquery 使用相同配置；cquery 只查询上面三个根目标。
  aquery 唯一选中 msm_drm 的 KernelModule 或 KernelModuleProcessWrapperSandbox
  编译动作，按该动作实际输入收集依赖 Symvers，不要求独立的依赖 KO 复制动作。
  缺失根产物、缺失实际输入 Symvers、重复提供者或 CRC/namespace 不匹配都会失败。
  不放宽 R18 内核配置、核心 CRC、release 或完整 vermagic 校验。

产物检查
  - manifest.expected_markers 中的每条必需探针都须出现在实际 KO，使用完整
    格式串后缀（marker + 换行 + NUL）匹配，防止更长的近似日志通过。
    允许的前缀仅为“MYRON_R21 ”、“MYRON_R23 ”、“MYRON_R25 ”，包括空格。
    保留原 39 条 R21/R23 必需探针，再加入源码 manifest 指定的 R25 必需探针。
  - 必须不存在旧 hwfence 成功日志的完整危险格式串，且存在删去 wr_idx 字段后
    的完整格式串。此项针对该一条日志，不禁止驱动其他合法 wr_idx 日志。
  - 格式串检查只证明相应源码改动进入 KO；实际 ELF 指令与现有 R18 + 16 个
    RAM 依赖模块的兼容性仍需在编译后复核。

输出
  内部目录保留 integration-artifacts/display-probe/，方便与已有收集工具兼容。
  GitHub artifact 名称为 myron-r25-display-output-<run_id>；报告名称为
  myron-r25-display-reports-<run_id>，内部运行报告均为 r25-*。
  产物包括候选 msm_drm.ko、核心元数据、实际动作输入、全部所用 Symvers、
  源码 manifest、逐 marker/格式串/CRC 校验、build_id 与构建日志。
  编译核心 Image 只记录 hash/release，不把新 Image 加入待交付候选。

使用与后续
  外层交付包提供配对的 myron-display-r25.zip 与 build-myron-display-r25.yml。
  前者放仓库根目录；后者放 .github/workflows/，再手动运行该 R25 workflow。
  默认 jobs=2。编译完成后提供 output 和 reports 两个 artifact，先复核实际 KO。
  本源码包不会调用 ADB/fastboot，不修改启动镜像、分区、模块自动加载列表，
  也不设置设备上的 drm.debug 参数。后续实机包须另行构建与审计。

本地离线校验
  python3 -m unittest discover -s tests -v
  python3 display_probe_build.py --print-plan
  源码 patch 另有精确 hash、结构及重复应用测试，见 probe-patch/。
  collector 单元测试对合成样例模拟 ELF 提取；生产路径仍用 R18 的原 ELF 解析器。
  真实历史 cquery fixture 保留 74 个 KO / 76 个 Symvers 声明，用于验证懒加载
  KO 输出的处理。aquery fixture 是明确标注的模拟图，不冒充历史实测。
  这些检查不包含新一轮远程 CI、内核编译、设备试运行或完整启动验证。

封包约定
  bundle-lock.json 锁定本目录所有交付文件（不含 lock 自身），记录路径、大小与
  SHA-256。源码 patch 合入后重建该 lock，再生成最终 ZIP。workflow 中
  __R25_BUNDLE_SHA256__ 必须由最终 ZIP 的 SHA-256 替换，才能执行。
