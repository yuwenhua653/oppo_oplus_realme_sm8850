#!/usr/bin/env python3
"""Retain diagnostic DTBO outputs; never modify DT image membership/order."""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def replace_pinned(target, before, after, dry_run=False):
    data = target.read_bytes()
    digest = sha(data)
    if digest == sha(after):
        return 'already_applied'
    if digest != sha(before):
        raise ValueError('Unexpected base; refusing overwrite: ' + str(target) + ' SHA256=' + digest)
    if not dry_run:
        target.write_bytes(after)
    return 'dry_run' if dry_run else 'applied'

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--workspace', required=True, type=Path)
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    root = a.workspace.resolve()
    lock = json.loads((HERE / 'retention-lock.json').read_text())
    before = (HERE / 'dtbs.bzl.before').read_bytes()
    after = (HERE / 'dtbs.bzl.after').read_bytes()
    if sha(before) != lock['dtbs_before_sha256'] or sha(after) != lock['dtbs_after_sha256']:
        raise ValueError('Damaged DT patch payload')
    for item in lock['outputs']:
        source = root / 'vendor/qcom/sm8850-devicetrees' / item['source']
        data = source.read_bytes()
        git_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if git_blob != item['source_git_blob']:
            raise ValueError('Changed DT source: ' + str(source))
    status = replace_pinned(root / lock['soc_path'], before, after, a.dry_run)
    report = {'status': status, 'output_count': lock['output_count'],
              'dtbs_before_sha256': lock['dtbs_before_sha256'],
              'dtbs_after_sha256': lock['dtbs_after_sha256'],
              'target': lock['target'], 'image_membership_changed': False,
              'target_compile_tested': False, 'flashable': False}
    if not a.dry_run:
        reports = root / 'integration-reports'
        reports.mkdir(exist_ok=True)
        (reports / 'dt-output-retention.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
