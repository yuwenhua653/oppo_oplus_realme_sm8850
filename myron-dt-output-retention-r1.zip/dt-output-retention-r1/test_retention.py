import ast
import json
import tempfile
import unittest
from pathlib import Path
from apply_retention import HERE, sha, replace_pinned

class Retention(unittest.TestCase):
    def test_pinned_operations(self):
        lock = json.loads((HERE / 'retention-lock.json').read_text())
        for kind, prefix in [('dtbs.bzl', 'dtbs'), ('runner', 'runner')]:
            before = (HERE / (kind + '.before')).read_bytes()
            after = (HERE / (kind + '.after')).read_bytes()
            self.assertEqual(sha(before), lock[prefix + '_before_sha256'])
            self.assertEqual(sha(after), lock[prefix + '_after_sha256'])
            with tempfile.TemporaryDirectory() as tmp:
                p = Path(tmp) / 'target'; p.write_bytes(before)
                self.assertEqual(replace_pinned(p,before,after,True),'dry_run')
                self.assertEqual(p.read_bytes(),before)
                self.assertEqual(replace_pinned(p,before,after),'applied')
                self.assertEqual(replace_pinned(p,before,after),'already_applied')
                self.assertEqual(p.read_bytes(),after)
                p.write_bytes(before + b'# conflicting user change\n')
                with self.assertRaises(ValueError): replace_pinned(p,before,after)
                self.assertEqual(p.read_bytes(),before + b'# conflicting user change\n')
    def test_only_outputs_change(self):
        # This subset of Starlark also parses as Python. Stub loads and rule calls.
        for target,stem,expected_added in [('canoe','canoe_perf',69),('canoe','canoe_consolidate',0),('other','other_perf',0)]:
            captures=[]
            env={'load': lambda *a:None, 'write_file':lambda **a:None, 'kernel_build_config':lambda **a:None,
                 'get_dtb_list':lambda t:['base.dtb'],'get_dtbo_list':lambda t:['board.dtbo'],
                 'get_custom_dtbo_img_list':lambda t:['image-recipe'], 'get_dtstree':lambda t:'tree',
                 'kernel_build':lambda **a: captures.append(a)}
            exec((HERE/'dtbs.bzl.after').read_text(),env)
            result=env['define_qcom_dtbs'](stem,target,'defconfig')
            self.assertEqual(result,[['base.dtb'],['board.dtbo'],['image-recipe']])
            self.assertEqual(len(captures[0]['outs']),7+expected_added)
    def test_existing_collector_retains_every_dtbo(self):
        lock=json.loads((HERE/'retention-lock.json').read_text())
        env={'__name__':'collector_test','__file__':str(HERE/'runner.before')}
        exec((HERE/'runner.before').read_text(),env)
        names=[x['output'] for x in lock['outputs']]+['Image','Module.symvers',
            'myron-sm8850-overlay.dtbo','myron-audio-mtp.dtbo',
            'myron-sm8850-camera-sensor.dtbo','myron-sde-display-mtp-overlay.dtbo']
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); paths=[]
            for name in names:
                rel=Path('bazel-out/canoe_perf_dtb_build')/name
                p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'fixture')
                paths.append(str(rel))
            count=env['collect'](root,paths,'dtbs')
            self.assertEqual(count,75)
            manifest=json.loads((root/'integration-artifacts/dtbs/artifact-manifest.json').read_text())
            self.assertEqual({Path(x['source']).name for x in manifest['files']},set(names))

    def test_runner_order(self):
        text=(HERE/'runner.after').read_text();ast.parse(text)
        self.assertLess(text.index('"r10-apply.log"'),text.index('"dt-output-retention.log"'))
        self.assertLess(text.index('"dt-output-retention.log"'),text.index('command = bazel + ["build"]'))
    def test_unique_observed_only(self):
        lock=json.loads((HERE/'retention-lock.json').read_text())
        self.assertEqual(len({x['output'] for x in lock['outputs']}),69)
        for x in lock['outputs']:
            self.assertTrue(x['r9_dtc_log_observed'])
            self.assertIn(x['source'].removesuffix('.dts')+'.dtbo: Warning (',x['dtc_log_example'])
        for x in lock['excluded_unobserved_outputs']:
            self.assertFalse(x['r9_dtc_log_observed'])

if __name__=='__main__': unittest.main()
