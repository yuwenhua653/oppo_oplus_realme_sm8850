#!/usr/bin/env python3
"""Install after r10/install_hooks.py on the same fresh runner."""
import argparse
import json
from pathlib import Path
from apply_retention import HERE, sha, replace_pinned

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--package', required=True, type=Path)
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    package = a.package.resolve()
    if HERE != package.parent / 'dt-output-retention-r1':
        raise ValueError('Place dt-output-retention-r1 beside myron-qcom-platform-r1')
    lock = json.loads((HERE / 'retention-lock.json').read_text())
    before = (HERE / 'runner.before').read_bytes()
    after = (HERE / 'runner.after').read_bytes()
    if sha(before) != lock['runner_before_sha256'] or sha(after) != lock['runner_after_sha256']:
        raise ValueError('Damaged runner hook payload')
    compile(after, 'build_platform.py', 'exec')
    status = replace_pinned(package / 'build_platform.py', before, after, a.dry_run)
    print(json.dumps({'status': status, 'runner_sha256': lock['runner_after_sha256'],
                      'order': ['r1_prepare', 'r10_apply', 'dt_output_retention', 'existing_bazel_build', 'existing_collect', 'r10_validate']}, indent=2))

if __name__ == '__main__':
    main()
