用途：保留 Canoe 子系统 DTBO，用于下一轮离线合成与差异检查。

本补丁沿用 //vendor/qcom/sm8850:canoe_perf_dtb_build，不新增编译目标，
不修改 get_dtbo_list、platform_map.bzl、返回列表或 dtbo.img 打包顺序。
只在 canoe_perf 的 kernel_build outs 中增加 69 个已在成功 r9 编译日志出现的输出。
这些输出属于 GPU、DSP、IPA、视频、EVA、音频、显示、相机、连接等子系统；
v2、家族/开发板变体会一起保存供比较，不能把所有 DTBO 顺序叠加到 Myron。
这不是刷机包，不表示设备树已完成，更不表示硬件可用。

依据：r9 Actions 37901007114，源码锁定：
SoC: LineageOS/android_kernel_qcom_sm8850 @ 557159b6a0d06f1c6f07ec4c1f22bc9309a113e4
DT: lolipuru/android_kernel_xiaomi_sm8850-devicetrees @ 8b86fedda64183338411f9751f5e62ce25997620
retention-lock.json 保存前后 SHA256、每个准确 Kbuild 输出、DTS Git blob、
DT 编译器对目标 .dtbo 的警告路径与日志行号、成功日志整体 SHA256。
这不是依靠 DTS include 路径猜测产物；69 项均有对应 .dtbo 目标路径。
另外 10 项只有源码/Kbuild 声明而没有产物观察，均未加入 outs：
HW fence、eSE、synx、三个 MMRM、NFC SN220、camera 基础、fingerprint、smem-mailbox。
它们是否生成仍需单独确认，不能为凑齐清单强行声明。

安装：
1. 保留原 myron-adaptation-r10.zip，SHA256/602 文件锁不变。
2. 把本目录 dt-output-retention-r1 放到仓库根目录。
3. 在原工作流“Install Myron r10 source adaptation and validation gates”后，
   “Apply integration and run selected build”前插入 workflow-step.yml 的步骤。
   现有 PACKAGE_DIR、WORKSPACE_DIR 沿用，不替换成示例路径。
4. 安装脚本只接受已安装 r10 的准确 build_platform.py；重复执行无变化，
   若版本不符直接报错，不覆盖现有修改。
5. 真正执行顺序是 r1 prepare → r10 apply → 本补丁 → 原 Bazel build。
   不要把 apply_retention.py 独立放在 prepare 之前，源码准备可能覆盖修改。
6. 下一轮原 full 构建即可一起保留这些输出；无需为本补丁立即单开一轮 CI。

本地预检查：python3 dt-output-retention-r1/test_retention.py
共 5 个测试方法：前后哈希/试运行/幂等/冲突拒绝、非 Canoe 不变、
返回镜像列表不变、hook 顺序、准确输出证据、原 collector 收集全部输出。
原 collector 会复制 cquery 返回的所有 .dtb/.dtbo，不需要另一层归档修改。
本地通过不等于真实 Bazel 构建通过。尚未执行修改后的目标编译。
apply_retention.py 也会检查 69 个 DTS Git blob，发现源码漂移直接退出。
