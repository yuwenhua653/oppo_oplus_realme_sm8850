#!/usr/bin/env python3
"""Verify one r13 artifact and materialize an explicit, isolated module-stage policy.

Offline only: never rebuilds, modifies source KOs, makes images, or accesses a device.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
from elf_contract import parse_elf, norm, safe, file_sha

CORE = 'objects/bazel-out/aarch64-fastbuild/bin/common/kernel_aarch64/'
RUNTIME = {'early': '/lib/modules', 'late': '/r17-deferred/lib/modules'}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n', encoding='utf-8')


def named(record):
    require(isinstance(record, dict) and isinstance(record.get('name'), str), 'Root/exclusion must be a named evidence record')
    name = norm(record['name'])
    require(re.fullmatch(r'[A-Za-z0-9_]+', name), 'Invalid module name: ' + name)
    require(isinstance(record.get('reason'), str) and record['reason'].strip(), 'Missing reason: ' + name)
    evidence = record.get('evidence')
    require(isinstance(evidence, list) and evidence and all(isinstance(x, str) and x.strip() for x in evidence), 'Missing evidence: ' + name)
    return name


def softdeps(name, lines):
    result = {'pre': set(), 'post': set()}
    for line in lines:
        mode = None
        for token in line.split():
            if token in ('pre:', 'post:'):
                mode = token[:-1]
            else:
                require(mode is not None, 'Malformed softdep on ' + name)
                target = norm(token)
                require(re.fullmatch(r'[A-Za-z0-9_]+', target), 'Invalid softdep name on ' + name)
                result[mode].add(target)
    return result


def read_artifacts(root, policy, artifact_lock):
    root = root.resolve()
    require(artifact_lock.get('schema') == 1 and set(artifact_lock.get('metadata', {})) ==
            {'artifact-manifest.json', 'module-selection.json'}, 'Explicit artifact metadata lock required')
    pins = artifact_lock['metadata']
    require(all(isinstance(v, str) and re.fullmatch(r'[0-9a-f]{64}', v) for v in pins.values()), 'Invalid artifact lock hash')
    metadata = {}
    for path, expected in pins.items():
        data = (root / path).read_bytes()
        require(sha(data) == expected, 'Pinned metadata hash mismatch: ' + path)
        metadata[path] = json.loads(data)
    manifest = metadata['artifact-manifest.json']
    require(not manifest.get('missing_required_outputs'), 'Artifact declares missing required outputs')
    records = {r['file']: r for r in manifest['files']}
    require(len(records) == len(manifest['files']), 'Duplicate artifact manifest path')
    verified = {}
    cache = {}

    def artifact(path):
        safe(path)
        require(path in records, 'Missing artifact metadata: ' + path)
        source = root / path
        require(source.is_file() and source.resolve().is_relative_to(root), 'Invalid artifact source: ' + path)
        if path not in cache:
            data = source.read_bytes()
            require(len(data) == records[path]['bytes'] and sha(data) == records[path]['sha256'], 'Source hash/size mismatch: ' + path)
            cache[path] = data
            verified[path] = {'bytes': len(data), 'sha256': sha(data)}
        return cache[path]

    # Integrity-check even unselected alternative modules and all symbol-version artifacts.
    for path in sorted(records):
        safe(path)
        if path.endswith(('.ko', '.symvers')) or PurePosixPath(path).name in ('Image', 'Image.gz', 'Image.lz4'):
            artifact(path)
    for path in records:
        if PurePosixPath(path).name in ('modules.options', 'modules.dyn_options'):
            active = [line for line in artifact(path).decode().splitlines() if line.strip() and not line.lstrip().startswith('#')]
            require(not active, 'Active source module options require an explicit implementation: ' + path)
    selection = metadata['module-selection.json']
    selected = set(selection['selected'])
    require(len(selected) == len(selection['selected']), 'Duplicate module-selection path')
    built = {r['file']: r for r in selection['all_built']}
    require(len(built) == len(selection['all_built']) and selected <= built.keys(), 'Invalid selected artifact inventory')
    for source, record in built.items():
        data = artifact('objects/' + source)
        require(sha(data) == record['sha256'], 'Module-selection hash mismatch: ' + source)
    info, modules = {}, {}
    for source in sorted(selected):
        record = built[source]
        name = norm(record['name'])
        require(name not in info, 'Duplicate selected module identity: ' + name)
        parsed = parse_elf(artifact('objects/' + source))
        require(parsed['name'] == name and parsed['info']['vermagic'] == [record['vermagic']], 'ELF/metadata identity mismatch: ' + name)
        basename = PurePosixPath(source).name
        require(basename.endswith('.ko') and norm(basename[:-3]) == name, 'Module filename/name mismatch: ' + name)
        info[name] = parsed
        modules[name] = {'source': 'objects/' + source, 'filename': basename, 'sha256': record['sha256'],
                         'bytes': len(cache['objects/' + source]), 'vermagic': record['vermagic']}
    magics = {x['vermagic'] for x in modules.values()}
    require(len(magics) == 1, 'Mixed full module vermagic values')
    magic = next(iter(magics))
    image = artifact(CORE + 'Image')
    require(image[56:60] == b'ARMd', 'Expected raw ARM64 kernel Image')
    symvers = artifact(CORE + 'vmlinux.symvers')
    core = {}
    for line in symvers.decode().splitlines():
        fields = line.split()
        require(len(fields) >= 3 and fields[1] not in core, 'Invalid/duplicate core export')
        core[fields[1]] = ('vmlinux', int(fields[0], 16))
    require('module_layout' in core, 'Core module_layout CRC missing')

    excluded = {}
    for rec in policy.get('provider_exclusions', []):
        name = named(rec)
        require(name in info and name not in excluded, 'Invalid/duplicate provider exclusion: ' + name)
        require(rec.get('source') == modules[name]['source'] and rec.get('sha256') == modules[name]['sha256'], 'Exclusion source/hash is not pinned: ' + name)
        replacement = rec.get('replaced_by', {})
        other = norm(replacement.get('name', ''))
        require(other in info and other != name, 'Missing replacement provider: ' + name)
        require(replacement.get('source') == modules[other]['source'] and replacement.get('sha256') == modules[other]['sha256'], 'Replacement source/hash is not pinned: ' + name)
        overlap = set(info[name]['export_crcs']) & set(info[other]['export_crcs'])
        require(overlap and all(info[name]['export_crcs'][s] == info[other]['export_crcs'][s] for s in overlap), 'Exclusion is not an equivalent competing export provider: ' + name)
        excluded[name] = dict(rec, overlapping_exports=len(overlap), never_selected=True)
    require(not any(norm(v['replaced_by']['name']) in excluded for v in excluded.values()), 'Excluded replacement provider')
    available = set(info) - set(excluded)
    providers = dict(core)
    for name in sorted(available):
        for symbol, crc in info[name]['export_crcs'].items():
            require(symbol not in providers, 'Duplicate symbol provider: ' + symbol + ' (' + str(providers.get(symbol)) + ', ' + name + ')')
            providers[symbol] = (name, crc)
    hard, soft, counts = {}, {}, {}
    for name in sorted(available):
        hard[name] = set(info[name]['depends'])
        for symbol, crc in info[name]['versions'].items():
            require(symbol in providers, 'Missing symbol provider: ' + name + ':' + symbol)
            provider, expected = providers[symbol]
            require(crc == expected, 'Import CRC mismatch: ' + name + ':' + symbol)
            if provider != 'vmlinux':
                hard[name].add(provider)
        require(name not in hard[name], 'Self dependency: ' + name)
        soft[name] = softdeps(name, info[name]['softdeps'])
        counts[name] = len(info[name]['versions'])
    identity = {'kernel_release': magic.split()[0], 'full_vermagic': magic, 'kernel_sha256': sha(image),
                'kernel_source': CORE + 'Image', 'core_symvers_sha256': sha(symvers),
                'artifact_manifest_sha256': pins['artifact-manifest.json'],
                'module_selection_sha256': pins['module-selection.json'],
                'artifact_lock_sha256': sha(canonical(artifact_lock))}
    return {'root': root, 'info': info, 'modules': modules, 'available': available, 'excluded': excluded,
            'hard': hard, 'soft': soft, 'counts': counts, 'identity': identity,
            'verified_artifacts': verified, 'cache': cache}


def create_plan(policy, universe):
    require(policy.get('module_options', {}) == {} and policy.get('dynamic_options', {}) == {}, 'Module options are unsupported; refusing to discard parameters')
    require(not any(k in policy for k in ('ignore_softdeps', 'allow_missing_softdeps', 'skip_crc')), 'Dependency/CRC bypass fields are not supported')
    require(policy.get('schema') == 1 and isinstance(policy.get('policy_id'), str) and policy['policy_id'], 'Invalid policy identity')
    require(policy.get('release_status') == 'offline_only', 'This builder only accepts offline_only policies')
    require(isinstance(policy.get('blockers'), list) and all(isinstance(x, str) and x.strip() for x in policy['blockers']), 'Policy blockers must be explicit strings')
    early_roots = [named(x) for x in policy['early_roots']]
    groups = policy['late_groups']
    require(isinstance(groups, list), 'late_groups must be a list')
    classified = {n: 0 for n in early_roots}
    require(len(classified) == len(early_roots), 'Duplicate early root')
    group_roots, ids = [], set()
    for index, group in enumerate(groups, 1):
        require(re.fullmatch(r'[A-Za-z0-9_-]+', group['id']) and group['id'] not in ids and group.get('reason'), 'Invalid/duplicate group identity')
        ids.add(group['id'])
        roots = [named(x) for x in group['roots']]
        require(roots and len(set(roots)) == len(roots), 'Empty/duplicate late roots: ' + group['id'])
        for name in roots:
            require(name not in classified, 'Module root assigned to multiple stages/groups: ' + name)
            classified[name] = index
        group_roots.append(roots)
    require(early_roots or groups, 'Policy has no explicit roots')
    late_only = {named(x) for x in policy.get('late_only', [])}
    require(not set(early_roots) & late_only, 'Early root declared late_only')
    available = universe['available']; hard = universe['hard']; soft = universe['soft']
    assigned = {}; reasons = collections.defaultdict(list)

    def visit(name, group_index, parent):
        require(name in available, 'Missing or explicitly excluded dependency: ' + name + ' required by ' + parent)
        require(not (group_index == 0 and (name in late_only or classified.get(name, 0) > 0)),
                'Stage crossing: early dependency would promote late module ' + name + ' required by ' + parent)
        require(classified.get(name, group_index) <= group_index, 'Group crossing: dependency would promote later root ' + name)
        reasons[name].append(parent)
        if name in assigned:
            require(assigned[name] <= group_index, 'Dependency already assigned to a later group: ' + name)
            return
        assigned[name] = group_index
        for target in sorted(hard[name] | soft[name]['pre'] | soft[name]['post']):
            visit(target, group_index, name)

    for name in early_roots:
        visit(name, 0, 'explicit early root')
    for index, roots in enumerate(group_roots, 1):
        for name in roots:
            visit(name, index, 'explicit late root')
    before = {n: set(hard[n] | soft[n]['pre']) for n in assigned}
    post_predecessors = collections.defaultdict(set)
    for name in assigned:
        for post in soft[name]['post']:
            require(assigned[post] == assigned[name], 'Post-softdep crosses stage/group: ' + name + ' -> ' + post)
            before[post].add(name)
            post_predecessors[post].add(name)
    for name, deps in before.items():
        require(deps <= assigned.keys(), 'Dependency closure incomplete: ' + name)
        require(all(assigned[d] <= assigned[name] for d in deps), 'Ordering crosses a stage/group boundary: ' + name)
    order, done, busy = [], set(), set()

    def order_visit(name):
        if name in done:
            return
        require(name not in busy, 'Dependency/softdep ordering cycle: ' + name)
        busy.add(name)
        for dep in sorted(before[name]):
            order_visit(dep)
        busy.remove(name); done.add(name); order.append(name)

    for stage in range(len(groups) + 1):
        for name in sorted(n for n, i in assigned.items() if i == stage):
            order_visit(name)
    positions = {name: i for i, name in enumerate(order)}
    require(all(positions[d] < positions[n] for n in order for d in before[n]), 'Output is not topologically ordered')
    basenames = [universe['modules'][n]['filename'] for n in order]
    require(len(basenames) == len(set(basenames)), 'Duplicate flat module filename')
    aliases = collections.defaultdict(set)
    output = {}
    for name in order:
        stage = 'early' if assigned[name] == 0 else 'late'
        source = universe['modules'][name]
        for alias in universe['info'][name]['info'].get('alias', []):
            require(alias and not any(c.isspace() for c in alias), 'Malformed module alias: ' + name)
            aliases[alias].add(name)
        output[name] = dict(source, stage=stage, group=None if stage == 'early' else groups[assigned[name]-1]['id'],
                           runtime_path=RUNTIME[stage] + '/' + source['filename'],
                           hard_dependencies=sorted(hard[name]), soft_pre=sorted(soft[name]['pre']),
                           soft_post=sorted(soft[name]['post']), soft_post_predecessors=sorted(post_predecessors[name]),
                           load_before=sorted(before[name], key=positions.get),
                           aliases=universe['info'][name]['info'].get('alias', []),
                           firmware=universe['info'][name]['info'].get('firmware', []),
                           inclusion_reasons=sorted(set(reasons[name])), import_crc_records=universe['counts'][name])
    conflicts = {a: sorted(v) for a,v in aliases.items() if len(v) > 1}
    require(not conflicts, 'Duplicate exact alias provider in output: ' + str(conflicts))
    return {'schema': 1, 'policy_id': policy['policy_id'], 'policy_sha256': sha(canonical(policy)),
            'release_status': policy['release_status'], 'blockers': policy['blockers'],
            'hardware_tested': False, 'flash_ready': False, 'build_identity': universe['identity'],
            'module_options': {}, 'dynamic_options': {},
            'early': {'runtime_directory': RUNTIME['early'], 'roots': early_roots, 'order': [n for n in order if assigned[n] == 0]},
            'late': {'runtime_directory': RUNTIME['late'], 'groups': [dict(id=g['id'], reason=g['reason'], roots=group_roots[i],
                      order=[n for n in order if assigned[n] == i+1]) for i,g in enumerate(groups)]},
            'modules': output, 'provider_exclusions': universe['excluded'],
            'integrity': {'all_candidate_module_crc_records_checked': sum(universe['counts'].values()),
                          'output_module_crc_records_checked': sum(universe['counts'][n] for n in order),
                          'all_selected_modules_parsed': len(universe['info']),
                          'available_modules_after_explicit_exclusions': len(universe['available']),
                          'verified_artifacts': universe['verified_artifacts']}}


def index_contents(plan, stage):
    names = plan['early']['order'] if stage == 'early' else [n for g in plan['late']['groups'] for n in g['order']]
    all_order = plan['early']['order'] + [n for g in plan['late']['groups'] for n in g['order']]
    positions = {n:i for i,n in enumerate(all_order)}
    modules = plan['modules']
    dep, alias, soft = [], [], []
    for name in names:
        module = modules[name]
        targets = []
        for target in sorted(module['hard_dependencies'], key=positions.get, reverse=True):
            record = modules[target]
            targets.append(record['filename'] if record['stage'] == stage else record['runtime_path'])
        dep.append(module['filename'] + ':' + (' ' + ' '.join(targets) if targets else ''))
        alias.extend('alias ' + pattern + ' ' + name for pattern in module['aliases'])
        tokens = []
        if module['soft_pre']:
            tokens += ['pre:'] + module['soft_pre']
        if module['soft_post']:
            tokens += ['post:'] + module['soft_post']
        if tokens:
            soft.append('softdep ' + name + ' ' + ' '.join(tokens))
    load = ''.join(modules[n]['filename'] + '\n' for n in names)
    result = {'modules.dep': '\n'.join(dep) + ('\n' if dep else ''),
              'modules.alias': '\n'.join(alias) + ('\n' if alias else ''),
              'modules.softdep': '\n'.join(soft) + ('\n' if soft else ''),
              'modules.load': load, 'modules.load.recovery': load,
              'modules.options': '# No options or force flags added.\n',
              'modules.blocklist': '# Only explicit policy closure is materialized.\n'}
    if stage == 'late':
        for group in plan['late']['groups']:
            result['modules.load.' + group['id']] = ''.join(modules[n]['filename'] + '\n' for n in group['order'])
    return result


def build(artifact_root, policy_path, out, artifact_lock_path):
    require(not out.resolve().is_relative_to(artifact_root.resolve()), 'Output must be outside the input artifact root')
    require(not out.exists(), 'Output already exists; use a fresh directory')
    policy = json.loads(policy_path.read_text(encoding='utf-8'))
    artifact_lock = json.loads(artifact_lock_path.read_text(encoding='utf-8'))
    universe = read_artifacts(artifact_root, policy, artifact_lock)
    plan = create_plan(policy, universe)
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.module-stage-', dir=out.parent) as temporary:
        staging = Path(temporary) / 'result'
        staging.mkdir()
        indexes = {}
        for stage in ('early', 'late'):
            directory = staging / stage / 'lib/modules'
            directory.mkdir(parents=True)
            contents = index_contents(plan, stage)
            for name, content in contents.items():
                (directory / name).write_text(content, encoding='utf-8')
            indexes[stage] = {name: {'bytes': len(content.encode()), 'sha256': sha(content.encode())} for name,content in contents.items()}
        for name, module in plan['modules'].items():
            target = staging / module['stage'] / 'lib/modules' / module['filename']
            target.write_bytes(universe['cache'][module['source']])
            require(target.stat().st_size == module['bytes'] and file_sha(target) == module['sha256'], 'Output copy verification failed: ' + name)
        plan['indexes'] = indexes
        plan['plan_id'] = sha(canonical(plan))
        write_json(staging / 'stage-plan.json', plan)
        write_json(staging / 'policy.json', policy)
        write_json(staging / 'artifact-lock.json', artifact_lock)
        require(not out.exists(), 'Output appeared during build; refusing overwrite')
        staging.rename(out)
    return plan


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--artifact-root', type=Path, required=True)
    ap.add_argument('--policy', type=Path, required=True)
    ap.add_argument('--artifact-lock', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    plan = build(args.artifact_root, args.policy, args.out, args.artifact_lock)
    print(json.dumps({'plan_id': plan['plan_id'], 'early_count': len(plan['early']['order']),
                      'late_count': sum(len(g['order']) for g in plan['late']['groups']),
                      'release_status': plan['release_status'], 'flash_ready': False}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError) as e:
        raise SystemExit('STOP: ' + str(e))
