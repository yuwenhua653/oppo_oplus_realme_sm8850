#!/usr/bin/env python3
"""Build the audited Myron boot dependency set from the pinned r13 source base.

All kernel and module outputs come from this invocation. No device operation,
partition image, old binary overlay, or full ROM build is performed.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_bundle():
    lock = json.loads((HERE / 'bundle-lock.json').read_text())
    paths = set()
    for item in lock['files']:
        relative = PurePosixPath(item['path'])
        require(not relative.is_absolute() and '..' not in relative.parts,
                'Unsafe bundle path')
        require(item['path'] not in paths, 'Duplicate locked file')
        paths.add(item['path'])
        path = HERE / relative
        require(path.resolve().is_relative_to(HERE), 'Bundle path escapes root')
        require(sha(path.read_bytes()) == item['sha256'], 'Bundle hash mismatch: ' + item['path'])
    required = {'boot_build.py', 'module-targets.json', 'boot-policy.json',
                'source-fix/apply_soccp.py', 'check_soccp_elf.py',
                'stage-builder/build_stages.py', 'stage-builder/elf_contract.py'}
    require(required <= paths, 'Incomplete bundle lock')
    return sha((HERE / 'bundle-lock.json').read_bytes())


def collect(root, paths, destination, target_plan):
    """Retain only fresh cquery outputs; select the 142 explicitly audited KOs."""
    require(not destination.exists(), 'Refusing stale output directory')
    destination.mkdir(parents=True)
    sys.path.insert(0, str(HERE / 'stage-builder'))
    from elf_contract import parse_elf
    expected = {r['name']: r['source'] for r in target_plan['modules']}
    require(len(expected) == 142, 'Boot dependency inventory changed; audit it first')
    items, all_built, selected = [], [], []
    found = set()
    keep_names = {'Image', 'Image.gz', 'Image.lz4', 'System.map', 'kernel.release',
                  'modules.builtin', 'modules.builtin.modinfo', 'kernel_aarch64_dot_config', '.config'}
    for name in dict.fromkeys(paths):
        rel = PurePosixPath(name)
        require(not rel.is_absolute() and '..' not in rel.parts and name.startswith('bazel-out/'),
                'Unexpected cquery output path: ' + name)
        if not (name.endswith(('.ko', '.symvers')) or rel.name in keep_names):
            continue
        source = root / name
        require(source.is_file(), 'Declared build output missing: ' + name)
        data = source.read_bytes()
        target = destination / 'objects' / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        items.append({'file': 'objects/' + name, 'source': name,
                      'bytes': len(data), 'sha256': sha(data)})
        if name.endswith('.ko'):
            elf = parse_elf(data)
            module = elf['name']
            all_built.append({'file': name, 'name': module, 'bytes': len(data),
                              'sha256': sha(data), 'vermagic': elf['info']['vermagic'][0]})
            if module in expected:
                require(name == expected[module], 'Unexpected provider path: ' + module)
                require(module not in found, 'Duplicate boot provider: ' + module)
                found.add(module)
                selected.append(name)
    required = {'Image', 'vmlinux.symvers', 'kernel_aarch64_dot_config', 'include/config/kernel.release',
                'modules.builtin', 'modules.builtin.modinfo'}
    core = 'objects/bazel-out/aarch64-fastbuild/bin/common/kernel_aarch64/'
    present = {r['file'] for r in items}
    missing = sorted(core + n for n in required if core + n not in present)
    missing += sorted('module:' + n for n in expected.keys() - found)
    write_json(destination / 'artifact-manifest.json', {
        'stage': 'boot', 'files': items, 'missing_required_outputs': missing,
        'flashable': False, 'hardware_tested': False,
        'scope': 'One new kernel build and the audited boot module set; not a full device build.'})
    write_json(destination / 'module-selection.json', {
        'all_built': all_built, 'selected': sorted(selected),
        'scope': 'Explicit audited boot providers only; unused cquery outputs are not autoloaded.'})
    require(not missing, 'Incomplete build outputs: ' + ', '.join(missing))
    config = (destination / (core + 'kernel_aarch64_dot_config')).read_text()
    require('CONFIG_ARM64_4K_PAGES=y\n' in config, 'Unexpected kernel page size')
    release = (destination / (core + 'include/config/kernel.release')).read_text().strip()
    require(release and (b'Linux version ' + release.encode() + b' ') in
            (destination / (core + 'Image')).read_bytes(), 'Image/kernel.release mismatch')
    for item in all_built:
        if item['file'] in selected:
            require(item['vermagic'].split()[0] == release,
                    'Module release differs from Image: ' + item['name'])
    lock = {'schema': 1, 'metadata': {n: sha((destination / n).read_bytes())
            for n in ('artifact-manifest.json', 'module-selection.json')}}
    write_json(destination / 'artifact-lock.json', lock)
    (destination / 'NOT-A-FLASH-PACKAGE.txt').write_text(
        '这是启动依赖源码构建产物，不是可刷镜像。必须审核新 SOCCP 字段、依赖和设备镜像装配后再做实机测试。\n')
    return destination / ('objects/' + expected['qcom_q6v5_pas'])


def run(args):
    root, package, baseline = args.workspace.resolve(), args.package.resolve(), args.baseline.resolve()
    reports = root / 'integration-reports'
    reports.mkdir(parents=True, exist_ok=True)
    status_path = reports / 'r18-boot-status.json'
    status = dict(schema=1, success=False, compiled=False, hardware_tested=False,
                  flashable=False, phase='verify_bundle', started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    output = root / 'integration-artifacts/boot'
    layout = root / 'integration-artifacts/boot-layout'
    # Never let artifacts from a failed/retried attempt appear as a new success.
    for directory in (output, layout):
        if directory.exists():
            shutil.rmtree(directory)
    for stale in reports.glob('r18-*'):
        if stale.is_file():
            stale.unlink()
    write_json(status_path, status)
    try:
        require(args.jobs >= 1 and args.ram_mb >= 2048, 'Invalid build resources')
        status['bundle_lock_sha256'] = verify_bundle()
        helper = load('r13_driver_check', baseline / 'drivers/driver_check.py')
        runner_path = package / 'build_platform.py'
        runner_data, metadata = helper.verify_bundle(baseline, runner_path)
        status['baseline_runner'] = metadata
        bazel, options = helper.runner_build_configuration(runner_data, root, args.jobs, args.ram_mb)
        runner = load('r13_runner', runner_path)
        status['phase'] = 'prepare_pinned_r13_sources'
        runner.logged([sys.executable, str(package / 'prepare_workspace.py'), '--workspace', str(root)],
                      root, reports / 'r18-prepare.log')
        runner.logged([sys.executable, str(baseline / 'run_r12.py'), 'apply', '--workspace', str(root), '--stage', 'soc'],
                      root, reports / 'r18-r13-apply.log')
        helper.verify_applied_writes(baseline, root)
        status['phase'] = 'apply_soccp_fix'
        runner.logged([sys.executable, str(HERE / 'source-fix/apply_soccp.py'),
                       '--soc', str(root / 'vendor/qcom/sm8850')], root, reports / 'r18-soccp-apply.log')
        # Generate the same kernel.release output-group wrapper as the verified r13 runner.
        runner.build_targets(root, 'soc')
        plan = json.loads((HERE / 'module-targets.json').read_text())
        targets = list(dict.fromkeys(r['target'] for r in plan['modules'])) + [
            '//common:kernel_aarch64', '//myron_artifact_metadata:kernel_release']
        require(len(targets) == 144, 'Unexpected number of explicit boot targets')
        status.update(phase='compile_boot_targets', targets=targets, module_count=142)
        write_json(status_path, status)
        runner.logged(bazel + ['build'] + options + targets, root, reports / 'r18-boot-build.log')
        status['compiled'] = True
        # Use the exact same configuration for cquery as for the DDK compilation.
        query = 'set(' + ' '.join(targets) + ')'
        command = bazel + ['cquery'] + options + ['--output=files', query]
        result = subprocess.run(command, cwd=root, text=True, capture_output=True)
        (reports / 'r18-cquery.log').write_text(result.stderr)
        (reports / 'r18-cquery-outputs.txt').write_text(result.stdout)
        require(result.returncode == 0, 'cquery failed; see r18-cquery.log')
        status['phase'] = 'verify_actual_binaries'
        pas = collect(root, result.stdout.splitlines(), output, plan)
        runner.logged([sys.executable, str(HERE / 'check_soccp_elf.py'), '--module', str(pas),
                       '--source', str(root / 'vendor/qcom/sm8850/drivers/remoteproc/qcom_q6v5_pas.c'),
                       '--expect-auto-boot', '1', '--report', str(reports / 'r18-soccp-elf.json')],
                      root, reports / 'r18-soccp-elf.log')
        runner.logged([sys.executable, str(HERE / 'stage-builder/build_stages.py'),
                       '--artifact-root', str(output), '--artifact-lock', str(output / 'artifact-lock.json'),
                       '--policy', str(HERE / 'boot-policy.json'), '--out', str(layout)],
                      root, reports / 'r18-module-closure.log')
        stages = json.loads((layout / 'stage-plan.json').read_text())
        require(len(stages['early']['order']) == 142 and not stages['late']['groups'],
                'Unexpected corrected boot closure')
        status.update(success=True, phase='boot_outputs_verified', stage_plan_id=stages['plan_id'],
                      limitation='Build/ABI/initializer verification only. Boot, SOCCP handshake and ADB are not device-tested.')
    except Exception as error:
        status['error'] = str(error)
        print('R18 STOP:', error, file=sys.stderr)
    finally:
        status['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        write_json(status_path, status)
        if output.is_dir():
            shutil.copy2(status_path, output / status_path.name)
            for name in ('r18-soccp-elf.json', 'r18-soccp-apply.log'):
                if (reports / name).is_file():
                    shutil.copy2(reports / name, output / name)
    return 0 if status['success'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--ram-mb', type=int, default=10000)
    return run(parser.parse_args())


if __name__ == '__main__':
    sys.exit(main())
