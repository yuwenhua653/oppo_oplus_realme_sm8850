# Canoe SOCCP automatic attach source fix

This changes only `canoe_soccp_resource.auto_boot` from its implicit false value
to true in pinned SoC source commit
`557159b6a0d06f1c6f07ec4c1f22bc9309a113e4`.
Its existing `early_boot = true` remains intact. Other SoC, ADSP and CDSP
resource definitions, firmware handling, timeout and panic behavior are not
changed.

The actual Myron DT uses the Canoe SOCCP PAS compatible. The bootloader starts
SOCCP before Linux. The driver marks it DETACHED; common `rproc_add()` only calls
the automatic attach path when `auto_boot` is true. Attachment starts SOCCP's
GLINK edge, which provides the `PMIC_RTR_SOCCP_APPS` RPMSG channel needed to
instantiate the PMIC UCSI child. The successful original-kernel control shows
this attachment before UCSI and USB enumeration.

Use the production application script on the pinned **SoC git repository
root**, after syncing sources and before compiling the PAS module:

```sh
python3 apply_soccp.py --soc /absolute/path/to/soc-checkout --check
python3 apply_soccp.py --soc /absolute/path/to/soc-checkout
python3 apply_soccp.py --soc /absolute/path/to/soc-checkout --check
```

`--check` performs no source writes. `check_ready` means the exact original
source is valid and would need the fix. `check_already_applied` means the exact
patched source is present. Both return zero. Applying to the exact postimage is
idempotent and does not rewrite the file. Unknown HEAD, unknown source bytes,
unexpected tracked source, and symlinked source paths are rejected. There is no
force or skip-verification option.

Every execution prints a JSON change report to stdout and returns nonzero on
refusal. CI may redirect stdout to its evidence directory. The production
script checks git HEAD, the original file at HEAD, and the working file's exact
pre/post SHA256. `soccp-source-lock.json` and the unified patch expose the same
fixed transformation for review.

The focused verification command is:

```sh
python3 validate_soccp_fix.py --source /path/to/pinned/original/qcom_q6v5_pas.c --out validation
```

This validates the exact patch, source check/apply/idempotency/refusal behavior,
then compiles a small host LP64 program using the **verbatim real `adsp_data`
definition and exact before/after initializer**. It confirms a 120-byte struct,
`auto_boot` at offset 54 and `early_boot` at offset 118, with only byte 54 changed.
Checkout-command responses are mocked only within these unit checks; a real CI
checkout must still pass the production script's unmocked git verification.
This is not a target module build or hardware test.

The fix requires recompiling `qcom_q6v5_pas.ko` and validating that new output's
source provenance, module imports/exports, vermagic and CRC compatibility with
the kernel and accompanying modules. Simply expanding the old r13 modules from
135 to 142 does **not** incorporate this source fix and must not be described
as completing the SOCCP correction.
