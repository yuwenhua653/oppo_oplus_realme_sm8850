#!/usr/bin/env python3
"""Focused source-fix checks plus LP64 layout compilation from the real struct.

No target module is built. Checkout validation is mocked only inside these
isolated unit checks; the production apply_soccp.py has no bypass option.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from unittest.mock import patch
import apply_soccp as fix


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();before=args.source.read_bytes();after=fix.patch_bytes(before)
    original=before.decode();modified=after.decode();checks={}
    expected_patch=''.join(difflib.unified_diff(original.splitlines(True),modified.splitlines(True),
        fromfile='a/'+fix.SOURCE_PATH,tofile='b/'+fix.SOURCE_PATH))
    checks['patch_matches_exact_locked_transformation']=expected_patch==Path(__file__).with_name('canoe-soccp-auto-attach.patch').read_text()
    checks['all_bytes_outside_canoe_initializer_unchanged']=before.replace(fix.BEFORE,b'INITIALIZER',1)==after.replace(fix.AFTER,b'INITIALIZER',1)
    with tempfile.TemporaryDirectory(prefix='soccp-fix-validate-') as tmp:
        root=Path(tmp);soc=root/'soc';target=soc/fix.SOURCE_PATH;target.parent.mkdir(parents=True);target.write_bytes(before)
        with patch.object(fix,'validate_checkout',return_value=fix.EXPECTED_HEAD):
            report=fix.apply(soc,True,fix.base_report(True))
            checks['check_is_read_only']=target.read_bytes()==before and report['would_change'] and not report['changed']
            report=fix.apply(soc,False,fix.base_report(False))
            checks['apply_matches_post_hash']=target.read_bytes()==after and report['action']=='applied'
            stamp=target.stat().st_mtime_ns
            report=fix.apply(soc,False,fix.base_report(False))
            checks['already_applied_does_not_rewrite']=target.stat().st_mtime_ns==stamp and report['action']=='already_applied'
            target.write_bytes(before+b'\n')
            try:fix.apply(soc,False,fix.base_report(False));checks['unknown_bytes_refused']=False
            except ValueError:checks['unknown_bytes_refused']=target.read_bytes()==before+b'\n'
        def wrong_git(directory,*cmd):
            if cmd==('rev-parse','--show-toplevel'):return str(soc).encode()+b'\n'
            if cmd==('rev-parse','HEAD'):return b'0'*40+b'\n'
            raise AssertionError(cmd)
        with patch.object(fix,'git_output',side_effect=wrong_git):
            try:fix.validate_checkout(soc);checks['wrong_git_head_refused']=False
            except ValueError:checks['wrong_git_head_refused']=True
        def valid_git(directory,*cmd):
            if cmd==('rev-parse','--show-toplevel'):return str(soc).encode()+b'\n'
            if cmd==('rev-parse','HEAD'):return fix.EXPECTED_HEAD.encode()+b'\n'
            if cmd==('show','HEAD:'+fix.SOURCE_PATH):return before
            raise AssertionError(cmd)
        with patch.object(fix,'git_output',side_effect=valid_git):
            checks['git_head_and_tracked_source_validation']=fix.validate_checkout(soc)==fix.EXPECTED_HEAD
        # Use the complete, verbatim real source struct. Only forward declare its
        # pointer type; do not reconstruct offsets by hand.
        start=original.index('struct adsp_data {');end=original.index('\n};',start)+3
        struct_source=original[start:end]
        c='''#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
struct q6_subdev;
'''+struct_source+'\n'+fix.BEFORE.decode().replace('canoe_soccp_resource','before')+'\n'+fix.AFTER.decode().replace('canoe_soccp_resource','after')+'''
int main(void) {
  const unsigned char *a=(const unsigned char *)&before;
  const unsigned char *b=(const unsigned char *)&after;
  size_t differences=0, difference_offset=0;
  for (size_t i=0;i<sizeof(before);i++) if(a[i]!=b[i]) { differences++; difference_offset=i; }
  printf("{\\"pointer_bytes\\":%zu,\\"struct_bytes\\":%zu,\\"auto_boot_offset\\":%zu,\\"early_boot_offset\\":%zu,\\"before_auto_boot\\":%d,\\"after_auto_boot\\":%d,\\"before_early_boot\\":%d,\\"after_early_boot\\":%d,\\"different_bytes\\":%zu,\\"difference_offset\\":%zu}\\n",sizeof(void*),sizeof(before),offsetof(struct adsp_data,auto_boot),offsetof(struct adsp_data,early_boot),before.auto_boot,after.auto_boot,before.early_boot,after.early_boot,differences,difference_offset);
  return !(sizeof(void*)==8 && sizeof(before)==120 && !before.auto_boot && after.auto_boot && before.early_boot && after.early_boot && differences==1 && difference_offset==offsetof(struct adsp_data,auto_boot));
}
'''
        cpath=root/'soccp_layout.c';cpath.write_text(c);exe=root/'soccp_layout'
        compiler=shutil.which('cc');assert compiler,'No host C compiler'
        comp=subprocess.run([compiler,'-std=c11','-Wall','-Wextra','-Werror',str(cpath),'-o',str(exe)],capture_output=True,text=True)
        assert comp.returncode==0,comp.stderr
        run=subprocess.run([str(exe)],capture_output=True,text=True)
        assert run.returncode==0,run.stdout+run.stderr
        layout=json.loads(run.stdout)
        checks['real_struct_compiled_layout_only_auto_boot_byte_changes']=True
        args.out.mkdir(parents=True,exist_ok=True)
        (args.out/'soccp_layout.c').write_text(c)
    assert all(checks.values()),checks
    report={'checks':checks,'host_layout':layout,'host_compiler':compiler,
        'git_validation_mocked_in_unit_checks':True,'production_applier_has_no_skip_git_option':True,
        'full_kernel_or_module_compiled':False,'hardware_tested':False,
        'source_before_sha256':fix.sha(before),'source_after_sha256':fix.sha(after),
        'aarch64_module_layout_claim':'Compare auto_boot offset with the existing r13 ELF independently; this executable check is host LP64, not an AArch64 module build.'}
    (args.out/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))


if __name__=='__main__':main()
