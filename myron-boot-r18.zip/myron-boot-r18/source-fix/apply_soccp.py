#!/usr/bin/env python3
"""Apply the pinned Canoe SOCCP auto-attach source fix, or inspect with --check.

The only source semantic change is canoe_soccp_resource.auto_boot = true.
An exact git HEAD and exact pre/post file hash are required. This script does
not compile modules, assemble images, operate hardware, or change other files.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile

EXPECTED_HEAD = '557159b6a0d06f1c6f07ec4c1f22bc9309a113e4'
SOURCE_PATH = 'drivers/remoteproc/qcom_q6v5_pas.c'
PRE_SHA256 = 'ffe7da1a5c05cd7d684d569ff6e56a9c7b2d9db0af630e6ce90094d128b6cf4c'
POST_SHA256 = '06b11e9af536b1ce77c9278602de35d0557e7a908cba12446f71196ec6c4d94a'
PRE_BYTES = 102736
POST_BYTES = 102831
BEFORE = b'''static const struct adsp_data canoe_soccp_resource = {
\t.crash_reason_smem = 656,
\t.firmware_name = "soccp.mbn",
\t.dtb_firmware_name = "soccp_dtb.mbn",
\t.pas_id = 51,
\t.dtb_pas_id = 0x41,
\t.minidump_id = 24,
\t.uses_elf64 = true,
\t.ssr_name = "soccp",
\t.sysmon_name = "soccp",
\t.early_boot = true,
};'''
AFTER = BEFORE.replace(b'\t.early_boot = true,',
    b'\t/* Attach bootloader-started SOCCP so its GLINK edge can publish UCSI. */\n'
    b'\t.auto_boot = true,\n\t.early_boot = true,')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def git_output(soc, *args):
    result = subprocess.run(['git','-C',str(soc),*args],capture_output=True,check=False)
    require(result.returncode == 0, 'git verification failed: '+result.stderr.decode(errors='replace').strip())
    return result.stdout


def validate_checkout(soc):
    root = Path(git_output(soc,'rev-parse','--show-toplevel').decode().strip()).resolve()
    require(root == soc, '--soc must identify the SoC source repository root')
    head = git_output(soc,'rev-parse','HEAD').decode().strip()
    require(head == EXPECTED_HEAD, 'Unexpected SoC git HEAD: '+head)
    tracked = git_output(soc,'show','HEAD:'+SOURCE_PATH)
    require(len(tracked) == PRE_BYTES and sha(tracked) == PRE_SHA256,
            'The pinned HEAD does not contain the expected original source bytes')
    return head


def patch_bytes(before):
    require(len(before) == PRE_BYTES and sha(before) == PRE_SHA256,
            'Unknown source bytes; refusing fuzzy patching')
    require(before.count(BEFORE) == 1 and AFTER not in before,
            'Expected exactly one unmodified Canoe SOCCP initializer')
    after = before.replace(BEFORE,AFTER,1)
    require(len(after) == POST_BYTES and sha(after) == POST_SHA256,
            'Patched bytes do not match the locked result')
    return after


def apply(soc, check, report):
    soc = soc.resolve()
    report['soc_directory'] = str(soc)
    report['actual_git_head'] = validate_checkout(soc)
    path = soc/SOURCE_PATH
    cursor = soc
    for part in Path(SOURCE_PATH).parts:
        cursor /= part
        require(not cursor.is_symlink(), 'Refusing symlink in source path: '+str(cursor))
    require(path.is_file(), 'Source file is missing')
    before = path.read_bytes()
    report['input'] = dict(bytes=len(before),sha256=sha(before))
    if len(before) == POST_BYTES and sha(before) == POST_SHA256:
        report.update(ok=True,action='check_already_applied' if check else 'already_applied',
                      changed=False,would_change=False,source_fix_present=True,output=report['input'])
        return report
    after = patch_bytes(before)
    if check:
        report.update(ok=True,action='check_ready',changed=False,would_change=True,
                      source_fix_present=False,output=report['input'],
                      expected_after_apply=dict(bytes=len(after),sha256=sha(after)))
        return report
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix='.soccp-source-',dir=path.parent,delete=False) as f:
            temporary = Path(f.name)
            f.write(after);f.flush();os.fsync(f.fileno())
        os.chmod(temporary,stat.S_IMODE(path.stat().st_mode))
        require(path.read_bytes() == before, 'Source changed concurrently; refusing replacement')
        os.replace(temporary,path)
        temporary = None
        verified = path.read_bytes()
        require(sha(verified) == POST_SHA256, 'Written source verification failed')
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    report.update(ok=True,action='applied',changed=True,would_change=True,
                  source_fix_present=True,output=dict(bytes=len(verified),sha256=sha(verified)))
    return report


def base_report(check):
    return dict(schema=1,ok=False,mode='check' if check else 'apply',
        expected_git_head=EXPECTED_HEAD,source_path=SOURCE_PATH,
        expected_original=dict(bytes=PRE_BYTES,sha256=PRE_SHA256),
        expected_patched=dict(bytes=POST_BYTES,sha256=POST_SHA256),
        only_changed_initializer='canoe_soccp_resource',
        semantic_change={'auto_boot':{'before':False,'after':True},'early_boot':{'before':True,'after':True}},
        other_remoteproc_initializers_changed=False,
        requires_rebuild=True,requires_recompiled_module='qcom_q6v5_pas.ko',
        binary_built=False,hardware_tested=False,
        old_r13_142_module_layout_includes_fix=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--soc',type=Path,required=True,help='Exact pinned SoC git checkout root')
    parser.add_argument('--check',action='store_true',help='Read only; verify known pre/post state and print JSON')
    args = parser.parse_args()
    report = base_report(args.check)
    try:
        apply(args.soc,args.check,report)
    except (OSError,ValueError,subprocess.SubprocessError) as exc:
        report.update(ok=False,action='refused',reason=str(exc))
    print(json.dumps(report,indent=2,sort_keys=True))
    return 0 if report['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
