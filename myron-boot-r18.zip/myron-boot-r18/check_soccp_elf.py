#!/usr/bin/env python3
"""Fail-closed SOCCP descriptor gate for source-built AArch64 PAS ELF objects.

This proves selected source/ELF fields and instruction layout, never runtime boot.
No third-party Python packages are required. No input is modified.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import sys

EXPECTED_STRUCT = """
int crash_reason_smem; int crash_reason_stack;
const char *firmware_name; const char *dtb_firmware_name;
struct q6_subdev *q6_subdev; int q6_subdev_count;
int pas_id; int dtb_pas_id; int lite_pas_id; unsigned int minidump_id;
bool both_dumps; bool uses_elf64; bool auto_boot; bool decrypt_shutdown;
char **proxy_pd_names;
const char *load_state; const char *ssr_name; const char *sysmon_name;
int ssctl_id; unsigned int smem_host_id; unsigned int early_boot_smem_id;
int region_assign_idx; int region_assign_count; bool region_assign_shared;
int region_assign_vmid; bool dma_phys_below_32b; bool check_status; bool early_boot;
"""


def compact(text):
    text = re.sub(r"/\*.*?\*/|//[^\n]*", "", text, flags=re.S)
    return re.sub(r"\s+", "", text)


def require(condition, message):
    if not condition:
        raise ValueError(message)


class ELF:
    def __init__(self, data, expected_machine=183):
        self.data = data
        require(data[:6] == b"\x7fELF\x02\x01", "Expected ELF64 little-endian")
        require(struct.unpack_from("<HH", data, 16) == (1, expected_machine),
                f"Expected ET_REL object/module for ELF machine {expected_machine}")
        off = struct.unpack_from("<Q", data, 40)[0]
        entry_size, count, _ = struct.unpack_from("<HHH", data, 58)
        require(entry_size == 64 and count > 0 and off + count * entry_size <= len(data), "Invalid section table")
        self.sections = [struct.unpack_from("<IIQQQQIIQQ", data, off + i * entry_size) for i in range(count)]
        self.symbols = []
        for i, h in enumerate(self.sections):
            if h[1] != 2:
                continue
            require(h[9] == 24, "Unexpected symbol entry size")
            strings = self.section(h[6])
            raw = self.section(i)
            require(len(raw) % 24 == 0, "Truncated symbol table")
            for j in range(0, len(raw), 24):
                name, info, other, sec, value, size = struct.unpack_from("<IBBHQQ", raw, j)
                require(name < len(strings), "Invalid symbol name offset")
                end = strings.find(b"\0", name)
                require(end >= 0, "Unterminated symbol name")
                self.symbols.append({"name": strings[name:end].decode(), "type": info & 15,
                                     "section": sec, "value": value, "size": size})

    def section(self, index):
        require(0 <= index < len(self.sections), "Invalid section index")
        h = self.sections[index]
        require(h[1] != 8, "No file data in NOBITS section")
        require(h[4] + h[5] <= len(self.data), "Truncated section")
        return self.data[h[4]:h[4] + h[5]]

    def symbol(self, name, symbol_type):
        candidates = [s for s in self.symbols if s["name"] == name and s["section"] != 0]
        require(len(candidates) == 1, f"Expected one defined {name}")
        s = candidates[0]
        require(s["type"] == symbol_type, f"Unexpected ELF symbol type for {name}")
        sec = self.section(s["section"])
        require(s["value"] + s["size"] <= len(sec), f"Out-of-range symbol {name}")
        return s, sec[s["value"]:s["value"] + s["size"]]


def probe_evidence(elf):
    symbol, code = elf.symbol("adsp_probe", 2)
    require(len(code) % 4 == 0, "adsp_probe size is not instruction-aligned")
    matches = []
    for offset in range(0, len(code) - 4, 4):
        load, store = struct.unpack_from("<II", code, offset)
        # A64 unsigned-immediate byte load/store. Register allocation and
        # function-relative location may vary; semantics/field offsets may not.
        if ((load & 0xffc00000) == 0x39400000 and (store & 0xffc00000) == 0x39000000
                and ((load >> 10) & 4095) == 54 and ((store >> 10) & 4095) == 1249
                and (load & 31) == (store & 31) and (load & 31) != 31):
            matches.append({"function_offset": offset, "load_word_hex": f"{load:08x}",
                            "store_word_hex": f"{store:08x}", "value_register": load & 31,
                            "descriptor_base_register": (load >> 5) & 31,
                            "rproc_base_register": (store >> 5) & 31,
                            "descriptor_offset": 54, "rproc_offset": 1249})
    require(len(matches) == 1, "Expected one adjacent desc+54 LDRB -> rproc+1249 STRB in adsp_probe; review changed compiler layout if absent")
    return {"symbol": symbol, "matches": matches,
            "note": "Semantic instruction scan; function offsets and registers are not hardcoded. A changed instruction sequence requires review, not a bypass."}


def inspect(path, require_fixed_values):
    data = path.read_bytes()
    elf = ELF(data)
    resources = {}
    for name in ("canoe_soccp_resource", "canoe_adsp_resource", "canoe_cdsp_resource"):
        symbol, raw = elf.symbol(name, 1)
        require(len(raw) == 120, f"{name} must be 120 bytes")
        resources[name] = {"symbol": symbol, "auto_boot": raw[54], "early_boot": raw[118],
                           "raw_sha256": hashlib.sha256(raw).hexdigest()}
    evidence = {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(),
                "resources": resources, "probe": probe_evidence(elf)}
    if require_fixed_values:
        require(resources["canoe_soccp_resource"]["auto_boot"] == 1, "SOCCP auto_boot must be 1")
        require(resources["canoe_soccp_resource"]["early_boot"] == 1, "SOCCP early_boot must remain 1")
        for name in ("canoe_adsp_resource", "canoe_cdsp_resource"):
            require(resources[name]["auto_boot"] == 0, f"{name} auto_boot must remain 0")
    return evidence


def validate_source(path):
    text = path.read_text()
    definitions = re.findall(r"struct\s+adsp_data\s*\{(.*?)\}\s*;", text, re.S)
    require(len(definitions) == 1, "Expected one adsp_data definition")
    require(compact(definitions[0]) == compact(EXPECTED_STRUCT), "adsp_data layout changed; offsets require re-audit")
    for label, auto, early in (("canoe_soccp_resource", True, True),
                              ("canoe_adsp_resource", False, None),
                              ("canoe_cdsp_resource", False, None)):
        matches = re.findall(r"static\s+const\s+struct\s+adsp_data\s+" + label + r"\s*=\s*\{(.*?)\}\s*;", text, re.S)
        require(len(matches) == 1, f"Expected exactly one source resource {label}")
        body = compact(matches[0])
        auto_values = re.findall(r"\.auto_boot=([^,}]+)", body)
        require(len(auto_values) <= 1, f"Duplicate auto_boot initializer in {label}")
        require((auto_values == ["true"]) if auto else (not auto_values or auto_values == ["false"]),
                f"Unexpected source auto_boot for {label}")
        if early:
            require(re.findall(r"\.early_boot=([^,}]+)", body) == ["true"], "SOCCP source early_boot must remain true")
    require("rproc->auto_boot=desc->auto_boot;" in compact(text), "Missing descriptor-to-rproc auto_boot assignment")
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "normalized_struct_sha256": hashlib.sha256(compact(EXPECTED_STRUCT).encode()).hexdigest(),
            "layout": {"struct_size": 120, "auto_boot_offset": 54, "early_boot_offset": 118}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--module", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--expect-auto-boot", type=int, choices=[1], default=1,
                        help="Corrected SOCCP must be 1; this gate does not accept the old value")
    parser.add_argument("--reference-module", type=Path,
                        help="Optional original r13 layout reference; SOCCP auto_boot is expected to be 0")
    parser.add_argument("--output", "--report", dest="output", type=Path)
    args = parser.parse_args()
    result = {"passed": False, "evidence_scope": "source layout and compiled ELF fields/instructions only",
              "runtime_tested": False, "boot_success_claimed": False}
    try:
        # Record useful old-artifact evidence even when the value gate fails.
        result["module"] = inspect(args.module, False)
        result["source"] = validate_source(args.source)
        if args.reference_module:
            result["reference"] = inspect(args.reference_module, False)
            reference = result["reference"]["resources"]
            require(reference["canoe_soccp_resource"]["auto_boot"] == 0, "Reference is not the uncorrected r13 SOCCP descriptor")
            require(reference["canoe_soccp_resource"]["early_boot"] == 1, "Reference SOCCP early_boot differs")
        inspect(args.module, True)
        result["passed"] = True
    except (ValueError, OSError, struct.error, UnicodeError) as error:
        result["error"] = str(error)
    encoded = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded)
    print(encoded, end="")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
