r7 Xiaomi 驱动候选
=================

保留 hwid/miev、xiaomi_touch 及七个 MCA 基础模块，新增 protocol_class、
protocol_qc_class、platform_loadsw_class、charge_interface 四个 MCA 接口模块。
source-lock.json 的 exports 是真实产物必须具备的完整导出集合；module_contracts
定义必要导入/依赖、参数和别名。导入 CRC 必须匹配同次构建的 Module.symvers。
此检查不声明与旧原厂二进制模块兼容。
upstream/ 保存原始文件，payload/ 保存安装内容；evidence/ 保存来源和适配差异。

新增接口的 callback 字段顺序依据原厂 ELF 调整，但完整 ABI/行为等价尚未证明。
protocol 增加注销 API 并使用 SRCU 保护回调；QC 注销后才允许其设备释放。
原厂 ADC 字段次序、hwid 身份映射保持不变，mca_hwid 现在完整初始化后才发布。
loadsw 的 DT 节点维持 disabled；源码编译不会自动启用该硬件路径。
主机测试编译实际 C，并模拟内核服务；它不替代目标模块构建、CFI 或实机测试。

本批不包含充电 IC、PD/ADSP 完整协议实现或电压/电流/温控策略。
触摸框架源自官方 popsicle，仅背移官方 warsaw 两个 MIEV 上报函数。
FT3683 匹配源码仍缺；DT 门禁仅验证现有框架节点绑定。
所有候选的硬件提供者生命周期、并发、固件和整机功能仍须进一步验证。
