R23 source-only DRM object diagnostics and hwfence debug-read fix

Pinned input
  LineageOS/android_kernel_qcom_sm8850-modules
  f2ecb6a09ea56bd8ec9a0bfd2e97f45e200ab322
  Exact paths and SHA256 before/after: manifest.json.
  Four targets: sde_rm.c, sde_hw_dspp.c, sde_kms.c, sde_fence.c.
  before/ contains original pinned upstream bytes, not the R21 patched files.

Apply to an already prepared modules checkout
  mkdir -p /path/to/reports
  python3 apply_probe.py --modules-root /path/to/vendor/qcom/sm8850-modules \
    --report /path/to/reports/r23-probe-apply.json

The report directory must already exist and be outside both modules-root and this
bundle. All four inputs, all before/after payloads, the patch and the pinned
manifest pass validation before source replacement. Only exact before/after
hashes are accepted. Known after bytes are not rewritten; known mixed input is
completed after all four pass. Unknown input, a corrupt payload or a symlink is
refused. Permissions are preserved. Replacements are atomic per file, not a
four-file transaction; an I/O failure after any replacement is partial_failure.
This applicator does not build, modify defaults or operate on a device.

What changes
The three R21 source files retain their 61 original probe occurrences, including
three existing temporary-result rewrites. R23 adds 110 pr_info occurrences to
sde_kms.c and does not rewrite any further expression, branch or hardware call.
New output requires no drm.debug enable: leave its existing default at zero.

The new probes identify the IRQ domain, display discovery counts/handles, setup
of WB/DSI/DP/HDMI/loopback displays, CESTA clients, encoders, bridges, connectors,
physical/virtual planes, CRTCs and object compatibility bookkeeping. DP MST uses
its existing stream index. DSI bridge logging also encloses its existing nested
sde_cesta_is_aoss_supported argument; DSI connector logging also encloses its
existing nested dsi_display_get_drm_panel argument. These are call boundaries,
not proof of which nested instruction failed.

virtual_plane_slot is an observation after the existing smart_dma_priority read,
before the existing priority-1 array writes. It uses initialized local variables.
object_counts and crtc_counts observe max_crtc_count and primary_planes_idx after
their existing calculations. No sspp_id/master_plane_id members are newly read,
and their original initialization/indexing semantics remain untouched.

The sde_fence.c change is limited to deleting " wr_idx:0x%x" and the associated
*hwfence_data->txq_wr_ptr_pa debug argument. This pointer stores a device IOVA;
the CPU must not dereference it for logging. The existing tx_wm CPU-VA read,
queue address setup, registration and hardware operations are unchanged. The
new debug string is:
  hwfence registered ctl:%d client:%d handle:0x%pK tx_wm:0x%x\n

R22's earlier debug-induced invalid read is distinct from R21's original stall
after kms_objects enter. Removing this read is not evidence that the original
stall or full Android boot has been fixed.

Pairing and failure interpretation
Most enter/return pairs directly bracket one existing call. Return logs occur
before the original error branch, including failed calls followed by continue or
goto. Pointer outputs record PTR_ERR only when IS_ERR, otherwise rc=0 and a
separate null flag. A null flag is not success, and existing error handling is
not altered. Void helpers report return without inventing an rc value.

display_discovery and display_setup pair one function entry with the existing
success or error exit. Allocation failures in discovery reach its original
cleanup path and final error return; allocations are not separately probed.
object_compatibility is one region pair. object_cleanup and irq_domain_cleanup
retain the prior failure rc while bracketing their cleanup calls. observed
events are deliberately unpaired snapshots.

Printk changes timing and adds bounded per-probe output. Missing return output
narrows an observed interval; transport loss can hide already-emitted records.
This is not a hot-path tracing patch and adds no delays or broad debug enable.

Validation and collector contract
  python3 verify_structure.py --report /path/to/reports/r23-structure.json
  python3 -m unittest discover -s tests -v

structure-validation.json proves exact reverse edits to pinned source hashes,
unchanged nonlogging call counts, return expressions, goto order and preprocessor
directives. It additionally checks that R23's kms delta consists only of logging
lines/whitespace, and that the fence delta is exactly the format/argument removal.
The host C literal compilation checks escape decoding and ELF string matching;
it does not compile the Qualcomm module or establish its target ABI.

There are 171 total occurrences and 168 unique formats. expected_markers contains
39 mandatory decoded formats: the original R21 19 plus 20 unconditional R23
IRQ/discovery-count/object-bookkeeping boundaries. all_source_markers includes
loop-, error- and configuration-dependent formats as optional audit evidence;
their absence from optimized module bytes must not fail collection. Formats omit
the decoded newline in the manifest. Both MYRON_R21 and MYRON_R23 prefixes are
intentional. A real build must check mandatory literals, the fence format and the
module ABI before a hardware test package is prepared.

The focused applicator tests cover pristine apply, idempotence/permissions,
unknown-fourth-file refusal before writes, corrupt before/after/patch payloads,
manifest pinning, symlink handling, path escapes and report clobber attempts.
application-validation.json also records applying the actual four-file payload
to a temporary pinned-source fixture and confirming an idempotent second pass.
No kernel/module build or device test was performed in this source-patch task.

The self-contained source review contract is before/, after/, edits.json and
manifest.json; the workspace-only generator is not required or included.
