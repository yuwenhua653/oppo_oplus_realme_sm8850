#!/usr/bin/env python3
"""Apply the pinned ACK legacy DT overlay compatibility patch; never builds/flashes."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(data):
    return hashlib.sha256(data).hexdigest()


def run(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("common_repo", type=Path)
    parser.add_argument("--check", action="store_true", help="Validate only; do not apply")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    manifest = json.loads((here / "ack-dtbo-dts-patch-manifest.json").read_text())
    patch = here / "ack-dtbo-dts-compat.patch"
    if digest(patch.read_bytes()) != manifest["patch_sha256"]:
        raise ValueError("Patch checksum mismatch")
    repo = args.common_repo.resolve(strict=True)
    if Path(run(repo, "rev-parse", "--show-toplevel")).resolve() != repo:
        raise ValueError("common_repo must name the Git repository root")
    if run(repo, "rev-parse", "HEAD") != manifest["revision"]:
        raise ValueError("Unexpected ACK revision; use the pinned commit")
    states = []
    for item in manifest["files"]:
        path = repo / item["path"]
        if path.is_symlink() or path.resolve(strict=True) != path:
            raise ValueError("Patched paths must be regular files without symlink parents")
        current = digest(path.read_bytes())
        if current == item["before_sha256"]:
            states.append("before")
        elif current == item["after_sha256"]:
            states.append("after")
        else:
            raise ValueError("Local edits or unexpected content: " + item["path"])
    if set(states) == {"after"}:
        print("COMMON_DT_PATCH=ALREADY_APPLIED")
        return
    if set(states) != {"before"}:
        raise ValueError("Partially applied patch; restore or review the files manually")
    subprocess.run(["git", "-C", str(repo), "apply", "--check", str(patch)], check=True)
    if args.check:
        print("COMMON_DT_PATCH=READY")
        return
    subprocess.run(["git", "-C", str(repo), "apply", str(patch)], check=True)
    for item in manifest["files"]:
        if digest((repo / item["path"]).read_bytes()) != item["after_sha256"]:
            raise ValueError("Post-application checksum mismatch: " + item["path"])
    print("COMMON_DT_PATCH=APPLIED")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print("COMMON_DT_PATCH=FAIL: " + str(exc), file=sys.stderr)
        sys.exit(1)
