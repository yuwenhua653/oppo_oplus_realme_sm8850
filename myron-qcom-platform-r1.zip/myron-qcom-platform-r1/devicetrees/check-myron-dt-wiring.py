#!/usr/bin/env python3
"""Check GNU make target wiring; does not replace cpp/dtc or Bazel compilation."""
import argparse
import ast
import json
from pathlib import Path
import subprocess
import sys


def inspect(dt):
    flags = "\n".join("CONFIG_ARCH_" + arch + " := y" for arch in
                      ("CANOE", "ALOR", "CHORA", "RAVELIN", "BOURTZI"))

    def evaluate(relative):
        source = dt / relative
        makefile = flags + "\nsrc := " + str(source.parent) + "\n"
        makefile += "include " + str(source) + "\n"
        makefile += ".PHONY: report\nreport:\n\t@echo $(dtb-y) $(dtbo-y)\n"
        result = subprocess.run(["make", "--no-print-directory", "-s", "-f", "-", "report"],
                                input=makefile, text=True, capture_output=True, check=True)
        if result.stderr.strip():
            raise ValueError("Kbuild warnings: " + result.stderr.strip())
        return sorted(set(result.stdout.split()))

    top = evaluate("qcom/Makefile")
    outputs = set(top)
    subcounts = {}
    for sub in ("audio", "bt", "camera", "data", "display", "dsp", "eSE", "eva",
                "fingerprint", "graphics", "mm", "mmrm", "nfc", "securemsm",
                "synx", "video", "wlan"):
        names = evaluate("qcom/" + sub + "/Kbuild")
        for name in names:
            source = dt / "qcom" / sub / name
            if not any(source.with_suffix(ext).is_file() for ext in (".dts", ".dtso")):
                raise ValueError("Missing subsystem DT source: " + str(source))
            outputs.add(sub + "/" + name)
        subcounts[sub] = len(names)

    tree = ast.parse((dt / "qcom/platform_map.bzl").read_text())
    platform_map = ast.literal_eval(tree.body[0].value)
    selected = ["canoe"] + platform_map["canoe"].get("binary_compatible_with", [])
    required = []
    for platform in selected:
        for group in ("dtb_list", "dtbo_list"):
            required.extend(item["name"] for item in platform_map[platform].get(group, []))
    for name in required:
        if name not in outputs:
            raise ValueError("Bazel output absent from Kbuild: " + name)
        source = dt / "qcom" / name
        if not any(source.with_suffix(ext).is_file() for ext in (".dts", ".dtso")):
            raise ValueError("Missing declared DT source: " + name)
    expected = ["myron-sm8850-overlay.dtbo", "audio/myron-audio-mtp.dtbo",
                "camera/myron-sm8850-camera-sensor.dtbo",
                "display/display/myron-sde-display-mtp-overlay.dtbo"]
    if not set(expected).issubset(required):
        raise ValueError("A myron component is absent from the Bazel output list")
    build = (dt / "BUILD.bazel").read_text()
    for pattern in ('"qcom/**/Kbuild"', '"qcom/**/*.mk"',
                    'modules_label("qcom/opensource/audio-kernel:dt_binding_headers")',
                    'modules_label("qcom/opensource/camera-kernel:dt_binding_headers")',
                    'modules_label("qcom/opensource/synx-kernel:dt_binding_headers")'):
        if pattern not in build:
            raise ValueError("Missing sandbox input: " + pattern)
    return {"status": "PASS", "scope": "GNU make and source/output wiring only",
            "platforms": selected, "main_targets": len(top), "subsystem_targets": subcounts,
            "declared_outputs_checked": len(required), "myron_components": expected,
            "dtc_compilation": "NOT_RUN", "hardware_validation": "NOT_RUN",
            "oem_dtbo_image_layout": "NOT_DEFINED"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dt_repo", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    dt = args.dt_repo.resolve(strict=True)
    if any(c.isspace() for c in str(dt)):
        raise ValueError("Kernel source paths must not contain whitespace")
    report = inspect(dt)
    text = json.dumps(report, indent=2) + "\n"
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        print("DT_WIRING=FAIL: " + str(exc), file=sys.stderr)
        sys.exit(1)
