#!/usr/bin/env python3
"""Install hash-pinned Xiaomi sources into the pinned experimental SoC checkout.

This only changes source/build metadata; it builds or flashes no device images.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import urllib.request

HERE = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def safe_path(root, rel):
    path = PurePosixPath(rel)
    if path.is_absolute() or not path.parts or any(p in (".", "..") for p in path.parts):
        raise ValueError("unsafe path: " + rel)
    resolved = (root / rel).resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError("path escapes destination: " + rel)
    return resolved

def checked_payload(item, key="sha256", field="payload"):
    data = safe_path(HERE, item[field]).read_bytes()
    if sha(data) != item[key]:
        raise ValueError("bundled payload hash mismatch: " + item[field])
    return data

def source_bytes(lock, entry, cache, offline):
    cached = safe_path(cache, entry["source_path"])
    if cached.exists():
        data = cached.read_bytes()
    else:
        if offline:
            raise ValueError("missing verified source cache: " + str(cached))
        url = "https://raw.githubusercontent.com/{}/{}/{}".format(
            lock["repository"], lock["commit"], entry["source_path"])
        with urllib.request.urlopen(url, timeout=60) as response:
            data = response.read(8 * 1024 * 1024 + 1)
    if len(data) != entry["bytes"] or sha(data) != entry["sha256"] or git_blob(data) != entry["git_blob_sha1"]:
        raise ValueError("pinned source verification failed: " + entry["source_path"])
    if not cached.exists():
        cached.parent.mkdir(parents=True, exist_ok=True)
        cached.write_bytes(data)
    return data

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--soc", required=True, type=Path, help="temporary pinned SoC checkout (not ACK common)")
    parser.add_argument("--cache", type=Path, default=HERE / "download-cache")
    parser.add_argument("--offline", action="store_true", help="require cached source files; hashes are always enforced")
    parser.add_argument("--check", action="store_true", help="validate inputs and print planned changes without writing SoC files")
    parser.add_argument("--report", type=Path, help="optional JSON audit report outside the SoC checkout")
    args = parser.parse_args()
    soc = args.soc.resolve()
    if args.report and args.report.resolve().is_relative_to(soc):
        raise ValueError("audit report must be outside the SoC checkout")
    lock = json.loads((HERE / "source-lock.json").read_text())
    integration = json.loads((HERE / "integration-lock.json").read_text())
    head = subprocess.check_output(["git", "-C", str(soc), "rev-parse", "HEAD"], text=True).strip()
    if head != lock["soc_commit"]:
        raise ValueError("wrong SoC HEAD: " + head)
    # Existing single providers stay intact. The notifier header alone is extended.
    for entry in integration["unchanged_guards"]:
        if sha(safe_path(soc, entry["path"]).read_bytes()) != entry["sha256"]:
            raise ValueError("provider/build interface has changed: " + entry["path"])
    planned = []
    for entry in lock["files"]:
        raw = source_bytes(lock, entry, args.cache.resolve(), args.offline)
        data = checked_payload(entry, "patched_sha256", "patched_payload") if "patched_payload" in entry else raw
        planned.append((entry["path"], entry.get("overwrite_sha256"), data))
    for entry in integration["files"]:
        planned.append((entry["path"], entry["before_sha256"], checked_payload(entry)))
    # Validate all writes first. Exact repeat runs are allowed; arbitrary edits fail.
    report = []
    seen = set()
    for rel, before, data in planned:
        if rel in seen:
            raise ValueError("duplicate integration destination: " + rel)
        seen.add(rel)
        dest = safe_path(soc, rel)
        current = sha(dest.read_bytes()) if dest.exists() else None
        if current not in {before, sha(data)}:
            raise ValueError("local edit / unexpected destination content: " + rel)
        report.append({"path": rel, "before_sha256": current, "after_sha256": sha(data), "changed": current != sha(data)})
    if not args.check:
        for rel, before, data in planned:
            dest = safe_path(soc, rel)
            if not dest.exists() or dest.read_bytes() != data:
                dest.parent.mkdir(parents=True, exist_ok=True)
                tmp = dest.with_name(dest.name + ".myron-tmp")
                if tmp.exists():
                    raise ValueError("unexpected temporary file: " + str(tmp))
                tmp.write_bytes(data)
                tmp.replace(dest)
    result = {
        "schema": 1, "mode": "check" if args.check else "applied", "soc_commit": head,
        "micode_commit": lock["commit"], "profile": "canoe_perf myron experiment",
        "outputs": ["mi_fp.ko", "mi_stack.ko", "mi_ubt.ko", "printk_enhance.ko"],
        "existing_providers": ["boot_stats.ko", "panel_event_notifier.ko"],
        "files": report,
        "warning": "Source integration only. Full new-core build and hardware validation are still required; no r38 KMI compatibility is implied."
    }
    text = json.dumps(result, indent=2) + "\n"
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text)
    print(text, end="")

if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        sys.exit(1)
