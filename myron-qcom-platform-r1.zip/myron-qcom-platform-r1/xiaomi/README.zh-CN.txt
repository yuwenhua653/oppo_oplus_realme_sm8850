Myron 小米模块 DDK 构建桥接（实验源码集成，非刷机包）

目的
  将已有源码验证基线中的 mi_fp、mi_stack、mi_ubt、printk_enhance 接入
  QCOM 的 create_module_registry -> ddk_config -> ddk_module 构建链。
  构建目标仍叫 canoe_perf，以使用现有 techpack 注册与平台配置。
  本脚本不修改 ACK common，不选择 common 版本，不加入 KernelSU/SUSFS，
  不生成/借用任何原厂 Module.symvers，不关闭 modpost 或符号校验。
  common / Kleaf / modules / DT 的配套版本与入口由上层实验工作区固定。

固定来源
  LineageOS/android_kernel_qcom_sm8850:
    557159b6a0d06f1c6f07ec4c1f22bc9309a113e4
  MiCode/Xiaomi_Kernel_OpenSource:
    45705be1220b4cfa8100516ad86711656c0b634e
  10 个 MiCode 文件均检查 commit URL、文件长度、SHA256 和 Git blob SHA1。
  三个小米调试驱动沿用 r2 已成功编译的修补，保留逐文件修补 diff 和修补后 hash。
  mi_fp 的 6 个 C/H 文件保持 MiCode 原文，与此前指纹正常试验的输入一致。
  这只说明源码沿用；新 common 构建不等于此前 r38 的硬件测试结果。

调用（只针对独立实验 checkout）
  python3 integrate_xiaomi.py --soc /path/to/workspace/msm-kernel \
      --cache /path/to/source-cache --check --report /path/to/check.json
  python3 integrate_xiaomi.py --soc /path/to/workspace/msm-kernel \
      --cache /path/to/source-cache --report /path/to/applied.json

  --soc 是实际 QCOM SoC 仓库根路径，不能指向 common。
  --check 检查来源与全部修改计划，并下载缺失源码缓存；不改 SoC 文件。
  --offline 必须已有全部源码缓存；不会跳过任何哈希检查。
  已正确应用的内容可重复运行；未知本地改动会报错，不覆盖。
  源码缓存布局与 MiCode 仓库的 source_path 一致。

实际改动
  新增：
    drivers/input/fingerprint/mi_fp/{fp_driver.c,fp_platform.c,fp_netlink.c,
                                  fp_input.c,fp_driver.h,fp_ultra.h}
    drivers/xiaomi/{mi_stack,mi_ubt,printk_enhance} 各自对应 C 文件
    drivers/xiaomi/myron/{Kconfig,modules.bzl}
  修改：
    modules.bzl: 调用新注册函数。
    Kconfig.msm: source 新 Kconfig。
    configs/canoe_perf.bzl: 四个模块=m，三种其他指纹模式=n。
    include/linux/soc/qcom/panel_event_notifier.h: 小米枚举扩展。
  不修改 configs/canoe_consolidate.bzl；其构建已继承 perf 的配置及模块选择。

DDK 目标（将 <SOC_PACKAGE> 替换成工作区实际 Bazel 包路径）
  //<SOC_PACKAGE>:canoe_perf/drivers/input/fingerprint/mi_fp
  //<SOC_PACKAGE>:canoe_perf/drivers/xiaomi/mi_stack
  //<SOC_PACKAGE>:canoe_perf/drivers/xiaomi/mi_ubt
  //<SOC_PACKAGE>:canoe_perf/drivers/xiaomi/printk_enhance
  全部使用该平台的 canoe_perf_base_kernel、canoe_perf_config。
  mi_fp 通过 deps 依赖真实编译的 drivers/soc/qcom/panel_event_notifier。
  平台 canoe_perf_all_modules 会包含四个新增目标。

共享 panel notifier 接口
  QCOM 已有 boot_stats.ko 与 panel_event_notifier.ko provider，不能再次导入
  旧批次中的同名 C 源码/模块注册。集成器保留 QCOM provider C 原样。
  QCOM 原头只有 4 个 client，缺少 mi_fp 使用的 FINGERPRINT client。
  现将共享头升级为锁定的 MiCode 定义：原 client 0..3 不变，新增
  FINGERPRINT=4、FINGERPRINT_SECOND=5、THERMAL=6、THERMAL_SECOND=7，MAX=8；
  同时追加 HBM_ON/OFF event。provider 的数组长度、范围检查和遍历都以 MAX
  为界，所以必须连 provider 与所有消费者一起从源码重新编译。
  不在 mi_fp 私有 include 中藏另一份头，不保留旧 CRC 来掩盖类型变化。
  QCOM C 源码中现有的 unregister IS_ERR 检查保留。
  头文件提供 HBM 枚举不代表显示驱动已经会触发小米 HBM 通知；显示适配仍须核对。

指纹模式
  CONFIG_SIDE_FINGERPRINT=n
  CONFIG_FOD_FINGERPRINT=n
  CONFIG_FP_HAVE_MULTI_SCREEN=n
  原始 fp_driver.h 仅在 SIDE 和 FOD 均关闭时选 FP_ULTRA_QCOM。
  因而不能仅因为设备是屏下指纹就打开 FOD_FINGERPRINT。这里保持先前成功
  mi_fp 试验的超声路径，并让 QCOM_PANEL_EVENT_NOTIFIER 真实配置为 m。

验证范围和下一关
  已做：源码/hash 检查、固定 checkout 上检查/应用/重复应用、拒绝未知源码改动、
  拒绝损坏缓存、git diff --check、四模块声明/路径/依赖/配置静态检查、单 provider
  与 shared enum 检查。
  尚未声称完成：完整 Bazel 构建、6.12 新 common 导出符号闭合、设备开机测试。
  若 modpost 报 undefined symbol，应处理实际导出/API 或禁用并明确标记相关模块，
  不可拷入原厂 symvers、KBUILD_MODPOST_WARN、--force 或私自改 CRC。
  尚未覆盖：小米触控/MCA 充电/显示/温控/相机等硬件驱动及分区加载顺序。
  因此本桥接和上层构建产物均不能视为可直接刷入的 myron OSS 内核。
