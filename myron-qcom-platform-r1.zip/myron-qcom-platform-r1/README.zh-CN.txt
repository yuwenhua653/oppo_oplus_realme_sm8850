Myron / SM8850 高通平台源码整合 r1

目标
把 ACK common、高通 SoC/DDK、外置驱动、小米设备树和已有小米模块修补，放进
同一套 Kleaf/Bazel 构建中。继续使用高通 canoe_perf 平台目标，额外提供
myron_platform_lab 诊断目标，避免把未经适配的高通参考板镜像当成手机刷机包。

版本变化必须知道
本包使用 LineageOS kernel-6.12 manifest 对应的一整套 AOSP 快照：
  Linux 6.12.81 / Android16 / KMI generation 6 / 4 KiB
  common: 41a2024a9e2eb66ab0643a865d74943b4ee3cff8
  Kleaf:  e114b907efb6c8ef513617cc13fdc0f87c46abde
  QCOM:   557159b6a0d06f1c6f07ec4c1f22bc9309a113e4
  modules:f2ecb6a09ea56bd8ec9a0bfd2e97f45e200ab322
  Xiaomi DT:8b86fedda64183338411f9751f5e62ce25997620

这与手机当前能启动的 6.12.38 / KMI generation 5 不同。当前内核和上一轮
vendor_dlkm 测试包继续保留。此包不包含刷机命令，也不生成 AK3、boot、
vendor_boot 或 dlkm 分区镜像。第一次 full 成功只表示这一批源码构建通过。
本轮重点是平台整合，KernelSU/SUSFS 尚未接入这个新构建配置。

已整合
1. sources.lock.json 固定 53 个 Git 仓库。50 个 AOSP 项目逐个匹配官方
   superproject d05e39f9704db1afe7863425c5d541e52bdf9fe3 的 gitlink。
   其余 3 个项目是高通 SoC、modules 和 lolipuru 小米设备树。
2. 正确的 Bzlmod 工作区及 tools/bazel、MODULE.bazel、WORKSPACE.bzlmod 链接。
3. 小米 DT 头文件依赖、各技术包 Kbuild 输入、已声明的小米板级目标、
   myron audio/camera/display 输出、相机递归构建，以及 dtbs-list 收集。
4. ACK 的 .dts -> .dtbo 兼容编译规则，保留原来的 .dtso 规则。
5. mi_fp、mi_stack、mi_ubt、printk_enhance 四个真实 DDK 模块。
   小米源文件固定到 MiCode 45705be1220b4cfa8100516ad86711656c0b634e；
   三个调试模块带上一轮 r2 修补。源码下载验证 SHA256、Git blob ID 和长度。
6. boot_stats、panel_event_notifier 使用高通现有实现，避免重复 provider。
   共享屏幕通知头补齐小米指纹需要的 client/HBM 枚举；消费者统一重编。

GitHub Actions 使用方法
1. 将 ZIP 解压到你的构建仓库根目录。应得到：
     .github/workflows/build-myron-qcom-platform.yml
     myron-qcom-platform-r1/  （本说明、脚本、锁文件和补丁）
   保留原来的 r38 workflow；两个流程互不覆盖。
2. 提交这两个路径到 GitHub。无需 fork 每一个上游源码仓库。
3. Actions -> Myron QCOM platform source build -> Run workflow。
   stage 选择 full，jobs 先选 2。
4. 成功后下载：
     myron-qcom-reports-<run_id>
     myron-qcom-source-build-full-<run_id>
   若失败，先发 reports 包和第一个实际错误；日志在失败时也会上传。

stage 的含义
  analyze  只进行完整目标的 Bazel 依赖分析，不执行内核编译。
  soc      编译 common 核心和高通 SoC 模块，包含新增的四个小米模块。
  dtbs     编译 DTB/DTBO 构建目标及其所需的基础内核。
  full     编译以上内容并加入高通 techpack 外置驱动。
默认 full；只有需要定位失败位置时才拆成 soc/dtbs。

Actions 默认使用 Ubuntu 24.04、2 个编译任务。任务会清理该一次性 hosted
runner 上预装但不使用的 Android/.NET/GHC SDK，不会触碰你的手机或本地电脑。
源代码和工具链体积较大，首次同步需要时间。工作流最长运行 6 小时。

本地 Linux 使用方法
建议 Ubuntu 22.04/24.04、Python >=3.10、至少 16 GiB 内存；给源码与输出预留
约 70 GiB 空闲磁盘。这里只是容量建议，实际取决于阶段和编译并发。

  sudo apt-get update
  sudo apt-get install -y git python3 build-essential bc bison flex libssl-dev libelf-dev libncurses-dev zstd lz4 rsync zip unzip cpio pkg-config

从含 myron-qcom-platform-r1 目录的位置运行：
  python3 myron-qcom-platform-r1/sync_sources.py --workspace "$PWD/myron-platform-work" --jobs 4
  python3 myron-qcom-platform-r1/build_platform.py --workspace "$PWD/myron-platform-work" --stage full --jobs 2 --ram-mb 10000

后续重试可直接执行第二条。换来源锁时用新的工作目录。脚本不会 reset 或清理
已有源码修改；发生 hash/HEAD 不符会停止，并指出需要检查的文件。

主要输出
  myron-platform-work/integration-reports/
    源码锁核验、应用补丁日志、完整差异、Bazel 日志和 stage-status.json。
  myron-platform-work/integration-artifacts/<stage>/
    Image、模块、DTB/DTBO、配置、符号表及 artifact-manifest.json。
    保留构建输出路径，不把同名的 core/vendor 模块混在一个目录里。

后续上机前仍需完成的适配
* 共享头包含 HBM 事件枚举，不代表高通显示驱动已经实现小米 HBM/FOD 通知。
* 高通通用 FocalTech 模块不能直接认定等价于 myron 的 focaltech_touch_3683。
* 小米 MCA 充电实现仍有源码缺口；DTS 节点存在不等于驱动齐全。
* 音频 overlay 的独立叠加验证仍缺 11 个外部符号。精确测试顺序、缺失名称
  及源码位置见 devicetrees/DT-INTEGRATION.zh-CN.txt 和关联 JSON 报告。
* 必须继续核对原厂实际模块集合、加载顺序、固件/HAL 接口和 DTBO 的 OEM
  合包/选择规则。此包没有为未知板级引脚或缺失源码添加替代实现。
* 仍保留的原厂二进制模块与这个 generation 6 内核的兼容性尚未建立。

验证记录
已实际同步并核验 53 个仓库，应用补丁，启动锁定工具链的 Bazel 8.0.0，
完成 myron_platform_lab 的 --nobuild 检查：93 packages loaded、
122786 targets configured，退出码 0。此检查分析构建图，不执行编译动作。
另有 10 项实际 cpp/dtc 编译探针通过；音频 overlay 的 11 个缺失外部符号
仍是已知适配缺口，不能由“DT 能编译”推出“能完整叠加或上机”。

本次环境剩余磁盘不足以完成完整内核构建，尚未运行 full 编译及实机测试。
源码核验、补丁门禁、Bazel 分析和 runner 检查记录保存在 validation/ 与
devicetrees/。完整平台编译是否成功，请以你本次 Actions 的 full-status.json
和编译日志为准。Bazel 原始 DEBUG 信息保留在日志文件中，控制台省略回显。

来源
https://github.com/LineageOS/android/blob/2a50ca061bffe4e73918ae2e0b99b7a05f647154/snippets/kernel-6.12.xml
https://android.googlesource.com/kernel/superproject/+/d05e39f9704db1afe7863425c5d541e52bdf9fe3
https://github.com/LineageOS/android_kernel_qcom_sm8850
https://github.com/LineageOS/android_kernel_qcom_sm8850-modules
https://github.com/lolipuru/android_kernel_xiaomi_sm8850-devicetrees/tree/lineage-24.0-staging
https://github.com/MiCode/Xiaomi_Kernel_OpenSource/tree/45705be1220b4cfa8100516ad86711656c0b634e

版权
第三方源文件与补丁保留各自版权和许可证声明；许可证文本位于 licenses/。
