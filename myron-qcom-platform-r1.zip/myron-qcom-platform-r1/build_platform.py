#!/usr/bin/env python3
"""Run a staged Bazel source build and retain audit logs on success or failure."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
TARGETS = {
    "analyze": "//vendor/qcom/sm8850:myron_platform_lab",
    "soc": "//vendor/qcom/sm8850:myron_soc_lab",
    "dtbs": "//vendor/qcom/sm8850:canoe_perf_dtb_build",
    "full": "//vendor/qcom/sm8850:myron_platform_lab",
}


def logged(command, cwd, logpath, echo=True):
    with logpath.open("w") as log:
        log.write("$ " + " ".join(map(str, command)) + "\n")
        log.flush()
        env = {**os.environ, "CCACHE_NODEBUG": "true"}
        env.pop("CCACHE_DEBUG", None)
        proc = subprocess.Popen(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1, env=env)
        for line in proc.stdout:
            log.write(line)
            log.flush()
            # Upstream WLAN macros print thousands of DEBUG lines during loading.
            # Keep the complete log for diagnosis without flooding Actions output.
            if echo and not line.startswith("DEBUG:"):
                print(line, end="", flush=True)
        status = proc.wait()
    if status:
        raise RuntimeError(f"Command failed ({status}); see {logpath}")


def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def collect(root, paths, stage):
    dest = root / "integration-artifacts" / stage
    dest.mkdir(parents=True, exist_ok=True)
    items = []
    for name in paths:
        source = root / name
        if not source.is_file():
            continue
        if not (source.suffix in (".ko", ".dtb", ".dtbo", ".symvers") or
                source.name in ("Image", "Image.gz", "Image.lz4", ".config", "System.map", "kernel.release")):
            continue
        rel = Path(name)
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unexpected Bazel output path: " + name)
        target = dest / "objects" / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        items.append({"file": str(target.relative_to(dest)), "source": name,
                      "bytes": target.stat().st_size, "sha256": sha(target)})
    names = {Path(x["file"]).name for x in items}
    required = {"Image", "Module.symvers"}
    if stage in ("soc", "full"):
        required |= {"mi_fp.ko", "mi_stack.ko", "mi_ubt.ko", "printk_enhance.ko", "panel_event_notifier.ko", "boot_stats.ko"}
    if stage in ("dtbs", "full"):
        required |= {"myron-sm8850-overlay.dtbo", "myron-audio-mtp.dtbo", "myron-sm8850-camera-sensor.dtbo", "myron-sde-display-mtp-overlay.dtbo"}
    missing = sorted(required - names)
    manifest = {"stage": stage, "files": items, "missing_required_outputs": missing,
                "flashable": False, "kernel": "6.12.81-android16 / KMI generation 6",
                "note": "Source-build diagnostics. No OEM partition image or AK3 is produced."}
    (dest / "artifact-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (dest / "NOT-A-FLASH-PACKAGE.txt").write_text("开发构建产物，尚未完成 myron 驱动覆盖、分区装配或实机验证。不能套用之前 r38 测试包的刷入步骤。\n")
    if missing:
        raise RuntimeError("Build finished but required outputs are missing: " + ", ".join(missing))
    return len(items)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--stage", choices=TARGETS, default="full")
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--ram-mb", type=int, default=6000)
    args = parser.parse_args()
    if args.jobs < 1 or args.ram_mb < 2048:
        parser.error("Use at least one job and 2048 MiB RAM")
    root = args.workspace.resolve()
    reports = root / "integration-reports"
    reports.mkdir(parents=True, exist_ok=True)
    status = {"stage": args.stage, "target": TARGETS[args.stage], "success": False,
              "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "hardware_tested": False}
    try:
        logged([sys.executable, str(HERE / "prepare_workspace.py"), "--workspace", str(root)], root, reports / "prepare.log")
        bazel = [str(root / "tools/bazel"), "--batch", "--host_jvm_args=-Xmx2g",
                 "--output_base=" + str(root / "out/bazel-integration")]
        options = ["--cpu=aarch64", f"--jobs={args.jobs}", f"--local_ram_resources={args.ram_mb}", "--color=no", "--curses=no", "--noshow_progress"]
        # Only traverse this diagnostic graph. No ABL, boot/vendor_boot or dlkm image targets.
        command = bazel + ["build"] + options
        if args.stage == "analyze":
            command += ["--nobuild"]
        command += [TARGETS[args.stage]]
        logged(command, root, reports / (args.stage + ".log"))
        status["analysis_passed"] = True
        if args.stage != "analyze":
            output = subprocess.run(bazel + ["cquery", "--cpu=aarch64", "--output=files", "--color=no", "--curses=no", TARGETS[args.stage]],
                                    cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            (reports / (args.stage + "-outputs.txt")).write_text(output.stdout)
            (reports / (args.stage + "-cquery.log")).write_text(output.stderr)
            if output.returncode:
                raise RuntimeError("Cannot enumerate built outputs; see cquery log")
            status["artifact_count"] = collect(root, output.stdout.splitlines(), args.stage)
            status["compiled"] = True
        else:
            status["compiled"] = False
        status["success"] = True
    except Exception as error:
        status["error"] = str(error)
        print("ERROR: " + str(error), file=sys.stderr)
    finally:
        status["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        (reports / (args.stage + "-status.json")).write_text(json.dumps(status, indent=2) + "\n")
    return 0 if status["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
