#!/usr/bin/env python3
"""Apply only the reviewed integration changes to the pinned build workspace."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(command, logfile):
    with logfile.open("w") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args()
    root = args.workspace.resolve()
    lock = json.loads((HERE / "sources.lock.json").read_text())
    state = json.loads((root / ".myron-platform.json").read_text())
    if state["lock_sha256"] != digest(HERE / "sources.lock.json"):
        raise ValueError("Workspace belongs to a different source lock")
    # Read each actual Git HEAD. A previous successful sync report alone is insufficient.
    for project in lock["projects"]:
        path = root / project["path"]
        head = subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()
        if head != project["commit"]:
            raise ValueError("Unexpected source revision: " + project["path"])
    reports = root / "integration-reports"
    reports.mkdir(exist_ok=True)
    soc = root / "vendor/qcom/sm8850"
    dt = root / "vendor/qcom/sm8850-devicetrees"
    invoke([sys.executable, str(HERE / "devicetrees/apply-ack-dtbo-dts-patch.py"), str(root / "common")], reports / "apply-common-dtbo.log")
    invoke([sys.executable, str(HERE / "devicetrees/apply-myron-dt-patch.py"), str(dt)], reports / "apply-dt.log")
    invoke([sys.executable, str(HERE / "devicetrees/check-myron-dt-wiring.py"), str(dt), "--report", str(reports / "dt-wiring.json")], reports / "dt-wiring.log")
    invoke([sys.executable, str(HERE / "xiaomi/integrate_xiaomi.py"), "--soc", str(soc),
            "--cache", str(root / "integration-cache/xiaomi"), "--report", str(reports / "xiaomi-integration.json")], reports / "apply-xiaomi.log")
    patch = json.loads((HERE / "platform-patch.json").read_text())
    changes = []
    for entry in patch["files"]:
        target = soc / entry["path"]
        payload = HERE / entry["payload"]
        if digest(payload) != entry["after_sha256"]:
            raise ValueError("Bundled platform payload checksum mismatch")
        current = digest(target)
        if current not in (entry["before_sha256"], entry["after_sha256"]):
            raise ValueError("Unexpected local edit: " + entry["path"])
        changes.append((entry, target, payload))
    for entry, target, payload in changes:
        if digest(target) != entry["after_sha256"]:
            target.write_bytes(payload.read_bytes())
    for name, repo in [("common", root / "common"), ("soc", soc), ("devicetrees", dt)]:
        invoke(["git", "-C", str(repo), "diff", "--check"], reports / (name + "-diff-check.log"))
        invoke(["git", "-C", str(repo), "diff", "--binary"], reports / (name + "-integration.diff"))
    (reports / "profile.json").write_text(json.dumps({
        "profile": lock["profile"], "kernel": lock["kernel"],
        "lock_sha256": digest(HERE / "sources.lock.json"),
        "target": "//vendor/qcom/sm8850:myron_platform_lab",
        "hardware_tested": False, "flashable": False,
        "existing_r38_test_package_is_separate": True,
        "known_gaps": ["Xiaomi display HBM/FOD event producer", "myron-specific touchscreen", "MCA charging drivers", "OEM DTBO packing and module-load integration"]
    }, indent=2) + "\n")
    print("Integration applied and checked. Profile: 6.12.81 / KMI generation 6 / 4 KiB.")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
